package com.example;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class NotificationReceiver extends BroadcastReceiver {

    private static final long MAX_LATE_RECORD_MS = 8L * 3600000L;

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null) return;
        int id = intent.getIntExtra(NotificationHelper.EXTRA_ID, 0);
        String kind = intent.getStringExtra(NotificationHelper.EXTRA_KIND);
        String title = intent.getStringExtra(NotificationHelper.EXTRA_TITLE);
        String text = intent.getStringExtra(NotificationHelper.EXTRA_TEXT);
        String tab = intent.getStringExtra(NotificationHelper.EXTRA_TAB);
        String ach = intent.getStringExtra(NotificationHelper.EXTRA_ACH);

        if (NotificationHelper.ACTION_SNOOZE.equals(intent.getAction())) {
            NotificationHelper.cancelShown(context, id);
            NotificationHelper.snooze(context, id, kind, title, text, tab, ach);
            return;
        }

        long ts = intent.getLongExtra(NotificationHelper.EXTRA_TS, 0L);
        NotificationHelper.removeSavedAlarm(context, id);

        // Un recordatorio diario que llega muy tarde (teléfono apagado) ya no tiene sentido.
        if (NotificationHelper.KIND_RECORD.equals(kind) && ts > 0L
                && System.currentTimeMillis() - ts > MAX_LATE_RECORD_MS) {
            return;
        }
        NotificationHelper.showNotification(context, id, kind, title, text, tab, ach, 0L);
    }
}
