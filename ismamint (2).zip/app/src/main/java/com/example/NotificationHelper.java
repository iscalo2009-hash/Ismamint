package com.example;

import android.Manifest;
import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.Icon;
import android.media.AudioAttributes;
import android.os.Build;
import android.provider.Settings;
import android.widget.RemoteViews;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Iterator;
import java.util.Locale;

/**
 * Sistema de notificaciones de ISMAMINT.
 *
 * Tres canales (heads-up, sonido, vibración, pantalla de bloqueo):
 *  - logros:        se consiguió un logro (a su hora real).
 *  - recordatorio:  aviso diario a las 4:44 pm (hora de Colombia).
 *  - importantes:   "falta poco" para un logro importante, también a las 4:44 pm.
 *
 * El aspecto "pixel" imita la app: fondo oscuro, borde del color de acento del tema,
 * tipografías Press Start 2P / VT323 y corazón pixelado. Los colores se sincronizan
 * desde la página (tema actual) con setStyle().
 */
public final class NotificationHelper {

    public static final String CHANNEL_LOGROS = "ismamint_logros";
    public static final String CHANNEL_RECORD = "ismamint_recordatorio";
    public static final String CHANNEL_IMPORT = "ismamint_importantes";
    private static final String LEGACY_CHANNEL = "ismamint_channel";

    public static final String KIND_LOGRO = "logro";
    public static final String KIND_RECORD = "recordatorio";
    public static final String KIND_IMPORT = "importante";

    public static final String ACTION_ALARM_NOTIFY = "com.example.ACTION_ALARM_NOTIFY";
    public static final String ACTION_SNOOZE = "com.example.ACTION_SNOOZE";
    public static final String ACTION_OPEN = "com.example.ACTION_OPEN_FROM_NOTIFICATION";

    public static final String EXTRA_ID = "notif_id";
    public static final String EXTRA_TITLE = "notif_title";
    public static final String EXTRA_TEXT = "notif_text";
    public static final String EXTRA_KIND = "notif_kind";
    public static final String EXTRA_TAB = "notif_tab";
    public static final String EXTRA_ACH = "notif_ach";
    public static final String EXTRA_TS = "notif_ts";
    public static final String EXTRA_OPEN_ACH = "open_ach";

    private static final String PREFS_NAME = "ismamint_alarms_prefs";
    private static final String KEY_ALARMS = "scheduled_alarms";
    private static final String KEY_STYLE = "notif_style";

    private static final long SNOOZE_MS = 60L * 60L * 1000L;
    private static final long HOUR_MS = 3600000L;
    private static final Locale LOC = new Locale("es", "CO");

    private static final String[] HEART = {
            "01100110", "11111111", "11111111", "11111111", "01111110", "00111100", "00011000"
    };

    private NotificationHelper() {}

    // ------------------------------------------------------------------ canales

    public static void ensureChannel(Context context) {
        ensureChannels(context);
    }

    public static void ensureChannels(Context context) {
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        try {
            nm.deleteNotificationChannel(LEGACY_CHANNEL);
        } catch (Exception ignored) {
        }
        createChannel(nm, CHANNEL_LOGROS,
                context.getString(R.string.channel_logros_name),
                context.getString(R.string.channel_logros_desc),
                new long[]{0L, 70L, 60L, 70L, 60L, 160L});
        createChannel(nm, CHANNEL_RECORD,
                context.getString(R.string.channel_record_name),
                context.getString(R.string.channel_record_desc),
                new long[]{0L, 70L, 90L, 70L});
        createChannel(nm, CHANNEL_IMPORT,
                context.getString(R.string.channel_import_name),
                context.getString(R.string.channel_import_desc),
                new long[]{0L, 100L, 60L, 100L, 60L, 220L});
    }

    private static void createChannel(NotificationManager nm, String id, String name, String desc, long[] vibration) {
        if (nm.getNotificationChannel(id) != null) return;
        NotificationChannel ch = new NotificationChannel(id, name, NotificationManager.IMPORTANCE_HIGH);
        ch.setDescription(desc);
        ch.enableVibration(true);
        ch.setVibrationPattern(vibration);
        ch.enableLights(true);
        ch.setLightColor(0xFFFF4D4D);
        ch.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        ch.setShowBadge(true);
        AudioAttributes attrs = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build();
        ch.setSound(Settings.System.DEFAULT_NOTIFICATION_URI, attrs);
        nm.createNotificationChannel(ch);
    }

    private static String normKind(String kind) {
        if (KIND_LOGRO.equals(kind)) return KIND_LOGRO;
        if (KIND_IMPORT.equals(kind)) return KIND_IMPORT;
        return KIND_RECORD;
    }

    private static String channelFor(String kind) {
        if (KIND_LOGRO.equals(kind)) return CHANNEL_LOGROS;
        if (KIND_IMPORT.equals(kind)) return CHANNEL_IMPORT;
        return CHANNEL_RECORD;
    }

    private static String tagFor(String kind) {
        if (KIND_LOGRO.equals(kind)) return "LOGRO";
        if (KIND_IMPORT.equals(kind)) return "AVISO";
        return "DIARIO";
    }

    public static boolean hasNotificationPermission(Context context) {
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
                return false;
            }
        }
        return nm == null || nm.areNotificationsEnabled();
    }

    // ------------------------------------------------------------------ estilo

    private static final class Style {
        boolean pixel = true;
        int accent = 0xFFFF4D4D;
        int soft = 0xFFFF9999;
        int text = 0xFFFFD6D6;
        int bg = 0xFF120000;
    }

    private static int parseColor(String s, int def) {
        try {
            return Color.parseColor(s.trim());
        } catch (Exception e) {
            return def;
        }
    }

    private static double luminance(int c) {
        return (0.299 * Color.red(c) + 0.587 * Color.green(c) + 0.114 * Color.blue(c)) / 255.0;
    }

    private static Style loadStyle(Context context) {
        Style st = new Style();
        String raw = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).getString(KEY_STYLE, null);
        if (raw == null || raw.isEmpty()) return st;
        try {
            JSONObject o = new JSONObject(raw);
            st.pixel = !"classic".equals(o.optString("mode", "pixel"));
            st.accent = parseColor(o.optString("accent", ""), st.accent);
            st.soft = parseColor(o.optString("soft", ""), st.soft);
            st.text = parseColor(o.optString("text", ""), st.text);
            st.bg = parseColor(o.optString("bg", ""), st.bg);
        } catch (Exception ignored) {
        }
        // Siempre fondo oscuro y texto claro para que se lea bien.
        if (luminance(st.bg) > 0.35) st.bg = 0xFF120000;
        if (luminance(st.text) < 0.5) st.text = 0xFFFFD6D6;
        if (luminance(st.soft) < 0.4) st.soft = st.text;
        if (luminance(st.accent) < 0.3) st.accent = st.soft;
        return st;
    }

    public static void setStyle(Context context, String json) {
        if (json == null || json.trim().isEmpty()) return;
        try {
            new JSONObject(json); // validar
        } catch (Exception e) {
            return;
        }
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .putString(KEY_STYLE, json)
                .apply();
    }

    private static Bitmap heart(int color, int bg, int size) {
        Bitmap bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bmp);
        if (bg != 0) canvas.drawColor(bg);
        Paint paint = new Paint();
        paint.setColor(color);
        paint.setAntiAlias(false);
        int px = Math.max(1, size / 10);
        int ox = (size - 8 * px) / 2;
        int oy = (size - 7 * px) / 2;
        for (int row = 0; row < HEART.length; row++) {
            for (int col = 0; col < 8; col++) {
                if (HEART[row].charAt(col) == '1') {
                    canvas.drawRect(ox + col * px, oy + row * px,
                            ox + (col + 1) * px, oy + (row + 1) * px, paint);
                }
            }
        }
        return bmp;
    }

    private static RemoteViews buildViews(Context context, int layout, Style st, String kind,
                                          String title, String text, Bitmap heart) {
        RemoteViews rv = new RemoteViews(context.getPackageName(), layout);
        rv.setInt(R.id.notif_root, "setBackgroundColor", st.accent);
        rv.setInt(R.id.notif_inner, "setBackgroundColor", st.bg);
        rv.setImageViewBitmap(R.id.notif_heart, heart);
        rv.setTextViewText(R.id.notif_title, title.toUpperCase(LOC));
        rv.setTextColor(R.id.notif_title, st.accent);
        rv.setTextViewText(R.id.notif_tag, tagFor(kind));
        rv.setTextColor(R.id.notif_tag, st.soft);
        rv.setTextViewText(R.id.notif_text, text);
        rv.setTextColor(R.id.notif_text, st.text);
        return rv;
    }

    // ------------------------------------------------------------------ mostrar

    /** Compatibilidad con el puente antiguo. */
    public static void showNotification(Context context, int id, String titulo, String texto) {
        showNotification(context, id, KIND_RECORD, titulo, texto, "p1", "", 0L);
    }

    public static void showNotification(Context context, int id, String kind, String titulo, String texto,
                                        String tab, String ach, long when) {
        if (!hasNotificationPermission(context)) {
            return;
        }
        ensureChannels(context);
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;

        String k = normKind(kind);
        Style st = loadStyle(context);
        String safeTitle = (titulo == null || titulo.isEmpty()) ? context.getString(R.string.app_name) : titulo;
        String safeText = (texto == null) ? "" : texto;
        String safeTab = (tab == null || tab.isEmpty()) ? "p1" : tab;
        String safeAch = (ach == null) ? "" : ach;

        PendingIntent open = openIntent(context, id, safeTab, safeAch);
        PendingIntent snooze = snoozeIntent(context, id, k, safeTitle, safeText, safeTab, safeAch);

        Notification.Builder b = new Notification.Builder(context, channelFor(k));
        b.setSmallIcon(R.drawable.ic_notification)
                .setColor(st.accent)
                .setContentTitle(safeTitle)
                .setContentText(safeText)
                .setContentIntent(open)
                .setAutoCancel(true)
                .setCategory(KIND_LOGRO.equals(k) ? Notification.CATEGORY_EVENT : Notification.CATEGORY_REMINDER)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setShowWhen(true)
                .setWhen(when > 0 ? when : System.currentTimeMillis());

        boolean custom = false;
        if (st.pixel) {
            try {
                Bitmap h = heart(st.accent, 0, 40);
                RemoteViews small = buildViews(context, R.layout.notif_collapsed, st, k, safeTitle, safeText, h);
                RemoteViews big = buildViews(context, R.layout.notif_expanded, st, k, safeTitle, safeText, h);
                b.setStyle(new Notification.DecoratedCustomViewStyle())
                        .setCustomContentView(small)
                        .setCustomBigContentView(big);
                custom = true;
            } catch (Exception ignored) {
                custom = false;
            }
        }
        if (!custom) {
            b.setStyle(new Notification.BigTextStyle().bigText(safeText).setBigContentTitle(safeTitle));
            b.setLargeIcon(heart(st.accent, st.bg, 96));
        }

        Icon icon = Icon.createWithResource(context, R.drawable.ic_notification);
        b.addAction(new Notification.Action.Builder(
                icon, KIND_LOGRO.equals(k) ? "VER LOGRO" : "ABRIR", open).build());
        b.addAction(new Notification.Action.Builder(icon, "MÁS TARDE (1 H)", snooze).build());

        try {
            nm.notify(id, b.build());
        } catch (SecurityException ignored) {
        }
    }

    public static void cancelShown(Context context, int id) {
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.cancel(id);
    }

    private static PendingIntent openIntent(Context context, int id, String tab, String ach) {
        Intent intent = new Intent(context, MainActivity.class);
        intent.setAction(ACTION_OPEN);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                | Intent.FLAG_ACTIVITY_CLEAR_TOP
                | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        intent.putExtra(WidgetDataHelper.EXTRA_OPEN_TAB, tab);
        if (ach != null && !ach.isEmpty()) {
            intent.putExtra(EXTRA_OPEN_ACH, ach);
        }
        return PendingIntent.getActivity(context, id, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private static PendingIntent snoozeIntent(Context context, int id, String kind, String title,
                                              String text, String tab, String ach) {
        Intent intent = new Intent(context, NotificationReceiver.class);
        intent.setAction(ACTION_SNOOZE);
        intent.putExtra(EXTRA_ID, id);
        intent.putExtra(EXTRA_KIND, kind);
        intent.putExtra(EXTRA_TITLE, title);
        intent.putExtra(EXTRA_TEXT, text);
        intent.putExtra(EXTRA_TAB, tab);
        intent.putExtra(EXTRA_ACH, ach);
        return PendingIntent.getBroadcast(context, id, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    // ------------------------------------------------------------------ programar

    /** Compatibilidad con el puente antiguo. */
    public static void scheduleNotification(Context context, int id, String titulo, String texto, long timestampMillis) {
        scheduleOne(context, id, KIND_RECORD, titulo, texto, "p1", "", timestampMillis);
    }

    public static void scheduleOne(Context context, int id, String kind, String titulo, String texto,
                                   String tab, String ach, long ts) {
        if (ts <= System.currentTimeMillis()) {
            return;
        }
        ensureChannels(context);
        String k = normKind(kind);
        JSONObject map = loadAlarmsMap(context);
        putAlarm(map, id, k, titulo, texto, tab, ach, ts);
        saveAlarmsMap(context, map);
        scheduleAlarmInternal(context, id, k, titulo, texto, tab, ach, ts);
    }

    /**
     * Reemplaza TODOS los avisos programados por los de la lista.
     * json = { "style": {...}, "items": [ {id, kind, title, text, ts, tab, ach}, ... ] }
     */
    public static int scheduleBatch(Context context, String json) {
        ensureChannels(context);
        JSONObject root;
        try {
            root = new JSONObject(json);
        } catch (Exception e) {
            return 0;
        }
        JSONObject style = root.optJSONObject("style");
        if (style != null) {
            setStyle(context, style.toString());
        }
        cancelAll(context);
        JSONArray items = root.optJSONArray("items");
        if (items == null) return 0;

        long now = System.currentTimeMillis();
        JSONObject map = new JSONObject();
        int count = 0;
        for (int i = 0; i < items.length(); i++) {
            JSONObject it = items.optJSONObject(i);
            if (it == null) continue;
            int id = it.optInt("id", 0);
            long ts = it.optLong("ts", 0L);
            if (id == 0 || ts <= now + 1000L) continue;
            String k = normKind(it.optString("kind", KIND_RECORD));
            String title = it.optString("title", "");
            String text = it.optString("text", "");
            String tab = it.optString("tab", "p1");
            String ach = it.optString("ach", "");
            putAlarm(map, id, k, title, text, tab, ach, ts);
            scheduleAlarmInternal(context, id, k, title, text, tab, ach, ts);
            count++;
        }
        saveAlarmsMap(context, map);
        return count;
    }

    /** Pospone un aviso 1 hora (evitando la madrugada). */
    public static void snooze(Context context, int id, String kind, String title, String text,
                              String tab, String ach) {
        long ts = quietAdjust(System.currentTimeMillis() + SNOOZE_MS);
        scheduleOne(context, id, kind, title, text, tab, ach, ts);
    }

    private static long quietAdjust(long ts) {
        long tz = WidgetDataHelper.TZ_OFFSET_MS;
        long day = WidgetDataHelper.DAY_MS;
        long local = ts - tz;
        long dayStart = Math.floorDiv(local, day) * day;
        long hour = (local - dayStart) / HOUR_MS;
        if (hour < 8L) return dayStart + 9L * HOUR_MS + tz;
        if (hour >= 22L) return dayStart + day + 9L * HOUR_MS + tz;
        return ts;
    }

    private static void scheduleAlarmInternal(Context context, int id, String kind, String titulo, String texto,
                                              String tab, String ach, long timestampMillis) {
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarmManager == null) return;

        PendingIntent pi = buildAlarmPendingIntent(context, id, kind, titulo, texto, tab, ach, timestampMillis,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        if (pi == null) return;

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !alarmManager.canScheduleExactAlarms()) {
                alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, timestampMillis, pi);
            } else {
                alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, timestampMillis, pi);
            }
        } catch (SecurityException e) {
            try {
                alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, timestampMillis, pi);
            } catch (Exception ignored) {
            }
        } catch (IllegalStateException ignored) {
            // Límite de alarmas del sistema alcanzado: se omite este aviso.
        }
    }

    public static void cancelAll(Context context) {
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        JSONObject map = loadAlarmsMap(context);
        Iterator<String> keys = map.keys();
        while (keys.hasNext()) {
            String key = keys.next();
            try {
                int id = Integer.parseInt(key);
                if (alarmManager != null) {
                    PendingIntent pi = buildAlarmPendingIntent(context, id, KIND_RECORD, "", "", "", "", 0L,
                            PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
                    if (pi != null) {
                        alarmManager.cancel(pi);
                        pi.cancel();
                    }
                }
            } catch (NumberFormatException ignored) {
            }
        }
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .remove(KEY_ALARMS)
                .apply();
    }

    public static void rescheduleAll(Context context) {
        ensureChannels(context);
        long now = System.currentTimeMillis();
        JSONObject map = loadAlarmsMap(context);
        JSONObject updated = new JSONObject();
        Iterator<String> keys = map.keys();
        while (keys.hasNext()) {
            String key = keys.next();
            JSONObject item = map.optJSONObject(key);
            if (item == null) continue;
            int id = item.optInt("id", 0);
            String kind = item.optString("kind", KIND_RECORD);
            String title = item.optString("title", "");
            String text = item.optString("text", "");
            String tab = item.optString("tab", "p1");
            String ach = item.optString("ach", "");
            long ts = item.optLong("ts", 0L);
            if (ts > now) {
                scheduleAlarmInternal(context, id, kind, title, text, tab, ach, ts);
                try {
                    updated.put(key, item);
                } catch (Exception ignored) {
                }
            } else if (now - ts < 12L * HOUR_MS && !KIND_RECORD.equals(kind)) {
                // Se apagó el teléfono justo en su hora: los logros y avisos importantes se entregan igual.
                showNotification(context, id, kind, title, text, tab, ach, 0L);
            }
        }
        saveAlarmsMap(context, updated);
    }

    public static void removeSavedAlarm(Context context, int id) {
        JSONObject map = loadAlarmsMap(context);
        map.remove(String.valueOf(id));
        saveAlarmsMap(context, map);
    }

    private static PendingIntent buildAlarmPendingIntent(Context context, int id, String kind, String titulo,
                                                         String texto, String tab, String ach, long ts, int flags) {
        Intent intent = new Intent(context, NotificationReceiver.class);
        intent.setAction(ACTION_ALARM_NOTIFY);
        intent.putExtra(EXTRA_ID, id);
        intent.putExtra(EXTRA_KIND, kind != null ? kind : KIND_RECORD);
        intent.putExtra(EXTRA_TITLE, titulo != null ? titulo : "");
        intent.putExtra(EXTRA_TEXT, texto != null ? texto : "");
        intent.putExtra(EXTRA_TAB, tab != null ? tab : "");
        intent.putExtra(EXTRA_ACH, ach != null ? ach : "");
        intent.putExtra(EXTRA_TS, ts);
        return PendingIntent.getBroadcast(context, id, intent, flags);
    }

    private static void putAlarm(JSONObject map, int id, String kind, String titulo, String texto,
                                 String tab, String ach, long ts) {
        try {
            JSONObject obj = new JSONObject();
            obj.put("id", id);
            obj.put("kind", kind != null ? kind : KIND_RECORD);
            obj.put("title", titulo != null ? titulo : "");
            obj.put("text", texto != null ? texto : "");
            obj.put("tab", tab != null ? tab : "");
            obj.put("ach", ach != null ? ach : "");
            obj.put("ts", ts);
            map.put(String.valueOf(id), obj);
        } catch (Exception ignored) {
        }
    }

    private static JSONObject loadAlarmsMap(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        String raw = prefs.getString(KEY_ALARMS, null);
        if (raw == null || raw.isEmpty()) {
            return new JSONObject();
        }
        try {
            return new JSONObject(raw);
        } catch (Exception e) {
            return new JSONObject();
        }
    }

    private static void saveAlarmsMap(Context context, JSONObject map) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .putString(KEY_ALARMS, map.toString())
                .apply();
    }
}
