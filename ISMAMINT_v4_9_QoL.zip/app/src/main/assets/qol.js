/* Navigation and accessibility refinements. No network or continuous loops. */
(()=>{'use strict';const panels=[...document.querySelectorAll('.panel')];let active=panels.find(p=>p.classList.contains('on'));const update=()=>{const next=panels.find(p=>p.classList.contains('on'));if(!next||next===active)return;active?.classList.remove('qol-enter');active=next;next.classList.add('qol-enter');};const observer=new MutationObserver(update);panels.forEach(p=>observer.observe(p,{attributes:true,attributeFilter:['class']}));
// Allow keyboard use of the start screen and the roulette without changing touch behavior.
for(const id of ['start','rc']){const el=document.getElementById(id);if(!el)continue;el.tabIndex=0;el.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();el.click();}});}
// Modal content is replaced in several flows. Start each new view at its top.
const modal=document.getElementById('lgm-c');if(modal)new MutationObserver(()=>{modal.scrollTop=0;const sc=modal.querySelector('.st-b');if(sc)sc.scrollTop=0;}).observe(modal,{childList:true});
})();
