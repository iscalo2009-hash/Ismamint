const assert=require('node:assert/strict'),C=require('../app/src/main/assets/heartbound-core');
const tick=(g,n)=>{for(let i=0;i<n;i++)g.update(1/120)};
let events=[];let g=C.create({stage:2,seed:44,emit:(id)=>events.push(id)}),s=g.state,p=s.player;
assert(s.catch);assert.equal(p.y,C.B.b-12);g.input.targetX=210;g.input.y=-1;tick(g,60);assert.equal(p.x,210);assert.equal(p.y,C.B.b-12);assert(!g.action());assert(!g.defense());
// Drop a heart within the broad catcher but outside the old heart hitbox.
s.spawn=100;s.hearts.push({kind:'pink',x:185,y:p.y,vy:0,t:1});tick(g,1);assert.equal(s.done,1);assert.equal(s.score,10);
// Powerups are automatic and not counted as hearts or points.
for(const k of ['magnet','shield','slow','rain']){s.hearts.push({kind:k,x:p.x,y:p.y,vy:0,t:1});tick(g,1);assert(events.includes('catch:power:'+k));}
assert.equal(s.done,1);assert(s.catch.magnet>0&&s.catch.slow>0&&s.catch.rain>0&&s.catch.shield===1);
p.inv=0;s.catch.obstacles.push({kind:'spike',x:p.x,bx:p.x,y:p.y,vy:0,t:1});tick(g,1);assert.equal(s.health,5);assert.equal(s.catch.shield,0);s.catch.obstacles.push({kind:'spike',x:p.x,bx:p.x,y:p.y,vy:0,t:1});tick(g,1);assert.equal(s.health,4);
// Misses reset combo, not life; avoid obstacle damage while catching.
s.combo=12;let hp=s.health;s.hearts.push({kind:'pink',x:25,y:p.y+11,vy:240,t:1});tick(g,2);assert.equal(s.combo,0);assert.equal(s.health,hp);
// Seeded spawns, multiple simultaneous hearts, no combat enemies during ordinary collection.
let a=C.create({stage:22,seed:123}),b=C.create({stage:22,seed:123});tick(a,480);tick(b,480);assert.deepEqual(a.state.catch,b.state.catch);assert.deepEqual(a.state.hearts,b.state.hearts);assert(a.state.hearts.length>=3);assert.equal(a.state.enemies.length,0);assert(a.state.catch.patternCount>=2);
// Advance with actual collection into combat; no old temporary effects or direct touch targets.
g=C.create({stage:2,seed:8});s=g.state;for(let k=0;k<120*45&&g.state===s;k++){const p=s.player,h=s.hearts.find(h=>h.y<=p.y+10);p.inv=2;g.input.targetX=h?.x??120;g.update(1/120);}assert.equal(g.state.stage,3);assert(!g.state.catch);assert.equal(g.input.targetX,null);const y=g.state.player.y;g.input.y=-1;tick(g,30);assert(g.state.player.y<y);console.log('Classic catch: horizontal controls, 4 pickups, hazards, misses, formations, seeded spawns and transition verified');
