/* Heartmint: deterministic encounter compiler. No remote data or stored progression. */
(function(root){'use strict';
const names=['FEID','JUSTIN BIEBER','LA DISTANCIA','SEVEN','CELOS'];
const colors=['#39ed65','#4dc3ff','#b0b0c8','#ff303e','#ff9a2e','#ffd34d','#ff6eae','#6de7d9','#95aaff','#f58b6e'];
const labels={aim:'PUNTERÍA',sweep:'BARRIDO',gate:'PORTAL',seven:'SIETE PULSOS',mirror:'ESPEJO',echo:'ECO',orbit:'ÓRBITA',lattice:'RETÍCULA',split:'DIVISIÓN',cascade:'CASCADA',cross:'CRUCE',meteor:'METEOROS'};
const all=Object.keys(labels), fixed=[['aim','echo','cross'],['sweep','orbit','cascade'],['gate','split','lattice'],['seven','cascade','meteor']];
const scales=[[0,2,3,5,7,8,10],[0,2,4,5,7,9,11],[0,1,3,5,7,8,10],[0,2,3,5,7,9,10],[0,2,3,6,7,8,11],[0,1,4,5,7,8,10]];
const rhythms=[[0,.5],[0,.25,.75],[0,1/3,2/3],[0,.5,.75],[0,.25,.5,.75],[0,.375,.75]];
function hash(n){n>>>=0;n=Math.imul(n^(n>>>16),0x21f0aaad);n=Math.imul(n^(n>>>15),0x735a2d97);return (n^(n>>>15))>>>0;}
function rng(s){return ()=>{s=(s+0x9e3779b9)>>>0;return hash(s)/4294967296;};}
const pick=(r,a)=>a[Math.floor(r()*a.length)], clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const concepts={aim:['Desconfianza','Sospechas','Control excesivo'],sweep:['Discusiones','Impulsividad','Malentendidos'],gate:['Distancia emocional','Falta de tiempo','Desconexión'],seven:['Estrés','Impaciencia','Frustración'],mirror:['Comparaciones','Inseguridad','Celos retrospectivos'],echo:['Rencor','Resentimiento','Heridas del pasado'],orbit:['Rutina','Monotonía','Desinterés'],lattice:['Expectativas','Dudas','Sobrepensar'],split:['Desacuerdos','Orgullo','Falta de comunicación'],cascade:['Agobio','Presión externa','Problemas acumulados'],cross:['Incompatibilidad','Falta de escucha','Prioridades opuestas'],meteor:['Miedo al cambio','Promesas rotas','Conflictos inesperados']};
const modifiers=['sin resolver','en aumento','recurrente','a distancia','del pasado','en silencio','sin hablar'];
function bossName(p){const r=rng(hash(p.key^0x5a12b3c4)),a=pick(r,concepts[p.patterns[0]]),b=pick(r,concepts[p.patterns[1]]);return pick(r,[a,`${a} ${pick(r,modifiers)}`,`${a} y ${b}`]).toUpperCase();}
function sprite(r){const rows=[];for(let y=0;y<10;y++){let half=[];for(let x=0;x<7;x++){let edge=y===0?2:y===9?3: y===1||y===8?1:0;half.push(x<edge?'0':(x===edge&&r()<.28?'0':'1'));}rows.push(half.concat(half.slice().reverse()).join(''));}for(let y=3;y<=4;y++)rows[y]=rows[y].slice(0,3)+'22'+rows[y].slice(5,9)+'22'+rows[y].slice(11);rows[7]=rows[7].slice(0,4)+'333333'+rows[7].slice(10);return rows;}
// Shared semantic genome: attack family drives silhouette, palette and score.
const themes={
 aim:['#75e84b','#286b36',154,4,1,'spikes','Desconfianza'],sweep:['#ad75ed','#49d9e8',146,4,3,'double','Malentendidos'],gate:['#7099cf','#574e99',112,2,2,'split','Distancia emocional'],seven:['#ff6258','#a83250',158,0,3,'spikes','Impaciencia'],mirror:['#e7a0c8','#76658e',124,2,4,'mask','Inseguridad'],echo:['#bc5363','#68263e',108,0,2,'heavy','Resentimiento'],orbit:['#aaa2c9','#80796e',120,3,0,'orb','Monotonía'],lattice:['#518cff','#b8c9ff',156,4,5,'eye','Sobrepensar'],split:['#e5bb53','#a34242',136,1,2,'crown','Orgullo'],cascade:['#ff9851','#a84435',150,0,3,'heavy','Presión externa'],cross:['#8375dd','#43c7d6',142,5,4,'double','Falta de comunicación'],meteor:['#b69a73','#775d89',130,2,5,'ghost','Recuerdos del pasado']};
const variants={aim:[['#d64aa9','#73346b',144,4,1,'spikes','Miedo al abandono']],gate:[['#9ce4e8','#497ba9',108,2,0,'crystal','Frialdad']],mirror:[['#8ad956','#316536',150,4,1,'spikes','Celos retrospectivos'],['#c34edb','#693188',136,4,2,'heart','Dependencia']]};
function blend(a,b,t){return '#'+[1,3,5].map(i=>Math.round(parseInt(a.slice(i,i+2),16)*(1-t)+parseInt(b.slice(i,i+2),16)*t).toString(16).padStart(2,'0')).join('');}
function themeName(theme,secondary,key,rarity){const r=rng(hash(key^0x5a12b3c4)),a=theme[6],b=secondary[6];return (rarity===3?`${a} sin fin`:pick(r,[a,`${a} ${pick(r,modifiers)}`,`${a} y ${b}`,`${a} ${pick(r,['sin respuesta','en conflicto','sin resolver','en aumento'])}`])).toUpperCase();}
function genomeSprite(key,shape,patterns,rare){const r=rng(hash(key^0x13579)),a=Array.from({length:14},()=>Array(14).fill('0'));const put=(x,y,c)=>{if(x>=0&&x<14&&y>=0&&y<14)a[y][x]=c;};const stretch=.85+r()*.3;
 for(let y=1;y<13;y++)for(let x=0;x<14;x++){const dx=Math.abs(x-6.5),dy=Math.abs(y-6.5);let inside;
 switch(shape){case 'heart':inside=((x-4)**2+(y-4)**2<12||(x-9)**2+(y-4)**2<12||dx+(y-4)*.7<6&&y>4&&y<12);break;case 'crystal':inside=dx+dy<7;break;case 'spikes':inside=dx+dy*.75<6.8;break;case 'split':inside=dx>1&&dx<6&&dy<5.5;break;case 'heavy':inside=dx<6&&dy<5;break;case 'ghost':inside=dx*dx/36+(y-5)**2/36<1||y>5&&y<12&&dx<5&&((x+y)%3!==0);break;case 'crown':inside=dx<5.5&&y>3&&y<12||y>=1&&y<=4&&x%4<2;break;case 'double':inside=(Math.abs(x-3)**2+dy*dy<22)||(Math.abs(x-10)**2+dy*dy<22);break;default:inside=dx*dx/(36*stretch)+dy*dy/30<1;}
 if(inside)put(x,y,dy>4||dx>4?'4':'1');}
 for(const x of [3,4,9,10]){put(x,5,'2');if(shape==='spikes'||shape==='heavy')put(x,6,'2');}for(let x=5;x<9;x++)put(x,9,'3');
 if(shape==='eye'){for(let y=4;y<9;y++)for(let x=5;x<9;x++)put(x,y,x===6||x===7?'3':'2');}
 if(shape==='mask')for(let y=2;y<12;y++)put(6+(y%2),y,'4');
 if(patterns.includes('orbit'))for(const [x,y] of [[0,3],[13,10],[2,0],[11,13]])put(x,y,'4');
 if(patterns.includes('mirror')){put(1,6,'2');put(12,6,'2');}
 if(patterns.includes('meteor')||shape==='spikes')for(const x of [1,4,9,12])put(x,0,'4');
 if(patterns.includes('gate')){put(0,7,'4');put(13,7,'4');}
 if(patterns.includes('cross')){put(2,2,'4');put(11,2,'4');put(3,3,'4');put(10,3,'4');}
 if(patterns.includes('echo')){for(const x of [1,12])for(const y of [4,8])put(x,y,'4');}
 if(patterns.includes('lattice')){for(const x of [2,11])for(const y of [3,10])put(x,y,'2');}
 if(patterns.includes('seven'))for(let x=1;x<14;x+=2)put(x,13,'4');
 if(patterns.includes('sweep')){put(0,6,'4');put(13,6,'4');}
 if(patterns.includes('split')&&shape!=='split'){for(let y=1;y<4;y++)put(6,y,'3');}
 if(patterns.includes('cascade'))for(const x of [2,5,8,11])put(x,12,'4');
 if(rare>=2){for(const x of [0,13])for(const y of [1,12])put(x,y,'4');}
 if(rare===3){for(const x of [3,6,7,10])put(x,0,'2');}
 for(let i=0;i<3+rare*2;i++){let x=2+Math.floor(r()*10),y=2+Math.floor(r()*10);if(a[y][x]==='1')put(x,y,'4');}
 return a.map(row=>row.join(''));}
const EXES=[{name:"EX MALVADO 1",col:"#ff83be",sprite:["00111111110000","01111111111000","11221111221100","11221111221100","11111111111100","11333333331100","01111111111000","00110000110000"]},{name:"EX MALVADO 2",col:"#b7c6ff",sprite:["00011111100000","00111111110000","01121112111000","01121112111000","01111111111000","01113331111000","01111111111000","01010101010000"]},{name:"EX MALVADO 3",col:"#ffd34d",sprite:["01100000011000","11111111111100","11221111221100","11111331111100","11111111111100","11333333331100","01111111111000","00110000110000"]}].map((e,i)=>({...e,movement:[1,4,3][i],patterns:[['aim','echo','cross','mirror'],['orbit','gate','echo','split'],['cascade','seven','sweep','meteor']][i],music:{root:53,scale:[0,2,4,5,7,9,11],tempo:[144,132,160][i],motif:[[0,4,2,6,1,5,0,7],[0,2,5,3,0,5,2,1],[0,7,3,1,6,0,4,2]][i],rhythm:[[0,.25,.75],[0,.5],[0,.25,.5,.75]][i],chords:[0,5,7,0],lead:['square','triangle','square'][i],bass:'triangle',drums:i}}));
function profile(n,run=0){n=Math.max(1,Math.floor(n)||1);const key=hash(hash(run)^hash(n>>>0)^hash(Math.floor(n/4294967296)));const r=rng(key), power=1-Math.exp(-(n-1)/14);
 const pool=all.filter(x=>n!==5||x!=='seven');const patterns=n<5?fixed[n-1].slice():n===5?['mirror']:[];
 const count=n<5?3:Math.min(7,4+Math.floor(Math.log2(n/5)));while(patterns.length<count){const p=pick(r,pool);if(!patterns.includes(p))patterns.push(p);}
 const music={root:n<5?[45,48,43,50][n-1]:38+Math.floor(r()*15),scale:scales[n<5?[0,1,2,3][n-1]:n===5?4:Math.floor(r()*scales.length)].slice(),tempo:n<5?[132,148,116,154][n-1]:128+Math.floor(r()*22),motif:Array.from({length:12},(_,i)=>i===0?0:Math.floor(r()*9)-1),rhythm:rhythms[n<5?n-1:Math.floor(r()*rhythms.length)].slice(),chords:n<5?[[0,5,3,7],[0,7,5,3],[0,1,5,3],[0,3,6,5]][n-1]:[0,pick(r,[1,3,5,7]),pick(r,[2,4,5,8]),pick(r,[1,3,6,7])],lead:pick(r,['square','triangle','sawtooth']),bass:pick(r,['triangle','square','sawtooth']),drums:Math.floor(r()*4),key};
 const exes=EXES.map((e,i)=>({...e,accent:["#a73972","#657cae","#d67a37"][i],shape:["spikes","ghost","double"][i],sprite:genomeSprite(hash(hash(run)^hash(i+700)),["spikes","ghost","double"][i],e.patterns,0)})); const ex=n>=7&&n<=9?exes[n-7]:null;
 if(ex){patterns.splice(0,patterns.length,...ex.patterns);Object.assign(music,ex.music);}
 if(n===10){patterns.splice(0,patterns.length,...new Set(exes.flatMap(e=>e.patterns)));Object.assign(music,{root:53,scale:[0,2,4,5,7,9,11],tempo:156,motif:exes.flatMap(e=>e.music.motif.slice(0,4)),rhythm:[0,.25,.75],chords:[0,5,7,0],lead:"square",bass:"triangle",drums:2,medley:exes.map(e=>e.music)});}
 const tr=rng(hash(key^0x77c2)), roll=tr(), special=n%25===0, rarity=n<=10?0:n%100===0?3:special?2:roll<.01?3:roll<.10?2:roll<.35?1:0;
 const theme=n===5?['#8ad956','#316536',150,4,1,'spikes','Celos']:pick(tr,[themes[patterns[0]],...(variants[patterns[0]]||[])]), secondary=themes[patterns[1]];
 const col=ex?ex.col:n<5?colors[n-1]:n===5?'#a1e64a':n===10?colors[5]:blend(theme[0],secondary[0],.3);
 const accent=ex?ex.accent:blend(theme[1],secondary[0],.3), shape=ex?ex.shape:theme[5];
 if(n>=5&&!ex&&n!==10){music.tempo=theme[2]+Math.floor(r()*13)-6;music.scale=scales[theme[3]].slice();music.drums=theme[4]%4;music.motif=Array.from({length:12},(_,i)=>i===0?0:theme[2]<120?Math.max(-2,5-Math.floor(i/2))+Math.floor(tr()*3)-1:theme[5]==='orb'?[0,2,4,2][i%4]:theme[5]==='double'?(i%2?5:1)+Math.floor(tr()*3):Math.floor(tr()*9)-1);music.rhythm=rhythms[theme[4]%rhythms.length].slice();music.lead=theme[2]>140?'square':theme[2]<120?'triangle':'sawtooth';}
  const name=ex?ex.name:n===10?"EXES MALVADOS":n<=5?names[n-1]:themeName(theme,secondary,key,rarity); return {n,key,name,col,patterns,trio:n===10?exes.map(e=>({...e})):null,movement:ex?ex.movement:n<5?n-1:n===5?4:({spikes:1,ghost:4,split:2,heavy:2,orb:0,eye:5,crown:2,double:3,mask:4,heart:0,crystal:2}[shape]??Math.floor(r()*6)),sprite:ex?ex.sprite:n===10?sprite(r):genomeSprite(key,shape,patterns,rarity),accent,shape,rarity,special,theme:theme[6],secondaryTheme:secondary[6],music,hp:Math.round((20+5*n/(1+n/20)+32*Math.log2(1+n/5))*(1+rarity*.045)),power};
}
function wave(p,phase,index,playerX){const r=rng(hash(p.key^hash(index+1)^hash(phase*313))), available=Math.min(p.patterns.length,phase+2),type=p.patterns[(index+(phase===3&&index%2?1:0))%available];
 const width=p.n===1&&phase===1?4:3;let start;
 if(type==='aim'||type==='mirror')start=clamp(Math.round(playerX/24)-1+(playerX<120?2:-2),0,10-width);else start=Math.floor(r()*(11-width));
 const safe=start*24+width*12, outside=Array.from({length:10},(_,i)=>i).filter(i=>i<start||i>=start+width);const dist=i=>Math.abs(i*24+12-playerX);let lanes=outside.slice(), kind='x', stagger=0, drift=0;
 switch(type){case 'aim':lanes.sort((a,b)=>dist(a)-dist(b));lanes=lanes.slice(0,phase+1);break;case 'sweep':lanes.sort((a,b)=>index%2?a-b:b-a);lanes=lanes.slice(0,phase+2);stagger=7;drift=5;kind='z';break;case 'gate':break;case 'seven':lanes=lanes.slice(0,7);stagger=5;kind='f';break;case 'mirror':lanes.sort((a,b)=>Math.abs(a-4.5)-Math.abs(b-4.5));lanes=lanes.slice(0,phase+3);stagger=3;drift=6;kind='z';break;case 'echo':lanes.sort((a,b)=>dist(a)-dist(b));lanes=lanes.slice(0,phase+1);stagger=10;break;case 'orbit':lanes=lanes.filter((_,i)=>i%2===index%2);drift=7;kind='z';stagger=5;break;case 'lattice':lanes=lanes.filter((_,i)=>i%2===0||phase===3);break;case 'split':lanes.sort((a,b)=>Math.abs(b-4.5)-Math.abs(a-4.5));lanes=lanes.slice(0,phase+3);stagger=4;break;case 'cascade':lanes.sort((a,b)=>index%2?a-b:b-a);stagger=8;kind='f';break;case 'cross':lanes.sort((a,b)=>Math.abs(a-4.5)-Math.abs(b-4.5));lanes=lanes.slice(0,phase+3);drift=6;stagger=5;kind='z';break;case 'meteor':lanes=lanes.filter(()=>r()<.72);if(!lanes.length)lanes=[outside[0]];stagger=6;kind='f';break;}
 const speed=2.6+1.35*p.power+.25*(phase-1)+Math.min(.05,(p.rarity||0)*.015), warning=Math.round(53-11*p.power-3*(phase-1)), rest=Math.round(26-15*p.power-3*(phase-1));
 const shots=lanes.map((lane,i)=>({lane,x:12+24*lane,kind,speed,delay:i*stagger,drift,offset:r()*Math.PI*2}));
 if(type==='echo'&&phase>=2)shots.push(...shots.map(s=>({...s,delay:s.delay+22,drift:0})));return {type,label:labels[type],start,width,safe,shots,warning,rest};
}
function position(p,t,ph){const a=Math.min(62,42+ph*6);switch(p.movement){case 0:return 120+Math.sin(t*(.016+ph*.003))*a;case 1:return 120+Math.sin(t*.032)*a;case 2:return 120+Math.sin(t*.009)*35;case 3:return 120+Math.sin(t*.026)*Math.cos(t*.009)*a;case 4:return 120+Math.sin(t*.021)*a+Math.sin(t*.052)*8;default:return 120+Math.sin(t*.018)*a*.65+Math.sin(t*.046)*a*.35;}}
const api={profile,wave,position,labels};if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.HeartmintBosses=api;
})(typeof window!=='undefined'?window:globalThis);
