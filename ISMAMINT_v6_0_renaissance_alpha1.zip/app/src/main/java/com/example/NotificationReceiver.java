package com.example;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class NotificationReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null) return;
        int id = intent.getIntExtra(NotificationHelper.EXTRA_ID, 0);
        String title = intent.getStringExtra(NotificationHelper.EXTRA_TITLE);
        String text = intent.getStringExtra(NotificationHelper.EXTRA_TEXT);

        // Elimina el registro primero para que nunca quede una alarma huérfana.
        NotificationHelper.removeSavedAlarm(context, id);
        if (!NotificationHelper.isAlarmFresh(intent)) return;
        NotificationHelper.showNotificationOnce(context, id, title, text);
    }
}
