from playwright.sync_api import sync_playwright
from pathlib import Path
import re
root=Path(__file__).resolve().parents[1]/'app/src/main/assets'; h=(root/'index.html').read_text()
def scripts(m):
 f=root/m.group(1)
 return '<script>\n'+f.read_text().replace('</script','<\\/script')+'\n</script>' if f.is_file() else ''
h=re.sub(r'<script\s+src="([^"]+)"\s*>\s*</script>',scripts,h)
h=re.sub(r'<link\s+rel="stylesheet"\s+href="([^"]+)"\s*/?>',lambda m:'<style>'+ (root/m.group(1)).read_text()+'</style>' if (root/m.group(1)).is_file() else '',h)
pre='''<script>for(const name of ['localStorage','sessionStorage']){const m=new Map();Object.defineProperty(window,name,{value:{getItem:k=>m.has(k)?m.get(k):null,setItem:(k,v)=>m.set(k,String(v)),removeItem:k=>m.delete(k),clear:()=>m.clear(),key:i=>[...m.keys()][i],get length(){return m.size}}});}</script>'''
h=re.sub(r'<head[^>]*>',lambda m:m.group(0)+pre,h,count=1,flags=re.I)

mock="""<script>
const realNow=Date.now.bind(Date);window.radioTestOffset=0;Date.now=()=>realNow()+window.radioTestOffset;
window.Audio=class extends EventTarget{constructor(){super();this.paused=true;this.currentTime=0;this.duration=0;this.readyState=0;this.volume=1;this.error=null;}load(){this.paused=true;this.currentTime=0;this.duration=window.IsmaRadio?.durations[(this.src||'').match(/(s\\d+)\\.(?:opus|mp3)/)?.[1]]||180;this.readyState=1;queueMicrotask(()=>this.dispatchEvent(new Event('loadedmetadata')));}play(){this.paused=false;this.dispatchEvent(new Event('play'));return Promise.resolve();}pause(){this.paused=true;this.dispatchEvent(new Event('pause'));}};
localStorage.setItem('ismamint_music_prefs',JSON.stringify({id:'s01',mode:'ordered',enabled:true,position:10}));
</script>"""
h=h.replace(pre,pre+mock,1)
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox']);page=b.new_page(viewport={'width':420,'height':850},is_mobile=True,has_touch=True);page.set_default_timeout(5000);page.route('**/*',lambda r:r.abort());errors=[];page.on('pageerror',lambda e:errors.append(str(e)));page.set_content(h,wait_until='domcontentloaded',timeout=12000);page.wait_for_timeout(250)
 page.evaluate('IsmaMusic.start()');page.wait_for_timeout(100);assert page.evaluate('IsmaMusic.state().id')=='s01';assert page.evaluate('IsmaMusic.state().playing');assert abs(page.evaluate('IsmaMusic.state().time')-10)<.1

 page.evaluate("document.querySelector('main').style.setProperty('display','block');document.querySelector('.tabs button[data-p=p1]').click()")
 page.evaluate("document.querySelector('#start').style.setProperty('display','none','important')")
 page.evaluate("__openTab('p12'); document.querySelector('#v6-music .rb-switch button:nth-child(2)').click(); IsmaMusic.select('s56')");page.wait_for_timeout(250)
 page.evaluate("IsmaMusic.seek(60)");page.wait_for_timeout(250)
 page.locator('#sm-immersive-open').click();page.wait_for_timeout(500)
 assert page.evaluate("document.body.classList.contains('sm-immersive') && getComputedStyle(document.querySelector('#main')).display==='none' && document.querySelector('.sm-director-back').classList.contains('on') && IsmaMusic.state().playing && IsmaMusic.state().id==='s56'")
 assert page.evaluate("document.querySelector('.sm-lyric').classList.contains('on')")
 seek=page.locator('#sm-immersive-seek');assert seek.is_visible();assert abs(float(seek.input_value())-60)<.15
 seek.evaluate("e=>{e.value=85;e.dispatchEvent(new Event('input',{bubbles:true}));e.dispatchEvent(new Event('change',{bubbles:true}));}");assert abs(page.evaluate('IsmaMusic.state().time')-85)<.15
 seek.evaluate("e=>{e.dispatchEvent(new PointerEvent('pointerdown',{bubbles:true}));e.value=100;e.dispatchEvent(new Event('input',{bubbles:true}));}");page.wait_for_timeout(3700);assert seek.is_visible();assert abs(page.evaluate('IsmaMusic.state().time')-85)<.15
 seek.evaluate("e=>{e.dispatchEvent(new Event('change',{bubbles:true}));}");assert abs(page.evaluate('IsmaMusic.state().time')-100)<.15
 page.evaluate('IsmaMusic.seek(60)');page.wait_for_timeout(200);assert abs(float(seek.input_value())-60)<.15

 page.get_by_role('button',name='Letra',exact=True).click();assert page.evaluate("getComputedStyle(document.querySelector('.sm-lyric')).visibility==='hidden'")
 page.get_by_role('button',name='Letra',exact=True).click();assert page.evaluate("getComputedStyle(document.querySelector('.sm-lyric')).visibility==='visible'")
 page.get_by_role('button',name='Pausar música').click();page.wait_for_timeout(250);assert page.evaluate("!IsmaMusic.state().playing&&document.querySelector('.sm-director-back').classList.contains('on')")
 page.get_by_role('button',name='Reproducir música').click();page.wait_for_timeout(250);assert page.evaluate('IsmaMusic.state().playing')
 page.locator('#sm-immersive-surface').click(position={'x':200,'y':450});assert page.locator('#sm-immersive-toolbar').is_hidden()
 page.locator('#sm-immersive-surface').click(position={'x':200,'y':450});assert page.locator('#sm-immersive-toolbar').is_visible()
 page.wait_for_timeout(3700);assert page.locator('#sm-immersive-toolbar').is_hidden()
 page.evaluate("IsmaMusic.next()");page.wait_for_timeout(250);assert page.evaluate("document.body.classList.contains('sm-immersive')&&document.querySelector('.sm-director-back').classList.contains('on')")
 page.evaluate("IsmaMusic.select('s56');IsmaMusic.seek(60)");page.wait_for_timeout(200)
 assert page.evaluate('__goBack()');assert page.evaluate("!document.body.classList.contains('sm-immersive')&&getComputedStyle(document.querySelector('#main')).display!=='none'&&IsmaMusic.state().id==='s56'&&IsmaMusic.state().playing")
 page.locator('#sm-immersive-open').click();page.keyboard.press('Escape');assert page.locator('#sm-immersive-open').is_visible()
 page.evaluate("document.querySelector('#start').style.setProperty('display','none','important')")
 page.locator('#sm-immersive-open').click();page.evaluate("__openTab('p1')");assert page.evaluate("!document.body.classList.contains('sm-immersive')")
 assert not errors,errors;print('Immersive: HUD, scene, lyrics, playback, touch controls, Android back, Escape and navigation passed');b.close()
