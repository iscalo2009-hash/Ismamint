from pathlib import Path
from playwright.sync_api import sync_playwright
import zipfile, sys
root=Path(__file__).resolve().parents[1]/'app/src/main/assets'
files=['soundtrack-data.js','soundtrack-presets.js','soundtrack-scenes.js','soundtrack-worlds.js','soundtrack-world-render.js','soundtrack-rhythm.js','soundtrack-spectrum.js','soundtrack-atelier.js']
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox']);pg=b.new_page();errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
 pg.set_content('<canvas width="360" height="640"></canvas>')
 for f in files:pg.add_script_tag(path=root/f)
 def frames():return pg.evaluate('''()=>{let c=document.querySelector('canvas').getContext('2d');return ISMA_SONGS.map(s=>{let p=ISMA_SCENES[s.id],r=ISMA_RHYTHM[s.id], times=[Math.min(24,r.duration*.2),r.duration*.51,r.duration*.85];return {id:s.id,frames:times.map((t,i)=>{c.clearRect(0,0,360,640);IsmaDirector.drawScene(c,p,t,1,.5,1,1,.65,i===0?0:1);return c.canvas.toDataURL();})}})}''')
 new=frames();assert len(new)==56 and not errs,errs
 if len(sys.argv)>1:
  with zipfile.ZipFile(sys.argv[1]) as z:old=z.read('app/src/main/assets/soundtrack-atelier.js').decode()
  pg.add_script_tag(content=old);before=frames();assert not errs,errs
  diffs=[sum(a!=b for a,b in zip(n['frames'],o['frames'])) for n,o in zip(new,before)];assert all(diffs),diffs
  print('Changed frames:',sum(diffs),'/',56*3,'; tracks changed:',sum(x>0 for x in diffs))
 for n in new:assert len(set(n['frames']))==3,n['id']
 b.close()
 print('56 actual canvas scenes, 168 renders, 3 distinct times per track; no JS errors')
