# Alpha 7.37.2.30 — Modo inmersivo de música

- Música > Reproduciendo > Ver fondo: oculta HUD, navegación, avisos y minirreproductor; aumenta la presencia del fondo nativo a opacidad completa.
- Tocar la escena muestra/oculta controles; estos se esconden tras 3,5 s (salvo foco de teclado). Pausa, letra y salida; Atrás de Android y Escape salen primero del modo.
- Usa el mismo Audio y la misma escena de cada canción. El karaoke nativo permanece separado y se centra abajo; ocultarlo es temporal. Al salir se conserva la posición de reproducción y las preferencias globales e individuales.
- La visualización se mantiene al pausar; con reducción de movimiento presenta una escena estática. Los efectos individuales desactivados no se fuerzan.
- Pruebas: Chromium con audio simulado, navegación, cambio de pista, HUD, subtítulos, pausa, controles y salida. Test de 56 perfiles visuales. APK no compilado.
