# 7.37.2.31 — Soundtrack: detalle e inmersión

Se conserva la composición y la dirección artística existente. Revisión incremental sobre el dossier y código locales, no una nueva investigación externa de las 56 canciones. Resolución 180×320, reloj y karaoke nativo conservados.

## Detalles por escena
- s01: Costuras y ribetes del mobiliario; pliegues de la cortina.
- s02: Trama de tinta de cómic en las esquinas del panel.
- s03: Marcas de arcén y reflejos del horizonte sobre la ruta.
- s04: Perforaciones y grano de película dentro de los marcos.
- s05: Gotas en el paraguas y bordes húmedos del sendero.
- s06: Surcos de tierra y hojas iluminadas al atardecer.
- s07: Costuras del edredón y luces del teléfono.
- s08: Reflejos cromáticos en el río de la escena psicodélica.
- s09: Juntas de panel y sombras en el suelo del cuarto blanco.
- s10: Juntas de la vitrina y pequeños reflejos facetados.
- s11: Glifos de energía sobre el contorno del portal.
- s12: Indicadores de conexión en el monitor secundario.
- s13: Detalle de plumas en el ave, sujeto a sus alas.
- s14: Indicadores de polaridad en la mesa.
- s15: Grabados en el marco de madera del reloj de arena.
- s16: Textura de pavimento y bordes del camino.
- s17: Carpintería de ventana y ribete de la cama.
- s18: Estratos de roca iluminados por la salida.
- s19: Asfalto con reflejos junto al vehículo.
- s20: Puntadas del cojín central y relieve de tejido.
- s21: Persianas y marco de la ventana iluminada.
- s22: Remaches, tablero y reflejos bajo el puente.
- s23: Etiqueta del disco y brillo del surco.
- s24: Mortero de ladrillos y reflejos mojados al pie del pasaje.
- s25: Herrajes y tornillos de las cajas de sonido.
- s26: Doblez y borde iluminado del sobre de baile.
- s27: Aros y remaches de las congas.
- s28: Moldura del piano y reflejo de lluvia sobre el suelo.
- s29: Ranuras y luces del anillo de la plataforma espacial.
- s30: Borde de papel y costuras del sobre.
- s31: Hojas y pequeñas luces en el arco floral.
- s32: Biseles y reflejos en los lentes.
- s33: Estrías de enfoque y tornillos en la cámara.
- s34: Juntas y pernos de la puerta de hierro.
- s35: Moteado del sendero y reflejos de luz.
- s36: Grabado dorado del pedestal y reflejo de estrellas.
- s37: Textura del banco y juntas del cemento.
- s38: Remaches en la moldura del escenario de club.
- s39: Cepillado y tornillos en la carcasa del tocadiscos.
- s40: Marcadores de escala del osciloscopio.
- s41: Molduras del tocador y detalles del armario.
- s42: Remaches del pedestal de la trompeta.
- s43: Cantos del libro y grano de papel.
- s44: Teclas y tornillos de la cabina telefónica.
- s45: Espuma y arena húmeda en la orilla.
- s46: Juntas de la cúpula y remaches del observatorio.
- s47: Escala y tornillería de la mesa de mezcla.
- s48: Anillos internos de los nodos de la red.
- s49: Pequeñas grietas secundarias en los espejos fracturados.
- s50: Graduaciones sobre los matraces.
- s51: Altavoces y marcas en la carcasa del cassette.
- s52: Juntas de madera y ribetes góticos.
- s53: Mampostería del faro y espuma al pie del acantilado.
- s54: Brillos de espuma en la estela del velero.
- s55: Tornillos y biseles del monitor del corazón digital.
- s56: Destellos de cristal sobre el agua, manteniendo el reencuentro original.

## Modo inmersivo
Barra de tiempo con posición y duración, arrastre con previsualización de tiempo y salto al soltar. Se usa IsmaMusic.seek, se congela la desaparición de controles durante el arrastre.

## Verificación
- Chromium: 168/168 fotogramas modificados frente a la versión anterior, 56 escenas con tres tiempos distintos y sin errores JS.
- Modo inmersivo: salto, arrastre, ocultación, letra, pausa, navegación y cambio de pista con audio simulado.
- No se realizó evaluación visual manual exhaustiva, investigación externa nueva ni compilación de APK.
