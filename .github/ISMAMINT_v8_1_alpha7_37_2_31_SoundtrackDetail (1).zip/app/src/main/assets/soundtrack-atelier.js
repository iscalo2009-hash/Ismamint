/* 7.19: 55 single-pass authored stages with physically grounded props and local climax lighting. */
(()=>{'use strict';
const previous=window.IsmaDirector, W=180,H=320,TAU=Math.PI*2,cl=(v,a=0,b=1)=>Math.max(a,Math.min(b,v)),mod=(v,m)=>((v%m)+m)%m;
const colorCache=new Map();const mix=(a,b,t)=>{const k=a+b+t;if(colorCache.has(k))return colorCache.get(k);let x=parseInt(a.slice(1),16),y=parseInt(b.slice(1),16);const v='#'+[16,8,0].map(s=>Math.round(((x>>s)&255)*(1-t)+((y>>s)&255)*t).toString(16).padStart(2,'0')).join('');if(colorCache.size>=4096)colorCache.clear();colorCache.set(k,v);return v;};
const hash=n=>{n=Math.imul(n^n>>>16,0x45d9f3b);n=Math.imul(n^n>>>16,0x45d9f3b);return ((n^n>>>16)>>>0)/4294967296};
const scoreCache=new Map();
function score(id,t){const r=window.ISMA_RHYTHM?.[id];if(!r?.sections?.length)return {phase:'verse',progress:cl(t/180),act:cl(t/180),chorus:0,entry:0,sectionProgress:0,energy:.5};let groups=scoreCache.get(id);if(!groups){groups=[];let count=0;for(const [at,phase,energy] of r.sections){const strong=phase==='chorus'||phase==='climax';const type=strong?'chorus':phase==='quiet'||phase==='intro'?'quiet':phase==='instrumental'?'instrumental':'verse';let last=groups[groups.length-1];if(!last||last.type!==type){if(strong)count++;groups.push({at,type,chorus:count});}}groups.forEach((g,i)=>g.end=groups[i+1]?.at??r.duration);scoreCache.set(id,groups);}let i=groups.length-1;while(i>0&&groups[i].at>t)i--;const g=groups[i],seg=r.sections[Math.min(r.sections.length-1,Math.max(0,Math.floor(t/2)))],progress=cl(t/r.duration),sectionProgress=cl((t-g.at)/Math.max(.1,g.end-g.at));return {phase:g.type,progress,act:cl(progress*.68+g.chorus*.10),chorus:g.chorus,entry:Math.max(0,1-(t-g.at)/2.4),sectionProgress,energy:seg?.[2]??.5};}
function rhythmPulse(id,t,enabled=true){if(!enabled)return 0;const r=window.ISMA_RHYTHM?.[id];if(!r)return 0;const upper=(arr,v,key)=>{let l=0,h=arr.length;while(l<h){let m=(l+h)>>1;if(key(arr[m])<=v)l=m+1;else h=m;}return l-1;};const beats=r.beats||[],hits=r.hits||[],i=upper(beats,t,x=>x),j=upper(hits,t,x=>x[0]);const period=60/Math.max(40,Math.min(240,r.bpm||100));const dt=i>=0?t-beats[i]:beats.length?Infinity:mod(t,period);const decay=Math.min(.23,period*.35);const pulse=Math.exp(-dt/decay)*(i>=0&&i%4===0?1:.74);const hit=j>=0?Math.exp(-(t-hits[j][0])/Math.min(.15,period*.23))*hits[j][1]:0;return cl(pulse*.66+hit*.45);}
function paint(c,p,t,u,beat,en){const sc=score(p.id,t),act=sc.act;const id=+p.id.slice(1),a=p.color,h=p.accent,d=p.dark,ink=mix(d,'#000000',.52),mid=mix(d,a,.33),shade=mix(d,a,.62),light=mix(h,'#ffffff',.34),white='#fff3de',r0=i=>hash(id*1379+i*199),sin=Math.sin,cos=Math.cos;let b=cl(beat),q=cl(u),tw=t*.5;const chorusLift=q*(.12+act*.28),entry=q*sc.entry;
// Ambient movement follows the playback clock, even when beat effects are disabled.
// The chorus changes the amplitude of a local effect, never its position in the scene.
const drift=(period,offset=0)=>.5+.5*sin(t*TAU/period+offset),
      mood=(period,offset=0)=>cl(.15+.34*drift(period,offset)+q*.30+act*.12+b*.09),
      pulseColor=(base,accent,period,offset=0)=>mix(base,accent,mood(period,offset));
function R(x,y,w,h,col){if(w<=0||h<=0)return;c.fillStyle=col;c.fillRect(Math.round(x),Math.round(y),Math.max(1,Math.round(w)),Math.max(1,Math.round(h)))}
function P(pts,col){c.fillStyle=col;c.beginPath();pts.forEach(([x,y],i)=>i?c.lineTo(Math.round(x),Math.round(y)):c.moveTo(Math.round(x),Math.round(y)));c.closePath();c.fill()}
function L(x,y,X,Y,col,w=1){const n=Math.max(1,Math.ceil(Math.max(Math.abs(X-x),Math.abs(Y-y))));for(let i=0;i<=n;i++)R(x+(X-x)*i/n,y+(Y-y)*i/n,w,w,col)}
function D(x,y,r,col){r=Math.max(0,r);for(let yy=-Math.floor(r);yy<=Math.floor(r);yy++){let w=Math.floor(Math.sqrt(Math.max(0,r*r-yy*yy)));R(x-w,y+yy,w*2+1,1,col)}}
function E(x,y,rx,ry,col){ry=Math.max(.5,ry);rx=Math.max(.5,rx);for(let yy=-Math.floor(ry);yy<=Math.floor(ry);yy++){let w=Math.floor(rx*Math.sqrt(Math.max(0,1-yy*yy/(ry*ry))));R(x-w,y+yy,w*2+1,1,col)}}
function outline(x,y,w,h,col=ink){R(x,y,w,1,col);R(x,y+h-1,w,1,col);R(x,y,1,h,col);R(x+w-1,y,1,h,col)}
function star(x,y,s=2,col=light){R(x-s,y,s*2+1,1,col);R(x,y-s,1,s*2+1,col);if(s>2)R(x-1,y-1,3,3,col)}
function sky(top=d,bot=shade,at=230){let low=mix(bot,h,.09*q);for(let y=0;y<H;y+=2)R(0,y,W,2,mix(top,low,cl(y/at)));for(let i=0;i<64;i++){let x=r0(8900+i*2)*180,y=r0(8901+i*2)*Math.min(180,at);R(x,y,1,1,mix(top,low,cl(y/at+.025)));}}
function stars(n=40,ymax=170){for(let i=0;i<n;i++){let x=r0(i*3)*W,y=r0(i*3+1)*ymax;R(x,y,1+(i%13===0),1+(i%13===0),mix(h,light,.3+.2*sin(t+i)));if(i%13===0)star(x,y,2,light)}}
function cloud(x,y,s=1,col=shade){E(x,y,17*s,5*s,col);E(x-7*s,y-3*s,7*s,5*s,col);E(x+4*s,y-5*s,10*s,7*s,col);R(x-18*s,y,36*s,3*s,col)}
function hills(y=190,col=mid,amp=25,layer=0){let pts=[[0,H]];for(let x=0;x<=180;x+=6)pts.push([x,y-sin(x*.049+layer)*amp*.55-r0(x+layer*20)*amp*.4]);pts.push([180,H]);P(pts,col)}
function moon(x,y,r,col=h,phase=0){c.save();c.beginPath();c.arc(x,y,r+.5,0,TAU);c.clip();D(x,y,r,col);for(let i=0;i<7;i++){let xx=x+(r0(300+i)*2-1)*r*.54,yy=y+(r0(320+i)*2-1)*r*.54,rr=1+r0(350+i)*r*.12;D(xx,yy,rr,mix(col,d,.18));D(xx+rr*.22,yy-rr*.2,rr*.58,mix(col,d,.10))}if(phase)D(x+r*.48,y-r*.16,r*.91,mix(d,col,.06));c.restore()}
function city(y=200,layer=0,sub=false){const lot=sub?24:18;for(let x=-4,i=0;x<W;x+=lot,i++){const w=lot-3,hh=Math.round((sub?23:39)+r0(i+82+layer*7)*(sub?17:66)),yy=y-hh,co=layer?ink:mid;R(x,yy,w,hh,co);R(x+w-3,yy+2,3,hh-2,mix(co,ink,.35));R(x,yy,w,2,mix(co,h,.16));if(sub){P([[x-1,yy],[x+w/2,yy-10],[x+w+1,yy]],shade)}else if(i%3===0){R(x+4,yy-4,w-8,4,co)}for(let xx=x+3;xx+2<x+w-2;xx+=5)for(let v=yy+6;v+3<y;v+=8){const on=r0(xx*13+v+layer)>.52;R(xx,v,2,3,on?mix(h,co,.32+.18*(1-drift(5,xx+v))):mix(co,ink,.35));}}}
function road(y=185){P([[78,y],[102,y],[180,320],[0,320]],ink);L(78,y,0,319,shade,2);L(102,y,178,319,shade,2);for(let i=0;i<9;i++){let v=mod(i/9+t*.09,1),yy=y+(320-y)*v*v;R(89-v*2,yy,2+v*4,2+v*11,h)}}
function lamp(x,y,s=1){R(x,y,3*s,60*s,ink);R(x-4*s,y+59*s,11*s,3*s,ink);R(x-8*s,y,19*s,4*s,shade);R(x-6*s,y+4*s,15*s,5*s,h);c.save();c.globalAlpha=.12+.12*q+.06*b;P([[x-5*s,y+9*s],[x+8*s,y+9*s],[x+23*s,y+60*s],[x-23*s,y+60*s]],h);c.restore();R(x,y+10*s,3*s,50*s,ink)}
function tree(x,y,s=1,col=mid){R(x-2*s,y-34*s,4*s,34*s,ink);D(x,y-43*s,14*s,col);D(x-10*s,y-34*s,10*s,col);D(x+9*s,y-35*s,12*s,col);D(x-3*s,y-48*s,8*s,mix(col,h,.24))}
function house(x,y,s=1,col=shade){R(x,y,40*s,40*s,col);for(let j=0;j<5;j++)R(x+1,y+(j+1)*7*s,38*s,1,mix(col,ink,.25));R(x+38*s,y,2*s,40*s,mix(col,ink,.25));P([[x-5*s,y],[x+20*s,y-22*s],[x+45*s,y]],ink);P([[x-4*s,y-1*s],[x+20*s,y-22*s],[x+20*s,y-17*s],[x+1*s,y-1*s]],shade);for(let j=1;j<5;j++){let yy=y-4*j*s;let k=5*j*s;R(x-4*s+k,yy,Math.max(1,48*s-2*k),1,mix(ink,shade,.38));}R(x+4*s,y+9*s,12*s,13*s,h);L(x+10*s,y+9*s,x+10*s,y+22*s,ink);L(x+4*s,y+15*s,x+16*s,y+15*s,ink);R(x+3*s,y+22*s,14*s,2*s,shade);R(x+24*s,y+16*s,12*s,24*s,mix(col,ink,.4));R(x+26*s,y+18*s,8*s,21*s,ink);R(x+32*s,y+28*s,2*s,2*s,h);R(x+23*s,y+39*s,14*s,2*s,shade)}
function windowAt(x,y,w=60,hh=85,col=h){R(x-4,y-4,w+8,hh+8,ink);R(x,y,w,hh,mix(d,a,.30));moon(x+w*.7,y+hh*.23,Math.min(w,hh)*.13,col);for(let i=0;i<10;i++)R(x+r0(i+400)*w,y+r0(i+450)*hh*.7,1,1,light);R(x,y+hh*.72,w,hh*.28,mid);R(x+w/2-1,y,3,hh,ink);R(x,y+hh/2,w,3,ink);outline(x,y,w,hh,col);R(x-7,y+hh,w+14,5,shade);R(x-7,y+hh,w+14,1,lit(shade,.4));R(x-3,y-3,2,hh+5,shade)}
function room(col=mid,floor=ink){for(let y=0;y<218;y+=4)R(0,y,180,4,mix(col,h,(.025+.13*q)*(y/218)));for(let y=12;y<212;y+=7)for(let x=(y%2)*3;x<180;x+=7)if(r0(x*11+y*23)>.72)R(x,y,1,1,mix(col,ink,.13));R(0,218,180,102,mix(floor,h,q*.055));R(0,213,180,5,mix(col,ink,.35));R(0,213,180,1,mix(col,h,.22));for(let j=0;j<42;j++){let x=r0(7120+j*2)*180,y=221+r0(7121+j*2)*98;R(x,y,3+r0(7100+j)*5,1,mix(floor,col,.065));}for(let y=244;y<320;y+=26){R(0,y,180,1,mix(floor,col,.20));for(let x=(y%3)*15;x<180;x+=38)R(x,y+1,1,Math.min(25,319-y),mix(floor,col,.10));}}
function bed(x,y,w=100,col=a){E(x+w*.5,y+20,w*.47,4,mix(ink,d,.3));R(x,y-30,7,42,ink);R(x+1,y-29,3,29,shade);R(x+w-5,y-10,5,22,ink);R(x,y,w,15,ink);R(x+4,y-6,w-9,10,h);R(x+9,y-11,22,9,white);R(x+12,y-10,15,2,mix(white,h,.22));R(x+33,y-5,w-39,13,col);R(x+33,y+3,w-39,3,shade);for(let j=0;j<4;j++)R(x+36+j*(w-43)/4,y-4,2,8,mix(col,h,.24));R(x+7,y+7,w-14,2,shade);R(x+4,y+14,5,8,ink);R(x+w-10,y+14,5,8,ink)}
function cup(x,y,s=1,col=h){E(x,y+12*s,15*s,3*s,ink);R(x-8*s,y-4*s,16*s,14*s,col);E(x,y-4*s,8*s,3*s,white);E(x,y-4*s,6*s,2*s,shade);outline(x+7*s,y,6*s,7*s,col);for(let i=0;i<2;i++)L(x-3+i*5+sin(t+i)*2,y-11*s,x-2+i*5,y-18*s,mix(h,d,.25))}
function table(x,y,w=75){R(x,y,w,6,shade);R(x+5,y+6,5,39,ink);R(x+w-10,y+6,5,39,ink)}
function rose(x,y,s=1,col=a){L(x,y,x-4*s,y+32*s,'#486f58',2*s);P([[x-3*s,y+20*s],[x-15*s,y+13*s],[x-10*s,y+26*s]],'#65895d');P([[x-3*s,y+25*s],[x+11*s,y+17*s],[x+4*s,y+29*s]],'#486f58');D(x,y,9*s,mix(col,ink,.35));D(x-4*s,y-2*s,5*s,col);D(x+3*s,y-3*s,5*s,mix(col,white,.2));D(x+2*s,y+3*s,4*s,col);D(x,y,3*s,shade)}
function guitar(x,y,s=1,col=a){D(x,y,12*s,ink);D(x,y-10*s,9*s,col);D(x,y+3*s,11*s,col);R(x-3*s,y-55*s,6*s,43*s,shade);R(x-5*s,y-60*s,10*s,8*s,col);D(x,y-2*s,4*s,ink);for(let i=-1;i<=1;i++)L(x+i,y-55*s,x+i,y+7*s,light);R(x-6*s,y+6*s,12*s,2*s,ink)}
function record(x,y,r=27){D(x,y,r,ink);for(let rr=r-2;rr>7;rr-=3){for(let z=0;z<TAU;z+=.08){const gleam=Math.max(0,cos(z-.7))*.5;R(x+cos(z)*rr,y+sin(z)*rr,1,1,mix(mid,h,gleam*.22));}}D(x,y,7,a);D(x,y,5,mix(a,h,.25));D(x,y,2,light);for(let j=0;j<4;j++){let z=t*.8+j*.17;R(x+cos(z)*(r-2),y+sin(z)*(r-2),1,1,mix(mid,h,.4));}}
function phone(x,y,s=1){R(x,y,32*s,58*s,ink);outline(x+1,y+1,30*s,56*s,h);R(x+3*s,y+6*s,26*s,43*s,mid);R(x+12*s,y+3*s,8*s,1,h);R(x+12*s,y+53*s,8*s,2,h);for(let i=0;i<4;i++){R(x+(i%2?9:5)*s,y+(10+i*9)*s,17*s,6*s,i%2?a:h);R(x+(i%2?11:7)*s,y+(12+i*9)*s,10*s,1,ink)}}
function heart(cx,cy,s=1,col=h){const rows=['0110110','1111111','1111111','0111110','0011100','0001000'];const left=cx-3.5*s,top=cy-3*s;rows.forEach((row,j)=>[...row].forEach((v,i)=>{if(v==='1'){const x=Math.round(left+i*s),y=Math.round(top+j*s);R(x,y,Math.round(left+(i+1)*s)-x,Math.round(top+(j+1)*s)-y,col)}}))}
function letter(x,y,w=60,hh=38){R(x,y,w,hh,h);outline(x,y,w,hh,shade);L(x,y,x+w/2,y+hh*.6,shade);L(x+w,y,x+w/2,y+hh*.6,shade);L(x,y+hh,x+w*.3,y+hh*.55,shade);L(x+w,y+hh,x+w*.7,y+hh*.55,shade);heart(x+w/2,y+hh*.5,1.2,a)}
function photo(x,y,w=42,hh=55,style=0){R(x+2,y+3,w,hh,ink);R(x,y,w,hh,white);R(x+3,y+3,w-6,hh-12,mid);R(x+4,y+4,w-8,Math.max(4,hh*.30),mix(mid,h,.2));D(x+w*.65,y+12,5,h);P([[x+3,y+hh-12],[x+w*.35,y+14],[x+w-3,y+hh-12]],shade);P([[x+3,y+hh-12],[x+w*.69,y+hh*.42],[x+w-3,y+hh-12]],ink);if(style){R(x+6,y+hh-24,w-12,3,a);star(x+w*.72,y+hh-28,2,light)}R(x+8,y+hh-5,w-16,1,shade)}
function rain(n=42){for(let i=0;i<n;i++){let x=mod(r0(i+800)*180-t*13,185),y=mod(r0(i+900)*320+t*(45+i%8*5),320);L(x,y,x-3,y+9,mix(h,d,.28),1)}}
function ocean(y=170){R(0,y,180,320-y,mid);for(let j=0;j<13;j++){let yy=y+7+j*10;for(let i=0;i<10;i++){let xx=mod(i*22+r0(j*40+i)*12+t*(j%2?1:-1)*4,190)-5;R(xx,yy+sin(i+t+j)*2,6+j*.7,1+j%2,mix(shade,h,j%3===0?.55:.12));if((i+j)%3===0)R(xx+2,yy+2+sin(i+t+j)*2,3+j*.38,1,mix(mid,ink,.22))}}}
function boat(x,y,s=1){E(x,y+8*s,19*s,2*s,mix(mid,h,.26));P([[x-18*s,y],[x+18*s,y],[x+10*s,y+7*s],[x-11*s,y+7*s]],ink);R(x-14*s,y+1*s,29*s,2*s,shade);R(x,y-31*s,2*s,31*s,h);P([[x-2*s,y-30*s],[x-2*s,y-3*s],[x-17*s,y-3*s]],h);P([[x-2*s,y-25*s],[x-2*s,y-3*s],[x-9*s,y-3*s]],mix(h,white,.4));P([[x+3*s,y-26*s],[x+3*s,y-3*s],[x+16*s,y-3*s]],a);P([[x+3*s,y-16*s],[x+3*s,y-3*s],[x+11*s,y-3*s]],mix(a,h,.3));}
function bridge(y=215){R(0,y,180,7,ink);for(let x of [15,158]){R(x,y-60,7,64,shade);R(x-3,y-64,13,4,h)}for(let x=16;x<=162;x+=3){let yy=y-56+sin((x-16)/146*Math.PI)*44;R(x,yy,3,2,h);if(x%12===4)L(x,yy,x,y,shade)}R(0,y-3,180,3,h)}
function clock(x,y,r=24,fast=1){D(x,y,r+3,ink);D(x,y,r,white);D(x,y,r-2,mix(h,white,.7));for(let i=0;i<12;i++){let z=i*TAU/12;L(x+cos(z)*r*.8,y+sin(z)*r*.8,x+cos(z)*r*.94,y+sin(z)*r*.94,shade,2)}let z=t*.09*fast;L(x,y,x+cos(z)*r*.78,y+sin(z)*r*.78,ink,2);L(x,y,x+cos(z*.14+1)*r*.55,y+sin(z*.14+1)*r*.55,a,3);D(x,y,2,ink)}
function curtain(open=.5,col=a){for(let side of [0,1])for(let y=0;y<320;y+=2){let width=13+(1-open)*43+sin(y/H*Math.PI)*12;for(let x=0;x<width;x+=3)R(side?180-x-3:x,y,3,2,mix(col,ink,.25+.3*(x%9===0)))}R(0,0,180,8,shade);for(let x=0;x<180;x+=7)D(x,8,4,shade)}
function spotlight(x,y,tx,ty,col=h,wide=30){P([[x-2,y],[x+2,y],[tx+wide,ty],[tx-wide,ty]],mix(d,col,.19));R(x-5,y-4,10,7,shade);R(x-2,y+2,4,2,col)}
function dancefloor(y=220){for(let j=0;j<7;j++)for(let i=0;i<9;i++){let yy=y+j*j*3,x=90+(i-4.5)*(12+j*4);R(x,yy,10+j*4,Math.max(3,j*4),mix(mid,(i+j+Math.floor(t*2))%3===0?h:a,.25+b*.13))}}
function starsBurst(x,y){for(let i=0;i<16;i++){let z=i*TAU/16,rr=20+mod(t*6+i*5,50);star(x+cos(z)*rr,y+sin(z)*rr,1+(i%4===0),i%2?h:a)}}
function web(x,y,r=44){for(let i=0;i<8;i++){let z=i*TAU/8;L(x,y,x+cos(z)*r,y+sin(z)*r,shade);for(let j=1;j<5;j++){let zz=(i+1)*TAU/8,rr=r*j/4;L(x+cos(z)*rr,y+sin(z)*rr,x+cos(zz)*rr,y+sin(zz)*rr,h)}}}
function spider(x,y,s=1){for(let i=0;i<4;i++){let v=i*4*s;for(let side of [-1,1]){L(x+side*5*s,y+v-7*s,x+side*(12*s+v*.25),y-9*s+v,shade,2);L(x+side*(12*s+v*.25),y-9*s+v,x+side*19*s,y+3*s+v,shade,2)}}D(x,y+3*s,8*s,h);D(x,y-6*s,5*s,light);D(x-2*s,y+1*s,3*s,white)}
function wings(x,y,s=1){for(let side of [-1,1])for(let i=0;i<6;i++){let xx=x+side*(7+i*5)*s,yy=y-i*3*s;P([[x,y+16*s],[xx,yy-12*s],[xx+side*8*s,yy-17*s],[xx+side*5*s,yy+5*s],[x,y+23*s]],mix(h,white,.15+i*.12))}}
function screen(x,y,w=65,hh=48){R(x-3,y-3,w+6,hh+8,ink);R(x,y,w,hh,mid);outline(x,y,w,hh,a);R(x,y,w,5,shade);for(let j=0;j<3;j++)R(x+w-4-j*5,y+1,3,3,h);for(let j=0;j<5;j++)R(x+5,y+9+j*6,8+r0(j+21)*(w-16),2,j%2?h:a);R(x+w*.45,y+hh+4,w*.1,8,ink);R(x+w*.3,y+hh+11,w*.4,3,shade)}
function bird(x,y,s=1){L(x-6*s,y-2*s,x,y+2*s,h,2*s);L(x,y+2*s,x+6*s,y-2*s,h,2*s)}
function flowers(y=285,n=18){for(let i=0;i<n;i++){let x=r0(i+650)*180,yy=y+r0(i+670)*35;L(x,yy,x,yy-7,'#496c57');D(x,yy-8,2,i%2?h:a)}}
function piano(x,y,w=120){R(x,y,w,35,ink);for(let i=0;i<14;i++){let xx=x+i*w/14;R(xx+1,y+2,w/14-2,29,(i+Math.floor(t*3))%14===0?h:white);if(i%7!==2&&i%7!==6)R(xx+w/14*.7,y+1,w/14*.55,17,ink)}}
function car(x,y,s=1,col=a){E(x,y+9*s,24*s,4*s,ink);R(x-22*s,y-8*s,44*s,14*s,col);R(x-21*s,y-7*s,42*s,3*s,mix(col,h,.38));P([[x-14*s,y-8*s],[x-7*s,y-20*s],[x+11*s,y-20*s],[x+20*s,y-8*s]],shade);P([[x-11*s,y-9*s],[x-5*s,y-17*s],[x+9*s,y-17*s],[x+16*s,y-9*s]],mid);R(x+2*s,y-17*s,2*s,8*s,ink);R(x-20*s,y+1*s,40*s,3*s,mix(col,ink,.52));for(let i of [-13,14]){D(x+i*s,y+5*s,6*s,ink);D(x+i*s,y+5*s,3*s,shade);D(x+i*s,y+5*s,1*s,h)}R(x+19*s,y-5*s,4*s,4*s,lit(h,.9));R(x-22*s,y-5*s,4*s,3*s,lit(a,.8));R(x-1*s,y-3*s,6*s,1,shade)}
function portal(x,y,rx=37,ry=58){for(let i=0;i<5;i++)for(let z=0;z<TAU;z+=.045){let r=rx+i*2+sin(z*5+t*2)*2;R(x+cos(z)*r,y+sin(z)*(ry+i*2),2,2,i%2?a:h)}}
function comet(x,y,s=1){for(let i=20;i>=0;i--)D(x-i*2*s,y+i*1.2*s,Math.max(1,(5-i*.23)*s),mix(h,d,i/22));D(x,y,5*s,white);star(x,y,6*s,light)}
function book(x,y,w=74){P([[x,y],[x+w/2,y+7],[x+w,y],[x+w,y+43],[x+w/2,y+49],[x,y+43]],white);L(x+w/2,y+8,x+w/2,y+49,shade);for(let j=0;j<6;j++){R(x+5,y+9+j*5,w/2-10,1,shade);R(x+w/2+5,y+10+j*5,w/2-10,1,shade)}}
// Authored compositions. Motion is evaluated against the audio clock; no random frame-to-frame jitter.
function pillow(x,y,w,col){R(x+3,y+3,w,18,ink);R(x,y,w,18,col);R(x+2,y+2,w-4,2,light);R(x+3,y+14,w-6,2,shade);}
function chair(x,y,s){R(x,y-31*s,20*s,31*s,shade);R(x+3*s,y-27*s,14*s,19*s,mid);R(x-3*s,y,26*s,6*s,h);R(x,y+6*s,3*s,23*s,ink);R(x+17*s,y+6*s,3*s,23*s,ink)}
function bench(x,y,w){for(let j=0;j<3;j++)R(x,y+j*5,w,4,j%2?shade:a);R(x,y+17,w,6,h);for(let z of [x+5,x+w-9])R(z,y+22,4,16,ink)}
function fence(x,y,w){for(let i=0;i<w;i+=13){R(x+i,y-10,4,24,shade);R(x+i-1,y-12,6,3,h)}R(x,y,w,3,h);R(x,y+10,w,3,shade)}
function speaker(x,y,w,hh){R(x,y,w,hh,ink);outline(x,y,w,hh,shade);R(x+2,y+2,w-4,hh-4,mix(ink,mid,.32));R(x+2,y+2,2,hh-4,shade);D(x+w/2,y+hh*.67,w*.35,shade);D(x+w/2,y+hh*.67,w*.27,mid);D(x+w/2,y+hh*.67,w*(.09+.035*b+.025*q),lit(h,.8));D(x+w/2,y+hh*.22,w*.16,mid);D(x+w/2,y+hh*.22,w*.06,h);R(x+4,y+hh-6,w-8,2,a)}
function comicCard(x,y,w,hh,v){R(x,y,w,hh,ink);R(x+3,y+3,w-6,hh-6,v?a:h);for(let j=0;j<8;j++)L(x+5,y+8+j*6,x+w-7,y+3+j*6,shade);P([[x+w*.55,y+9],[x+w*.25,y+hh*.55],[x+w*.5,y+hh*.55],[x+w*.37,y+hh-10],[x+w*.79,y+hh*.38],[x+w*.55,y+hh*.38]],light)}
function keyboard(x,y,w){R(x,y,w,14,ink);for(let j=0;j<3;j++)for(let i=0;i<12;i++)R(x+2+i*(w-4)/12,y+2+j*4,Math.max(2,(w-4)/12-1),2,shade);R(x+w*.3,y+11,w*.4,2,h)}
function magnet(x,y,dir,col){R(x,y,38,14,col);R(x,y+32,38,14,col);R(x+(dir===1?0:25),y+12,13,23,col);R(x+(dir===1?30:0),y,8,14,h);R(x+(dir===1?30:0),y+32,8,14,light)}
function trumpet(x,y,s){R(x,y,52*s,5*s,h);R(x+12*s,y-4*s,28*s,17*s,a);R(x+15*s,y,22*s,9*s,ink);for(let j=0;j<3;j++){R(x+(19+j*7)*s,y-11*s,3*s,16*s,shade);R(x+(17+j*7)*s,y-12*s,7*s,3*s,h)}P([[x+43*s,y],[x+62*s,y-12*s],[x+62*s,y+16*s],[x+43*s,y+5*s]],h)}
function console(x,y,w){R(x,y,w,25,ink);outline(x,y,w,25,h);for(let j=0;j<4;j++)R(x+4+j*10,y+5,6,4,j%2?a:h);R(x+4,y+15,w-8,3,shade)}
function camera(x,y,w){R(x,y,w,35,ink);R(x+8,y-6,20,8,shade);R(x+w-17,y+4,11,5,h);D(x+w*.55,y+18,15,shade);D(x+w*.55,y+18,11,mid);D(x+w*.55,y+18,5,h);star(x+w*.55-4,y+14,2,white)}
function vase(x,y,w){P([[x+w*.25,y],[x+w*.75,y],[x+w*.67,y+10],[x+w,y+40],[x,y+40],[x+w*.33,y+10]],shade);R(x+5,y+28,w-10,4,h);rose(x+w*.5,y-27,.95,a)}
function telescope(x,y,s){L(x,y+9*s,x-21*s,y+49*s,shade,3*s);L(x,y+9*s,x+21*s,y+49*s,shade,3*s);P([[x-22*s,y-4*s],[x+23*s,y-24*s],[x+28*s,y-12*s],[x-17*s,y+8*s]],h);R(x+20*s,y-24*s,8*s,14*s,ink);D(x,y+5*s,5*s,shade)}
function mirror(x,y,w,hh){R(x,y,w,hh,ink);R(x+3,y+3,w-6,hh-6,mid);outline(x,y,w,hh,h);L(x+5,y+hh-10,x+w-5,y+8,shade,3);L(x+w*.45,y+4,x+w*.57,y+hh*.4,light);L(x+w*.57,y+hh*.4,x+w*.28,y+hh-4,light)}
function ring(x,y,rx,ry,col,w=2){for(let z=0;z<TAU;z+=.035)R(x+cos(z)*rx,y+sin(z)*ry,w,w,col)}
function glowRays(x,y,col,n=10){for(let i=0;i<n;i++){let z=i*TAU/n+t*.045;L(x+cos(z)*25,y+sin(z)*25,x+cos(z)*(64+b*9),y+sin(z)*(83+b*9),col,2)}}
function reflection(x,y,w,col){for(let j=0;j<8;j++){let ww=w*(1-j/10);R(x-ww/2+sin(t+j)*3,y+j*6,ww,2+(j%2),mix(col,d,j*.075))}}
function burstPetals(x,y){for(let i=0;i<25;i++){let z=i*2.399+t*.12,rr=15+mod(t*6+i*9,83);E(x+cos(z)*rr,y+sin(z)*rr,2+i%3,2,i%2?h:a)}}


function desk(x,y,w){P([[x,y],[x+w,y],[x+w+2,y+4],[x-2,y+4]],mix(shade,h,.22));R(x,y+4,w,5,shade);R(x,y+4,w,1,h);R(x+5,y+9,5,28,ink);R(x+w-10,y+9,5,28,ink);R(x+6,y+10,1,26,mid);R(x+w-9,y+10,1,26,mid)}
function beam(x,y,X,Y,w,col){c.save();c.globalAlpha=.07+q*.21+.015*sin(t*.65);P([[x-2,y],[x+2,y],[X+w,Y],[X-w,Y]],col);c.restore()}
function warm(col){return mix(col,white,cl(q*.46+b*.06));}
function glint(x,y,n=3){star(x,y,n,warm(h))}
function tableLamp(x,y,s=1){R(x-2*s,y-34*s,4*s,34*s,shade);E(x,y,10*s,3*s,ink);P([[x-8*s,y-51*s],[x+8*s,y-51*s],[x+15*s,y-32*s],[x-15*s,y-32*s]],warm(h))}
function player(x,y,w){R(x,y,w,28,ink);outline(x,y,w,28,shade);E(x+w*.37,y+13,w*.29,10,mid);E(x+w*.37,y+13,w*.24,7,ink);D(x+w*.37,y+13,3,a);L(x+w*.82,y+4,x+w*.65,y+17,h,2);R(x+w*.82,y+3,5,4,shade);R(x+w-9,y+22,4,2,warm(h));R(x+w*.37+cos(t*2)*w*.2,y+13+sin(t*2)*6,2,1,h)}
function perfume(x,y,s=1){R(x-3*s,y-29*s,6*s,7*s,light);R(x-7*s,y-22*s,14*s,5*s,shade);R(x-10*s,y-17*s,20*s,17*s,a);outline(x-10*s,y-17*s,20*s,17*s,h);R(x-6*s,y-12*s,12*s,5*s,warm(h))}
function vanity(x,y,w,hh){R(x,y,w,hh,ink);R(x+7,y+7,w-14,hh-14,mid);P([[x+10,y+hh-10],[x+w-12,y+10],[x+w-26,y+10],[x+10,y+hh-34]],shade);for(let i=0;i<7;i++){D(x+3,y+6+i*(hh-12)/6,3,warm(h));D(x+w-4,y+6+i*(hh-12)/6,3,warm(h))}}
function mask(x,y){P([[x-24,y-7],[x-4,y-4],[x,y],[x+4,y-4],[x+24,y-7],[x+17,y+12],[x+6,y+12],[x,y+5],[x-6,y+12],[x-17,y+12]],ink);E(x-11,y+2,6,3,h);E(x+11,y+2,6,3,h)}
function discoBall(x,y,r){L(x,0,x,y-r,shade,2);D(x,y,r,ink);for(let i=-r+3;i<r;i+=5)for(let j=-r+3;j<r;j+=5)if(i*i+j*j<(r-3)**2)R(x+i,y+j,4,4,mix(mid,warm(h),sin(i+j+t*3)>.1?.9:.35))}
function rear(x,y,s,col){P([[x-23*s,y+9*s],[x-23*s,y-7*s],[x-13*s,y-18*s],[x+13*s,y-18*s],[x+23*s,y-7*s],[x+23*s,y+9*s]],ink);R(x-19*s,y-7*s,38*s,14*s,col);R(x-11*s,y-15*s,22*s,7*s,mid);R(x-18*s,y-4*s,8*s,4*s,warm('#e34c63'));R(x+10*s,y-4*s,8*s,4*s,warm('#e34c63'));R(x-5*s,y+1*s,10*s,3*s,white);R(x-18*s,y+8*s,6*s,5*s,ink);R(x+12*s,y+8*s,6*s,5*s,ink)}
function flatBook(x,y,w){P([[x,y],[x+w/2,y+3],[x+w,y],[x+w+2,y+17],[x+w/2,y+22],[x-2,y+17]],white);L(x+w/2,y+3,x+w/2,y+22,shade);for(let j=0;j<4;j++){R(x+5,y+4+j*3,w/2-10,1,shade);R(x+w/2+5,y+4+j*3,w/2-10,1,shade)}}
function win(x,y,w,hh,fn){R(x-4,y-4,w+8,hh+8,ink);c.save();c.beginPath();c.rect(x,y,w,hh);c.clip();R(x,y,w,hh,mid);fn();c.restore();R(x+w/2-1,y,3,hh,ink);R(x,y+hh*.5,w,3,ink);outline(x,y,w,hh,shade);R(x-7,y+hh,w+14,4,shade)}
function petals(x,y,w,hh,n){for(let i=0;i<n;i++)E(x+mod(r0(i+90)*w+sin(t+i)*3,w),y+mod(r0(i+200)*hh+t*(4+q*7),hh),2,1.5,i%2?h:a)}
function screenHeart(x,y,w,hh){screen(x,y,w,hh);R(x+4,y+7,w-8,hh-11,ink);let s=Math.min((w-12)/8,(hh-15)/7);heart(x+w/2,y+hh/2,s,warm(a));}
function pot(x,y){P([[x-12,y-16],[x+12,y-16],[x+8,y],[x-8,y]],shade);for(let i=0;i<3;i++)rose(x+(i-1)*8,y-36-(i%2)*7,.6,i%2?h:a)}
function note(x,y){E(x,y,4,3,h);R(x+3,y-16,2,16,h);P([[x+4,y-16],[x+13,y-12],[x+13,y-9],[x+4,y-13]],h)}
function shimmer(x,y,w,n=8){for(let i=0;i<n;i++){let ww=w*(1-i/(n+2));R(x-ww/2+sin(t+i)*3,y+i*5,ww,1+q,mix(h,d,.4+i*.035-q*.2))}}
function barWindow(x,y,w,hh){R(x,y,w,hh,ink);R(x+4,y+4,w-8,hh-8,warm(h));for(let j=0;j<6;j++)R(x+4,y+5+j*(hh-8)/6,w-8,2+q*2,shade)}
function gems(x,y,w,hh){R(x,y,w,hh,ink);outline(x,y,w,hh,shade);let xx=x+w/2,yy=y+hh*.5;P([[xx-14,yy],[xx,yy-19],[xx+14,yy],[xx,yy+22]],warm(h));L(xx-14,yy,xx+14,yy,white);L(xx,yy-19,xx,yy+22,shade);if(q>.5)glint(xx,yy-19,3)}


// Props have a physical support, and illumination is restricted to its source or receiver.
const lit=(base,amount=.5)=>mix(base,h,cl(amount*(.025+.075*(.5+.5*sin(t*.62))+q*.65+chorusLift*.34+entry*.10+b*.075)));
function surface(x,y,w,hh=45){R(x,y,w,6,shade);R(x+3,y+6,w-6,hh,ink);R(x+7,y+10,w-14,hh-8,mid);R(x+12,y+14,w-24,2,shade);R(x+7,y+hh-1,w-14,2,mix(mid,ink,.48));R(x+4,y+1,w-8,1,mix(shade,h,.28));for(let j=0;j<3;j++)R(x+8+j*5,y+hh-6,2,2,mix(mid,shade,.35));for(let j=0;j<3;j++)if(22+j*8<hh-2)R(x+12,y+22+j*8,w-24,1,mix(mid,shade,.16));}
function glowWindow(x,y,w,hh){R(x-3,y-3,w+6,hh+6,ink);R(x,y,w,hh,lit(mid,.84));R(x+w/2-1,y,3,hh,ink);R(x,y+hh/2, w,3,ink);R(x-5,y+hh,w+10,4,shade)}
function lightbulb(x,y,r=3){D(x,y,r+2,mix(d,h,.2+.35*q));D(x,y,r,lit(shade,.95));}
function vanity(x,y,w,hh){R(x,y,w,hh,ink);R(x+6,y+6,w-12,hh-12,mid);outline(x+6,y+6,w-12,hh-12,shade);P([[x+10,y+hh-16],[x+w-10,y+12],[x+w-10,y+24],[x+10,y+hh-4]],mix(mid,h,.13+q*.27));for(let yy=y+8;yy<y+hh;yy+=15){lightbulb(x+2,yy);lightbulb(x+w-3,yy)}for(let xx=x+15;xx<x+w-10;xx+=16)lightbulb(xx,y+2)}
function perfume(x,y,s=1){R(x-8*s,y-19*s,16*s,19*s,a);outline(x-8*s,y-19*s,16*s,19*s,light);R(x-4*s,y-24*s,8*s,5*s,shade);R(x-5*s,y-28*s,10*s,4*s,h);R(x-5*s,y-14*s,3*s,9*s,light);R(x-4*s,y-8*s,9*s,3*s,shade)}
function lipstick(x,y){R(x,y-17,7,17,ink);R(x,y-20,7,4,h);R(x+1,y-29,5,9,a);R(x+1,y-30,3,2,a)}
function cuffs(x,y,s=1){for(const dir of [-1,1]){let xx=x+dir*19*s;E(xx,y,14*s,12*s,ink);E(xx,y-1*s,13*s,11*s,'#b6b7c3');E(xx,y-1*s,9*s,7*s,shade);E(xx,y-1*s,8*s,6*s,ink);R(xx-9*s,y-9*s,10*s,2*s,white);R(xx-dir*12*s,y-5*s,7*s,10*s,'#858597');R(xx-dir*12*s,y-5*s,7*s,2*s,light);R(xx-dir*9*s,y-1*s,2*s,3*s,ink);}for(let i=0;i<3;i++){let xx=x-6*s+i*6*s;E(xx,y+1*s,4*s,2.8*s,'#c5c4cd');E(xx,y+1*s,2*s,1*s,shade);}star(x-23*s,y-10*s,1+b*.7,white)}
function garmentBrief(x,y,s=1,col=a){const pts=[[x-21*s,y],[x+21*s,y],[x+17*s,y+10*s],[x+9*s,y+12*s],[x+5*s,y+23*s],[x-5*s,y+23*s],[x-9*s,y+12*s],[x-17*s,y+10*s]];P(pts,ink);P([[x-19*s,y+2*s],[x+19*s,y+2*s],[x+15*s,y+8*s],[x+7*s,y+10*s],[x+4*s,y+21*s],[x-4*s,y+21*s],[x-7*s,y+10*s],[x-15*s,y+8*s]],col);R(x-17*s,y+3*s,34*s,2*s,mix(col,white,.48));L(x-12*s,y+8*s,x-4*s,y+19*s,shade);L(x+12*s,y+8*s,x+4*s,y+19*s,shade);}
function garmentTop(x,y,s=1,col=a){for(let side of [-1,1]){L(x+side*9*s,y-14*s,x+side*16*s,y+3*s,col,2*s);P([[x+side*2*s,y+6*s],[x+side*9*s,y-2*s],[x+side*18*s,y+1*s],[x+side*21*s,y+12*s],[x+side*16*s,y+16*s],[x+side*6*s,y+15*s]],col);L(x+side*6*s,y+15*s,x+side*17*s,y+15*s,mix(col,white,.45),1);L(x+side*20*s,y+12*s,x+side*27*s,y+9*s,shade,2*s);}R(x-3*s,y+10*s,6*s,4*s,col);}
function turntable(x,y,w=96){R(x,y,w,35,ink);outline(x,y,w,35,shade);record(x+28,y+17,15);R(x+w-19,y+6,12,18,shade);L(x+w-13,y+10,x+42,y+21,h,2);R(x+w-11,y+26,5,3,lit(a,.8));}
function jukebox(x,y,w=76,hh=116){D(x+w/2,y+w/2,w/2,ink);R(x,y+w/2,w,hh-w/2,ink);D(x+w/2,y+w/2,w/2-5,lit(a,.7));R(x+5,y+w/2,w-10,hh-w/2-5,lit(a,.7));D(x+w/2,y+w/2,w/2-12,mid);R(x+12,y+w/2,w-24,hh-w/2-13,mid);record(x+w/2,y+w/2,16);R(x+17,y+hh-39,w-34,21,ink);for(let i=0;i<5;i++)R(x+20+i*(w-40)/5,y+hh-36,3,15,lit(shade,.8));}
function floorLights(y){for(let j=0;j<5;j++){const yy=y+j*13;for(let i=0;i<7;i++){let x=4+i*26;R(x,yy,22,10,mix(mid,(i+j)%2?a:h,.09+.05*(.5+.5*sin(t*.7+i+j))+q*.55*(.7+.3*sin(t*2+i+j))))}}}
function skyRain(y0=0,y1=185,n=32){for(let i=0;i<n;i++){let x=mod(r0(i+800)*180-t*13,180),y=y0+mod(r0(i+900)*320+t*(32+i%8*4),Math.max(1,y1-y0-8));L(x,y,x-2,y+7,mix(h,d,.48),1)}}
function litHouse(x,y,s=1){house(x,y,s,shade);glowWindow(x+5*s,y+8*s,11*s,12*s);}
function globe(x,y,r){D(x,y,r+5,mix(d,a,.20+q*.35));D(x,y,r,lit(a,.54));for(let j=0;j<7;j++){let xx=x+(r0(j+320)-.5)*r*1.1,yy=y+(r0(j+350)-.5)*r*1.1;P([[xx-r*.12,yy],[xx-r*.05,yy-r*.15],[xx+r*.13,yy-r*.08],[xx+r*.11,yy+r*.12],[xx-r*.03,yy+r*.15]],mix(a,d,.53));}ring(x,y,r-1,r*.34,shade,1);ring(x,y,r*.35,r-1,shade,1);R(x-3,y+r,6,Math.max(14,249-y-r),shade);E(x,250,r*.64,4,ink);}
function openDoor(x,y,w,hh){R(x-4,y-4,w+8,hh+8,ink);R(x,y,w,hh,lit(shade,.92));let dw=Math.max(8,w*(1-.78*q));R(x,y,dw,hh,mid);R(x+dw-5,y+hh*.56,3,4,h);P([[x+dw,y+hh],[x+w,y+hh],[Math.min(180,x+w+28*q),320],[Math.max(0,x+dw-28*q),320]],mix(d,h,.12+.25*q));}
function flashLocal(x,y,r){star(x,y,2+q*3,lit(shade,.9));if(q>.5)star(x+r*.4,y+r*.3,2,light)}
function moonWater(x,y,r,water=178){moon(x,y,r,lit(h,.35));ocean(water);for(let j=0;j<11;j++){let ww=(8+j*5)*(1+q*.8);R(x-ww/2+sin(t+j)*4,water+5+j*9,ww,1+j%2,mix(mid,h,.22+.48*q));}}
function wallLamp(x,y){R(x-4,y-6,8,25,shade);R(x-3,y+9,12,4,ink);P([[x-8,y],[x+8,y],[x+14,y+16],[x-14,y+16]],lit(a,.82));R(x-10,y+16,20,2,lit(h,.65));}
function lampGlow(x,y){R(x-12,y,24,3,shade);P([[x-8,y],[x+8,y],[x+15,y+16],[x-15,y+16]],lit(a,.72));R(x-1,y+16,3,24,ink);R(x-10,y+40,20,3,shade);}
function hangingMirror(x,y,w,hh){R(x,y,w,hh,ink);R(x+4,y+4,w-8,hh-8,mix(mid,h,.15+q*.2));outline(x+4,y+4,w-8,hh-8,shade);P([[x+8,y+hh-17],[x+w-8,y+8],[x+w-8,y+17],[x+8,y+hh-8]],mix(mid,h,.18+q*.4));}
function arch(x,y,w,hh){D(x+w/2,y+w/2,w/2,ink);D(x+w/2,y+w/2,w/2-5,lit(a,.8));R(x,y+w/2,w,hh-w/2,ink);R(x+5,y+w/2,w-10,hh-w/2,lit(a,.75));D(x+w/2,y+w/2,w/2-12,d);R(x+12,y+w/2,w-24,hh-w/2,d);}
function terminal(x,y,w,hh){R(x,y,w,hh,ink);outline(x,y,w,hh,shade);R(x+2,y+2,w-4,2,mix(shade,h,.35));R(x+5,y+5,w-10,hh-10,mid);R(x+6,y+6,w-12,5,a);for(let j=0;j<3;j++)R(x+w-9-j*5,y+7,3,3,mix(a,h,.55));for(let i=0;i<4&&16+i*7+2<hh-10;i++)R(x+10,y+16+i*7,Math.max(3,(w-22)*(.4+.5*r0(i+20))),2,lit(shade,.9));for(let i=0;i<Math.floor((hh-20)/5);i++)R(x+6,y+12+i*5,w-12,1,mix(mid,ink,.20));R(x+10+mod(t*9,w-23),y+hh-12,4,3,h);R(x+w-8,y+hh-4,2,2,lit(h,.9));}
function tableBook(x,y,w){book(x,y,w)}
function flask(x,y,sz,col){const top=y-70*sz;R(x-5*sz,top,10*sz,29*sz,light);P([[x-5*sz,top+26*sz],[x-23*sz,y],[x+23*sz,y],[x+5*sz,top+26*sz]],shade);let fy=y-(10+18*q)*sz;let fw=Math.max(7,23-(y-fy)/sz*.36)*sz;P([[x-fw,fy],[x-20*sz,y-3*sz],[x+20*sz,y-3*sz],[x+fw,fy]],col);for(let i=0;i<6;i++){let yy=y-5*sz-mod(t*8+i*5,(y-fy)-2);let xx=x+sin(i*4)*Math.max(2,fw-4);D(xx,yy,1+i%2,light)}R(x-4*sz,top+3,2,20*sz,h);}
function roadFixed(y=200){P([[79,y],[101,y],[180,320],[0,320]],ink);L(79,y,0,319,mid,2);L(101,y,179,319,mid,2);for(let i=0;i<7;i++){let k=i/7,yy=y+(320-y)*k*k;R(89-k*2,yy,2+k*4,2+k*7,lit(shade,.55));}}
// Small contextual assets: bounded reflections, bulbs, illuminated display and grounded props.
function clipBox(x,y,w,hh,fn){c.save();c.beginPath();c.rect(x,y,w,hh);c.clip();fn();c.restore()}
function shine(x,y,w,hh,period=3,co=h){clipBox(x,y,w,hh,()=>{let v=mod(t/period,1);let xx=x-w*.3+v*w*1.6;P([[xx,y],[xx+3,y],[xx-hh*.28+3,y+hh],[xx-hh*.28,y+hh]],mix(mid,co,.30+.32*q));})}
function bulbRow(x,y,n,step=7,period=2.8){for(let j=0;j<n;j++){R(x+j*step,y,3,2,ink);R(x+j*step+1,y,2,2,pulseColor(shade,light,period,j*.6))}}
function led(x,y,col=h,period=2){R(x-1,y-1,4,4,ink);R(x,y,2,2,pulseColor(shade,col,period))}
function candle(x,y,s=1){E(x,y,6*s,2*s,ink);R(x-3*s,y-14*s,6*s,14*s,white);R(x-3*s,y-14*s,6*s,1,h);L(x,y-14*s,x,y-17*s,ink);D(x+sin(t*3)*s*.6,y-20*s,(2+drift(1.7)*.9+q*.7)*s,'#e5a25d');R(x,y-21*s,1,2,white)}
function meter(x,y,w,hh,n=7){R(x,y,w,hh,ink);let cw=w/n;for(let j=0;j<n;j++){let v=.12+.46*drift(1.6+j*.23,j)+.22*q+.11*b;let z=Math.max(2,(hh-3)*v);R(x+j*cw+1,y+hh-1-z,Math.max(1,cw-2),z,pulseColor(shade,j%2?h:a,2.5,j))}}
function ripple(x,y,w,period=3){for(let j=0;j<4;j++){let v=mod(t/period+j/4,1),ww=w*(.25+.75*v);E(x,y+v*5,ww,1,pulseColor(mid,h,period,j))}}
function frameDetail(x,y,w,hh){outline(x,y,w,hh,shade);R(x+1,y+1,w-2,1,mix(shade,h,.42));R(x+1,y+hh-2,w-2,1,ink)}
function dial(x,y,r,period=8){D(x,y,r,ink);D(x,y,r-2,shade);let ang=t*TAU/period;L(x,y,x+cos(ang)*(r-3),y+sin(ang)*(r-3),h);D(x,y,1,light)}

// 7.20: authored material studies, perspective and atmosphere. Only used by revised scenes.
function dusk(top,lower,ground,at=210){sky(top,lower,at);R(0,at,W,H-at,ground);}
function glow(x,y,rx,ry,col,amount=.3){c.save();for(let i=5;i>0;i--){c.globalAlpha=amount*(.035+i*.013);E(x,y,rx*i/5,ry*i/5,col)}c.restore();}
function groundShadow(x,y,rx,ry=4){E(x,y,rx,ry,mix(ink,d,.22));}
function timber(x,y,w,hh,col=shade){R(x,y,w,hh,col);for(let j=5;j<hh;j+=11)R(x,y+j,w,1,mix(col,ink,.26));R(x,y,w,2,mix(col,h,.3));}
function shelfGround(x,y,w,hh=12){R(x,y,w,hh,ink);R(x,y,w,3,mix(shade,h,.38));R(x+2,y+3,w-4,hh-3,shade);}
function drape(x,y,w,hh,col,side=1){for(let i=0;i<w;i+=3){const f=i/w;P([[x+i,y],[x+i+3,y],[x+i+3+side*9*sin(f*Math.PI),y+hh],[x+i+side*9*sin(f*Math.PI),y+hh]],mix(col,ink,.12+.24*(i%9===0)));}R(x,y,w,3,mix(col,h,.28));}
function foliage(x,y,s=1,col='#536c61'){R(x-2*s,y-37*s,4*s,37*s,ink);for(let j=0;j<5;j++){const side=j%2?1:-1,yy=y-8*s-j*6*s;E(x+side*8*s,yy,9*s,4*s,mix(col,h,.1+.12*drift(6,j)));}E(x,y-39*s,5*s,8*s,col)}
function bloom(x,y,r,col){for(let j=0;j<5;j++){let z=j*TAU/5;D(x+cos(z)*r*.65,y+sin(z)*r*.65,r*.62,col)}D(x,y,r*.30,lit(h,.65));}
function flowerBed(y,n=16){for(let j=0;j<n;j++){let x=7+r0(1700+j)*166,yy=y+r0(1800+j)*30,sz=2+r0(1900+j)*2;L(x,yy,x+sin(t*.8+j)*2,yy-9,'#526a56');bloom(x+sin(t*.8+j)*2,yy-10,sz,mix(a,h,r0(2000+j)));}}
function citySilhouette(y,col,seed=0){for(let j=0;j<11;j++){let x=j*17-3,hh=20+r0(j+3000+seed)*45;let yy=y-hh;R(x,yy,14,hh,col);R(x+1,yy+1,12,1,mix(col,h,.12));R(x+12,yy+2,2,hh-2,mix(col,ink,.3));if(j%3===1){R(x+5,yy-4,5,4,col);R(x+7,yy-9,1,5,mix(col,h,.22));}for(let k=0;k<4;k++)for(let v=0;v<2;v++)if(yy+6+k*8+3<y&&r0(3400+j*13+k*3+v)>.42){R(x+3+v*6,yy+6+k*8,2,3,mix(col,h,.18+.35*drift(5,j+k)));R(x+3+v*6,yy+9+k*8,3,1,mix(col,ink,.24));}}}
function archGlass(x,y,w,hh){R(x-4,y-4,w+8,hh+8,ink);R(x,y,w,hh,mid);}
function sofa(x,y,w,col){groundShadow(x+w/2,y+45,w*.49);R(x+6,y-23,w-12,39,ink);R(x+10,y-20,w-20,34,mix(col,ink,.15));R(x,y+5,w,30,col);R(x,y+2,12,31,mix(col,ink,.22));R(x+w-12,y+2,12,31,mix(col,ink,.22));R(x+13,y+12,w-26,12,mix(col,h,.30));R(x+w/2,y+13,1,12,shade);R(x+8,y+33,w-16,4,shade);R(x+10,y+37,6,8,ink);R(x+w-16,y+37,6,8,ink);}
function cushion(x,y,w,hh,col){R(x+2,y+3,w,hh,ink);R(x,y,w,hh,col);R(x+2,y+2,w-4,2,mix(col,h,.45));R(x+2,y+hh-3,w-4,2,mix(col,ink,.35));}
function hangingLight(x,y,s=1){L(x,0,x,y,shade,2);P([[x-13*s,y],[x+13*s,y],[x+21*s,y+18*s],[x-21*s,y+18*s]],ink);R(x-18*s,y+15*s,36*s,3*s,lit(h,.9));}
function glassGem(x,y,r,col){P([[x-r,y],[x-r*.62,y-r*.65],[x+r*.62,y-r*.65],[x+r,y],[x,y+r*1.15]],col);P([[x-r,y],[x,y+r*1.15],[x-r*.3,y]],mix(col,ink,.45));P([[x-r*.62,y-r*.65],[x-r*.3,y],[x+r*.3,y],[x+r*.62,y-r*.65]],mix(col,h,.5));L(x+r*.3,y,x,y+r*1.15,mix(col,h,.55));L(x-r,y,x+r,y,light);}
function pulseLamp(x,y,r=3){glow(x,y,r*5,r*5,h,.5+q*.3);D(x,y,r,pulseColor(shade,light,2.5));}
function pane(x,y,w,hh,fn){R(x-5,y-5,w+10,hh+10,ink);clipBox(x,y,w,hh,fn);outline(x,y,w,hh,shade);R(x-7,y+hh,w+14,5,shade);}
function glassFlask(x,y,sz,col){const top=y-65*sz;const neck=5*sz;const pts=[[x-neck,top],[x-neck,top+23*sz],[x-23*sz,y-5*sz],[x-20*sz,y],[x+20*sz,y],[x+23*sz,y-5*sz],[x+neck,top+23*sz],[x+neck,top]];P(pts,shade);c.save();c.beginPath();pts.forEach(([X,Y],i)=>i?c.lineTo(X,Y):c.moveTo(X,Y));c.closePath();c.clip();R(x-25*sz,y-(14+q*9)*sz,50*sz,24*sz,col);for(let j=0;j<7;j++){let yy=y-mod(t*(9+q*6)+j*7,20*sz),xx=x+sin(j*2)*14*sz;D(xx,yy,1+j%2,light);}L(x-3*sz,top+3,x-3*sz,top+20*sz,light);L(x-9*sz,top+31*sz,x-19*sz,y-5*sz,light);c.restore();R(x-8*sz,top-2,16*sz,3,light);}

// Single pass: background → architecture → supported props → local effects. No generic overlay.
switch(id){
case 1: { room('#352337','#211724');pane(20,29,140,152,()=>{sky('#151122','#68405c');moon(126,53,14,h,1);citySilhouette(181,mid,1);skyRain(29,181,23);});for(let j=0;j<8;j++){let yy=30+j*18;R(20,yy,140,Math.max(3,9-q*5),mix(ink,shade,.25));R(20,yy+Math.max(3,9-q*5),140,1,lit(a,.8));}R(8,181,164,6,shade);R(0,206,180,112,mix(d,'#100c19',.3));P([[22,206],[158,206],[176,320],[4,320]],mix(d,a,.04+q*.10));for(let j=0;j<5;j++){let yy=214+j*17,ww=126+j*7;R(90-ww/2,yy,ww,1+q*1.4,mix(d,a,.08+q*.21+b*.07));}drape(0,8,16,178,'#69334e',1);drape(164,8,16,178,'#69334e',-1);surface(19,263,142,48);R(24,254,132,9,mix(shade,h,.2));E(58,251,35,4,ink);cuffs(57,239,1.02);E(132,252,24,3,ink);garmentBrief(132,230,.93,'#a75b83');star(36,228,2+b*1.5,light);R(24,262,132,1,pulseColor(shade,h,3)); 
 // 7.37.2.31: Costuras y ribetes del mobiliario; pliegues de la cortina
 for(let j=0;j<8;j++){R(27+j*16,258,9,1,mix(shade,h,.22));}for(let x of [4,171])for(let j=0;j<6;j++)R(x,20+j*24,2,13,mix(ink,a,.22));
 break; }
case 2: { sky('#263551','#f1a06e');D(123,67,32,lit('#ffd45e',.5));citySilhouette(167,'#344561',2);citySilhouette(196,ink,9);P([[0,196],[180,169],[180,230],[0,230]],shade);P([[0,200],[180,173],[180,218],[0,224]],lit(a,.5));clipBox(0,200,180,26,()=>{for(let j=0;j<12;j++)L(j*21+mod(t*25,21),200,j*21-19+mod(t*25,21),226,mix(a,h,.5),2)});R(8,233,164,75,ink);R(12,237,156,67,mix(mid,a,.45));heart(90,270,5+q*2+b*.55,h);for(let j=0;j<4;j++)star(30+j*40,243+(j%2)*49,1+q+b,pulseColor(shade,light,2,j)); 
 // 7.37.2.31: Trama de tinta de cómic en las esquinas del panel
 for(let j=0;j<6;j++)for(let k=0;k<3;k++){R(15+j*4,240+k*4,1,1,mix(mid,ink,.42));R(164-j*4,300-k*4,1,1,mix(mid,ink,.42));}R(12,237,156,1,light);
 break; }
case 3: { sky('#352342',lit('#e2955d',.38));D(43,91+q*(20+act*16)+sin(t*.12)*3,29,lit(a,.6+b*.15));moon(137,39,20,h,1);hills(186,mid,34);hills(211,ink,20,1);roadFixed(211);for(let i=0;i<6;i++)star(99+i*12,20+i%3*13,1,pulseColor(mid,h,4,i));R(82,212,16,2,lit(shade,.9)); for(let i=0;i<7;i++){let yy=222+i*11,ww=4+i*5;R(90-ww/2,yy,ww,1,mix(ink,h,.12+q*.29));} for(let j=0;j<5;j++){let x=12+j*29+sin(t*.28+j)*3;cloud(x,121+j%2*9,.55,mix(shade,h,.22));} 
 // 7.37.2.31: Marcas de arcén y reflejos del horizonte sobre la ruta
 for(let j=0;j<6;j++){let y=220+j*17,v=(y-211)/109;R(78-v*75,y,2+v*2,2,mix(mid,h,.4));R(101+v*75,y,2+v*2,2,mix(mid,h,.4));}
 break; }
case 4: { sky('#241c25','#695142');R(12,18,156,284,'#4a372b');R(17,23,146,274,'#b38f65');for(let i=0;i<3;i++){let yy=34+i*87;R(26,yy,128,77,ink);for(let j=0;j<5;j++){R(30,yy+5+j*14,7,6,h);R(143,yy+5+j*14,7,6,h)}clipBox(42,yy+6,96,65,()=>{R(42,yy+6,96,65,mix('#5b4543','#d9ab76',.15+q*.43+drift(7,i)*.22+b*.12));D(106,yy+23,13,light);P([[42,yy+64],[76,yy+29],[100,yy+64],[138,yy+38],[138,yy+71],[42,yy+71]],mid);});}let y=24+mod(t*19,269);R(18,y,144,2,mix(h,light,.6)); 
 // 7.37.2.31: Perforaciones y grano de película dentro de los marcos
 for(let j=0;j<3;j++){let yy=34+j*87;R(42,yy+6,96,1,mix(h,white,.3));for(let k=0;k<4;k++){R(44+k*22,yy+68,12,1,mix(mid,ink,.22));}}
 break; }
case 5: { sky('#15263b','#60799f');skyRain(0,170,Math.round(42-23*q));hills(233,ink,22);litHouse(48,144,2.05);R(0,227,180,93,mid);P([[99,226],[119,226],[151,320],[61,320]],shade);L(40,231,40,260,ink,2);P([[18,231],[28,214],[40,209],[52,214],[62,231]],a);R(20,230,40,2,h);flowers(278,24); for(let j=0;j<5;j++){let yy=255+j*11;E(116+sin(t*.7+j)*5,yy,5+j*2,1,mix(mid,h,.15+q*.32));} ripple(40,269,10+b*3,3.1);ripple(121,299,17,4); 
 // 7.37.2.31: Gotas en el paraguas y bordes húmedos del sendero
 for(let j=0;j<5;j++){let x=24+j*7;R(x,229+sin(j)*1,2,1,pulseColor(shade,h,2.7,j));}for(let j=0;j<5;j++){let y=240+j*14;R(98-(y-226)*.38,y,3,1,mix(mid,h,.24));}
 break; }
case 6: { sky('#3c233c','#d69378');D(90,87,32+q*3,lit('#efaa7d',.6));hills(145,'#74506a',18,3);hills(170,'#4f5552',17,4);R(0,171,180,149,'#59423b');for(let j=0;j<7;j++){let x=90+(j-3)*49;P([[90+(j-3)*8,172],[90+(j-3)*8+4,172],[x+15,320],[x-15,320]],mix('#59423b','#2e3836',.65));}for(let i=0;i<26;i++){let z=r0(i+600),y=180+z*z*135,x=90+(r0(i+690)-.5)*(y-150)*1.1;let size=1+z*3;L(x,y,x+sin(t*.8+i)*size,y-7*size,'#52705b',1);bloom(x+sin(t*.8+i)*size,y-7*size,size,mix('#b94a64',h,.15+q*.36));}for(let j=0;j<4;j++)cloud(mod(t*1.4+j*53,212)-16,34+j%2*14,.65,'#b97d83'); 
 // 7.37.2.31: Surcos de tierra y hojas iluminadas al atardecer
 for(let j=0;j<18;j++){let z=r0(8400+j),y=178+z*z*132,x=90+(r0(8500+j)-.5)*(y-145);R(x,y,2+z*4,1,mix("#59423b","#b28b70",.16+q*.1));}
 break; }
case 7: { room(mix('#65405f','#a05d85',q*.5));windowAt(104,32,54,79,a);photo(18,48,34,44,1);photo(57,59,34,44);bed(11,242,112,a);surface(132,240,38,38);phone(139,192,.82);R(144,205,17,8,lit(a,.8));R(144,217,17,6,lit(h,.6));R(21,119,136,3,shade);for(let j=0;j<7;j++)D(25+j*21,124,2,pulseColor(mid,h,3,j)); for(let i=0;i<3;i++)R(145,201+i*8,12+(i%2)*3,1,lit(h,.8));R(15,253,101,3,mix(a,h,.36)); shine(144,199,17,31,4.8); 
 // 7.37.2.31: Costuras del edredón y luces del teléfono
 for(let j=0;j<5;j++)R(26+j*15,249,9,1,mix(a,h,.35));R(142,228,18,1,mix(ink,h,.4));
 break; }
case 8: { sky('#292553','#d48b78');D(91,81,27+q*8+sin(t*.35)*1.5,lit('#f6c36c',.4));for(let i=0;i<6;i++)for(let z=Math.PI;z<TAU;z+=.035)R(90+cos(z)*(47+i*6),105+sin(z)*(47+i*6),2+q+b*.3,2+q+b*.3,['#e67d98','#edc478','#7ccdb7','#78afd5','#b4a1e7','#f3b8d1'][i]);for(let i=0;i<3;i++){let x=24+i*65,y=153+i%2*29-q*(16+act*12);P([[x-65,265],[x,y],[x+65,265]],i%2?'#356a82':'#63528c');P([[x-15,y+26],[x,y],[x+15,y+26],[x,y+21]],white)}hills(265,ink,14); for(let i=0;i<8;i++){let x=8+i*23;P([[x-5,288],[x,267-i%3*6],[x+5,288]],mix(ink,'#496b65',.38+q*.2));} for(let j=0;j<4;j++){let x=20+j*43;cloud(x+sin(t*.31+j)*5,125+j%2*13,.64,mix(shade,h,.35));}P([[88,265],[95,265],[138,320],[56,320]],mix(mid,'#427b93',.46));for(let j=0;j<9;j++){let yy=271+j*5,xx=92+sin(j*.7+t*.5)*6;R(xx-j*2,yy,4+j*4,1,pulseColor(mid,h,3.5,j));} 
 // 7.37.2.31: Reflejos cromáticos en el río de la escena psicodélica
 for(let j=0;j<6;j++){let y=275+j*7;R(88-j*3+sin(t*.6+j)*3,y,7+j*4,1,mix(mid,[a,h,white][j%3],.38+q*.2));}
 break; }
case 9: { room('#b6b2ae','#756f76');R(8,18,164,195,'#dedbd0');let sx=sin(t*.45)*8;P([[34+sx,22],[68+sx,22],[155+sx,198],[122+sx,198]],mix('#c5c1ba','#99969a',q*.25));R(9,20,18+q*(17+act*12),190,'#99969a');R(153-q*(17+act*12),20,18+q*(17+act*12),190,'#99969a');for(let x of [47+q*8,108-q*8])E(x+10,278,15,3,mix('#756f76','#39343e',.35));chair(47+q*8,246,1.05);chair(108-q*8,246,1.05);R(0,215,180,3,lit('#9d9893',.15));  R(9,20,2,190,pulseColor('#99969a','#bcb8b4',7));R(169,20,2,190,pulseColor('#99969a','#bcb8b4',7,1)); 
 // 7.37.2.31: Juntas de panel y sombras en el suelo del cuarto blanco
 R(10,211,160,1,"#aaa5a0");for(let j=0;j<4;j++)R(10+j*42,216,1,8,"#aaa5a0");
 break; }
case 10: { sky('#121923','#35475b');R(13,28,154,236,ink);R(19,34,142,224,'#263342');hangingLight(90,47,.85);glow(90,151,65,86,'#cbd8eb',.35+q*.35);P([[28,211],[47,150],[133,150],[152,211]],'#34465c');P([[28,211],[152,211],[152,224],[28,224]],'#1d2b3d');E(90,189,42,9,ink);for(let j=0;j<17;j++){let z=Math.PI*.13+j*Math.PI*.74/16;D(90+cos(z)*39,143+sin(z)*41,3,lit('#b9cfe6',.8));}glassGem(90,188,18+q*2,lit('#a8c6e4',.8));star(85,180,2+b*3,light);c.save();c.beginPath();c.rect(19,34,142,224);c.clip();let gemx=90+sin(t*3)*6;R(gemx,184+sin(t*2)*4,2,2,light);c.restore();R(19,227,142,5,shade);shine(19,34,142,191,5.7,'#a9c7e7');outline(19,34,142,224,shade);shelfGround(10,263,160,9); 
 // 7.37.2.31: Juntas de la vitrina y pequeños reflejos facetados
 for(let j=0;j<4;j++){R(23+j*43,229,2,2,light);}R(21,36,138,1,mix(shade,h,.5));R(21,37,1,188,mix(shade,h,.4));
 break; }
case 11: { sky('#191b3c','#674270');stars(24,98);citySilhouette(244,'#4b365e',1);citySilhouette(279,ink,7);R(0,280,180,40,ink);let rx=37+q*12,ry=57+q*15;glow(90,125,rx+15,ry+18,a,.5);c.save();c.beginPath();c.ellipse(90,125,rx,ry,0,0,TAU);c.clip();R(25,35,130,180,'#31466b');moon(115,93,16,h);citySilhouette(179,'#354c78',9);citySilhouette(205,'#23334b',12);c.restore();ring(90,125,rx+3,ry+3,lit(a,.9),2);ring(90,125,rx+7,ry+7,lit(h,.8),1);for(let j=0;j<6;j++){let z=t*.5+j*TAU/6;star(90+cos(z)*(rx+5),125+sin(z)*(ry+5),1+b*2,light);} 
 // 7.37.2.31: Glifos de energía sobre el contorno del portal
 for(let j=0;j<9;j++){let z=t*.25+j*TAU/9;R(90+cos(z)*(rx+8),125+sin(z)*(ry+8),2,1,pulseColor(a,h,3,j));}
 break; }
case 12: { room(mix('#552b55','#a03f88',q*.53),'#311d42');windowAt(115,29,45,62,a);surface(10,231,160,51);terminal(16,106,91,92);terminal(115,143,48,55);R(54,198,10,32,ink);R(37,226,44,4,shade);R(137,198,6,32,ink);R(124,226,28,4,shade);R(53,99,14,7,ink);D(60,102,2,lit(h,1));keyboard(20,217,83);phone(128,203,.48);R(24,129,76,55,mid);heart(62,155,Math.min(7,5+q*(.8+act*1.2)+b*.35),lit(a,.7)); R(26,187,72,4,ink);R(28,188,Math.max(3,68*mod(t*.12,1)),2,lit(h,.9));D(65,102,1,lit(a,1)); meter(29,179,66,6,10);led(100,194,a,1.7); 
 // 7.37.2.31: Indicadores de conexión en el monitor secundario
 for(let j=0;j<4;j++)R(123+j*8,177,4,2,pulseColor(shade,h,2,j));R(120,185,36,1,mix(mid,h,.35));
 break; }
case 13: { sky('#26435f','#b4cddd');D(119,85,26,mix(h,white,.48+q*.25));for(let i=0;i<6;i++)cloud(mod(i*37+t*2,205)-10,45+i%3*27,1.1,mix(white,h,.14));hills(227,mix(mid,'#758eaa',.45),28,2);hills(254,mid,24);let x=83+sin(t*.28)*9,y=154+sin(t*.54)*3,wing=11+sin(t*1.8)*4+b*4;P([[x-22,y+4],[x-43,y+13],[x-35,y-4],[x-14,y-1]],mix(h,white,.32));E(x,y,20,9,white);P([[x-9,y-3],[x-30,y-wing-12],[x-10,y-wing-6],[x+7,y+1]],mix(h,white,.70));P([[x-8,y],[x-21,y+wing],[x+6,y+8],[x+10,y+2]],mix(h,white,.30));D(x+17,y-7,9,white);P([[x+25,y-8],[x+34,y-5],[x+25,y-2]],'#d8ae79');R(x+19,y-10,2,2,ink);flowers(278,25);for(let i=0;i<5;i++){let v=mod(t*.09+i*.2,1),xx=12+i*36+sin(t*.6+i)*5,yy=205+v*31;P([[xx,yy],[xx+3,yy-5],[xx+4,yy],[xx+1,yy+4]],mix(mid,h,.3+q*.4));}
 // 7.37.2.31: Detalle de plumas en el ave, sujeto a sus alas
 for(let j=0;j<3;j++)L(x-10-j*4,y-2-j*2,x-18-j*4,y-wing-3+j*2,mix(h,white,.68));
 break;}
case 14: { room('#31314d');R(0,0,90,218,'#213957');R(90,0,90,218,'#623448');surface(9,222,162,53);R(15,64,150,72,ink);R(19,68,142,64,mid);R(20,69,70,62,mix(mid,'#213957',.60));R(90,69,70,62,mix(mid,'#623448',.60));for(let j=0;j<6;j++){let x=25+j*23,yy=113-r0(j+90)*24;R(x,yy,15,131-yy,ink);for(let n=0;n<3;n++)R(x+3,yy+4+n*5,3,2,pulseColor(shade,h,4,j+n));}R(15,137,150,5,shade);let dx=q*(8+act*6);magnet(15+dx,176,1,a);magnet(127-dx,176,-1,h);for(let j=0;j<4;j++){let y=183+j*10;for(let k=0;k<16;k++){let x=57+dx+k*(66-dx*2)/16;R(x,y+sin(k*.2+t*.6+j)*2,2,1,lit(shade,.9));}} for(let i=0;i<6;i++)R(69+i*7,228,4,2,lit(i%2?a:h,.6)); for(let j=0;j<4;j++){let v=mod(t*.55+j*.25,1),x=57+dx+v*(66-dx*2);D(x,183+j*10+sin(v*TAU+t*.6)*2,1+q+b*.65,pulseColor(a,h,2,j));} 
 // 7.37.2.31: Indicadores de polaridad en la mesa
 for(let j=0;j<4;j++){R(20+j*5,234,3,2,mix(shade,a,.48));R(142+j*5,234,3,2,mix(shade,h,.48));}
 break; }
case 15: { sky('#211e2a','#6b5447');glow(90,155,82,122,h,.35+q*.4);const top=64,bottom=254,waist=159;R(39,top-8,102,9,ink);R(44,top-8,92,3,light);R(39,bottom,102,9,ink);R(44,bottom,92,3,shade);for(let x of [43,133]){R(x,top+1,4,bottom-top-1,shade);R(x+1,top+1,1,bottom-top-1,h)}const pts=[[53,top],[127,top],[119,top+35],[101,waist-14],[93,waist],[101,waist+14],[119,bottom-35],[127,bottom],[53,bottom],[61,bottom-35],[79,waist+14],[87,waist],[79,waist-14],[61,top+35]];P(pts,'#665c58');c.save();c.beginPath();pts.forEach(([x,y],i)=>i?c.lineTo(x,y):c.moveTo(x,y));c.closePath();c.clip();const fill=cl(.83-sc.progress*.72);R(50,top+3+(1-fill)*53,80,70*fill,'#d5b77f');P([[52,bottom],[90,bottom-11-sc.progress*45],[128,bottom]],'#d5b77f');for(let j=0;j<8;j++)R(89+sin(j)*1.5,waist+mod(t*32+j*9,80),1,2+b*2,light);L(58,top+5,80,waist-15,light,2);L(99,waist+16,120,bottom-8,h,2);c.restore();for(let j=0;j<pts.length;j++)L(...pts[j],...pts[(j+1)%pts.length],shade,2);R(26,263,128,7,shade);E(90,273,62,4,ink); 
 // 7.37.2.31: Grabados en el marco de madera del reloj de arena
 for(let j=0;j<5;j++){R(48+j*17,top-5,6,1,mix(shade,h,.42));R(48+j*17,bottom-5,6,1,mix(shade,h,.32));}
 break; }
case 16: { sky('#24364d','#75879c');moon(135,52,23,h);citySilhouette(185,mid,16);R(0,190,180,130,'#303e44');P([[81,190],[99,190],[157,320],[23,320]],'#56616a');for(let j=0;j<7;j++){let yy=202+j*17,ww=20+j*15;R(90-ww/2,yy,ww,1,mix('#56616a',h,.12+q*.16));}tree(21,232,1.1,'#394f55');tree(162,244,1.05,'#354850');lamp(47,160,.75);lamp(134,160,.75);glow(48,166,20,25,h,.4+q*.3);glow(135,166,20,25,h,.4+q*.3);flowerBed(282,10); 
 // 7.37.2.31: Textura de pavimento y bordes del camino
 for(let j=0;j<6;j++){let y=200+j*18,v=(y-190)/130;R(81-58*v,y,3,2,mix(mid,h,.22));R(99+58*v,y,3,2,mix(mid,h,.22));}
 break; }
case 17: { room('#77717a','#403f49');windowAt(34,24,112,128,'#c9d9f0');c.save();c.beginPath();c.rect(37,27,106,122);c.clip();comet(43+mod(t*4,86),49+sin(t*.15)*8,.46+q*(.14+act*.16));c.restore();R(88,24,3,128,ink);R(34,88,112,3,ink);bed(32,253,125,shade);surface(4,232,24,37);cup(16,222,.5); R(27,152,126,2,lit(shade,.75+b*.15));for(let i=0;i<5;i++)R(66+i*15,257,9,1,mix(shade,h,.3)); shine(37,27,50,58,8); 
 // 7.37.2.31: Carpintería de ventana y ribete de la cama
 R(35,25,110,1,mix(shade,h,.42));R(36,26,1,124,mix(shade,h,.32));R(43,259,103,1,mix(shade,h,.34));
 break; }
case 18: { sky('#292135',mix('#75414d','#f7c08b',q));D(90,118,29+q*12,pulseColor('#dc785b','#ffdf9e',3));hills(195,'#72505d',24,1);P([[0,0],[47,0],[66,65],[49,111],[76,165],[47,212],[66,320],[0,320]],ink);P([[180,0],[136,0],[116,53],[135,111],[107,161],[142,219],[122,320],[180,320]],ink);P([[0,0],[36,0],[51,65],[34,113],[57,165],[29,222],[43,320],[0,320]],mid);P([[180,0],[149,0],[132,53],[150,111],[125,161],[158,219],[147,320],[180,320]],mid);P([[79,193],[101,193],[135,320],[43,320]],mix('#4e3844','#d59b72',q*.62));for(let j=0;j<7;j++){let y=205+j*15;R(90-(y-190)*.27,y,(y-190)*.54,2,pulseColor(shade,h,2.5,j));} 
 // 7.37.2.31: Estratos de roca iluminados por la salida
 for(let j=0;j<7;j++){let y=22+j*43;L(4,y,22+sin(j)*4,y+6,mix(mid,h,.13+q*.18));L(176,y,158+sin(j)*3,y+7,mix(mid,h,.13+q*.18));}
 break; }
case 19: { sky('#183239','#bb7a5b');moonWater(133,51,23,156);R(0,223,180,97,ink);R(0,224,180,5,shade);car(119,252,1.35,a);surface(9,281,55,30);phone(23,231,.86);R(28,244,19,9,lit(a,.9)); for(let j=0;j<4;j++)R(137+j,262+j*4,10+j*3,1,mix(ink,a,.2+q*.25));R(29,265,16,2,lit(h,.8)); meter(29,251,17,9,4);; 
 // 7.37.2.31: Asfalto con reflejos junto al vehículo
 for(let j=0;j<8;j++){let y=278+j*5;R(103+sin(j+t*.3)*3,y,5+j*3,1,mix(ink,a,.10+q*.17));}
 break; }
case 20: { sky('#493346','#b3838c');glow(90,135,85,130,h,.30+q*.45);for(let j=0;j<15;j++){for(let i=0;i<12;i++){let x=i*17-9,y=45+j*18,off=sin(i*.5+j*.2+t*.65)*2;let cols=['#a06c80','#b98293','#dca6ad','#c58d96'];let co=cols[(Math.floor(j/3)+i%2)%4];R(x,y+off,17,18,mix(co,h,q*.15));R(x+2,y+off+2,13,2,mix(co,light,.24));R(x+4,y+off+7,1,8,mix(co,ink,.26));}}P([[0,45],[180,45],[180,76],[0,85]],'#8b5c70');for(let i=0;i<12;i++){let x=5+i*16;L(x,75,x+sin(t*.9+i)*2,92,lit(h,.8),2);}R(38,129,104,101,'#e7b7ad');outline(38,129,104,101,'#825669');for(let j=0;j<12;j++){R(42+j*8,134,4,1,shade);R(42+j*8,224,4,1,shade);}heart(90,180,8+q*.9+b*.35,pulseColor('#ad647c','#ce8190',4)); 
 // 7.37.2.31: Puntadas del cojín central y relieve de tejido
 for(let j=0;j<8;j++){R(43,140+j*10,1,4,mix(shade,h,.5));R(136,140+j*10,1,4,mix(shade,h,.5));}
 break; }
case 21: { sky('#142b34','#5b7668');moon(138,51,18,h,1);hills(154,'#37504c',20,3);citySilhouette(173,mid,21);P([[78,174],[107,174],[177,320],[0,320]],'#283b40');for(let i=0;i<9;i++){let yy=178+i*i*2;R(90-(yy-169)*.52,yy,(yy-169)*1.04,2,mix(shade,h,.2));}R(14,112,49,109,'#425755');R(117,92,51,104,'#435c58');R(124,109,35,39,pulseColor('#685e45','#e8c18a',4));R(140,109,2,39,ink);R(124,128,35,2,ink);lamp(76,130,.62);for(let x=4;x<180;x+=25){R(x,247,4,73,ink);P([[x-2,249],[x+2,241],[x+6,249]],shade);}R(0,260,180,4,ink);R(0,306,180,4,ink); 
 // 7.37.2.31: Persianas y marco de la ventana iluminada
 for(let j=0;j<5;j++)R(125,112+j*7,33,1,mix(shade,h,.30+q*.12));R(123,148,37,2,mix(ink,h,.28));
 break; }
case 22: { sky('#463243','#e8aa8a');moonWater(90,94,29+q*(4+act*5),159);bridge(215);for(let i=0;i<11;i++)if(i/11<q||i%3===0)R(10+i*15,210,4,3,lit(shade,.95));P([[0,237],[30,237],[55,320],[0,320]],ink);P([[180,237],[150,237],[125,320],[180,320]],ink);  for(let j=0;j<9;j++){let x=23+j*16;R(x,211,3,2,mix(shade,h,.25+.45*q+.24*b));} 
 // 7.37.2.31: Remaches, tablero y reflejos bajo el puente
 for(let j=0;j<11;j++){R(8+j*16,218,4,1,mix(ink,h,.40));R(8+j*16,226,3,1,mix(mid,h,.15+q*.24));}
 break; }
case 23: { sky('#271d30','#67405a');glow(90,152,85,96,a,.28+q*.3);record(90,152,74);D(90,152,24,mix(a,h,.28));for(let i=0;i<5;i++){let z=t*.7+i*TAU/5;D(90+cos(z)*9,152+sin(z)*9,6,pulseColor(a,h,3,i));}D(90,152,3,ink);let z=t*.7;for(let j=0;j<4;j++)D(90+cos(z+j*.07)*64,152+sin(z+j*.07)*64,1,light);P([[155,244],[170,244],[168,276],[157,276]],shade);L(162,248,143,211,h,4);D(143,211,4,light); 
 // 7.37.2.31: Etiqueta del disco y brillo del surco
 for(let j=0;j<12;j++){let z=t*.7+j*TAU/12;R(90+cos(z)*20,152+sin(z)*20,1,1,mix(a,light,.45));}
 break; }
case 24: { sky('#243342','#71808a');citySilhouette(152,'#424d58',24);R(0,170,180,150,'#3f4950');R(0,0,180,39,'#4a4548');for(let x of [0,145])R(x,38,35,240,'#514a48');for(let y=45;y<267;y+=13)for(let x of [0,145]){R(x,y,35,1,ink);R(x+((y%2)*16+8)%30,y+1,1,11,ink);}P([[35,39],[145,39],[145,57],[121,57],[108,49],[72,49],[59,57],[35,57]],shade);skyRain(39,170,31);for(let j=0;j<8;j++)R(43+j*7,220+j*8,34+j*4,1,pulseColor(mid,h,3,j));groundShadow(121,284,29);guitar(121,262,1.24,'#c3a879');L(121,274,108,284,shade,2);L(121,274,134,284,shade,2); 
 // 7.37.2.31: Mortero de ladrillos y reflejos mojados al pie del pasaje
 for(let j=0;j<6;j++){R(3,65+j*28,27,1,mix(shade,h,.12));R(150,65+j*28,27,1,mix(shade,h,.12));}
 break; }
case 25: { sky('#1b1b24','#48434b');R(0,19,180,8,'#9e9696');for(let j=0;j<7;j++){let x=5+j*26;L(x,19,x+24,27,ink,2);L(x,27,x+24,19,ink,2);}for(let x of [24,90,156]){R(x-9,28,18,8,ink);D(x,36,5,pulseColor('#8e8b91','#ffd5b0',2,x));c.save();c.globalAlpha=.08+.16*q+.06*b;P([[x-5,39],[x+5,39],[Math.min(180,x+49),228],[Math.max(0,x-49),228]],'#ffdebd');c.restore();}R(0,228,180,92,'#24232b');R(0,228,180,3,'#7a7378');for(let x of [12,128]){R(x,150,40,78,ink);outline(x+2,152,36,74,'#8e8586');R(x+5,160,30,9,'#b1a7a7');for(let j=0;j<3;j++){D(x+20,183+j*15,7,'#5a535c');D(x+20,183+j*15,3+b*1.7,pulseColor('#8b7d7b','#efb99a',1.8,j));}}D(90,205,25,'#a49a9b');D(90,205,21,'#363039');D(90,205,5,'#a49a9b');for(let x of [72,108]){R(x-12,169,24,19,'#766f78');E(x,168,12,3,'#ddd2cc');L(x,186,x,197,'#8a8589',2);}for(let x of [59,121]){L(x,155,x,226,'#b5a8a5',2);E(x,152+sin(t*8)*b,18,3,'#c9bba6');}groundShadow(42,282,23);P([[32,248],[24,258],[30,272],[43,277],[53,266],[49,254],[44,245],[43,210],[37,210],[37,245]],'#b5a2a2');R(37,200,9,13,'#d5c5bc');R(37,214,2,43,ink);L(39,275,27,284,shade,2);L(39,275,52,284,shade,2);for(let j=0;j<7;j++)R(63+j*15,284,10,2,pulseColor('#55474e','#f1c297',2,j)); 
 // 7.37.2.31: Herrajes y tornillos de las cajas de sonido
 for(let x of [12,128])for(let y of [154,221])for(let dx of [4,35])R(x+dx,y,2,2,mix(shade,h,.35));
 break; }
case 26: { sky('#372659','#9265a0');for(let j=0;j<8;j++){let x=j*25;L(x,0,90,48,shade);D(x,11+sin(j)*6,4,pulseColor(a,h,2,j));}discoBall(90,66,29);glow(90,66,66,59,h,.4+q*.4);R(0,221,180,99,'#392b58');floorLights(226);R(27,136,126,76,ink);R(30,139,120,70,'#e9bad3');L(30,139,90,184,'#966789',2);L(150,139,90,184,'#966789',2);heart(90,184,3+q*.6+b*.25,'#cb577e');for(let j=0;j<18;j++){let x=mod(r0(j+9)*180+sin(t+j)*6,180),y=mod(r0(j+33)*110+t*11,110)+100;if(x<27||x>153||y<136)R(x,y,2,3,pulseColor(a,h,2,j));} 
 // 7.37.2.31: Doblez y borde iluminado del sobre de baile
 R(31,140,118,1,mix(h,white,.45));for(let j=0;j<6;j++)R(32+j*18,207,9,1,mix(a,h,.35));
 break; }
case 27: { sky('#52323e','#d39b78');moon(128,55,25,h);citySilhouette(173,'#57454b',27);R(0,200,180,120,'#57403b');for(let j=0;j<5;j++){let yy=200+j*25;R(0,yy,180,1,shade);}L(0,25,90,53,ink);L(90,53,180,25,ink);for(let j=0;j<11;j++){let x=8+j*16,y=25+27*sin(x/180*Math.PI);D(x,y,3,pulseColor(a,h,2.3,j));}for(let x of [58,119]){E(x,279,26,5,ink);P([[x-24,213],[x+24,213],[x+15,277],[x-15,277]],'#a87a4f');for(let j=-2;j<=2;j++)L(x+j*8,219,x+j*5,275,shade,2);E(x,213,24,8,ink);E(x,212,20,6,pulseColor('#d5b696','#ffe1b0',2,x));R(x-17,231,34,3,shade);} 
 // 7.37.2.31: Aros y remaches de las congas
 for(let x of [58,119]){E(x,270,16,2,mix(shade,h,.35));for(let j=0;j<4;j++)R(x-12+j*8,221,2,3,mix(shade,h,.45));}
 break; }
case 28: { sky('#46678b','#e1caa6');cloud(31+sin(t*.3)*7,48,1.1,white);cloud(143+sin(t*.24)*6,65,1.25,white);if(q<.75)skyRain(0,155,Math.round(28*(1-q)));for(let i=0;i<6;i++)for(let z=Math.PI;z<Math.PI+Math.PI*(.72+.28*q);z+=.035)R(90+cos(z)*(72-i*5),153+sin(z)*(72-i*5),3,3,['#e58d98','#edb986','#f4d86d','#a2d2aa','#84bfd8','#bda6d6'][i]);hills(215,'#739c83',22);R(0,232,180,88,'#476c58');groundShadow(90,269,62);R(28,190,124,51,'#e6d9cf');R(25,188,130,7,white);R(34,239,6,31,ink);R(140,239,6,31,ink);piano(32,219,116);R(34+(Math.floor(t*4)%14)*8,243,6,5,mix(a,h,.25+.60*b));flowerBed(279,20); 
 // 7.37.2.31: Moldura del piano y reflejo de lluvia sobre el suelo
 R(29,191,122,2,mix(shade,white,.4));for(let j=0;j<5;j++)R(29+j*25,267+j%2*2,13,1,mix(mid,h,.25+q*.2));
 break; }
case 29: { sky('#171d43','#664479');stars(36,170);moon(114,72,37,'#89bce5');ring(114,72,53,13,h,2);hills(201,'#4d416d',18,3);P([[0,216],[180,216],[180,320],[0,320]],'#252c53');for(let j=0;j<5;j++){let yy=224+j*20;R(0,yy,180,2,mid);}for(let j=0;j<6;j++)L(90,216,j*36-10,320,mid,2);E(90,220,57,17,ink);E(90,216,56,16,pulseColor('#596a9b','#cdb1ed',3));E(90,216,47,10,'#333858');for(let j=0;j<10;j++){let z=j*TAU/10+t*.4;D(90+cos(z)*51,216+sin(z)*13,2+q*.6,pulseColor(a,h,1.5,j));}for(let j=0;j<3;j++){let x=mod(t*(7+j*2)+j*68,210)-15,y=126+j*18;E(x,y,10,3,h);D(x,y-3,4,shade);} 
 // 7.37.2.31: Ranuras y luces del anillo de la plataforma espacial
 for(let j=0;j<14;j++){let z=j*TAU/14;R(90+cos(z)*49,216+sin(z)*12,2,1,pulseColor(shade,h,3,j));}
 break; }
case 30: { sky('#b48298','#e7bbbc');for(let j=0;j<80;j++)R(r0(j+800)*180,r0(j+900)*320,1,1,mix(h,a,.4));P([[19,74],[160,74],[160,239],[19,239]],'#84586d');R(15,67,142,165,'#f3d7be');outline(15,67,142,165,'#c497a2');for(let j=0;j<8;j++)R(28,90+j*13,90-j%3*12,1,'#cda3a3');R(110,79,29,32,'#dca6b3');heart(124,94,2.5,'#b85f82');P([[23,197],[90,157],[151,197],[151,272],[23,272]],'#b87e93');P([[23,197],[87,238],[151,197],[151,272],[23,272]],'#e8b5c4');heart(87,238,3+q*.8+b*.3+.18*drift(2.9),'#b66083');rose(144,153,.65,'#ca7e9b');shine(110,79,29,32,4.7,'#f1d4c1');heart(124,94,2.5,'#b85f82'); 
 // 7.37.2.31: Borde de papel y costuras del sobre
 for(let j=0;j<10;j++){R(25+j*12,269,5,1,"#b8879e");}R(18,69,136,1,"#fff1d5");
 break; }
case 31: { sky('#342134','#a15d75');moon(90,76,22,'#f5c9ae');hills(210,'#493743',20,3);R(0,238,180,82,'#35443e');for(let side of [-1,1]){let x=90+side*61;L(x,304,x,135,'#5f765c',5);for(let j=0;j<10;j++){let z=j*Math.PI/18;let xx=90+side*61*cos(z),yy=135-61*sin(z);if(j)L(90+side*61*cos(z-Math.PI/18),135-61*sin(z-Math.PI/18),xx,yy,'#5f765c',4);bloom(xx,yy,5+q*2+b*.3,mix(a,h,.32));}for(let j=0;j<7;j++){let yy=157+j*21;bloom(x+side*sin(j)*8,yy,7+q*2,mix(a,h,.24));}}P([[75,238],[105,238],[143,320],[37,320]],'#775b63');flowerBed(274,13); 
 // 7.37.2.31: Hojas y pequeñas luces en el arco floral
 for(let side of [-1,1])for(let j=0;j<6;j++){let x=90+side*61,y=170+j*21;E(x-side*6,y+5,4,2,mix("#5f765c",h,.20+q*.1));}
 break; }
case 32: { sky('#19364c','#6485a0');for(let j=0;j<7;j++)R(0,222+j*13,180,1,mix(mid,ink,.45));E(90,223,82,9,ink);for(let x of [10,96]){P([[x,106],[x+74,106],[x+70,174],[x+58,190],[x+14,190],[x+3,174]],ink);const pts=[[x+5,112],[x+68,112],[x+64,171],[x+55,183],[x+17,183],[x+9,170]];P(pts,'#31536d');c.save();c.beginPath();pts.forEach(([X,Y],i)=>i?c.lineTo(X,Y):c.moveTo(X,Y));c.closePath();c.clip();for(let j=0;j<8;j++){let xx=x+7+j*8,hh=12+r0(j+x)*25;R(xx,178-hh,6,hh,'#1d354d');}shine(x+4,112,66,72,2.2,'#d7e8f6');R(x+11,115,49,1,pulseColor('#537087','#b8e3fa',3));c.restore();}R(81,115,18,6,ink);L(11,106,0,91,shade,4);L(169,106,179,91,shade,4); 
 // 7.37.2.31: Biseles y reflejos en los lentes
 for(let x of [10,96]){L(x+6,112,x+67,112,mix(h,white,.28));R(x+13,183,42,1,mix(mid,h,.24));}
 break; }
case 33: { sky('#341e37','#87516c');glow(90,140,83,90,a,.35+q*.45);R(16,101,148,120,ink);R(21,106,138,110,'#5b4358');R(28,89,47,14,shade);R(115,90,30,13,ink);R(25,111,37,18,'#b890ab');R(129,112,23,17,'#c9a5ac');D(91,164,51,ink);D(91,164,45,shade);D(91,164,37,ink);D(91,164,30,'#674d77');D(91,164,23,'#322a4b');D(91,164,12,'#926288');E(80+sin(t*.9)*4,150,12,6,pulseColor('#9a769f','#efd2db',3));star(103,176,2+q*2+b*.8,h);R(26,205,128,5,shade);E(90,229,70,6,ink); 
 // 7.37.2.31: Estrías de enfoque y tornillos en la cámara
 for(let j=0;j<16;j++){let z=j*TAU/16;R(91+cos(z)*47,164+sin(z)*47,2,1,mix(shade,h,.42));}for(let x of [23,151])R(x,211,2,2,h);
 break; }
case 34: { sky('#302337','#745258');moon(141,54,15,h);R(0,158,180,162,'#514149');for(let j=0;j<6;j++)R(0,158+j*28,180,1,ink);for(let x of [12,132]){R(x,82,35,81,ink);R(x-4,76,43,8,shade);R(x+5,91,25,20,mid);R(x+6,96,23,4,pulseColor('#674650','#f0a277',2,x));}R(54,99,72,149,ink);R(60,105,60,143,'#302836');clipBox(60,105,60,143,()=>{for(let j=-5;j<15;j++){L(60+j*14,105,60+j*14+143,248,shade);L(60+j*14,105,60+j*14-143,248,shade);}});R(89,105,3,143,shade);R(83,177,15,7,ink);D(90,180,3,h);for(let x of [27,149]){c.save();c.globalAlpha=.10+q*.16+b*.06;P([[x-5,101],[x+5,101],[x+35,315],[x-35,315]],'#eaa37c');c.restore();} 
 // 7.37.2.31: Juntas y pernos de la puerta de hierro
 for(let j=0;j<6;j++){R(56,111+j*23,2,2,mix(shade,h,.4));R(121,111+j*23,2,2,mix(shade,h,.4));}
 break; }
case 35: { sky('#314761','#e7bb8f');D(90,96,26,lit('#f5c880',.6));cloud(25+sin(t*.3)*6,62,.9,white);cloud(151,83,.9,white);hills(182,'#7e8993',26,2);hills(223,'#495a65',30,4);P([[82,218],[99,218],[153,320],[28,320]],'#7d7566');for(let j=0;j<7;j++){let yy=228+j*13,ww=16+j*13;R(90-ww/2,yy,ww,1,lit(shade,.6));}wings(90,129,.85+q*.15);glow(90,131,48,39,h,.3+q*.3);flowerBed(279,13); 
 // 7.37.2.31: Moteado del sendero y reflejos de luz
 for(let j=0;j<8;j++){let y=226+j*11,v=(y-218)/102;R(82-51*v,y,2,1,mix(shade,h,.45));R(99+54*v,y,2,1,mix(shade,h,.45));}
 break; }
case 36: { sky('#12212e','#344854');stars(44,205);R(0,270,180,50,'#3a342c');R(0,270,180,4,'#8b6b40');glow(90,159,76,84,'#f6cd62',.4+q*.4);globe(90,160,50);R(68,249,44,5,shade);R(50,254,80,16,ink);R(55,255,70,3,lit('#a58549',.7));clipBox(42,112,96,96,()=>{c.save();c.beginPath();c.arc(90,160,47,0,TAU);c.clip();shine(43,113,94,94,7,'#ffe18d');c.restore();});for(let j=0;j<5;j++)star(23+j*34,33+j%3*27,1+q+b*.5,light); 
 // 7.37.2.31: Grabado dorado del pedestal y reflejo de estrellas
 for(let j=0;j<8;j++)R(56+j*8,263,3,1,mix(shade,h,.50));R(55,257,70,1,mix(shade,h,.32));
 break; }
case 37: { sky('#293d3e','#9b9b83');citySilhouette(178,mid,37);R(0,184,180,136,'#596962');for(let j=0;j<6;j++)R(0,195+j*22,180,1,mix('#596962',ink,.35));for(let i=0;i<7;i++)L(90,184,i*34-12,320,mix('#596962',ink,.24));tree(17,230,1.12,'#405b4f');tree(165,230,1.12,'#405b4f');lamp(45,155,.75);lamp(137,155,.75);bench(53,246,74);R(66,228,48,18,ink);D(77,237,6,shade);D(77,237,3+b,lit(a,.8));D(102,237,6,shade);D(102,237,3+b,lit(h,.8));R(84,232,10,3,lit(h,.9)); 
 // 7.37.2.31: Textura del banco y juntas del cemento
 for(let j=0;j<5;j++)R(57+j*14,251,2,1,mix(shade,h,.42));for(let j=0;j<7;j++)R(15+j*23,290+(j%2)*6,7,1,mix(mid,ink,.26));
 break; }
case 38: { sky('#241d36','#63465d');R(0,0,180,86,'#302439');for(let j=0;j<9;j++){let x=10+j*20;R(x,14,10,29,ink);R(x+2,17,6,21,pulseColor(shade,'#e7c49e',2,j));}P([[0,86],[180,86],[167,105],[13,105]],'#71536c');for(let j=0;j<13;j++)D(12+j*13,93,3,pulseColor(a,h,1.5,j));R(18,106,144,119,ink);glow(90,163,72,70,h,.25+q*.45);P([[28,205],[50,151],[126,151],[151,205]],'#4d3b53');R(30,205,119,7,shade);piano(37,181,105);R(37,212,5,32,ink);R(137,212,5,32,ink);E(90,147,25,5,ink);P([[76,147],[79,133],[101,133],[105,147]],ink);R(78,143,25,3,h);R(0,246,180,74,'#30263a');for(let j=0;j<8;j++)R(10+j*22,257,16,3,pulseColor(shade,a,2,j)); 
 // 7.37.2.31: Remaches en la moldura del escenario de club
 for(let j=0;j<9;j++)R(19+j*16,102,2,2,mix(shade,h,.5));R(30,207,119,1,mix(shade,h,.4));
 break; }
case 39: { sky('#332929','#81604d');for(let j=0;j<8;j++)R(0,215+j*14,180,1,mix('#81604d',ink,.35));glow(90,130,65,90,'#e2bc85',.35+q*.32);P([[15,128],[135,128],[166,204],[34,204]],'#665046');P([[34,204],[166,204],[166,220],[34,220]],ink);E(83,165,57,30,ink);for(let j=0;j<7;j++)E(83,165,54-j*5,28-j*2,mix(ink,shade,.10+j*.055));E(83,165,14,8,a);D(83,165,2,h);let z=t*.8;R(83+cos(z)*43,165+sin(z)*22,3,2,light);D(138,147,7,shade);L(138,147,119,177,h,3);R(116,177,7,3,light);R(143,194,10,3,pulseColor(a,h,3)); 
 // 7.37.2.31: Cepillado y tornillos en la carcasa del tocadiscos
 for(let j=0;j<7;j++)R(37+j*17,213,8,1,mix(shade,h,.26));R(38,209,2,2,h);R(161,209,2,2,h);
 break; }
case 40: { sky('#24243e','#514367');R(9,51,162,205,ink);R(16,59,148,154,'#222e42');outline(16,59,148,154,shade);clipBox(18,61,144,150,()=>{for(let j=0;j<8;j++)R(18,64+j*20,144,1,'#344253');for(let j=0;j<8;j++)R(18+j*20,61,1,150,'#344253');for(let x=19;x<162;x++){let z=(x-19)*.095-t*2;let y1=137+sin(z)*34*(1-q*.4),y2=137+sin(z+(1-q)*2)*34*(1-q*.4);R(x,y1,2,2,a);R(x,y2,2,2,h);}});for(let j=0;j<3;j++)dial(38+j*38,233,10,6+j);led(152,233,h,2.2); 
 // 7.37.2.31: Marcadores de escala del osciloscopio
 for(let j=0;j<8;j++){R(19,68+j*18,3,1,mix(shade,h,.42));R(158,68+j*18,3,1,mix(shade,h,.42));}
 break; }
case 41: { room(mix('#5a395b','#7b334d',q),'#34223d');curtain(.70+.24*q,'#8b3f60');vanity(23,36,96,134);surface(12,245,156,48);turntable(18,208,86);perfume(120,242,1.1);lipstick(143,242);R(126,50,3,144,shade);R(173,50,3,144,shade);R(126,50,50,3,light);R(123,193,55,4,ink);L(150,54,150,65,light);P([[150,65],[132,76],[168,76]],shade);garmentTop(150,91,.80,'#d76e9e');L(150,111,150,123,light);P([[150,123],[132,134],[168,134]],shade);garmentBrief(150,140,.88,'#c15b8e');R(128,188,44,5,shade);R(32,39,78,1,lit(h,.85));R(20,242,82,2,lit(shade,.65));candle(109,243,.72+b*.02);shine(31,44,80,115,5.5);star(117,223,1+b*2,light);
 // 7.37.2.31: Molduras del tocador y detalles del armario
 for(let j=0;j<5;j++)R(130+j*9,190,2,1,mix(shade,h,.55));R(25,37,91,1,mix(shade,h,.45));
 break; }
case 42: { sky('#192d42','#506476');stars(42,160);moon(122,71,39,lit('#e9cda0',.4));for(let j=0;j<4;j++)star(25+j*37,42+j%2*29,1+q+b*.5,light);hills(197,'#3b4e61',23,1);citySilhouette(223,'#26394b',42);R(0,241,180,79,'#2a2932');R(0,239,180,3,shade);shelfGround(22,270,136,10);trumpet(38,246,1.60);glow(89,248,56,25,h,.25+q*.3); 
 // 7.37.2.31: Remaches del pedestal de la trompeta
 for(let j=0;j<7;j++)R(26+j*19,274,3,1,mix(shade,h,.50));
 break; }
case 43: { sky('#304944','#75958b');glow(90,166,80,100,h,.25+q*.4);P([[12,77],[90,89],[168,77],[168,248],[90,260],[12,248]],ink);P([[17,72],[90,84],[90,254],[17,242]],'#e3d7b2');P([[90,84],[163,72],[163,242],[90,254]],'#f0e2bc');L(90,84,90,254,shade,2);for(let j=0;j<11;j++){R(27,96+j*12,49-j%3*6,1,'#8b8974');R(103,96+j*12,49-j%3*6,1,'#8b8974');}for(let j=0;j<8;j++){let x=27+j*8,y=201+sin(t*.7+j*.4)*7;R(x,y,3,2,a);R(180-x,y,3,2,h);}heart(90,216,2+q*.55+b*.2,'#b8798d'); 
 // 7.37.2.31: Cantos del libro y grano de papel
 for(let j=0;j<8;j++){R(20,101+j*17,1,4,"#c0b58f");R(159,101+j*17,1,4,"#c0b58f");}L(19,243,89,255,"#c6b78f");L(91,255,161,243,"#c6b78f");
 break; }
case 44: { sky('#163236','#526d63');citySilhouette(213,mid,44);R(0,230,180,90,'#293b3e');R(0,229,180,3,shade);R(48,71,84,207,ink);R(53,77,74,193,'#3e625b');R(58,83,64,23,lit(a,.9));R(58,113,64,119,mid);R(66,125,48,85,ink);R(73,134,34,23,lit(h,.7));for(let j=0;j<3;j++)for(let k=0;k<3;k++)R(79+k*8,169+j*8,4,4,shade);R(67,131,5,55,h);R(65,130,12,8,h);R(65,179,12,8,h);L(68,187,78,208,ink,2);L(78,208,84,198,ink,2);R(54,272,72,5,shade);glow(90,137,32,51,a,.27+q*.3);for(let j=0;j<5;j++)R(68-j*2,283+j*6,44+j*4,1,lit(shade,.5)); 
 // 7.37.2.31: Teclas y tornillos de la cabina telefónica
 for(let x of [56,119])for(let y of [80,265])R(x,y,2,2,mix(shade,h,.45));for(let j=0;j<3;j++)R(80+j*8,190,3,1,mix(mid,h,.45));
 break; }
case 45: { sky('#74616e','#f1b798');D(109,99,30,lit('#ffdbad',.7));hills(156,'#9a7c83',15,4);ocean(162);P([[0,234],[180,213],[180,320],[0,320]],'#b58f7d');for(let j=0;j<9;j++){let yy=222+j*5+sin(t*.8+j*.5)*2;L(0,yy+10,180,yy-13,mix('#b58f7d',white,.35+j*.025));}for(let j=0;j<4;j++){let y=252+j*19;E(51+j*8+(j%2)*9,y,3.5,5,'#987467');E(79+j*8+(j%2)*9,y-4,3.5,5,'#987467');}for(let j=0;j<5;j++)R(109-14+sin(t+j)*3,174+j*8,28+j*4,1,pulseColor(mid,h,4,j)); 
 // 7.37.2.31: Espuma y arena húmeda en la orilla
 for(let j=0;j<16;j++){let x=r0(9300+j)*180,y=240-x*.115+sin(t*.7+j)*2;R(x,y,2+r0(j)*4,1,mix("#b58f7d",white,.36));}
 break; }
case 46: { sky('#16243b',lit('#53677e',.3));stars(44,181);moon(139,61,31,h,1);comet(55+mod(t*4,67),33,.62+q*(.28+act*.28)+b*.08);hills(212,mid,19,3);D(39,220,33,shade);R(6,220,66,28,ink);R(34,189,5,32,ink);R(39,189,4,30,mix(shade,h,.38));R(5,242,68,4,shade);hills(229,ink,28);R(0,264,180,56,mid);telescope(86,229,1.25); E(86,291,28,3,mix(mid,ink,.48));L(67,227,99,213,lit(h,.85),2); shine(71,216,30,4,4.8); 
 // 7.37.2.31: Juntas de la cúpula y remaches del observatorio
 for(let j=0;j<6;j++){R(9+j*10,244,2,1,mix(shade,h,.45));}
 break; }
case 47: { sky('#1e1e29','#69606a');R(8,40,164,232,ink);R(14,46,152,220,'#77717a');R(21,54,138,51,'#2b2831');for(let x of [53,127]){D(x,79,22,'#c3b7b3');D(x,79,18,ink);for(let j=0;j<3;j++){let z=t*1.8+j*TAU/3;D(x+cos(z)*11,79+sin(z)*11,5,shade);}D(x,79,3,h);}for(let j=0;j<8;j++){let x=20+j*18;R(x,118,13,130,'#3b3741');meter(x+2,122,9,42,2);R(x+6,173,2,59,ink);R(x+1,178+drift(2.3,j)*42-q*9,12,5,pulseColor(shade,h,2,j));led(x+6,243,a,2+j*.12);} 
 // 7.37.2.31: Escala y tornillería de la mesa de mezcla
 for(let j=0;j<8;j++){let x=20+j*18;for(let k=0;k<5;k++)R(x+2,176+k*11,2,1,mix(shade,h,.4));R(x+10,120,1,1,h);}
 break; }
case 48: { sky('#32213d','#6c3d59');let nodes=[[32,57],[90,38],[148,57],[40,125],[140,125],[90,160],[25,224],[155,224],[65,277],[115,277]];let links=[[0,1],[1,2],[0,3],[2,4],[3,5],[4,5],[1,5],[3,6],[4,7],[6,8],[7,9],[8,9],[5,8],[5,9]];for(let j=0;j<links.length;j++){let [i,k]=links[j],v=nodes[i],w=nodes[k];L(...v,...w,mix(shade,a,.25+q*.18),1);let z=mod(t*(.65+q*.3)+j*.15,1);D(v[0]+(w[0]-v[0])*z,v[1]+(w[1]-v[1])*z,1.5+b*.65,light);}nodes.forEach(([x,y],j)=>{if(j!==5){D(x,y,8+q*2,shade);D(x,y,5+b*.5,pulseColor(a,h,2,j));}});D(90,160,25+q*3,lit(a,.5));heart(90,160,4+q*.8+b*.25,h); 
 // 7.37.2.31: Anillos internos de los nodos de la red
 nodes.forEach(([x,y],j)=>{if(j!==5){R(x-2,y-5,4,1,mix(shade,h,.5));R(x+5,y,1,2,mix(shade,h,.32));}});
 break; }
case 49: { sky('#262a45','#81829a');moon(50,80,24,h,1);moon(130,80,24,a,1);stars(27,105);hills(162,'#4f536e',20,4);ocean(170);for(let x of [50,130])for(let j=0;j<10;j++){let ww=22-j*1.5;R(x-ww/2+sin(t*.8+j)*4,180+j*10,ww,1,pulseColor(mid,x===50?h:a,3,j));}P([[15,255],[50,225],[78,249],[61,290],[29,283]],'#556176');P([[115,245],[152,218],[170,258],[143,298],[102,280]],'#647184');L(50,225,41,259,shade);L(41,259,61,290,shade);L(152,218,132,254,shade);L(132,254,143,298,shade); 
 // 7.37.2.31: Pequeñas grietas secundarias en los espejos fracturados
 L(41,259,24,254,mix(shade,h,.6));L(132,254,159,250,mix(shade,h,.6));L(41,259,53,272,mix(shade,h,.32));
 break; }
case 50: { sky('#31243d','#60486d');for(let j=0;j<6;j++)R(18,50+j*40,144,1,mix(mid,shade,.3));R(18,267,144,8,ink);glassFlask(49,266,1.47,lit(a,.8));glassFlask(131,266,1.47,lit(h,.8));let y=266-65*1.47;L(49,y,49,91,shade,7);L(49,91,131,91,shade,7);L(131,91,131,y,shade,7);L(49,y,49,91,h,2);L(49,91,131,91,h,2);L(131,91,131,y,h,2);for(let j=0;j<6;j++)D(49+mod(t*19+j*17,82),91,1+b*.7,light);glow(90,236,76,35,h,.25+q*.4); 
 // 7.37.2.31: Graduaciones sobre los matraces
 for(let x of [49,131])for(let j=0;j<5;j++)R(x+7+j,235+j*5,4,1,mix(shade,h,.4));
 break; }
case 51: { sky('#46676d','#e7a5a6');D(90,101,45,lit('#f3bd9d',.7));for(let j=0;j<5;j++){let x=mod(t*2+j*46,214)-17;cloud(x,145+j%2*19,1.6,'#c5a7ad');}hills(196,'#77728c',21,4);R(0,231,180,89,'#465a65');R(17,214,146,77,ink);R(21,218,138,69,'#a0c5ba');R(28,228,124,35,'#4e6470');for(let x of [55,125]){D(x,246,12,'#253741');D(x,246,8,h);for(let j=0;j<3;j++){let z=t*1.8+j*TAU/3;D(x+cos(z)*5,246+sin(z)*5,2,ink);}}R(68,244,44,4,ink);P([[48,282],[62,267],[118,267],[132,282]],shade); 
 // 7.37.2.31: Altavoces y marcas en la carcasa del cassette
 for(let j=0;j<6;j++)R(25+j*23,220,9,1,mix(shade,h,.3));R(23,283,134,1,mix(shade,h,.42));
 break; }
case 52: { room('#4c333c','#29232d');drape(0,0,23,219,'#723647');drape(157,0,23,219,'#723647',-1);pane(57,24,66,91,()=>{R(57,24,66,91,'#52424b');skyRain(24,115,13);});R(88,24,3,91,ink);R(57,67,66,2,ink);clock(37,54,19,.6);R(89,0,2,19,shade);E(90,20,15+sin(t*1.2)*5,3,shade);D(90,20,3,ink);glow(90,172,65,75,a,.3*(1-q*.5));shelfGround(22,247,136,9);R(27,256,126,42,ink);cup(50,235,.85);cup(130,235,.85);candle(90,246,1.2);R(83,216,14,31,shade);rose(90,191,.85,a);glow(90,225,18,26,h,.18+.18*drift(2.8)+b*.45); 
 // 7.37.2.31: Juntas de madera y ribetes góticos
 for(let j=0;j<6;j++)R(28+j*20,250,9,1,mix(shade,h,.25));R(59,25,62,1,mix(shade,h,.32));
 break; }
case 53: { sky('#303d5d','#7996ae');stars(22,109);ocean(170);P([[113,218],[125,197],[153,192],[180,214],[180,320],[108,320]],ink);P([[115,221],[136,211],[160,220],[180,225],[180,320],[115,320]],mid);P([[126,207],[134,105],[151,105],[159,207]],h);for(let j=0;j<4;j++)R(133-j*1.6,118+j*21,18+j*3,7,shade);R(128,91,29,15,ink);R(133,95,19,7,lit(h,.9));P([[125,91],[142,82],[160,91]],shade);c.save();c.globalAlpha=.09+q*.23;let yy=82+sin(t*.6)*18;P([[133,98],[0,yy-28],[0,yy+28]],h);c.restore();boat(51+sin(t*.3)*4,246,1.02);ripple(51+sin(t*.3)*4,255,18,4); 
 // 7.37.2.31: Mampostería del faro y espuma al pie del acantilado
 for(let j=0;j<5;j++){let y=216+j*18;R(150+(j%2)*10,y,12,1,mix(mid,h,.18));}for(let j=0;j<6;j++)R(104-j*2,231+j*12,3,1,mix(mid,h,.24+q*.1));
 break; }
case 54: { sky('#557b91','#e7b5b4');moonWater(90,121,34+q*4,177);cloud(29+sin(t*.3)*5,51,.9,white);cloud(147+sin(t*.25)*4,68,.85,white);bird(64+sin(t*.6)*8,80+sin(t*2)*2,1.3);bird(109+sin(t*.6)*8,72+sin(t*2+.4)*2,1.3);boat(90+sin(t*.45)*4,251,1.23);ripple(90+sin(t*.45)*4,260,20+b*3,4); 
 // 7.37.2.31: Brillos de espuma en la estela del velero
 for(let j=0;j<5;j++){let x=90+sin(t*.45)*4,y=262+j*4;R(x-4-j*2,y,3+j,1,mix(mid,h,.42));}
 break; }
case 55: { room(mix('#321a32','#603046',q*.55),'#231727');for(let i=0;i<4;i++){let x=22+i*44;L(x,0,x,28+i%2*9,shade,2);L(x,28+i%2*9,90,28+i%2*9,shade,2);R(x-2,mod(t*18+i*5,27),4,3,lit(a,.9));}terminal(12,62,74,54);terminal(96,62,72,54);surface(13,259,154,43);R(28,133,124,114,ink);R(34,139,112,102,mid);outline(34,139,112,102,a);let rows=['0110110','1111111','1111111','0111110','0011100','0001000'];for(let j=0;j<6;j++)for(let i=0;i<7;i++)if(rows[j][i]==='1'&&(q>.8||r0(i+j*7)<.68+q*(.24+act*.15)||mod(t*.8+i+j,7)<1))R(55+i*10,153+j*10,9,9,lit((i+j)%3?h:a,.6+b*.25));keyboard(39,245,101); R(38,234,104,3,ink);R(39,235,Math.max(3,102*cl(.12+q*.60+act*.28)),1,lit(h,.9));for(let x of [22,106])R(x,110,48,2,lit(a,.8)); meter(38,224,104,8,14);led(158,108,a,1.5); 
 // 7.37.2.31: Tornillos y biseles del monitor del corazón digital
 for(let x of [31,148])for(let y of [136,242])R(x,y,2,2,mix(shade,h,.6));R(36,140,108,1,mix(shade,h,.36));
 break; }
case 56: {
 // JANE DOE: authored single composition; no generated scenery or camera shake.
 const smooth=(x)=>{x=cl(x);return x*x*(3-2*x)},
 rise=smooth((t-14.63)/12), dialogue=smooth((t-92)/20), reunion=smooth((t-136.93)/33)*.48+smooth((t-170.36)/25)*.52,
 ending=smooth((t-190)/18), pink='#e8a2bd',gold='#efd08b',silver='#c0c1c7',
 lx=36+reunion*42,rx=144-reunion*42,hy=157, floor=206,
 audio=window.IsmaSoundFX?.sample('s56',t)||{energy:.2,mid:.2,treble:.1,attack:.1},
 intensity=cl(.23+q*.34+b*.17+audio.mid*.20), darken=1-ending*.52;
 sky('#0c0d14','#22232d',180);
 // Fixed, layered silhouettes of clouds with very slow drift.
 for(let j=0;j<4;j++) {let x=17+j*47+sin(t*.045+j)*7;cloud(x,77+j%2*20,.65+j%2*.22,'#1d2029');}
 for(let j=0;j<18;j++){let x=r0(j+630)*180,y=r0(j+660)*116+10;R(x,y,1,1,mix('#171923',silver,.12+.12*drift(9,j)));}
 // A low moon, half concealed in haze, echoes the cover's restrained monochrome.
 glow(90,hy-9,53,28,'#b6b5c3',.18+intensity*.18);D(90,hy-12,11,'#a5a7b0');D(94,hy-15,11,'#242630');
 R(0,hy,180,163,'#11151d');R(0,hy,180,1,'#777981');
 // Perspective water bands and the two paths reflected across them.
 for(let j=0;j<25;j++){let z=j/25,yy=hy+3+z*z*149;for(let k=0;k<7;k++){let x=mod(r0(800+j*29+k)*210+t*(.25+z*1.25)*(k%2?1:-1),205)-12;R(x,yy+sin(t*.6+k+j)*1.2,3+z*14+r0(k+j*8)*9,1+(j>18),mix('#151923','#737581',.08+.14*drift(5,j+k)+intensity*.08));}}
 for(let side=0;side<2;side++){let x=side?rx:lx,col=side?gold:pink;const voice=side?dialogue:rise;const local=.28+voice*.24+audio.mid*.22+q*.20;
  glow(x,hy-2,24,20,col,(.18+local*.48)*darken);
  for(let j=0;j<19;j++){let z=j/19,yy=hy+3+z*54,xx=x+(90-x)*z*.42+sin(t*.8+j*.77+side)*z*3;let ww=2+z*7+audio.mid*3;R(xx-ww/2,yy,ww,1,mix('#141923',col,cl((.19+local*.48)*darken*(1-z*.62))));}
  // Small human silhouettes, framed above the lyric-safe lower third.
  let y=hy-2, coat= mix('#5a5260',col,.36+local*.3),head=mix('#c5b6b9',col,.34);
  D(x,y-24,3,head);R(x-3,y-26,6,3,mix('#5d5864',col,.30));
  if(!side){R(x-4,y-23,2,9,coat);R(x+3,y-23,2,7,coat);P([[x-3,y-19],[x+3,y-19],[x+5,y-7],[x-5,y-7]],coat);}else{R(x-4,y-20,8,13,coat);R(x-5,y-19,2,10,coat);R(x+4,y-19,2,10,coat);}
  R(x-3,y-7,2,7,head);R(x+1,y-7,2,7,head);R(x-4,y-1,3,1,col);R(x+1,y-1,3,1,col);
 }
 // Angular glass pieces on the near shore, not randomly spawned particles.
 const shards=[[[4,236],[32,218],[48,231],[25,249]],[[141,219],[165,207],[178,232],[150,245]],[[22,273],[48,253],[72,275],[47,294]],[[114,268],[144,252],[160,286],[128,300]],[[64,229],[76,213],[93,225],[83,239]],[[99,241],[122,228],[133,249],[117,257]]];
 shards.forEach((pts,i)=>{const strength=cl(.12+intensity*.32+audio.treble*.20+drift(6,i)*.15);P(pts,mix('#10131b','#383b45',.22));for(let k=0;k<pts.length;k++){let p0=pts[k],p1=pts[(k+1)%pts.length];L(...p0,...p1,mix('#1d222c',silver,strength*(k===0?1:.36)));}if((i%2===0||q>.6)&&rise>.1){let p0=pts[0],p1=pts[1],z=drift(7,i*1.4);R(p0[0]+(p1[0]-p0[0])*z,p0[1]+(p1[1]-p0[1])*z,2,1,mix('#545966',silver,intensity));}});
 // Crimson traces are part of the glass itself: they persist after the first refrain,
 // become more prominent on the second, and replay deterministically when seeking.
 const blood=smooth((t-59.02)/12)*.66+smooth((t-136.93)/12)*.34;
 if(blood>0.001){
  const stains=[{i:0,k:0,z:.28},{i:2,k:1,z:.46},{i:3,k:0,z:.21},{i:4,k:2,z:.35},{i:5,k:1,z:.54}];
  const red=mix('#4f1725','#ba3549',cl(.34+b*.18+audio.mid*.19+q*.18)), wet=mix(red,'#e96b72',.22+audio.treble*.18);
  stains.forEach(({i,k,z},n)=>{const pts=shards[i],A=pts[k],B=pts[(k+1)%pts.length],center=pts.reduce((o,p)=>[o[0]+p[0]/pts.length,o[1]+p[1]/pts.length],[0,0]);
   const f=cl(blood*(1.18-n*.06)), x=A[0]+(B[0]-A[0])*z,y=A[1]+(B[1]-A[1])*z;
   c.save();c.globalAlpha=.48+.52*f;
   // Pixelated pooling along the sharp edge, with short trails on the shard surface.
   const u=Math.max(0,z-.17*f),v=Math.min(1,z+.30*f),C=[A[0]+(B[0]-A[0])*u,A[1]+(B[1]-A[1])*u],F=[A[0]+(B[0]-A[0])*v,A[1]+(B[1]-A[1])*v];
   P([C,F,[x+(center[0]-x)*.64*f,y+(center[1]-y)*.64*f],[C[0]+(center[0]-C[0])*.14,C[1]+(center[1]-C[1])*.14]],mix('#39141d',red,.72));
   L(...C,...F,red,2);R(x,y,2,1,wet);
   for(let j=0;j<3;j++){const r=(j+1)/4,xx=x+(center[0]-x)*r*f,yy=y+(center[1]-y)*r*f;R(xx,yy,2,1,mix(red,'#40121d',r*.6));}
   // A small stain lies next to each shard, reflected on the dark floor.
   E(x+(n%2?3:-2),y+5,3+3*f,1+f,mix('#26131c',red,.54));
   c.restore();
  });
  // A few irregular crimson footprints form a path towards the center, not particles.
  for(let j=0;j<5;j++){let z=j/5,appear=cl(blood*1.7-z*.6);if(appear>.03){c.save();c.globalAlpha=appear*.75;let xx=53+z*31+(j%2?3:-2),yy=234-z*28;E(xx,yy,2+z,1.5,mix('#471624',red,.45));R(xx-1,yy-2,2,1,red);c.restore();}}
 }
 // The paths meet near the last reprise; the only explicit heart is a tiny bicolor one.
 if(reunion>.35){const z=smooth((reunion-.35)/.65);glow(90,hy+2,32,14,'#e4d4c9',z*.32);if(z>.86){const shape=['0110110','1111111','1111111','0111110','0011100','0001000'];shape.forEach((row,j)=>[...row].forEach((v,k)=>{if(v==='1')R(83+k*2,hy-48+j*2,2,2,k<3?pink:k>3?gold:(j%2?pink:gold));}));}}
 // Dark foreground vignette; quiet tail fades, no flashes.
 for(let y=244;y<320;y+=4){c.save();c.globalAlpha=.08+(y-244)/76*.30;R(0,y,180,4,'#080a10');c.restore();}
 if(ending>0){c.save();c.globalAlpha=ending*.43;R(0,0,180,320,'#090b11');c.restore();}
 
 // 7.37.2.31: Destellos de cristal sobre el agua, manteniendo el reencuentro original
 for(let j=0;j<9;j++){let x=r0(9700+j)*180,y=hy+18+r0(9800+j)*72;R(x,y,1,1,mix("#171923",silver,.20+intensity*.18));}
 break; }
}
}
const cache=new Map();
function drawScene(c,p,t,power,b,alpha,seed,en,phase=0,theme=null,live=false){if(alpha<.002)return;if(typeof document==='undefined'||typeof c.drawImage!=='function')return previous.draw(c,phase>.5?'climax':'verse',p,t,power,b,alpha,seed,en);const themeKey=theme?.main&&/^#[0-9a-f]{6}$/i.test(theme.main)?theme.main:"";const themeDark=theme?.dark&&/^#[0-9a-f]{6}$/i.test(theme.dark)?theme.dark:"";const styled=themeKey?{...p,color:mix(p.color,themeKey,.10),accent:mix(p.accent,themeKey,.06),dark:themeDark?mix(p.dark,themeDark,.13):p.dark}:p;const key=p.id+themeKey+themeDark;let v=cache.get(key);if(!v){let cv=document.createElement('canvas');cv.width=W;cv.height=H;v={cv,ctx:cv.getContext('2d'),frame:-1};cache.set(key,v);while(cache.size>4)cache.delete(cache.keys().next().value)}const frame=Math.floor(t*30),beatKey=Math.round(cl(b)*16),phaseKey=Math.round(cl(phase)*64);if(v.frame!==frame||(!live&&(v.beatKey!==beatKey||v.phaseKey!==phaseKey))||t<v.lastT-.05||Math.abs(t-v.lastT)>.2){v.ctx.clearRect(0,0,W,H);paint(v.ctx,styled,t,phaseKey/64,beatKey/16,en);Object.assign(v,{frame,beatKey,phaseKey,lastT:t})}c.save();c.globalAlpha=alpha*.94;c.imageSmoothingEnabled=false;c.drawImage(v.cv,0,0,360,640);c.restore()}
function draw(c,k,p,t,power,b,alpha,seed,en){return drawScene(c,p,t,power,b,alpha,seed,en,k==='climax'?1:0)}
function event(c,e,p,t,power){const q=(t-e.t)/e.life;if(!(q>0&&q<1))return;const fade=Math.sin(q*Math.PI),x=e.x||180,y=e.y||320,s=(e.size||1)*(1+.22*q),a1=Math.min(.34,.08+fade*.26)*Math.max(.5,power);c.save();c.globalAlpha=a1;c.lineWidth=2;c.strokeStyle=p.accent;c.fillStyle=p.color;const R=(x,y,w,h,f=true)=>f?c.fillRect(x,y,w,h):c.strokeRect(x,y,w,h),C=(x,y,r,f=false)=>{c.beginPath();c.arc(x,y,Math.max(.1,r),0,TAU);f?c.fill():c.stroke()},L=(x1,y1,x2,y2,col=p.accent,w=2)=>{c.strokeStyle=col;c.lineWidth=w;c.beginPath();c.moveTo(x1,y1);c.lineTo(x2,y2);c.stroke()},diamond=(x,y,r,col=p.color)=>{c.fillStyle=col;c.beginPath();c.moveTo(x,y-r);c.lineTo(x+r,y);c.lineTo(x,y+r);c.lineTo(x-r,y);c.closePath();c.fill()},heartLine=(x,y,r,col=p.accent)=>{c.strokeStyle=col;c.beginPath();c.moveTo(x,y+r*.65);c.bezierCurveTo(x-r*1.6,y-r*.45,x-r*.5,y-r*1.15,x,y-r*.35);c.bezierCurveTo(x+r*.5,y-r*1.15,x+r*1.6,y-r*.45,x,y+r*.65);c.stroke()},ring=(x,y,rx,ry,col=p.accent,w=2)=>{c.strokeStyle=col;c.lineWidth=w;c.beginPath();c.ellipse(x,y,rx,ry,0,0,TAU);c.stroke()};switch(e.kind){case 'shutter': for(let i=0;i<7;i++){let yy=y-34*s+i*11*s,off=fade*18*(i%2?1:-1);R(x-42*s+off,yy,84*s,4,true);} ring(x,y,46*s,18*s,p.accent,2); break;case 'burst': for(let i=0;i<14;i++){let ang=i*TAU/14+t*2.2;L(x,y,x+Math.cos(ang)*(24+fade*38)*s,y+Math.sin(ang)*(24+fade*38)*s,i%2?p.accent:p.color,2);} C(x,y,10+fade*8*s,true); break;case 'orbit': for(let i=0;i<3;i++)ring(x,y,(18+i*12+fade*10)*s,(12+i*9+fade*7)*s,i%2?p.color:p.accent,2); break;case 'frame': for(let i=0;i<3;i++){let pad=(8+i*12+fade*8)*s;R(x-26*s-pad*.2,y-18*s-pad*.2,52*s+pad*.4,36*s+pad*.4,false);} break;case 'petal': for(let i=0;i<10;i++){let ang=i*TAU/10+t*.7,rr=(12+fade*30+i%3*5)*s;c.beginPath();c.ellipse(x+Math.cos(ang)*rr,y+Math.sin(ang)*rr,5*s,2.8*s,ang,0,TAU);c.fillStyle=i%2?p.color:p.accent;c.fill();} break;case 'thread': for(let i=0;i<4;i++){c.strokeStyle=i%2?p.accent:p.color;c.lineWidth=2;c.beginPath();c.moveTo(x-46*s,y-25*s+i*16*s);c.bezierCurveTo(x-12*s,y-46*s+fade*30,x+12*s,y+46*s-fade*30,x+46*s,y+25*s-i*16*s);c.stroke();} break;case 'crack': for(let i=0;i<4;i++){let xx=x+(i-1.5)*9*s;L(xx,y-40*s,xx-8*s,y-14*s,p.accent,2);L(xx-8*s,y-14*s,xx+6*s,y+10*s,p.color,2);L(xx+6*s,y+10*s,xx-4*s,y+40*s,p.accent,2);} break;case 'feather': for(let i=0;i<4;i++){let ang=(i-1.5)*.35+Math.sin(t*1.6)*.15,yy=y-18*s+i*12*s;L(x-4*s,yy,x+28*s,yy-14*s,p.accent,2);for(let j=0;j<5;j++)L(x+2*s+j*5*s,yy-j*2*s,x+10*s+j*5*s,yy+6*s-j*2*s,p.color,1);} break;case 'beam': for(let i=0;i<3;i++){c.fillStyle=i%2?p.accent:p.color;c.globalAlpha=a1*(.7-i*.18);c.beginPath();c.moveTo(x,y-18*s);c.lineTo(x+(24+i*16)*s,y+55*s);c.lineTo(x-(24+i*16)*s,y+55*s);c.closePath();c.fill();} break;case 'signal': for(let i=0;i<4;i++){ring(x,y,(13+i*11+fade*10)*s,(13+i*11+fade*10)*s,i%2?p.accent:p.color,2);} break;case 'portal': for(let i=0;i<5;i++)ring(x,y,(12+i*8+fade*10)*s,(22+i*10+fade*8)*s,i%2?p.color:p.accent,2); break;case 'pixel': for(let ix=-3;ix<=3;ix++)for(let iy=-3;iy<=3;iy++)if((ix+iy)&1)R(x+ix*9*s,y+iy*9*s,6*s,6*s,true); break;case 'rainbow': ['#ff92a5','#ffd480','#fff0ab','#a2ddc6','#8abcf4','#d0b5ff'].forEach((col,i)=>{c.strokeStyle=col;c.lineWidth=4; c.beginPath(); c.arc(x,y+30*s,(25+i*8+fade*10)*s,Math.PI,TAU); c.stroke();}); break;case 'sand': for(let i=0;i<22;i++){let ang=i*2.399,rr=(8+fade*38*(i%3?1:.65))*s; C(x+Math.cos(ang)*rr,y+Math.sin(ang)*rr,1.4+(i%3),true);} break;case 'meteor': for(let i=0;i<5;i++){let xx=x-40*s+i*10*s+fade*20*s,yy=y-16*s+i*7*s;L(xx,yy,xx+28*s,yy+14*s,p.accent,2);C(xx+28*s,yy+14*s,3*s,true);} break;case 'spark': for(let i=0;i<10;i++){let ang=i*TAU/10+t*.9;diamond(x+Math.cos(ang)*(12+fade*24)*s,y+Math.sin(ang)*(12+fade*24)*s,4.5*s,i%2?p.accent:p.color);} break;case 'wave': for(let i=0;i<4;i++){c.strokeStyle=i%2?p.color:p.accent;c.beginPath();for(let xx=-52;xx<=52;xx+=6){const yy=Math.sin(xx*.08+t*3+i)*((8+i*2)*s); if(xx===-52)c.moveTo(x+xx*s,y+yy); else c.lineTo(x+xx*s,y+yy);} c.stroke();} break;case 'gem': diamond(x,y,14*s,p.accent);diamond(x,y,8*s,p.color); break;case 'confetti': for(let i=0;i<16;i++){let ang=i*2.399,rr=(14+fade*34)*s;R(x+Math.cos(ang)*rr,y+Math.sin(ang)*rr,6,3,true);} break; default: ring(x,y,(24+fade*15)*s,(24+fade*15)*s,p.accent,2); heartLine(x,y,11*s,p.color); break;} c.restore()}
window.IsmaDirector={draw,drawScene,event};window.IsmaAtelier={paint,score,rhythmPulse};})();
