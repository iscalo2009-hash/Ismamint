/* Music-only scene viewer. No separate audio, no persistent changes. */
(()=>{'use strict';
const body=document.body, music=window.IsmaMusic, core=window.IsmaCore;
const player=document.getElementById('v6-track-title')?.parentElement;
if(!player||!music||!core)return;
const make=(label,fn)=>{const b=document.createElement('button');b.type='button';b.textContent=label;b.addEventListener('click',fn);return b;};
const enter=make('Ver fondo',open);enter.id='sm-immersive-open';enter.setAttribute('aria-label','Ver fondo de la canción en modo inmersivo');player.append(enter);
const surface=make('',()=>{if(toolbar.hidden)show();else hide();});surface.id='sm-immersive-surface';surface.hidden=true;surface.setAttribute('aria-label','Mostrar u ocultar controles del modo inmersivo');surface.setAttribute('aria-expanded','false');
const toolbar=document.createElement('div');toolbar.id='sm-immersive-toolbar';toolbar.hidden=true;toolbar.setAttribute('role','group');toolbar.setAttribute('aria-label','Controles del modo inmersivo');
const play=make('Pausa',()=>{music.toggle();refresh();show();});
const lyrics=make('Letra',()=>{body.classList.toggle('sm-immersive-no-lyrics');refresh();show();});
const exit=make('Salir',()=>close());const actions=document.createElement('div');actions.className='sm-immersive-actions';actions.append(play,lyrics,exit);
const timeline=document.createElement('div');timeline.className='sm-immersive-timeline';
const elapsed=document.createElement('span'), total=document.createElement('span'), seek=document.createElement('input');seek.type='range';seek.id='sm-immersive-seek';seek.min='0';seek.max='1';seek.step='.1';seek.value='0';seek.setAttribute('aria-label','Posición de reproducción');timeline.append(elapsed,seek,total);toolbar.append(actions,timeline);body.append(surface,toolbar);
let timer=0, active=false, scroll=0, ticker=0, dragging=false, dragTrack=null;
const fmt=t=>{t=Math.max(0,Math.floor(Number(t)||0));return Math.floor(t/60)+':'+String(t%60).padStart(2,'0');};
function updateTime(){const st=music.state(),duration=Math.max(0,Number(st.duration)||0);if(dragging&&st.id!==dragTrack){dragging=false;dragTrack=null;}seek.disabled=!duration;seek.max=String(duration||1);const v=dragging?Number(seek.value):Math.min(duration,Math.max(0,Number(st.time)||0));if(!dragging)seek.value=String(v);elapsed.textContent=fmt(v);total.textContent=fmt(duration);seek.style.setProperty('--sm-progress',(duration?100*v/duration:0)+'%');seek.setAttribute('aria-valuetext',fmt(v)+' de '+fmt(duration));}
function arm(){clearTimeout(timer);if(active&&!toolbar.hidden&&!dragging)timer=setTimeout(()=>{if(!dragging&&!toolbar.querySelector(':focus-visible'))hide();},3500);}
seek.addEventListener('pointerdown',()=>{dragging=true;dragTrack=music.state().id;clearTimeout(timer);});
seek.addEventListener('input',()=>{if(!dragging)music.seek(Number(seek.value));updateTime();arm();});
function finishSeek(commit){if(dragging){if(commit&&dragTrack===music.state().id)music.seek(Number(seek.value));dragging=false;dragTrack=null;updateTime();arm();}}
seek.addEventListener('change',()=>{if(dragging)finishSeek(true);else{music.seek(Number(seek.value));updateTime();arm();}});
window.addEventListener('pointerup',()=>{if(dragging)finishSeek(true);});window.addEventListener('pointercancel',()=>finishSeek(false));seek.addEventListener('blur',()=>{if(dragging)finishSeek(false);arm();});
function refresh(){updateTime();const state=music.state();play.textContent=state.enabled?'Pausa':'Reproducir';play.setAttribute('aria-label',state.enabled?'Pausar música':'Reproducir música');lyrics.setAttribute('aria-pressed',String(!body.classList.contains('sm-immersive-no-lyrics')));}
function hide(){if(dragging)return;clearTimeout(timer);if(toolbar.contains(document.activeElement))surface.focus({preventScroll:true});toolbar.hidden=true;surface.setAttribute('aria-expanded','false');}
function show(){if(!active)return;clearTimeout(timer);refresh();toolbar.hidden=false;surface.setAttribute('aria-expanded','true');arm();}
function open(){if(active||!body.classList.contains('rb-music-player')||!music.state().id)return;active=true;scroll=window.scrollY;body.classList.add('sm-immersive');body.classList.remove('sm-immersive-no-lyrics');surface.hidden=false;surface.focus({preventScroll:true});window.scrollTo(0,0);document.dispatchEvent(new Event('isma:immersivechange'));show();clearInterval(ticker);ticker=setInterval(()=>{if(active&&!toolbar.hidden)refresh();},150);}
function close(restore=true){if(!active)return false;active=false;clearTimeout(timer);clearInterval(ticker);dragging=false;dragTrack=null;body.classList.remove('sm-immersive','sm-immersive-no-lyrics');toolbar.hidden=true;surface.hidden=true;surface.setAttribute('aria-expanded','false');document.dispatchEvent(new Event('isma:immersivechange'));if(restore&&core.navigation.current()==='p12'){enter.focus({preventScroll:true});window.scrollTo(0,scroll);}return true;}
core.events.on('navigation:changed',({to})=>{if(to!=='p12')close(false);});
new MutationObserver(()=>{if(active&&!body.classList.contains('rb-music-player'))close(false);}).observe(body,{attributes:true,attributeFilter:['class']});
const back=window.__goBack;window.__goBack=()=>close()||back?.()||false;
document.addEventListener('keydown',e=>{if(!active)return;if(e.key==='Escape'){e.preventDefault();e.stopImmediatePropagation();close();}else if(e.code==='Space'&&e.target===surface){e.preventDefault();music.toggle();show();}},true);
document.addEventListener('visibilitychange',()=>{if(document.hidden)clearTimeout(timer);else if(active)show();});
})();
