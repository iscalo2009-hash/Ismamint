# Alpha 7.37.1 — Together

Base: Alpha 7.37 Hidden Side. Se agregan 3 logros secretos sin subcategoría; no se eliminan los anteriores. Total de secretos documentados: 98 (65 anteriores + 33 de Hidden Side). No modifica Pulse, notificaciones personalizadas ni vibraciones.

- Mucho texto: 444 puntos de código Unicode, contando espacios, en un mensaje nuevo de texto confirmado. Mensaje: `mucho texto, te amo`.
- Tienes razón: mensaje exacto `tienes razon`, con o sin acento, ignorando mayúsculas y espacios exteriores. Mensaje: `momento historico, hagan captura` y destello dorado. Ambos efectos se pueden repetir, el logro solo una vez por dispositivo; siguiendo el comportamiento de secretos del chat, tanto quien envía como quien recibe puede descubrirlos durante una sesión activa.
- Los dos aquí: los dos miembros autenticados en primer plano, con presencia reciente confirmada por el servidor. Indicador bajo el encabezado general, visible solo si hay coincidencia reciente. El logro requiere una señal de la pareja posterior o igual a la primera señal confirmada de la sesión actual; así una señal anterior a la entrada no basta por sí sola. Se registra una vez por dispositivo mediante el sistema de logros existente, sin nueva notificación remota.

## Firebase
Publicar `firestore.rules` (contiene las reglas previas y el nuevo bloque `ismamint_presence`). Si hay modificaciones externas, integrar únicamente el bloque nuevo en lugar de sobrescribirlas. Cada cuenta puede leer los dos documentos autorizados y escribir solo el suyo. Guarda únicamente ID de sesión, estado activo y hora del servidor, no historial. Usa transacciones sin cola offline, refresco cada 20 s y caducidad máxima de 40 s. Al salir intenta marcar inactivo; si hay desconexión, el estado caduca. Respeta Chat > Privacidad > Mostrar actividad en ISMAMINT y escribiendo. La indicación es aproximada y no sirve para conocer actividad en otros programas ni en segundo plano. Ambos teléfonos deben estar actualizados, autenticados y conectados. No cambiar Cloudflare.

## Validación
50 suites JS, análisis sintáctico de 30 fuentes Java con JavacTask y prueba Chromium de los dos disparadores, indicación simulada, caducidad y persistencia del logro. No se ha compilado APK ni ejecutado contra el Firebase real; tampoco se han verificado reglas con emulador.
