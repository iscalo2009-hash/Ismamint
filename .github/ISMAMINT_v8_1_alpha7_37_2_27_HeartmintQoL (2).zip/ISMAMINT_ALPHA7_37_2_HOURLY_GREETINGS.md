# Alpha 7.37.2 — 24 horas contigo

Base Alpha 7.37.1 Together. Se incorporan los 24 mensajes del JSON del usuario literalmente. A las 04:44 y 16:44 del reloj local, durante el minuto completo, el saludo es exactamente `4:44`, incluso en festividades. A las 04:45/16:45 vuelve el saludo horario o el especial de la fecha. Los saludos festivos conservan prioridad fuera de ese minuto. El saludo se verifica cada segundo y al volver a primer plano, y solo se redibuja si cambia el minuto o el desfase horario. No se alteran las notificaciones, los logros, la presencia, Firebase ni Cloudflare.

Prueba específica: tests/hourly-greetings.test.js cubre los 1440 minutos del día en Colombia, México y Madrid y los límites del minuto especial. No implica verificación en Android real.
