# Alpha 7.35.1 — Textos personalizados

- 38 variantes de avisos actualizadas según el JSON del usuario.
- 6 frases semanales eliminadas del aviso del domingo.
- Se conservan los nombres dinámicos, números y fechas; los textos se respetan literalmente.
- Las variantes ocultas de latidos y regalos ahora muestran el nombre de la pareja, tal como se solicitó; no exponen el contenido de mensajes o regalos.
- El texto de cumpleaños es el escrito por Ismael, idéntico en los dos teléfonos.
- El aviso de prueba conserva su texto original (no incluido en los cambios).
- Los textos de avisos de fechas con logro (43/44) se actualizaron, pero el filtro anterior excluye la categoría fe de esa ruta; no se cambió el criterio de programación.
- No se modificaron Pulse 2.1, vibraciones, reglas, permisos, apariencia ni horarios.
- Pruebas: 29 archivos Java analizados sintácticamente, 49 scripts de pruebas JS ejecutados y prueba de programación en Colombia/CDMX superada. Sin compilación APK ni prueba de dispositivo real.
