# Alpha 7.34.2 · Lyric Sync

Base: Alpha 7.34.1 Public Heartbeats. No cambios en actualizador público, firma, reglas Firebase, archivos Opus ni otras canciones.

- Esclava – Remix: 2026-10-05 → 2025-10-05 (día y mes conservados).
- Wonderwall: marcas directas de `Oasis - Wonderwall (Remastered).lrc`, archivo del usuario `karaoke-lrc-karaoke.zip`. Se sustituyen los tiempos de línea base incorrectos, sin reescalado. 47 líneas, 268 marcas de inicio de palabra, 20 intervalos vacíos. Primer inicio 22.33 s, último inicio de línea 217.48 s. Duración del Opus: 258.779833 s. Los finales de palabra no están incluidos en el LRC y se estiman; no se ha verificado la voz mediante alineación acústica independiente.
- Migración única de la sincronización manual de Wonderwall: respaldo en `ismamint_music_previousSync`, eliminación del ajuste anterior, conservación de todos los demás ajustes y posibilidad de volver a calibrar manualmente.
- Limpieza de letras anteriores al buscar una posición o cambiar canción. Wonderwall no superpone fantasmas ni aplica una entrada lenta a cada frase, para respetar los tiempos de referencia.
- Pruebas: 49 suites Node; referencia global 1725 líneas / 12003 palabras, 1153 líneas estimadas, 0 marcas inválidas; integración Home y prueba específica Wonderwall (inicio, silencios, final, búsqueda hacia atrás, migración).
- No se ha compilado APK ni probado reproducción vocal en Android físico.
