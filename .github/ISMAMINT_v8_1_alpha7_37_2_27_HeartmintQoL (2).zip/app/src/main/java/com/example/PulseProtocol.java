package com.example;

/** Pure protocol validation, independently testable without Android or Firebase. */
final class PulseProtocol {
    private static final String A="MCbwjlCpBnhTHxfQTuvcOVWLN3w2", I="MIPr6C3HW5QPp9GXd5ZjlHCmFQJ3";
    private PulseProtocol() {}
    static boolean member(String uid){return A.equals(uid)||I.equals(uid);}
    static String peer(String uid){return A.equals(uid)?I:I.equals(uid)?A:null;}
    static boolean valid(String kind,String id){
        if(kind==null||id==null)return false;
        switch(kind){
            case "message":case "pulse":return id.matches("[A-Za-z0-9]{20}");
            case "gift":case "gift_opened":return id.matches("[-A-Za-z0-9_]{1,90}");
            default:return false;
        }
    }
    static String deliveryId(String sender,String kind,String id){
        if(!member(sender)||!valid(kind,id))return null;
        return sender+"_"+("pulse".equals(kind)?"message":kind)+"_"+id;
    }
    static boolean fresh(String kind,long age){
        long limit="pulse".equals(kind)?120000L:"gift".equals(kind)?86400000L:600000L;
        return age>=-60000L&&age<=limit;
    }
}
