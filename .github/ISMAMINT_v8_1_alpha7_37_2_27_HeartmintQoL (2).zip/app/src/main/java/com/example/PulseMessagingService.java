package com.example;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

/** Data-only FCM: never trusts payload text or opens a gift automatically. */
public final class PulseMessagingService extends FirebaseMessagingService {
    @Override public void onNewToken(String token){PulseClient.register(this);}
    @Override public void onMessageReceived(RemoteMessage message){PulseClient.receive(this,message.getData(),message.getPriority()==RemoteMessage.PRIORITY_HIGH);}
    @Override public void onDeletedMessages(){ChatNotifications.schedule(this);GiftNotifications.schedule(this);PulseWork.catchup(this);}
}
