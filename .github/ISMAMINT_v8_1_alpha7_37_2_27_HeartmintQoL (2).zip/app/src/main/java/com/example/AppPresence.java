package com.example;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.webkit.WebView;
import com.google.firebase.Timestamp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.*;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Foreground-only, two-member presence lease. No history or background service. */
final class AppPresence {
    private static final String A="MCbwjlCpBnhTHxfQTuvcOVWLN3w2", I="MIPr6C3HW5QPp9GXd5ZjlHCmFQJ3";
    private static final long INTERVAL=20000, LEASE=40000;
    private final WebView web;
    private final FirebaseAuth auth;
    private final FirebaseFirestore db=FirebaseFirestore.getInstance();
    private final CollectionReference docs=db.collection("ismamint_presence");
    private final Handler main=new Handler(Looper.getMainLooper());
    private final FirebaseAuth.AuthStateListener authListener;
    private boolean foreground, destroyed;
    private String user, session;
    private volatile long generation;
    private long firstBeat;
    private final Runnable tick=this::poll;
    AppPresence(WebView web,FirebaseAuth auth){
        this.web=web;this.auth=auth;
        authListener=a->main.post(this::refresh);
        auth.addAuthStateListener(authListener);
    }
    private String member(){FirebaseUser u=auth.getCurrentUser();if(u==null)return null;String id=u.getUid();return A.equals(id)||I.equals(id)?id:null;}
    private boolean allowed(){return web.getContext().getSharedPreferences("isma_chat_privacy",Context.MODE_PRIVATE).getBoolean("seen",true);}
    void resume(){foreground=true;refresh();}
    void pause(){foreground=false;stop();}
    void privacyChanged(){refresh();}
    void destroy(){foreground=false;stop();destroyed=true;auth.removeAuthStateListener(authListener);}
    private void refresh(){if(destroyed)return;String u=member();if(!foreground||!allowed()||u==null){stop();return;}if(u.equals(user)&&session!=null)return;stop();user=u;session=UUID.randomUUID().toString();firstBeat=0;poll();}
    private Map<String,Object> value(String s,boolean active){Map<String,Object> m=new HashMap<>();m.put("session",s);m.put("active",active);m.put("updated",FieldValue.serverTimestamp());return m;}
    private void emit(boolean online,boolean confirmed,long ttl){if(!destroyed)web.evaluateJavascript("window.IsmaHidden&&window.IsmaHidden.presence("+online+","+confirmed+","+ttl+")",null);}
    private void stop(){
        ++generation;main.removeCallbacks(tick);String u=user,s=session;user=null;session=null;firstBeat=0;emit(false,false,0);
        if(u==null||s==null||!u.equals(member()))return;
        DocumentReference own=docs.document(u);
        // Transaction never queues an offline 'online' update; compare session before closing.
        db.runTransaction(tx->{DocumentSnapshot previous=tx.get(own);if(!previous.exists()||s.equals(previous.getString("session")))tx.set(own,value(s,false));return null;});
    }
    private boolean current(long g,String u,String s){return !destroyed&&foreground&&g==generation&&u.equals(user)&&s.equals(session)&&u.equals(member())&&allowed();}
    private void next(long g,String u,String s){if(current(g,u,s)){main.removeCallbacks(tick);main.postDelayed(tick,INTERVAL);}}
    private void poll(){
        final String u=user,s=session;final long g=generation;
        if(u==null||s==null||!current(g,u,s))return;
        final long started=SystemClock.elapsedRealtime();
        final DocumentReference own=docs.document(u),other=docs.document(A.equals(u)?I:A);
        db.runTransaction(tx->{
            // Read own as well to serialize with a concurrent close of this session.
            tx.get(own);DocumentSnapshot peer=tx.get(other);
            if(g!=generation)throw new FirebaseFirestoreException("Presence session ended",FirebaseFirestoreException.Code.ABORTED);
            tx.set(own,value(s,true));return peer;
        }).addOnCompleteListener(t->{
            if(!current(g,u,s))return;
            if(!t.isSuccessful()){emit(false,false,0);next(g,u,s);return;}
            DocumentSnapshot peer=t.getResult();
            own.get(Source.SERVER).addOnCompleteListener(result->{
                if(!current(g,u,s))return;
                if(!result.isSuccessful()){emit(false,false,0);next(g,u,s);return;}
                DocumentSnapshot self=result.getResult();Timestamp selfTime=self.getTimestamp("updated"),peerTime=peer.getTimestamp("updated");
                if(!s.equals(self.getString("session"))||!Boolean.TRUE.equals(self.getBoolean("active"))||selfTime==null){emit(false,false,0);next(g,u,s);return;}
                long serverNow=selfTime.toDate().getTime();if(firstBeat==0)firstBeat=serverNow;
                long peerStamp=peerTime==null?0:peerTime.toDate().getTime(),age=serverNow-peerStamp;
                long ttl=LEASE-age-Math.max(0,SystemClock.elapsedRealtime()-started);
                boolean online=Boolean.TRUE.equals(peer.getBoolean("active"))&&peerStamp>0&&age>=0&&ttl>0;
                emit(online,online&&peerStamp>=firstBeat,online?ttl:0);next(g,u,s);
            });
        });
    }
}
