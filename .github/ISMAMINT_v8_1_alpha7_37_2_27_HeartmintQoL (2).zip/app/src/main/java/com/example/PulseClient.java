package com.example;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.util.Log;
import androidx.work.*;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.FirebaseAuth;
import org.json.JSONObject;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.TimeUnit;
import com.google.android.gms.tasks.Tasks;

/** Account-bound, durable transport. Only Firebase ID tokens leave the device. */
final class PulseClient {
    static final String BASE="https://ismamint-pulse.iscalo2009.workers.dev";
    static final long MIN=60_000L, DAY=86_400_000L;
    static final String TAG="IsmamintPulse";
    private static final Constraints NETWORK=new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build();
    private PulseClient() {}
    static boolean member(String u){return PulseProtocol.member(u);}
    static String peer(String u){return PulseProtocol.peer(u);}
    static boolean valid(String kind,String id){return PulseProtocol.valid(kind,id);}
    private static Data data(String mode,String uid,String kind,String id){return new Data.Builder().putString("mode",mode).putString("uid",uid).putString("kind",kind).putString("id",id).putLong("queued",System.currentTimeMillis()).build();}
    private static void enqueue(Context c,String name,Data data,boolean urgent){
        try {
            OneTimeWorkRequest.Builder b=new OneTimeWorkRequest.Builder(PulseWork.class).setInputData(data).setConstraints(NETWORK).setBackoffCriteria(BackoffPolicy.EXPONENTIAL,10,TimeUnit.SECONDS).addTag("ismamint-pulse");
            // Pre-Android 12 expedited jobs require a foreground service; keep the old fallback instead.
            if(urgent&&Build.VERSION.SDK_INT>=31)b.setExpedited(OutOfQuotaPolicy.RUN_AS_NON_EXPEDITED_WORK_REQUEST);
            WorkManager.getInstance(c.getApplicationContext()).enqueueUniqueWork(name,ExistingWorkPolicy.KEEP,b.build());
        }catch(RuntimeException e){Log.w(TAG,"enqueue_failed",e);}
    }
    static void start(Context c){
        String u=ChatNotifications.uid();if(!member(u))return;
        try{
            WorkManager.getInstance(c.getApplicationContext()).enqueueUniquePeriodicWork("pulse-register-periodic",ExistingPeriodicWorkPolicy.KEEP,new PeriodicWorkRequest.Builder(PulseWork.class,12,TimeUnit.HOURS).setConstraints(NETWORK).setInputData(new Data.Builder().putString("mode","register").build()).build());
        }catch(RuntimeException e){Log.w(TAG,"periodic_failed",e);}
        register(c);
    }
    static void register(Context c){String u=ChatNotifications.uid();if(member(u))enqueue(c,"pulse-register-"+u,data("register",u,"",""),false);}
    static void send(Context c,String u,String kind,String id){
        if(!member(u)||!u.equals(ChatNotifications.uid())||!valid(kind,id)||"pulse".equals(kind))return;
        enqueue(c,"pulse-send-"+u+"_"+kind+"_"+id,data("send",u,kind,id),true);
    }
    static void receive(Context c,Map<String,String> m,boolean urgent){
        String u=m.get("recipient"),s=m.get("sender"),kind=m.get("kind"),id=m.get("eventId"),delivery=m.get("deliveryId"),v=m.get("v");
        if(!member(u)||!peer(u).equals(s)||!valid(kind,id)||!u.equals(ChatNotifications.uid())||!("1".equals(v)||"2".equals(v)))return;
        String expected=PulseProtocol.deliveryId(s,kind,id);
        if(!expected.equals(delivery))return;
        long created;try{created=Long.parseLong(m.get("created"));}catch(RuntimeException e){return;}
        long age=System.currentTimeMillis()-created;
        if(!PulseProtocol.fresh(kind,age))return;
        Data input=new Data.Builder().putString("mode","receive").putString("uid",u).putString("kind",kind).putString("id",id).putString("delivery",delivery).putLong("created",created).putLong("queued",System.currentTimeMillis()).build();
        enqueue(c,"pulse-receive-"+delivery,input,urgent);
    }
    static JSONObject json(Object... args) throws Exception {JSONObject o=new JSONObject();for(int i=0;i<args.length;i+=2)o.put((String)args[i],args[i+1]);return o;}
    static final class Reply {final int status;final JSONObject data;Reply(int s,JSONObject d){status=s;data=d;}boolean ok(){return status>=200&&status<300&&data.optBoolean("ok",false);}String error(){return data.optString("error","");}boolean retry(){return status==401||status==408||status==429||status>=500;}}
    static Reply call(String u,String path,JSONObject body) throws Exception {
        for(int i=0;i<2;i++){
            FirebaseUser user=FirebaseAuth.getInstance().getCurrentUser();if(user==null||!u.equals(user.getUid()))throw new SecurityException("account_changed");
            String token=Tasks.await(user.getIdToken(i!=0),12,TimeUnit.SECONDS).getToken();
            if(token==null||!u.equals(ChatNotifications.uid()))throw new SecurityException("account_changed");
            HttpURLConnection conn=(HttpURLConnection)new URL(BASE+path).openConnection();
            try{
                conn.setInstanceFollowRedirects(false);conn.setConnectTimeout(8000);conn.setReadTimeout(15000);conn.setRequestMethod("POST");conn.setDoOutput(true);
                conn.setRequestProperty("Authorization","Bearer "+token);conn.setRequestProperty("Content-Type","application/json");
                byte[] bytes=body.toString().getBytes(StandardCharsets.UTF_8);conn.setFixedLengthStreamingMode(bytes.length);
                try(OutputStream out=conn.getOutputStream()){out.write(bytes);}
                int status=conn.getResponseCode();if(status==401&&i==0)continue;
                InputStream stream=status>=400?conn.getErrorStream():conn.getInputStream();ByteArrayOutputStream result=new ByteArrayOutputStream();
                if(stream!=null)try(InputStream in=stream){byte[] buf=new byte[2048];int n;while((n=in.read(buf))!=-1){if(result.size()+n>16384)throw new IOException("response_too_large");result.write(buf,0,n);}}
                JSONObject j;try{j=new JSONObject(result.toString("UTF-8"));}catch(Exception e){j=new JSONObject();}
                return new Reply(status,j);
            }finally{conn.disconnect();}
        }
        return new Reply(401,new JSONObject());
    }
    /** Shared by FCM and Firestore catch-up; claims survive process death. */
    static synchronized boolean claimChat(Context c,String u,String id){
        SharedPreferences p=c.getSharedPreferences("isma_pulse_chat_dedup_"+u,Context.MODE_PRIVATE);long now=System.currentTimeMillis();
        if(p.getLong(id,0)>now-2*DAY)return false;
        SharedPreferences.Editor e=p.edit().putLong(id,now);
        if(now-p.getLong("_pruned",0)>60*MIN){
            for(Map.Entry<String,?> x:p.getAll().entrySet())if(!"_pruned".equals(x.getKey())&&x.getValue() instanceof Long&&(Long)x.getValue()<=now-2*DAY)e.remove(x.getKey());
            e.putLong("_pruned",now);
        }
        return e.commit();
    }
}
