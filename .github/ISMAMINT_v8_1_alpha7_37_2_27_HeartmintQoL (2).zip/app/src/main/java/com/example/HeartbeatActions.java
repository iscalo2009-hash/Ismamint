package com.example;

import android.app.*;
import android.content.*;
import android.os.*;
import com.google.firebase.firestore.*;
import java.util.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;

/** Explicit, account-bound notification actions. No server credentials or new collections. */
public final class HeartbeatActions extends BroadcastReceiver {
    static final String REPLY_KEY="isma_direct_reply", PREFIX="♥ Latido:";
    static long[] pattern(String text){
        if(text==null||!text.startsWith(PREFIX))return null;
        String[] parts=text.substring(PREFIX.length()).split(",",-1);
        if(parts.length<2||parts.length>16)return null;
        long[] result=new long[parts.length];long total=0;
        try{for(int i=0;i<parts.length;i++){if(!parts[i].matches("[0-9]{1,4}"))return null;long n=Long.parseLong(parts[i]);if(i==0?n!=0:n<90||n>3000)return null;total+=n;result[i]=n;}}catch(NumberFormatException e){return null;}
        return total<=8000?result:null;
    }
    static boolean isPulse(String text){return ChatNotifications.PULSE_TEXT.equals(text)||pattern(text)!=null;}
    static PendingIntent intent(Context c,String uid,String source,boolean reply,boolean widget){
        Intent i=new Intent(c,HeartbeatActions.class).setAction(widget?"isma.widget.pulse":reply?"isma.reply.text":"isma.reply.pulse").setData(android.net.Uri.parse("ismamint://action/"+uid+"/"+source)).putExtra("account",uid).putExtra("source",source);
        int flags=PendingIntent.FLAG_UPDATE_CURRENT|(reply?(Build.VERSION.SDK_INT>=31?PendingIntent.FLAG_MUTABLE:0):PendingIntent.FLAG_IMMUTABLE);
        return PendingIntent.getBroadcast(c,0,i,flags);
    }
    static PendingIntent replayIntent(Context c,String uid,String source,String text){
        Intent i=new Intent(c,HeartbeatActions.class).setAction("isma.replay.pulse").setData(android.net.Uri.parse("ismamint://replay/"+uid+"/"+source)).putExtra("account",uid).putExtra("source",source).putExtra("pattern",text);
        return PendingIntent.getBroadcast(c,0,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    }
    static Map<String,Object> message(String uid,String text,String reply){Map<String,Object> m=new HashMap<>();m.put("sender",uid);m.put("text",text);m.put("created",FieldValue.serverTimestamp());m.put("reply",reply);m.put("edited",false);m.put("deleted",false);m.put("reactions",new HashMap<String,String>());return m;}
    static String stable(String uid,String source,String action){try{byte[] hash=MessageDigest.getInstance("SHA-256").digest((uid+":"+source+":"+action).getBytes(StandardCharsets.UTF_8));StringBuilder b=new StringBuilder();for(int i=0;i<10;i++)b.append(String.format(Locale.ROOT,"%02x",hash[i]&255));return b.toString();}catch(Exception e){throw new IllegalStateException(e);}}
    @Override public void onReceive(Context c,Intent i){
        String uid=ChatNotifications.uid(),source=i.getStringExtra("source"),action=i.getAction();
        if("isma.replay.pulse".equals(action)){
            String text=i.getStringExtra("pattern");
            if(uid!=null&&uid.equals(i.getStringExtra("account"))&&source!=null&&source.matches("[A-Za-z0-9]{20}")&&isPulse(text)){
                NotificationManager nm=ChatNotifications.manager(c);NotificationChannel ch=nm==null?null:nm.getNotificationChannel(ChatNotifications.PULSE_CHANNEL);
                if(NoticePreferences.on(c,"pulses")&&nm!=null&&nm.areNotificationsEnabled()&&ch!=null&&ch.shouldVibrate()&&ch.getImportance()!=NotificationManager.IMPORTANCE_NONE)TactileEngine.replay(c,pattern(text));
            }return;
        }
        boolean widget="isma.widget.pulse".equals(action),reply="isma.reply.text".equals(action);
        if(uid==null||!uid.equals(i.getStringExtra("account"))||source==null||(!widget&&!source.matches("[A-Za-z0-9]{20}"))||(!widget&&!reply&&!"isma.reply.pulse".equals(action)))return;
        Bundle remote=reply?RemoteInput.getResultsFromIntent(i):null;CharSequence input=remote==null?null:remote.getCharSequence(REPLY_KEY);
        String text=reply?(input==null?"":input.toString().trim()):ChatNotifications.PULSE_TEXT;
        if(text.isEmpty()||text.length()>4000)return;
        if(widget){long now=System.currentTimeMillis();android.content.SharedPreferences prefs=ChatNotifications.prefs(c);if(now-prefs.getLong(uid+"_widget_pulse",0)<3000)return;prefs.edit().putLong(uid+"_widget_pulse",now).apply();}
        PendingResult pending=goAsync();Handler handler=new Handler(Looper.getMainLooper());java.util.concurrent.atomic.AtomicBoolean finished=new java.util.concurrent.atomic.AtomicBoolean();Runnable end=()->{if(finished.compareAndSet(false,true))pending.finish();};handler.postDelayed(end,8000);
        DocumentReference ref=widget?ChatNotifications.messages().document():ChatNotifications.messages().document(stable(uid,source,action));
        // Firestore persists the local mutation when offline. Same notification always targets the same document.
        if(widget)android.widget.Toast.makeText(c,"Latido pendiente",android.widget.Toast.LENGTH_SHORT).show();
        ref.set(message(uid,text,widget?"":source)).addOnCompleteListener(t->{
            if(t.isSuccessful())PulseClient.send(c,uid,"message",ref.getId());
            if(t.isSuccessful()&&uid.equals(ChatNotifications.uid())&&!widget){NotificationManager nm=ChatNotifications.manager(c);int id=reply?ChatNotifications.NOTICE:ChatNotifications.PULSE_NOTICE;if(nm!=null)for(android.service.notification.StatusBarNotification n:nm.getActiveNotifications())if(n.getId()==id&&source.equals(n.getNotification().extras.getString("isma_source")))nm.cancel(id);}
            handler.removeCallbacks(end);end.run();
        });
        PulseClient.send(c,uid,"message",ref.getId());
    }
}
