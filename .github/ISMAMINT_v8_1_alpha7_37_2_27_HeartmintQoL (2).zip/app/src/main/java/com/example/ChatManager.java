package com.example;

import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.os.Handler;
import android.os.Looper;
import com.google.firebase.Timestamp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.*;
import org.json.*;
import java.util.*;

/** Native, foreground-only chat bridge. No credentials or chat data in localStorage. */
public final class ChatManager {
    private static final String A="MCbwjlCpBnhTHxfQTuvcOVWLN3w2", I="MIPr6C3HW5QPp9GXd5ZjlHCmFQJ3";
    private final WebView web;
    private final ChatNotifications notifications;
    private final Handler main=new Handler(Looper.getMainLooper());
    private final FirebaseAuth auth;
    private final AppPresence appPresence;
    private final CollectionReference messages, states, receipts;
    private ListenerRegistration receiptListener;
    private boolean shareSeen=true,shareRead=true;
    private final Set<String> deliveredIds=new HashSet<>(),readIds=new HashSet<>();
    private DocumentSnapshot oldest;
    private ListenerRegistration msgListener, stateListener;
    private ListenerRegistration secretMessages, secretMusic;
    private String secretSong = "";
    private long secretSongEpoch = 0;
    private boolean active, foreground, destroyed, typing;
    private int limit=50;
    private long lastTyping=0;
    private String latestIncoming="";
    private final Runnable heartbeat=new Runnable(){public void run(){if(active&&foreground&&uid()!=null){presence(typing);main.postDelayed(this,25000);}}};
    public ChatManager(WebView web){this.web=web;notifications=new ChatNotifications((android.app.Activity)web.getContext());auth=FirebaseAuth.getInstance();appPresence=new AppPresence(web,auth);DocumentReference room=FirebaseFirestore.getInstance().collection("ismamint_chat").document("private");messages=room.collection("messages");states=room.collection("states");receipts=room.collection("receipts");}
    private String uid(){FirebaseUser u=auth.getCurrentUser();return u!=null&&(A.equals(u.getUid())||I.equals(u.getUid()))?u.getUid():null;}
    private String peer(){return A.equals(uid())?I:A;}
    private void emit(String type,Object value){if(destroyed)return;try{JSONObject o=new JSONObject();o.put("type",type);o.put("value",value==null?JSONObject.NULL:value);web.evaluateJavascript("window.IsmaChat&&window.IsmaChat.receive("+JSONObject.quote(o.toString())+")",null);}catch(JSONException ignored){}}
    private void error(Exception e){emit("error", e instanceof FirebaseFirestoreException&&((FirebaseFirestoreException)e).getCode()==FirebaseFirestoreException.Code.PERMISSION_DENIED?"Acceso denegado. Comprueba las reglas de Firestore.":"No se pudo completar la operación. Comprueba tu conexión o tus datos.");}
    private void session(){String u=uid();emit("session",u);}
    @JavascriptInterface public void open(boolean value){main.post(()->{active=value;notifications.chat(value);if(value){session();start();}else {finishVoice(false);stop();}});}
    @JavascriptInterface public void login(String email,String password){main.post(()->{auth.signInWithEmailAndPassword(email.trim(),password).addOnCompleteListener(t->{if(destroyed)return;if(!t.isSuccessful()){error(t.getException());return;}if(uid()==null){auth.signOut();emit("error","Cuenta no autorizada.");return;}session();PulseClient.start(web.getContext());start();startSecretMessages();});});}
    @JavascriptInterface public void logout(){main.post(()->{appPresence.pause();stopSecrets();stop();auth.signOut();if(foreground)appPresence.resume();limit=50;latestIncoming="";session();});}
    public void resume(){foreground=true;appPresence.resume();notifications.setPulseListener(text->alive("heartbeatReceived",text));notifications.resume(active);startSecretMessages();if(active){session();start();}}
    public void pause(){appPresence.pause();stopSecrets();foreground=false;notifications.setPulseListener(null);notifications.pause();finishVoice(false);stop();}
    public void destroy(){appPresence.destroy();stopSecrets();finishVoice(false);stop();notifications.destroy();destroyed=true;}
    @JavascriptInterface public String notificationOptions(){return notifications.options();}
    @JavascriptInterface public void configureNotifications(boolean enabled,boolean preview,String mute){main.post(()->{try{notifications.configure(enabled,preview,Long.parseLong(mute));emit("notificationOptions",notifications.options());}catch(NumberFormatException ignored){}});}
    @JavascriptInterface public void notificationPermission(){main.post(notifications::requestPermission);}
    @JavascriptInterface public void notificationSettings(){main.post(notifications::openSettings);}
    private void start(){if(!active||!foreground||uid()==null||msgListener!=null)return;subscribe();stateListener=states.document(peer()).addSnapshotListener((s,e)->{if(!active||!foreground)return;if(e!=null){error(e);return;}try{JSONObject o=new JSONObject();if(s!=null&&s.exists()){o.put("seen",ms(s.getTimestamp("seen")));o.put("typing",Boolean.TRUE.equals(s.getBoolean("typing")));o.put("read",ms(s.getTimestamp("read")));o.put("shareSeen",!Boolean.FALSE.equals(s.getBoolean("shareSeen")));o.put("shareRead",!Boolean.FALSE.equals(s.getBoolean("shareRead")));}emit("peer",o);}catch(JSONException ignored){}});android.content.SharedPreferences prefs=web.getContext().getSharedPreferences("isma_chat_privacy",0);shareSeen=prefs.getBoolean("seen",true);shareRead=prefs.getBoolean("read",true);receiptListener=receipts.whereEqualTo("recipient",peer()).addSnapshotListener((q,e)->{if(e!=null||q==null||!active||!foreground)return;try{JSONObject out=new JSONObject();for(DocumentSnapshot d:q.getDocuments()){JSONObject r=new JSONObject();r.put("delivered",ms(d.getTimestamp("delivered")));r.put("read",ms(d.getTimestamp("read")));out.put(d.getId(),r);}emit("receipts",out);}catch(JSONException ignored){}});presence(false);main.removeCallbacks(heartbeat);main.postDelayed(heartbeat,25000);}
    private void stop(){main.removeCallbacks(heartbeat);if(receiptListener!=null){receiptListener.remove();receiptListener=null;}if(msgListener!=null){msgListener.remove();msgListener=null;}if(stateListener!=null){stateListener.remove();stateListener=null;}if(uid()!=null&&shareSeen&&(typing||lastTyping!=0)){Map<String,Object> m=new HashMap<>();m.put("typing",false);m.put("seen",FieldValue.serverTimestamp());states.document(uid()).set(m,SetOptions.merge());}typing=false;lastTyping=0;}
    // Recent private message metadata is reused for pair achievements. No extra message documents.
    private void startSecretMessages(){
        if(destroyed||!foreground||uid()==null||secretMessages!=null)return;
        final String u=uid();
        secretMessages=messages.orderBy("created",Query.Direction.DESCENDING).limit(40).addSnapshotListener(MetadataChanges.INCLUDE,(snap,error)->{
            if(error!=null||snap==null||snap.getMetadata().isFromCache()||destroyed||!foreground||!u.equals(uid()))return;
            JSONArray arr=new JSONArray();
            try{for(DocumentSnapshot doc:snap.getDocuments()){
                if(doc.getMetadata().hasPendingWrites())continue;
                Timestamp ts=doc.getTimestamp("created");if(ts==null)continue;
                JSONObject row=new JSONObject();row.put("id",doc.getId());row.put("sender",doc.getString("sender"));row.put("text",doc.getString("text"));row.put("kind",doc.getString("kind"));row.put("created",ms(ts));row.put("deleted",Boolean.TRUE.equals(doc.getBoolean("deleted")));row.put("edited",Boolean.TRUE.equals(doc.getBoolean("edited")));arr.put(row);
            }web.evaluateJavascript("window.IsmaHidden&&window.IsmaHidden.messages("+arr.toString()+")",null);}catch(JSONException ignored){}
        });
    }
    // Music coincidence is foreground-only. Only the current track ID and server timestamp are stored.
    @JavascriptInterface public void secretSong(String song){main.post(()->{
        String u=uid();if(destroyed||!foreground||u==null||song==null||(!song.isEmpty()&&!song.matches("s[0-9]{2,3}")))return;
        if(song.isEmpty()){clearSecretMusic();return;}
        boolean changed=!song.equals(secretSong);secretSong=song;long epoch=++secretSongEpoch;
        CollectionReference music=FirebaseFirestore.getInstance().collection("ismamint_secret_music");
        if(secretMusic==null)secretMusic=music.document(peer()).addSnapshotListener(MetadataChanges.INCLUDE,(snap,error)->{
            if(error!=null||snap==null||snap.getMetadata().isFromCache()||!foreground||destroyed||!u.equals(uid())||secretSong.isEmpty())return;
            emitSecretMusic(snap);
        });
        Map<String,Object> value=new HashMap<>();value.put("song",song);value.put("updated",FieldValue.serverTimestamp());
        music.document(u).set(value).addOnSuccessListener(v->{
            if(changed&&epoch==secretSongEpoch&&foreground&&u.equals(uid()))music.document(peer()).get(Source.SERVER).addOnSuccessListener(snap->{if(epoch==secretSongEpoch&&foreground&&u.equals(uid()))emitSecretMusic(snap);});
        });
    });}
    private void emitSecretMusic(DocumentSnapshot snap){
        try{JSONObject obj=new JSONObject();obj.put("song",snap.exists()?snap.getString("song"):"");obj.put("updated",ms(snap.getTimestamp("updated")));web.evaluateJavascript("window.IsmaHidden&&window.IsmaHidden.songPeer("+obj.toString()+")",null);}catch(JSONException ignored){}
    }
    private void clearSecretMusic(){
        ++secretSongEpoch;if(secretMusic!=null){secretMusic.remove();secretMusic=null;}
        String u=uid();if(!secretSong.isEmpty()&&u!=null){Map<String,Object> value=new HashMap<>();value.put("song","");value.put("updated",FieldValue.serverTimestamp());FirebaseFirestore.getInstance().collection("ismamint_secret_music").document(u).set(value);}
        secretSong="";
    }
    private void stopSecrets(){if(secretMessages!=null){secretMessages.remove();secretMessages=null;}clearSecretMusic();}
    private long ms(Timestamp t){return t==null?0:t.toDate().getTime();}
    private void subscribe(){oldest=null;if(msgListener!=null)msgListener.remove();msgListener=messages.orderBy("created",Query.Direction.DESCENDING).limit(limit).addSnapshotListener(MetadataChanges.INCLUDE,(s,e)->{if(!active||!foreground||uid()==null)return;if(e!=null){error(e);return;}if(s==null)return;try{JSONArray arr=new JSONArray();List<DocumentSnapshot> docs=s.getDocuments();if(oldest==null&&!docs.isEmpty())oldest=docs.get(docs.size()-1);for(int n=docs.size()-1;n>=0;n--){DocumentSnapshot d=docs.get(n);JSONObject o=new JSONObject();o.put("id",d.getId());o.put("sender",d.getString("sender"));o.put("text",d.getString("text"));o.put("kind",d.getString("kind"));o.put("filename",d.getString("filename"));o.put("bytes",d.getLong("bytes"));o.put("duration",d.getLong("duration"));o.put("reply",d.getString("reply"));o.put("created",ms(d.getTimestamp("created",DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)));o.put("edited",Boolean.TRUE.equals(d.getBoolean("edited")));o.put("deleted",Boolean.TRUE.equals(d.getBoolean("deleted")));o.put("pending",d.getMetadata().hasPendingWrites());Object r=d.get("reactions");o.put("reactions",r instanceof Map?new JSONObject((Map)r):new JSONObject());arr.put(o);}
        JSONObject out=new JSONObject();out.put("items",arr);out.put("more",docs.size()==limit);out.put("cache",s.getMetadata().isFromCache());emit("messages",out);if(!s.getMetadata().isFromCache())for(DocumentSnapshot d:docs)if(!d.getMetadata().hasPendingWrites()&&!uid().equals(d.getString("sender")))receipt(d.getId(),false);
    }catch(JSONException ignored){}});}
    @JavascriptInterface public void older(){main.post(()->{if(!active||!foreground||uid()==null||oldest==null){emit("older",new JSONObject());return;}String u=uid();messages.orderBy("created",Query.Direction.DESCENDING).startAfter(oldest).limit(50).get().addOnSuccessListener(q->{if(!u.equals(uid()))return;try{JSONArray arr=new JSONArray();List<DocumentSnapshot> docs=q.getDocuments();if(!docs.isEmpty())oldest=docs.get(docs.size()-1);for(int n=docs.size()-1;n>=0;n--){DocumentSnapshot d=docs.get(n);JSONObject o=new JSONObject();o.put("id",d.getId());o.put("sender",d.getString("sender"));o.put("text",d.getString("text"));o.put("kind",d.getString("kind"));o.put("filename",d.getString("filename"));o.put("bytes",d.getLong("bytes"));o.put("duration",d.getLong("duration"));o.put("reply",d.getString("reply"));o.put("created",ms(d.getTimestamp("created")));o.put("edited",Boolean.TRUE.equals(d.getBoolean("edited")));o.put("deleted",Boolean.TRUE.equals(d.getBoolean("deleted")));o.put("pending",false);Object r=d.get("reactions");o.put("reactions",r instanceof Map?new JSONObject((Map)r):new JSONObject());arr.put(o);}JSONObject out=new JSONObject();out.put("items",arr);out.put("more",docs.size()==50);emit("older",out);}catch(JSONException ignored){}}).addOnFailureListener(this::error);});}
    @JavascriptInterface public void privacy(boolean seen,boolean read){main.post(()->{shareSeen=seen;shareRead=read;web.getContext().getSharedPreferences("isma_chat_privacy",0).edit().putBoolean("seen",seen).putBoolean("read",read).apply();appPresence.privacyChanged();if(uid()!=null)presence(false);});}
    @JavascriptInterface public void receiptRead(String id){main.post(()->{if(active&&foreground&&shareRead&&valid(id))receipt(id,true);});}
    private void receipt(String id,boolean read){String u=uid();if(u==null)return;Set<String> done=read?readIds:deliveredIds;if(!done.add(id))return;DocumentReference ref=receipts.document(id);FirebaseFirestore.getInstance().runTransaction(tx->{DocumentSnapshot d=tx.get(ref);Map<String,Object> data=new HashMap<>();if(!d.exists()){data.put("recipient",u);data.put("delivered",FieldValue.serverTimestamp());}if(read&&d.getTimestamp("read")==null)data.put("read",FieldValue.serverTimestamp());if(!data.isEmpty())tx.set(ref,data,SetOptions.merge());return null;}).addOnFailureListener(e->done.remove(id));}
    private CollectionReference media(){return messages.getParent().collection("media");}
    private static boolean validMedia(String kind,String data){
        if(data==null||data.length()>600000)return false;
        String prefix=kind.equals("photo")||kind.equals("sticker")?"data:image/jpeg;base64,":kind.equals("voice")?"data:audio/mp4;base64,":kind.equals("video")?"data:video/mp4;base64,":kind.equals("file")?"data:application/octet-stream;base64,":"";
        if(prefix.isEmpty()||!data.startsWith(prefix)||(kind.equals("photo")||kind.equals("sticker"))&&data.length()>240000)return false;
        return data.substring(prefix.length()).matches("[A-Za-z0-9+/=]+");
    }
    @JavascriptInterface public void sendPhoto(String data,String caption,String reply){sendMedia("photo",data,caption,reply,"",0);}
    @JavascriptInterface public void sendMedia(String kind,String data,String caption,String reply,String filename,int duration){main.post(()->{
        String u=uid();if(!active||u==null||!validMedia(kind,data)||caption.length()>1000||filename.length()>120||duration<0||duration>120||(!reply.isEmpty()&&!valid(reply))){emit("photoFailed","");return;}
        String id=messages.document().getId();Map<String,Object> m=new HashMap<>();m.put("sender",u);m.put("text",caption.trim());m.put("kind",kind);m.put("filename",filename);m.put("bytes",data.substring(data.indexOf(',')+1).length()*3/4);m.put("duration",duration);m.put("created",FieldValue.serverTimestamp());m.put("reply",reply);m.put("edited",false);m.put("deleted",false);m.put("reactions",new HashMap<String,String>());
        Map<String,Object> file=new HashMap<>();file.put("data",data);file.put("sender",u);WriteBatch b=FirebaseFirestore.getInstance().batch();b.set(messages.document(id),m);b.set(media().document(id),file);b.commit().addOnSuccessListener(v->{PulseClient.send(web.getContext(),u,"message",id);emit("photoSent",id);}).addOnFailureListener(e->{emit("photoFailed",id);error(e);});PulseClient.send(web.getContext(),u,"message",id);
    });}
    private android.media.MediaRecorder recorder;private java.io.File voiceFile;private long voiceStart;
    private final Runnable voiceLimit=()->finishVoice(true);
    @JavascriptInterface public void startVoice(){main.post(()->{if(!active||!foreground||uid()==null||recorder!=null)return;android.app.Activity a=(android.app.Activity)web.getContext();if(a.checkSelfPermission(android.Manifest.permission.RECORD_AUDIO)!=android.content.pm.PackageManager.PERMISSION_GRANTED){a.requestPermissions(new String[]{android.Manifest.permission.RECORD_AUDIO},2011);emit("voiceError","Concede el permiso del micrófono y vuelve a pulsar Grabar.");return;}try{voiceFile=java.io.File.createTempFile("isma-voice-",".m4a",a.getCacheDir());recorder=new android.media.MediaRecorder();recorder.setAudioSource(android.media.MediaRecorder.AudioSource.MIC);recorder.setOutputFormat(android.media.MediaRecorder.OutputFormat.MPEG_4);recorder.setAudioEncoder(android.media.MediaRecorder.AudioEncoder.AAC);recorder.setAudioChannels(1);recorder.setAudioSamplingRate(24000);recorder.setAudioEncodingBitRate(24000);recorder.setOutputFile(voiceFile.getAbsolutePath());recorder.prepare();recorder.start();voiceStart=android.os.SystemClock.elapsedRealtime();main.postDelayed(voiceLimit,120000);emit("voiceStarted",true);}catch(Exception e){finishVoice(false);emit("voiceError","No se pudo iniciar el micrófono.");}});}
    @JavascriptInterface public void stopVoice(boolean keep){main.post(()->finishVoice(keep));}
    private void finishVoice(boolean keep){main.removeCallbacks(voiceLimit);if(recorder==null){if(voiceFile!=null){voiceFile.delete();voiceFile=null;}return;}int seconds=(int)Math.min(120,Math.max(1,(android.os.SystemClock.elapsedRealtime()-voiceStart)/1000));boolean ok=true;try{recorder.stop();}catch(Exception e){ok=false;}try{recorder.release();}catch(Exception ignored){}recorder=null;try{if(keep&&ok&&voiceFile!=null&&voiceFile.length()<=449000){byte[] data=java.nio.file.Files.readAllBytes(voiceFile.toPath());JSONObject out=new JSONObject();out.put("data","data:audio/mp4;base64,"+android.util.Base64.encodeToString(data,android.util.Base64.NO_WRAP));out.put("duration",seconds);emit("voiceReady",out);}else if(keep)emit("voiceError","Audio demasiado corto o grande. Intenta de nuevo.");else emit("voiceCancelled",true);}catch(Exception e){emit("voiceError","No se pudo preparar el audio.");}finally{if(voiceFile!=null)voiceFile.delete();voiceFile=null;}}
    @JavascriptInterface public void exportMedia(String kind,String data,String filename){main.post(()->{if(uid()==null||!validMedia(kind,data))return;try{if(android.os.Build.VERSION.SDK_INT<29){emit("mediaExport","Guardar archivos requiere Android 10 o posterior.");return;}String mime=kind.equals("voice")?"audio/mp4":kind.equals("video")?"video/mp4":kind.equals("file")?"application/octet-stream":"image/jpeg";String ext=kind.equals("voice")?".m4a":kind.equals("video")?".mp4":kind.equals("file")?".bin":".jpg";String safe=filename.replaceAll("[^a-zA-Z0-9._-]","_");if(safe.isEmpty())safe="Ismamint-"+System.currentTimeMillis()+ext;android.content.ContentResolver r=web.getContext().getContentResolver();android.content.ContentValues v=new android.content.ContentValues();v.put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME,safe);v.put(android.provider.MediaStore.MediaColumns.MIME_TYPE,mime);v.put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH,"Download/Ismamint");v.put(android.provider.MediaStore.MediaColumns.IS_PENDING,1);android.net.Uri uri=r.insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI,v);if(uri==null)throw new Exception();try(java.io.OutputStream out=r.openOutputStream(uri)){if(out==null)throw new Exception();out.write(android.util.Base64.decode(data.substring(data.indexOf(',')+1),android.util.Base64.DEFAULT));}catch(Exception e){r.delete(uri,null,null);throw e;}v.clear();v.put(android.provider.MediaStore.MediaColumns.IS_PENDING,0);r.update(uri,v,null,null);emit("mediaExport","Guardado en Descargas/Ismamint");}catch(Exception e){emit("mediaExport","No se pudo guardar el archivo.");}});}
    @JavascriptInterface public void cameraPhoto(){main.post(()->{if(uid()==null||!active)return;try{((android.app.Activity)web.getContext()).startActivityForResult(new android.content.Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE),2012);}catch(Exception e){emit("voiceError","No se pudo abrir la cámara.");}});}
    public void cameraResult(android.content.Intent data){if(data==null||data.getExtras()==null)return;Object obj=data.getExtras().get("data");if(!(obj instanceof android.graphics.Bitmap))return;java.io.ByteArrayOutputStream b=new java.io.ByteArrayOutputStream();((android.graphics.Bitmap)obj).compress(android.graphics.Bitmap.CompressFormat.JPEG,82,b);emit("cameraPhoto","data:image/jpeg;base64,"+android.util.Base64.encodeToString(b.toByteArray(),android.util.Base64.NO_WRAP));}
    @JavascriptInterface public void loadPhoto(String id){main.post(()->{if(uid()==null||!valid(id))return;media().document(id).get().addOnSuccessListener(d->{try{JSONObject o=new JSONObject();o.put("id",id);if(!d.exists()){emit("photoError",id);return;}o.put("data",d.getString("data"));emit("photoData",o);}catch(JSONException ignored){}}).addOnFailureListener(e->emit("photoError",id));});}
    private long lastPulseSend=0;
    @JavascriptInterface public void sendHeartbeat(){sendPulse(ChatNotifications.PULSE_TEXT);}
    @JavascriptInterface public void sendHeartbeatPattern(String pattern){String text=HeartbeatActions.PREFIX+pattern;if(HeartbeatActions.pattern(text)!=null)sendPulse(text);}
    private void sendPulse(String text){main.post(()->{
        String u=uid();long now=android.os.SystemClock.elapsedRealtime();
        if(u==null){alive("heartbeatStatus","Inicia sesión en el chat");return;}
        if(lastPulseSend>0&&now-lastPulseSend<3000)return;lastPulseSend=now;notifications.askPermissionOnce();
        Map<String,Object> m=new HashMap<>();m.put("sender",u);m.put("text",text);m.put("created",FieldValue.serverTimestamp());m.put("reply","");m.put("edited",false);m.put("deleted",false);m.put("reactions",new HashMap<String,String>());
        alive("heartbeatStatus","Latido pendiente");
        String id=messages.document().getId();
        messages.document(id).set(m).addOnSuccessListener(v->{PulseClient.send(web.getContext(),u,"message",id);if(u.equals(uid()))alive("heartbeatStatus","Latido enviado");}).addOnFailureListener(e->{if(u.equals(uid()))alive("heartbeatStatus","No se pudo enviar el latido");});PulseClient.send(web.getContext(),u,"message",id);
    });}
    private void alive(String type,String value){if(!destroyed)web.evaluateJavascript("window.IsmaAlive&&window.IsmaAlive.receive("+JSONObject.quote(type)+","+JSONObject.quote(value)+")",null);}
    @JavascriptInterface public void send(String text,String reply){main.post(()->sendAt(messages.document().getId(),text,reply));}
    @JavascriptInterface public void sendWithId(String id,String text,String reply){main.post(()->{if(valid(id))sendAt(id,text,reply);});}
    @JavascriptInterface public void retrySend(String id,String text,String reply){main.post(()->{
        if(!valid(id))return; String u=uid();
        messages.document(id).get(Source.SERVER).addOnSuccessListener(d->{
            if(u==null||!u.equals(uid()))return;
            if(d.exists()){if(u.equals(d.getString("sender"))){PulseClient.send(web.getContext(),u,"message",id);emit("sendOk",id);}else error(new IllegalStateException("ID conflict"));}
            else if(active)sendAt(id,text,reply);
        }).addOnFailureListener(this::error);
    });}
    private void sendAt(String id,String text,String reply){String u=uid();if(!active||u==null||text.trim().isEmpty()||text.length()>4000||reply.length()>150)return;Map<String,Object> m=new HashMap<>();m.put("sender",u);m.put("text",text.trim());m.put("created",FieldValue.serverTimestamp());m.put("reply",reply);m.put("edited",false);m.put("deleted",false);m.put("reactions",new HashMap<String,String>());messages.document(id).set(m).addOnSuccessListener(v->{PulseClient.send(web.getContext(),u,"message",id);if(u.equals(uid()))emit("sendOk",id);}).addOnFailureListener(e->{if(!u.equals(uid()))return;try{JSONObject out=new JSONObject();out.put("id",id);out.put("text",text);out.put("reply",reply);emit("sendFailed",out);}catch(JSONException ignored){}error(e);});PulseClient.send(web.getContext(),u,"message",id);setTyping(false);}
    @JavascriptInterface public void edit(String id,String text){main.post(()->{if(valid(id)&&!text.trim().isEmpty()&&text.length()<=4000)messages.document(id).update("text",text.trim(),"edited",true).addOnFailureListener(this::error);});}
    @JavascriptInterface public void remove(String id){main.post(()->{if(valid(id))messages.document(id).get().addOnSuccessListener(d->{if(d.getString("kind")!=null){WriteBatch b=FirebaseFirestore.getInstance().batch();b.update(messages.document(id),"text","","deleted",true);b.delete(media().document(id));b.commit().addOnFailureListener(this::error);}else messages.document(id).update("text","","deleted",true).addOnFailureListener(this::error);}).addOnFailureListener(this::error);});}
    private void refreshReaction(String id){String u=uid();messages.document(id).get().addOnSuccessListener(d->{if(u==null||!u.equals(uid())||!d.exists())return;try{JSONObject out=new JSONObject();out.put("id",id);Object r=d.get("reactions");out.put("reactions",r instanceof Map?new JSONObject((Map)r):new JSONObject());emit("reactionUpdate",out);}catch(JSONException ignored){}});}
    @JavascriptInterface public void react(String id,String emoji){main.post(()->{if(valid(id)&&emoji.length()<=64)messages.document(id).update("reactions."+uid(),emoji.isEmpty()?FieldValue.delete():emoji).addOnSuccessListener(v->refreshReaction(id)).addOnFailureListener(e->{error(e);refreshReaction(id);});});}
    @JavascriptInterface public void profiles(){main.post(()->{if(uid()==null){emit("profiles",new JSONObject());return;}String u=uid();FirebaseFirestore.getInstance().collection("ismamint_chat/private/profiles").get().addOnSuccessListener(q->{if(!u.equals(uid()))return;JSONObject out=new JSONObject();try{for(DocumentSnapshot d:q.getDocuments())out.put(d.getId(),new JSONObject(d.getData()));}catch(JSONException ignored){}emit("profiles",out);}).addOnFailureListener(this::error);});}
    @JavascriptInterface public void saveProfile(String name,String bio,String photo){main.post(()->{String u=uid();if(u==null){emit("profileError","Inicia sesión para guardar el perfil.");return;}if(name==null||bio==null||photo==null||name.trim().isEmpty()||name.trim().length()>40||bio.length()>160||photo.length()>100000||(!photo.isEmpty()&&!photo.startsWith("data:image/jpeg;base64,"))){emit("profileError","Comprueba el nombre y la imagen del perfil.");return;}Map<String,Object> m=new HashMap<>();m.put("name",name.trim());m.put("bio",bio);m.put("photo",photo);FirebaseFirestore.getInstance().collection("ismamint_chat/private/profiles").document(u).set(m).addOnSuccessListener(v->{if(u.equals(uid())){emit("profileSaved",true);profiles();}}).addOnFailureListener(e->{if(u.equals(uid()))emit("profileError",e instanceof FirebaseFirestoreException&&((FirebaseFirestoreException)e).getCode()==FirebaseFirestoreException.Code.PERMISSION_DENIED?"No se permite guardar el perfil. Revisa las reglas de Firestore.":"No se pudo guardar el perfil. Comprueba tu conexión.");});});}
    private boolean valid(String id){return active&&uid()!=null&&id.matches("[A-Za-z0-9]{20}");}
    @JavascriptInterface public void writing(boolean value){main.post(()->setTyping(value));}
    private void setTyping(boolean value){if(!active||!foreground||uid()==null)return;long now=System.currentTimeMillis();if(value==typing&&now-lastTyping<4000)return;presence(value);}
    private void presence(boolean value){String u=uid();if(u==null)return;typing=value;lastTyping=System.currentTimeMillis();Map<String,Object> m=new HashMap<>();m.put("typing",shareSeen&&value);m.put("shareSeen",shareSeen);m.put("shareRead",shareRead);if(shareSeen)m.put("seen",FieldValue.serverTimestamp());states.document(u).set(m,SetOptions.merge()).addOnFailureListener(this::error);}
    @JavascriptInterface public void read(String id){main.post(()->{if(!foreground||!shareRead||!valid(id)||id.equals(latestIncoming))return;String u=uid();messages.document(id).get(Source.SERVER).addOnSuccessListener(d->{if(!foreground||!active||u==null||!u.equals(uid())||!d.exists()||u.equals(d.getString("sender")))return;Timestamp t=d.getTimestamp("created");if(t==null)return;latestIncoming=id;Map<String,Object> m=new HashMap<>();m.put("read",t);states.document(u).set(m,SetOptions.merge()).addOnFailureListener(e->{latestIncoming="";error(e);});});});}
}
