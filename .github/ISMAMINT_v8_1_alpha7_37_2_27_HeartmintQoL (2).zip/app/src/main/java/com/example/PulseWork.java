package com.example;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import androidx.annotation.NonNull;
import androidx.work.*;
import com.google.android.gms.tasks.Tasks;
import com.google.firebase.firestore.*;
import com.google.firebase.messaging.FirebaseMessaging;
import org.json.JSONArray;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.Callable;
import java.util.List;

/** All networking is bounded and off the UI thread. The existing native notice engines render alerts. */
public final class PulseWork extends Worker {
    private final Context c;
    public PulseWork(@NonNull Context context,@NonNull WorkerParameters params){super(context,params);c=context.getApplicationContext();}
    static void catchup(Context c){String u=ChatNotifications.uid();if(!PulseClient.member(u))return;try{WorkManager.getInstance(c).enqueueUniqueWork("pulse-catchup-"+u,ExistingWorkPolicy.KEEP,new OneTimeWorkRequest.Builder(PulseWork.class).setConstraints(new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()).setInputData(new Data.Builder().putString("mode","catchup").putString("uid",u).build()).build());}catch(RuntimeException ignored){}}
    @NonNull @Override public Result doWork(){
        String mode=getInputData().getString("mode"),u=getInputData().getString("uid");
        if("register".equals(mode)&&u==null)u=ChatNotifications.uid();
        if(!PulseClient.member(u)||!u.equals(ChatNotifications.uid()))return Result.success();
        try{
            if("register".equals(mode))return register(u);
            if("send".equals(mode))return send(u);
            if("receive".equals(mode))return receive(u);
            if("catchup".equals(mode)){catchup(u);return Result.success();}
            return Result.failure();
        }catch(SecurityException e){return Result.success();}
        catch(Exception e){Log.w(PulseClient.TAG,"work_retry_"+mode+"_"+e.getClass().getSimpleName());return retryBounded();}
    }
    private Result retryBounded(){return getRunAttemptCount()<8?Result.retry():Result.failure();}
    private <T> T main(Callable<T> task) throws Exception {return Tasks.await(Tasks.call(r->new Handler(Looper.getMainLooper()).post(r),task),12,TimeUnit.SECONDS);}
    private Result register(String u) throws Exception {
        String token=Tasks.await(FirebaseMessaging.getInstance().getToken(),15,TimeUnit.SECONDS);
        if(token==null||!u.equals(ChatNotifications.uid()))return Result.success();
        ChatNotifications.ensureChannel(c);GiftNotifications.channel(c);
        JSONArray normal=new JSONArray();
        if(!ChatNotifications.enabled(c)||ChatNotifications.muted(c)||!NoticePreferences.allowed(c,ChatNotifications.CHANNEL))normal.put("message");
        if(!NoticePreferences.on(c,"pulses")||!NoticePreferences.allowed(c,ChatNotifications.PULSE_CHANNEL))normal.put("pulse");
        if(!NoticePreferences.on(c,"gifts")||!NoticePreferences.allowed(c,GiftNotifications.CHANNEL))normal.put("gift");
        if(!NoticePreferences.on(c,"receipts")||!NoticePreferences.allowed(c,NoticePreferences.RECEIPTS))normal.put("gift_opened");
        SharedPreferences p=c.getSharedPreferences("isma_pulse_registration",Context.MODE_PRIVATE);
        // Store only a digest, not a duplicate copy of the FCM registration token.
        String fingerprint=android.util.Base64.encodeToString(java.security.MessageDigest.getInstance("SHA-256").digest((token+normal.toString()).getBytes(java.nio.charset.StandardCharsets.UTF_8)),android.util.Base64.NO_WRAP);
        if(fingerprint.equals(p.getString(u+"_fingerprint",""))&&System.currentTimeMillis()-p.getLong(u+"_last",0)<6*60*PulseClient.MIN)return Result.success();
        PulseClient.Reply r=PulseClient.call(u,"/v2/register",PulseClient.json("token",token,"dedup",true,"syncMessages",false,"normalKinds",normal));
        if(r.ok()){p.edit().putString(u+"_fingerprint",fingerprint).putLong(u+"_last",System.currentTimeMillis()).apply();Log.i(PulseClient.TAG,"registered");return Result.success();}
        Log.w(PulseClient.TAG,"register_http_"+r.status);return r.retry()||r.status==409?retryBounded():Result.failure();
    }
    private Result send(String u) throws Exception {
        String kind=getInputData().getString("kind"),id=getInputData().getString("id");if(!PulseClient.valid(kind,id)||"pulse".equals(kind))return Result.failure();
        if(System.currentTimeMillis()-getInputData().getLong("queued",0)>PulseClient.DAY)return Result.success();
        PulseClient.Reply r=PulseClient.call(u,"/v2/send",PulseClient.json("kind",kind,"id",id));
        if(r.ok()){Log.i(PulseClient.TAG,"send_"+r.data.optString("status","accepted"));return Result.success();}
        if(r.retry()||(r.status==404&&"event_missing".equals(r.error())))return retryBounded();
        Log.w(PulseClient.TAG,"send_http_"+r.status);return Result.failure();
    }
    private boolean ack(String u,String id,String status) throws Exception {
        PulseClient.Reply r=PulseClient.call(u,"/v2/ack",PulseClient.json("deliveryId",id,"status",status));
        if(r.ok())return true;
        if(r.retry()||r.status==409)return false;
        // A missing/expired job cannot be acknowledged; don't block local rendering.
        return true;
    }
    private Result receive(String u) throws Exception {
        String kind=getInputData().getString("kind"),id=getInputData().getString("id"),delivery=getInputData().getString("delivery");
        if(!PulseClient.valid(kind,id)||delivery==null)return Result.failure();
        long created=getInputData().getLong("created",0),age=System.currentTimeMillis()-created;
        if(!PulseProtocol.fresh(kind,age))return Result.success();
        if("message".equals(kind)||"pulse".equals(kind)){
            DocumentSnapshot d=Tasks.await(ChatNotifications.messages().document(id).get(Source.SERVER),12,TimeUnit.SECONDS);
            if(!d.exists()||!PulseClient.peer(u).equals(d.getString("sender"))||Boolean.TRUE.equals(d.getBoolean("deleted")))return Result.success();
            // Firestore, not FCM, decides whether the document is a true heartbeat.
            main(()->{ChatNotifications.consumePush(c,u,d);return null;});
        }else if("gift".equals(kind)){
            List<DocumentSnapshot> docs=Tasks.await(GiftNotifications.query(u).get(Source.SERVER),12,TimeUnit.SECONDS).getDocuments();
            main(()->{GiftNotifications.consume(c,u,docs);return null;});
        }else{
            List<DocumentSnapshot> docs=Tasks.await(GiftNotifications.receiptQuery(u).get(Source.SERVER),12,TimeUnit.SECONDS).getDocuments();
            main(()->{GiftNotifications.consumeReceipts(c,u,docs,id);return null;});
        }
        if(!u.equals(ChatNotifications.uid()))return Result.success();
        // Render first: a slow ACK must never delay a valid local alert.
        try{ack(u,delivery,"received");}catch(Exception ignored){}
        // Completed means handled by Android (including muted/disabled/duplicate), not proof of vibration or reading.
        try{ack(u,delivery,"processed");}catch(Exception ignored){}
        return ack(u,delivery,"completed")?Result.success():retryBounded();
    }
    private void catchup(String u) throws Exception {
        for(int i=0;i<3;i++){
            List<DocumentSnapshot> docs=Tasks.await(ChatNotifications.query(c,u).get(Source.SERVER),12,TimeUnit.SECONDS).getDocuments();
            main(()->{ChatNotifications.consume(c,u,docs,ChatNotifications.isInChat());return null;});
            if(docs.size()<100)break;
        }
        List<DocumentSnapshot> gifts=Tasks.await(GiftNotifications.query(u).get(Source.SERVER),12,TimeUnit.SECONDS).getDocuments();
        List<DocumentSnapshot> receipts=Tasks.await(GiftNotifications.receiptQuery(u).get(Source.SERVER),12,TimeUnit.SECONDS).getDocuments();
        main(()->{GiftNotifications.consume(c,u,gifts);GiftNotifications.consumeReceipts(c,u,receipts);return null;});
    }
}
