/* Saludos de ISMAMINT escritos por el usuario; reloj local del dispositivo. */
(function(root){
  'use strict';
  const hours=Object.freeze([
  "¿Qué haces tan tarde en el celular? Duérmete xd",
  "oye no esta muy tarde ya?",
  "YA ESTA MUY TARDE",
  "CUANDO TE PIENSAS DORMIR",
  "me rindo princesa, duermete cuando quieras",
  "Madrugadora",
  "Al que madruga el diablo lo ayuda",
  "Empezando el dia eh",
  "Buenos dias, preciosa",
  "Buenos días, mi vida",
  "ya desayunaste?",
  "ya casi medio dia",
  "MITAD DEL DIA",
  "BUENAS TARDES MI AMOR",
  "Ya almorzaste?",
  "BIENVENIDA A ISMAMINT",
  "las CUATRO de la tarde",
  "Hola princesa",
  "Preciosa, estas libre?",
  "Buenas noches mi vida",
  "se hace de noche, se acaba el dia",
  "Buenas noches, princesa",
  "YA CASI SE ACABA EL DIA",
  "A MIMIR EN UN RATO"
]);
  const events=Object.freeze({cumple:"¡FELIZ CUMPLEAÑOS!",ismael:"¿YA ME FELICITASTE?",navidad:"¡FELIZ NAVIDAD!",halloween:"¡FELIZ HALLOWEEN!",valentin:"¡FELIZ SAN VALENTÍN!",ano:"¡FELIZ AÑO NUEVO!"});
  const preview={madrugada:2,dia:9,tarde:15,noche:21};
  function get(now,event,override){
    const d=new Date(now), forced=Object.prototype.hasOwnProperty.call(preview,override);
    const h=forced?preview[override]:d.getHours();
    if(!forced&&(h===4||h===16)&&d.getMinutes()===44)return {text:"4:44",event:false};
    if(Object.prototype.hasOwnProperty.call(events,event))return {text:events[event],event:true};
    return {text:hours[h],event:false};
  }
  function minuteKey(now){const d=new Date(now);return Math.floor(+d/60000)+":"+d.getTimezoneOffset();}
  const api={hours,get,minuteKey};
  if(typeof module!=="undefined"&&module.exports)module.exports=api;else root.IsmaHourlyGreetings=api;
})(typeof window!=="undefined"?window:globalThis);
