(function(root){'use strict';
const key=id=>'se_hidden_'+id.replace(/-/g,'_');
function pattern(text){if(typeof text!=='string'||!text.startsWith('♥ Latido:'))return null;const a=text.slice('♥ Latido:'.length).split(',');if(a.length<2||a.length>16||a.some(x=>!/^\d{1,4}$/.test(x)))return null;const b=a.map(Number);return b[0]===0&&b.slice(1).every(x=>x>=90&&x<=3000)&&b.reduce((s,x)=>s+x,0)<=8000?b:null;}
function isPulse(t){return t==='♥ Latido'||!!pattern(t);}
function twins(a,b){return a&&b&&a.length===b.length&&a.every((v,i)=>Math.abs(v-b[i])<=Math.max(120,.2*Math.max(v,b[i])));}
function pairs(rows){const found=new Set();const clean=rows.filter(x=>x&&x.id&&x.sender&&Number.isFinite(x.created)&&x.created>0&&!x.pending&&!x.deleted&&!x.edited&&!x.kind&&typeof x.text==='string').sort((a,b)=>a.created-b.created);for(let i=0;i<clean.length;i++){const a=clean[i];for(let j=i+1;j<clean.length;j++){const b=clean[j],dt=b.created-a.created;if(dt>60000)break;if(a.sender===b.sender||a.id===b.id)continue;if(dt<5000&&isPulse(a.text)&&isPulse(b.text))found.add('old-22');if(dt<2000&&a.text===b.text&&!isPulse(a.text)&&a.text.trim())found.add('old-24');if(twins(pattern(a.text),pattern(b.text)))found.add('new-38');}}return [...found];}
function taps(count,gap,max){let a=[];return t=>{if(a.length&&(t<a.at(-1)||t-a.at(-1)>gap))a=[];a.push(t);while(a.length&&t-a[0]>max)a.shift();if(a.length>=count){a=[];return true;}return false;};}
const code=s=>typeof s==='string'&&/^\d{8}$/.test(s)?({'11092025':'old-05','03112025':'old-06'}[s]||null):null;
function messageExtras(text){if(typeof text!=='string'||isPulse(text))return [];const ids=[];if(Array.from(text).length===444)ids.push('extra-01');if(text.trim().toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'')==='tienes razon')ids.push('extra-02');return ids;}
const api={key,pattern,isPulse,twins,pairs,taps,code,messageExtras};if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.IsmaHiddenCore=api;
})(typeof window!=='undefined'?window:globalThis);
