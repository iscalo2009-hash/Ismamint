# Heartmint — integración de lanzamiento en Ismamint

Base: ISMAMINT_v8_1_alpha7_37_2_24_Hora2s.zip y Heartmint Release RC1.

- Nuevo módulo integrado en Explorar → Heartmint. Sustituye la ejecución del juego clásico; sus archivos y guardados históricos se conservan para no destruir datos.
- Guardado nuevo: `heartmint_reborn_v2_progress`; réplica en el contenedor `heartmint_reborn_v2_host`. No se importa la partida, récord, equipo ni nivel antiguos. El nuevo juego empieza con sus dos elementos iniciales y nivel 1. Ambos guardados pertenecen al almacenamiento local; el mecanismo existente de respaldo incluye las claves `heartmint_*`. No se añadió sincronización remota ni se cambió Firebase.
- 437 logros nuevos, ID `hm2_`: 99 skins y 29 armas desbloqueables (el equipo inicial no cuenta como logro), 218 victorias por encuentro hasta nivel 1000 incluidas revanchas, y 91 hitos/secretos. Los logros clásicos compatibles conservan sus IDs y se pueden alcanzar con métricas del juego nuevo; los clásicos ya obtenidos se conservan. Los criterios clásicos sin equivalente se archivan, salvo los ya conseguidos. La interfaz de logros principal de Ismamint es la fuente de presentación y almacenamiento de premios.
- Mapa limitado a los mundos alcanzados y jefes sin nombre ni retrato antes de derrotarlos. Las partidas de práctica no desbloquean progreso ni logros.
- Pantalla completa dentro de la aplicación mediante botón exterior, ajuste proporcional 15:23 en vertical y horizontal, pausa inmediata y manual al regresar. Eliminados debug, accesos de prueba, guía del combate, cuenta atrás y ajuste de efectos reducidos. Los avisos de peligro siguen visibles; se conserva el render de emergencia interno para fallos gráficos.
- Rendimiento: sprites rasterizados reutilizables, omisión de capas vacías, dibujo de partida sincronizado con los pasos de simulación a 60 Hz (sin dibujar cuadros idénticos en paneles rápidos), menú a 30 Hz solo cuando está visible, pausa de animaciones y audio al salir, y suspensión del fondo general de la app mientras está abierto Heartmint. No se cambió el equilibrio de los ataques.

## Validación

Sintaxis de scripts inline y nuevos módulos. Chromium con el código principal y el iframe cargados como fixture local en memoria: arranque con partidas clásicas preexistentes, guardado limpio, 437 identificadores distintos, partida automatizada de nivel 1 hasta nivel 2 y sincronización de logros, pausa/reanudación inmediata, pantalla completa y proporción del canvas en orientación vertical y horizontal. No se detectaron excepciones en estas pruebas.

No se compiló un APK ni se ejecutó el WebView nativo en un móvil. No se midieron FPS en hardware real; la optimización reduce trabajo redundante pero no garantiza una cifra concreta. El empaquetado y las pruebas de Android son el siguiente control antes de publicar. Se mantuvieron las opciones de versión/firmado y la configuración de servicios originales.
