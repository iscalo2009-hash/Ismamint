from playwright.sync_api import sync_playwright
from pathlib import Path
import re
root=Path(__file__).resolve().parents[1]/'app/src/main/assets'; h=(root/'index.html').read_text()
def scripts(m):
 f=root/m.group(1)
 return '<script>\n'+f.read_text().replace('</script','<\\/script')+'\n</script>' if f.is_file() else ''
h=re.sub(r'<script\s+src="([^"]+)"\s*>\s*</script>',scripts,h)
h=re.sub(r'<link\s+rel="stylesheet"\s+href="([^"]+)"\s*/?>',lambda m:'<style>'+ (root/m.group(1)).read_text()+'</style>' if (root/m.group(1)).is_file() else '',h)
pre='''<script>for(const name of ['localStorage','sessionStorage']){const m=new Map();Object.defineProperty(window,name,{value:{getItem:k=>m.has(k)?m.get(k):null,setItem:(k,v)=>m.set(k,String(v)),removeItem:k=>m.delete(k),clear:()=>m.clear(),key:i=>[...m.keys()][i],get length(){return m.size}}});}</script>'''
h=re.sub(r'<head[^>]*>',lambda m:m.group(0)+pre,h,count=1,flags=re.I)
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox']);page=b.new_page(viewport={'width':390,'height':844},is_mobile=True,has_touch=True,timezone_id='America/Bogota');page.route('**/*',lambda r:r.abort());errors=[];page.on('pageerror',lambda e:errors.append(str(e)));page.clock.install(time=__import__('datetime').datetime(2026,11,25,17,tzinfo=__import__('datetime').timezone.utc));page.set_content(h,wait_until='domcontentloaded',timeout=12000)

 page.evaluate("boot=false; document.getElementById('main').style.display='block';document.getElementById('p1').classList.add('on')")
 assert page.evaluate("IsmaHiddenData.every(x=>ACH.filter(a=>a.id===x.secretAchievement.id&&a.cat==='se'&&a.g===''&&a.secret).length===1)")
 for i in range(44):
  page.evaluate("document.getElementById('feel-home-heart').click()")
  page.clock.run_for(100)
 assert page.evaluate("!!U.se_hidden_old_01")
 for i in range(4): page.evaluate("document.getElementById('hidden-formula-four').click()")
 assert page.evaluate("!!U.se_hidden_old_04")
 page.evaluate("const ii=document.createElement('input');ii.value='11092025';document.body.append(ii);ii.dispatchEvent(new Event('input',{bubbles:true}));ii.value='03112025';ii.dispatchEvent(new Event('input',{bubbles:true}));ii.remove()")
 assert page.evaluate("!!U.se_hidden_old_05 && !!U.se_hidden_old_06")
 page.evaluate("IsmaHidden.messages([{id:'a',sender:'a',text:'♥ Latido',created:Date.now()-1000},{id:'b',sender:'b',text:'♥ Latido',created:Date.now()}])")
 assert page.evaluate("!!U.se_hidden_old_22")
 page.evaluate("IsmaHidden.messages([{id:'c',sender:'a',text:'te amo',created:Date.now()}])")
 assert page.evaluate("!!U.se_hidden_old_11")
 page.evaluate("IsmaMusic.state=()=>({playing:true,id:'s01'});IsmaHidden.songPeer({song:'s01',updated:Date.now()})")
 assert page.evaluate("!!U.se_hidden_old_27")
 page.evaluate("IsmaHidden.songFinished('s01')")
 assert page.evaluate("!!U.se_hidden_new_18")
 assert page.evaluate("JSON.parse(localStorage.getItem('aurora_logros_v1')).se_hidden_old_01>0")
 page.evaluate("IsmaHidden.messages([{id:'extra-a',sender:'a',text:'x'.repeat(444),created:Date.now()},{id:'extra-b',sender:'b',text:'TIENES RAZÓN',created:Date.now()}])")
 assert page.evaluate("!!U.se_hidden_extra_01 && !!U.se_hidden_extra_02")
 page.evaluate("IsmaHidden.presence(true,false,10000)")
 assert page.evaluate("!document.getElementById('app-together').hidden && !U.se_hidden_extra_03")
 page.evaluate("IsmaHidden.presence(true,true,10000)")
 assert page.evaluate("!document.getElementById('app-together').hidden && !!U.se_hidden_extra_03")
 stamp=page.evaluate("U.se_hidden_extra_03")
 page.clock.run_for(11000)
 assert page.evaluate("document.getElementById('app-together').hidden")
 page.evaluate("IsmaHidden.presence(true,true,10000);IsmaHidden.presence(false,false,0)")
 assert page.evaluate("document.getElementById('app-together').hidden && U.se_hidden_extra_03 === "+str(stamp))
 assert not errors,errors
 print('New catalog, taps, codes, simulated chat/music and persistence OK');b.close()
