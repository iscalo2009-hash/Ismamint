const assert=require('node:assert/strict');
const g=require('../app/src/main/assets/hourly-greetings.js');
const expected=["¿Qué haces tan tarde en el celular? Duérmete xd", "oye no esta muy tarde ya?", "YA ESTA MUY TARDE", "CUANDO TE PIENSAS DORMIR", "me rindo princesa, duermete cuando quieras", "Madrugadora", "Al que madruga el diablo lo ayuda", "Empezando el dia eh", "Buenos dias, preciosa", "Buenos días, mi vida", "ya desayunaste?", "ya casi medio dia", "MITAD DEL DIA", "BUENAS TARDES MI AMOR", "Ya almorzaste?", "BIENVENIDA A ISMAMINT", "las CUATRO de la tarde", "Hola princesa", "Preciosa, estas libre?", "Buenas noches mi vida", "se hace de noche, se acaba el dia", "Buenas noches, princesa", "YA CASI SE ACABA EL DIA", "A MIMIR EN UN RATO"];
for(const zone of ['America/Bogota','America/Mexico_City','Europe/Madrid']){
  process.env.TZ=zone;
  const at=(h,m,s=0)=>+new Date(2026,10,26,h,m,s);
  for(let h=0;h<24;h++)for(let m=0;m<60;m++){
    assert.equal(g.get(at(h,m),'','').text,(h===4||h===16)&&m===44?'4:44':expected[h]);
  }
  for(const h of [4,16]){
    assert.equal(g.get(at(h,43,59),'','').text,expected[h]);
    assert.equal(g.get(at(h,44,0),'navidad','').text,'4:44');
    assert.equal(g.get(at(h,44,59),'','').text,'4:44');
    assert.equal(g.get(at(h,45,0),'','').text,expected[h]);
    assert.equal(g.get(at(h,45,0),'navidad','').text,'¡FELIZ NAVIDAD!');
    assert.notEqual(g.minuteKey(at(h,43,59)),g.minuteKey(at(h,44,0)));
  }
  assert.equal(g.get(at(5,0),'cumple','').text,'¡FELIZ CUMPLEAÑOS!');
  assert.equal(g.get(at(5,0),'','noche').text,expected[21]);
}
console.log('24 saludos y 4:44 AM/PM OK (3 zonas horarias)');
