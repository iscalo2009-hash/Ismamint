package com.example;
public class PulseProtocolTest {
    static void check(boolean b){if(!b)throw new AssertionError();}
    public static void main(String[] args){
        String a="MCbwjlCpBnhTHxfQTuvcOVWLN3w2",i="MIPr6C3HW5QPp9GXd5ZjlHCmFQJ3",m="abcdefghijklmnopqrst";
        check(PulseProtocol.member(a));check(PulseProtocol.member(i));check(!PulseProtocol.member(null));check(!PulseProtocol.member("other"));
        check(PulseProtocol.peer(a).equals(i));check(PulseProtocol.peer(i).equals(a));check(PulseProtocol.peer(null)==null);
        check(PulseProtocol.valid("message",m));check(PulseProtocol.valid("pulse",m));check(!PulseProtocol.valid("message","../"));check(!PulseProtocol.valid("pulse","abc"));
        check(PulseProtocol.valid("gift","my-gift_01"));check(PulseProtocol.valid("gift_opened","my-gift_01"));check(!PulseProtocol.valid("gift","foo/bar"));check(!PulseProtocol.valid("gift","a".repeat(91)));check(!PulseProtocol.valid(null,m));
        check(PulseProtocol.deliveryId(a,"pulse",m).equals(a+"_message_"+m));check(PulseProtocol.deliveryId(i,"gift_opened","abc").equals(i+"_gift_opened_abc"));check(PulseProtocol.deliveryId("other","message",m)==null);
        check(PulseProtocol.fresh("pulse",120000));check(!PulseProtocol.fresh("pulse",120001));check(PulseProtocol.fresh("message",600000));check(!PulseProtocol.fresh("message",600001));check(PulseProtocol.fresh("gift",86400000));check(!PulseProtocol.fresh("gift",86400001));check(!PulseProtocol.fresh("message",-60001));
        System.out.println("PulseProtocol: 25 assertions passed");
    }
}
