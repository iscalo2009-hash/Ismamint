from playwright.sync_api import sync_playwright
from pathlib import Path
import re
root=Path(__file__).resolve().parents[1]/'app/src/main/assets'; h=(root/'index.html').read_text()
def scripts(m):
 f=root/m.group(1)
 return '<script>\n'+f.read_text().replace('</script','<\\/script')+'\n</script>' if f.is_file() else ''
h=re.sub(r'<script\s+src="([^"]+)"\s*>\s*</script>',scripts,h)
h=re.sub(r'<link\s+rel="stylesheet"\s+href="([^"]+)"\s*/?>',lambda m:'<style>'+ (root/m.group(1)).read_text()+'</style>' if (root/m.group(1)).is_file() else '',h)
pre='''<script>for(const name of ['localStorage','sessionStorage']){const m=new Map();Object.defineProperty(window,name,{value:{getItem:k=>m.has(k)?m.get(k):null,setItem:(k,v)=>m.set(k,String(v)),removeItem:k=>m.delete(k),clear:()=>m.clear(),key:i=>[...m.keys()][i],get length(){return m.size}}});}</script>'''
h=re.sub(r'<head[^>]*>',lambda m:m.group(0)+pre,h,count=1,flags=re.I)
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox']);page=b.new_page(viewport={'width':390,'height':844},is_mobile=True,has_touch=True,timezone_id='America/Bogota');page.route('**/*',lambda r:r.abort());errors=[];page.on('pageerror',lambda e:errors.append(str(e)));page.clock.install(time=__import__('datetime').datetime(2026,11,25,17,tzinfo=__import__('datetime').timezone.utc));page.set_content(h,wait_until='domcontentloaded',timeout=12000)
 print(page.evaluate("ACH.filter(a=>a.cat==='se').length"),page.evaluate("ACH.filter(a=>a.secret).length"))
 assert page.evaluate("ACH.filter(a=>a.cat==='se').length")==83
 assert page.evaluate("ACH.filter(a=>a.secret).length")==42
 page.evaluate("boot=false;window.IsmaMusic.state=()=>({playing:true,id:'s55'});document.getElementById('p1').classList.add('on')")
 for i in range(4):
  page.evaluate("document.getElementById('feel-home-heart').click()")
  page.clock.run_for(200)
 page.evaluate('achStep(Date.now())')
 assert page.evaluate("!!U.se_egg_four && !!U.se_egg_machine")
 assert not page.evaluate("!!U.se_egg_yellow || !!U.se_egg_echo")
 page.clock.run_for(1000)
 page.evaluate("window.IsmaMusic.state=()=>({playing:true,id:'s36'})")
 for i in range(4):
  page.evaluate("document.getElementById('feel-home-heart').click()")
  page.clock.run_for(200)
 page.evaluate('achStep(Date.now())')
 assert page.evaluate("!!U.se_egg_echo && !!U.se_egg_yellow && !!U.se_egg_complete")
 assert page.evaluate("JSON.parse(localStorage.getItem('aurora_logros_v1')).se_egg_complete>0")
 assert not errors,errors
 print('All five Easter eggs registered and persisted; existing 60 preserved');b.close()
