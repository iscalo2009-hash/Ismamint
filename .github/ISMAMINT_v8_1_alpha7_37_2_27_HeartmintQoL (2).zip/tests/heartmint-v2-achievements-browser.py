from pathlib import Path
from playwright.sync_api import sync_playwright
import re,json
root=Path(__file__).resolve().parents[1]/'app/src/main/assets'; h=(root/'index.html').read_text();child=(root/'heartmint-v2/index.html').read_text();child=child.replace('<script src="../heartmint-v2-achievements.js"></script>','<script>'+(root/'heartmint-v2-achievements.js').read_text()+'</script>');
# Only the in-memory test fixture exposes the private simulation for accelerated input.
pos=child.rfind('})();');child=child[:pos]+"window.__testHM={get:()=>game,save:()=>{updateRecords(game.state);},draw,diagnostics:()=>diagnosticLog,restore:()=>{}};"+child[pos:]
def scripts(m):
 f=root/m.group(1)
 if not f.is_file(): return ''
 t=f.read_text()
 if f.name=='heartmint-v2-host.js':t=t.replace("frame.src='heartmint-v2/index.html';",'frame.srcdoc='+json.dumps(child).replace('</script','<\\/script')+';')
 return '<script>\n'+t.replace('</script','<\\/script')+'\n</script>'
h=re.sub(r'<script\s+src="([^"]+)"\s*>\s*</script>',scripts,h)
h=re.sub(r'<link\s+rel="stylesheet"\s+href="([^"]+)"\s*/?>',lambda m:'<style>'+ (root/m.group(1)).read_text()+'</style>' if (root/m.group(1)).is_file() else '',h)
pre='''<script>for(const name of ['localStorage','sessionStorage']){const m=new Map();Object.defineProperty(window,name,{value:{getItem:k=>m.has(k)?m.get(k):null,setItem:(k,v)=>m.set(k,String(v)),removeItem:k=>m.delete(k),clear:()=>m.clear(),key:i=>[...m.keys()][i],get length(){return m.size}}});}localStorage.setItem('heartmint_release_v1',JSON.stringify({max:90,metrics:{hearts:5000,best:12345}}));localStorage.setItem('hm_classic_preview_v5',JSON.stringify({max:777,checkpoint:700,profileStats:{bestScore:999999}}));localStorage.setItem('aurora_logros_v1',JSON.stringify({hmr_boss_1:123456}));</script>'''
h=re.sub(r'<head[^>]*>',lambda m:m.group(0)+pre,h,count=1,flags=re.I)
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage']);p=b.new_page(viewport={'width':420,'height':850},is_mobile=True,has_touch=True); errs=[];logs=[];p.on('pageerror',lambda e:errs.append(str(e)));p.on('console',lambda e:logs.append(e.text) if e.type=='error' else None);p.route('**/*',lambda r:r.abort());p.set_content(h,wait_until='domcontentloaded',timeout=15000);p.wait_for_timeout(300)
 print('init errors',errs[:10],flush=True)
 print('parent globals',p.evaluate('''()=>({game:typeof GAME,catalog:HeartmintV2.achievements.length,oldAward:U.hmr_boss_1,oldCard:ACH.some(a=>a.id==='hmr_boss_1'),new:ACH.filter(a=>a.id.startsWith('hm2_')).length,spoilers:ACH.filter(a=>a.id.startsWith('hm2_victory_')&&!a.secret).length})'''),flush=True)
 p.evaluate("document.querySelector('main').style.setProperty('display','block','important');document.querySelector('#start').style.display='none';document.querySelector('.tabs button[data-p=p4]').click()")
 p.wait_for_timeout(800);fr=p.frame(url='about:srcdoc');assert fr,[f.url for f in p.frames]
 print('child init',fr.evaluate('''()=>({debug:!!document.querySelector('#hmDebug'),reduced:!!document.querySelector('#reduced'),countdown:!!document.querySelector('#countdown'),guide:!!document.querySelector('#instruction'),home:document.querySelector('#hmHomeStats').textContent,preview:typeof HeartmintPreview})'''),flush=True)
 print('host initial',p.evaluate('GAME.progress()'),flush=True)
 fr.locator('#hmPlay').click(force=True);fr.locator('#continue').click(force=True);p.wait_for_timeout(1000)
 print('running',p.evaluate('GAME.info()'),fr.locator('#stageLabel').inner_text(),flush=True)
 # Drive the actual engine with a deterministic catch controller. No direct event fabrication.
 result=fr.evaluate("""()=>{const q=__testHM.get(),s=q.state;let i=0;document.querySelector('#music').checked=false;for(;i<3600&&q.state.stage<2&&q.state.status==='play';i++){const z=q.state;const candidates=z.hearts.filter(h=>h.y<350&&h.y>200&&h.kind!=='bomb').sort((a,b)=>b.y-a.y);if(candidates.length){z.player.x=candidates[0].x;q.input.targetX=candidates[0].x;q.input.directTouch=true;}q.update(1/60);if(i%10===0)__testHM.draw();}__testHM.save();return {steps:i,stage:q.state.stage,score:q.state.score,caught:q.state.caught,errors:__testHM.diagnostics()}}""");print('played',result,flush=True);p.wait_for_timeout(600);print('award sync',p.evaluate("()=>({earned:GAME.progress().earned,level:GAME.progress().max,heartAward:!!U.hm2_hearts_10,levelAward:!!U.hm2_level_1,oldAward:U.hmr_boss_1})"),flush=True);assert result['stage']>=2 and not result['errors'],result;assert p.evaluate('!!U.hm2_hearts_10&&!!U.hm2_level_1&&U.hmr_boss_1===123456');print('errors',errs[:30],logs[:10],flush=True);b.close();assert not errs and not logs,(errs,logs)
