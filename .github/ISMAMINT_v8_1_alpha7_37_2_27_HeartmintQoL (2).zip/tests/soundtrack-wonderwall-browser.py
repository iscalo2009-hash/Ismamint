from playwright.sync_api import sync_playwright
from pathlib import Path
import re
root=Path(__file__).resolve().parents[1]/'app/src/main/assets'; h=(root/'index.html').read_text()
def scripts(m):
 f=root/m.group(1)
 return '<script>\n'+f.read_text().replace('</script','<\\/script')+'\n</script>' if f.is_file() else ''
h=re.sub(r'<script\s+src="([^"]+)"\s*>\s*</script>',scripts,h)
h=re.sub(r'<link\s+rel="stylesheet"\s+href="([^"]+)"\s*/?>',lambda m:'<style>'+ (root/m.group(1)).read_text()+'</style>' if (root/m.group(1)).is_file() else '',h)
pre='''<script>for(const name of ['localStorage','sessionStorage']){const m=new Map();Object.defineProperty(window,name,{value:{getItem:k=>m.has(k)?m.get(k):null,setItem:(k,v)=>m.set(k,String(v)),removeItem:k=>m.delete(k),clear:()=>m.clear(),key:i=>[...m.keys()][i],get length(){return m.size}}});}</script>'''
h=re.sub(r'<head[^>]*>',lambda m:m.group(0)+pre,h,count=1,flags=re.I)

mock="""<script>
const realNow=Date.now.bind(Date);window.radioTestOffset=0;Date.now=()=>realNow()+window.radioTestOffset;
window.Audio=class extends EventTarget{constructor(){super();this.paused=true;this.currentTime=0;this.duration=0;this.readyState=0;this.volume=1;this.error=null;}load(){this.paused=true;this.currentTime=0;this.duration=window.IsmaRadio?.durations[(this.src||'').match(/(s\\d+)\\.(?:opus|mp3)/)?.[1]]||180;this.readyState=1;queueMicrotask(()=>this.dispatchEvent(new Event('loadedmetadata')));}play(){this.paused=false;this.dispatchEvent(new Event('play'));return Promise.resolve();}pause(){this.paused=true;this.dispatchEvent(new Event('pause'));}};
localStorage.setItem('ismamint_music_prefs',JSON.stringify({id:'s01',mode:'ordered',enabled:true,position:10}));
localStorage.setItem('ismamint_music_sync',JSON.stringify({s24:{offset:8,scale:1.13},s03:{offset:.5,scale:1}}));
</script>"""
h=h.replace(pre,pre+mock,1)
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox']);page=b.new_page(viewport={'width':420,'height':850},is_mobile=True,has_touch=True);page.route('**/*',lambda r:r.abort());errors=[];page.on('pageerror',lambda e:errors.append(str(e)));page.set_content(h,wait_until='domcontentloaded',timeout=12000);page.wait_for_timeout(250)
 page.evaluate('IsmaMusic.start()');page.wait_for_timeout(100);assert page.evaluate('IsmaMusic.state().id')=='s01';assert page.evaluate('IsmaMusic.state().playing');assert abs(page.evaluate('IsmaMusic.state().time')-10)<.1

 page.evaluate("document.querySelector('main').style.setProperty('display','block','important');document.querySelector('.tabs button[data-p=p1]').click()")
 assert page.evaluate("ISMA_SONGS.find(s=>s.id==='s01').date")=='2025-10-05'
 assert page.evaluate("JSON.parse(localStorage.getItem('ismamint_music_sync'))") == {'s03':{'offset':.5,'scale':1}}
 assert page.evaluate("JSON.parse(localStorage.getItem('ismamint_music_previousSync')).s24") == {'offset':8,'scale':1.13}
 assert page.evaluate("JSON.parse(localStorage.getItem('ismamint_music_timingRevisions')).s24")==2
 page.evaluate("IsmaMusic.select('s24')");page.wait_for_timeout(150)
 for t,visible in [(14.5,False),(22.5,True),(24.7,True),(41.8,False),(44.5,True),(115.0,True),(217.8,True),(230.0,False),(22.5,True)]:
  page.evaluate(f"IsmaMusic.seek({t})");page.wait_for_timeout(500)
  state=page.evaluate("({visible:document.querySelector('.sm-lyric').classList.contains('on'),timing:document.querySelector('.sm-lyric').dataset.wordTiming,active:document.querySelectorAll('.sm-lyric .is-word').length})")
  assert state['visible']==visible,(t,state)
  if visible:assert state['timing']=='reference-direct' and state['active']==1,(t,state)
 assert not errors,errors
 print('Wonderwall: migration, intro, verse, instrumental gaps, outro, backward seek and direct word marks verified')
 b.close()
