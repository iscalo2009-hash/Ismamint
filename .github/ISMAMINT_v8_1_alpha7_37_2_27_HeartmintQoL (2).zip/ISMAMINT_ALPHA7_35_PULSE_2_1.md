# ISMAMINT v8.1 · Alpha 7.35 — Pulse 2.1

Base: Alpha 7.34.2 Lyric Sync. Endpoint ya desplegado: https://ismamint-pulse.iscalo2009.workers.dev

## Cambios
- Firebase Messaging con el BOM existente; WorkManager 2.10.1 para trabajos persistentes con red y backoff. En Android 12+ se intenta usar trabajo acelerado para los envíos y FCM de prioridad alta; en versiones anteriores se usa trabajo normal. No se agrega un servicio permanente.
- Registro autenticado `/v2/register` al iniciar sesión, volver a la aplicación, cambiar las preferencias y renovar token, más comprobación periódica de 12 h. Solo un dispositivo actual por cuenta; se guarda una huella del token, no otra copia del token en preferencias. Los tokens de Firebase Auth se renuevan ante HTTP 401.
- `/v2/send` para texto, multimedia, latidos normales y personalizados, widget, respuesta directa, regalos inmediatos/programados y transición a regalo abierto. Los trabajos de envío son únicos por UID, tipo e ID; si la escritura aún no llegó al servidor, se reintenta el evento ausente. El Worker valida la propiedad y el estado antes de enviar.
- FCM de datos sin texto privado; se verifica destinatario, remitente, tipo, ID y antigüedad; luego se consulta Firestore con sesión del destinatario. Se usa la clasificación real del documento. Los regalos sellados no se leen ni se abren automáticamente.
- Los listeners y trabajos periódicos existentes siguen funcionando como respaldo. Para chat se comparte una marca persistente por ID y no se adelanta el cursor por una notificación puntual; para regalos se comparte el conjunto persistente de IDs. La agrupación de mensajes queda en la notificación Android existente, no se colapsan los mensajes en FCM. Se conserva el sistema de latidos de primer plano y el motor táctil original en segundo plano.
- Confirmaciones `/v2/ack` de recepción, procesamiento y finalización. `completed` significa evento gestionado (también si estaba silenciado, suprimido o duplicado), no garantiza lectura ni vibración física.
- Las nuevas colecciones de Pulse continúan bloqueadas al acceso directo de los clientes. No se agrega ninguna clave de servicio al APK. Se conserva la firma, applicationId, actualizador, assets y versionado de CI existentes.

## Instalación
1. Subir este ZIP como siguiente ZIP del repositorio que ya ejecuta el workflow de compilación, sin borrar el workflow ni modificar la firma.
2. Compilar el APK y revisar que el build termine. Instalar la actualización en ambos teléfonos sin desinstalar la versión anterior.
3. Abrir ISMAMINT una vez en cada teléfono, comprobar sesión autorizada y permisos de notificaciones. Los tokens se registran automáticamente; en la colección privada `ismamint_pulse` deben aparecer documentos de ambos usuarios con `protocol=2` y `dedup=true`.
4. Probar texto, multimedia, latido simple y patrón personalizado; repetir con destinatario en otra pantalla, app minimizada y pantalla bloqueada; comprobar respuesta desde notificación y widget. Probar regalo programado para unos minutos después, cerrar ambas apps sin forzar detención, y abrir regalo desde aviso.
5. Revisar `ismamint_pulse_jobs` desde Firebase Console: `dispatched`, `received`, `processed`, `completed`; `fallback` significa que se mantiene la recuperación local. Verificar que no hay avisos repetidos al abrir el chat. Revisar los logs Android filtrando `IsmamintPulse` y Cloudflare Observability. No publicar tokens ni credenciales.

## Límites y pruebas
- Pruebas locales: 49 archivos de test Node aprobados; 25 comprobaciones del protocolo Java; análisis sintáctico de los 29 archivos Java; manifiesto XML válido. No se ha compilado APK aquí: no hay Android SDK ni Gradle instalados. No se ha probado FCM real ni vibración física.
- Los trabajos acelerados y notificaciones dependen de Android, permisos, Google Play Services, cuotas, conexión, modo de ahorro y ajustes del fabricante; forzar la detención puede impedir entregas hasta reabrir la app.
- Los regalos programados se registran al crearse desde esta versión. No se migran masivamente regalos antiguos. Si el proceso termina antes de persistir el trabajo de envío, el respaldo Firestore sigue disponible; no existe transacción atómica entre Firestore y WorkManager. Los trabajos tienen reintentos limitados. Una notificación FCM aceptada no prueba que el sistema operativo la mostró.
- El Worker 2.1 y los dos cron ya configurados no se cambian. No se necesita modificar reglas otra vez si ya se publicaron las tres protecciones. No se necesita Firebase Blaze; las cuotas gratuitas de Firestore y Cloudflare siguen aplicando.
