# Alpha 7.37 — The Hidden Side
Base: Alpha 7.35.2 Notice Texts. Adds 30 approved discoveries, with one permanent secret achievement each. No separate Easter egg category. All preexisting achievement IDs, notifications, Pulse 2.1 and ordinary resources are preserved. No discarded proposal is added, and no existing secret is removed.

## Installation
Publish the added `ismamint_secret_music` rule in Firestore (included in `firestore.rules`) for the cooperative music discovery. Other discoveries use existing rules. No Cloudflare change. Compile the APK through the usual GitHub Actions workflow; both phones need the new version to see the cooperative effects.

## Interpretations and constraints
- The exported dates for El principio and Aquella madrugada were identical. Restored the distinct original date 03112025 for Aquella madrugada. Exact codes are recognized only in ordinary fields within ISMAMINT, not in passwords, logins, or other apps. No keyboard data is collected or stored.
- Added a discreet decorative 4 alongside the original formula and a small separator at the bottom of Inicio; the actual formula and live counter are unchanged.
- ISMAMINT Classic is a temporary retro view inspired by the original formula, not a bundled exact old APK. The live count remains real.
- Cooperative message and heartbeat discoveries compare server-confirmed recent chat messages (up to 40, from the current session or previous two minutes); matching time differences use server timestamps. Effects and unlocks happen locally while the app is active. Not a new background push protocol. Special notification for Pensamos lo mismo uses existing achievement preferences; if several achievements are unlocked together, the usual batch notification may be shown instead.
- Ritmo gemelo tolerance: equal pulse count and each interval within max(120 ms, 20% of the longer interval). No extra vibration.
- Music coincidence is foreground-only, online, best-effort, using current track ID and a server timestamp, refreshed every 20 seconds while actively playing; a 35-second freshness window tolerates delivery delays. It does not record a listening history. The peer song field is cleared when pausing/leaving if connected; a stale value expires. Requires the extra rule.
- A random event can occur once per eligible cold WebView session; each selected probability is its exact marginal chance, with mutually exclusive events. The cat discoveries require tapping the cat. Effects may repeat according to the approved plan, while each achievement is persisted once.
- Fin de la cinta requires playing a continuous track from the beginning to the end without seeking forward. Uninterrupted playback is detected using the audio element's played range.
- New-45 uses four different achievement categories; new-46 counts 10 distinct approved proposals designated Easter egg, not just any secret achievement.

## Validation
Node tests: 50 test files passed before final minor UI/audio adjustments. Chromium smoke tests for the existing five secrets and the new catalog passed; tested 44 taps, the two date codes, simulated chat and music, persistence, and no browser exceptions. Native Firestore/Android, exact haptics, production notification delivery and the complete APK were not tested in this environment. The Java bridge and Firestore rules need production verification. See `ISMAMINT_SECRETOS_APROBADOS.json` for the catalog and specific trigger decisions.
