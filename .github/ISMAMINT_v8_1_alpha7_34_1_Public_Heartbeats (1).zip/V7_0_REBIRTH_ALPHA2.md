# Rebirth Alpha 2 — Tacto y ritmo

- Los dos desgloses temporales se muestran siempre, también con preferencias antiguas de resumen. Se conserva la personalización de módulos de Inicio.
- Corazón interactivo en Inicio, Datos (latidos) y osciloscopio. El pulso estimado conserva el período de 864 ms (100.000 al día), con patrón táctil doble de 45/80/30 ms. No representa una medición fisiológica.
- Preferencias locales independientes en Ajustes > Sonido y tacto: pulsaciones, latidos en Datos, osciloscopio, latidos automáticos de Inicio (desactivados inicialmente), movimiento musical y vibración musical (desactivada inicialmente). Se respeta el interruptor general de vibración. El puente Android permite cancelar una vibración con 0.
- Movimiento musical conectado a los beats, intensidad y acento del motor de escenas existente. Anima elementos decorativos sin desplazar textos ni controles. Respeta movimiento reducido y se suspende en segundo plano o en otras pantallas.
- Feedback táctil de botones con protección contra duplicación inmediata y prioridad de patrones de latido. No se alteran las mecánicas de juegos ni el chat.
- No se cambian los datos originales, las canciones, las dedicatorias, la firma, los avisos ni Firebase.

Validación: pruebas unitarias de Rebirth Core y sintaxis JavaScript, prueba de interfaz Chromium con recursos JS/CSS integrados, localStorage y puente Android simulados (desgloses, latidos, interruptores, pulso musical simulado). Pendiente compilación y validación del actuador físico Android; no es un APK.
