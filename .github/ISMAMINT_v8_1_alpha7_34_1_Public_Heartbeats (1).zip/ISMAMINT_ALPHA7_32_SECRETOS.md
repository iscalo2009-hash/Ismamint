# ISMAMINT v8.1 · Alpha 7.32 — Secretos

Catálogo de desarrollo (spoilers): 53 secretos generales y 12 de Heartmint; 65 logros secretos en total. Dos sorpresas de cumpleaños independientes. Fuente: `app/src/main/assets/index.html`, `heartmint-release.js`, `heartbound-app.js`, `birthday.js`, `birthday-core.js` y el nuevo `secret-eggs.js`.

## Serie del 4 (12)
Todos requieren como mínimo 444 días desde que se conocieron. Los días, amores y meses se calculan desde la fecha original, no desde el noviazgo. Los 11 hitos componen la serie.

| Nombre | Condición |
|---|---|
| Cuatro, cuatro, cuatro | 444 días |
| Cuarenta y cuatro mil millones | 44.444.444.444 amores |
| Cuatro y cuatro | 4 años y 4 meses (52 meses) |
| Cuatrocientos cuarenta y cuatro mil millones | 444.444.444.444 amores |
| Cuatro mil cuatrocientos cuarenta y cuatro | 4.444 días |
| Cuatro billones y pico | 4.444.444.444.444 amores |
| Cuarenta y cuatro años | 44 años |
| Cuarenta y cuatro mil días | 44.444 días |
| Cuatrocientos cuarenta y cuatro billones | 444.444.444.444.444 amores |
| Cuatrocientos cuarenta y cuatro años | 444 años |
| Cuatrocientos cuarenta y cuatro mil días | 444.444 días |
| La serie completa | Los otros 11 secretos de esta serie |

## Coincidencias numéricas (8)
También requieren como mínimo 444 días. Los contadores son amores y las seis estadísticas de Datos.

| Nombre | Condición efectiva |
|---|---|
| Todos terminan en cuatro | Cuatro o más contadores terminan en 4 en la misma actualización |
| Doble 444 | Dos o más contadores terminan en 444 a la vez |
| De ida y vuelta | Detectar un número de amores palíndromo |
| Cuatro veces de ida y vuelta | Detectar cuatro palíndromos distintos |
| Mismo final | Al menos tres contadores comparten un último dígito en cuatro comprobaciones consecutivas (aprox. una por segundo; el dígito puede cambiar entre comprobaciones) |
| Cuatro iguales | Al menos dos contadores tienen cuatro últimos dígitos iguales entre sí dentro de cada contador; no tienen que coincidir ambos (0000 también cuenta) |
| Cuatro casualidades | Cuatro de los seis secretos anteriores |
| La suma de los cuatros | 444 días, 44.444.444.444 amores y al menos otros cuatro secretos generales desbloqueados |

Los palíndromos se buscan en un intervalo reciente de hasta 3.001 números, no exclusivamente en el valor visible. Mismo final conserva su nombre aunque su condición sea diferente del logro ordinario homónimo de Datos.

## Otros secretos: tiempo, datos y cifras (20)
No requieren la barrera de los 444 días. Las magnitudes se cuentan desde que se conocieron; los latidos, respiraciones y parpadeos son estimaciones matemáticas.

| Nombre | Condición |
|---|---|
| Uno, cuatro, tres | 143 días |
| Quinientos veinte | 520 días |
| Mil trescientos catorce | 1.314 días |
| Un año de horas | 8.760 horas |
| Quinientos veintiuno | 521 días |
| Mil cuatro | 1.004 días |
| Siete mil setecientos setenta y siete | 7.777 días |
| Cuatro mil cuatrocientas cuarenta y cuatro horas | 4.444 horas |
| Cuarenta y cuatro mil cuatrocientas cuarenta y cuatro horas | 44.444 horas |
| Cuatrocientas cuarenta y cuatro mil cuatrocientas cuarenta y cuatro horas | 444.444 horas |
| Cuatrocientos cuarenta y cuatro mil minutos | 444.444 minutos |
| Cuatro millones cuatrocientos mil minutos y pico | 4.444.444 minutos |
| Cuarenta y cuatro millones de segundos | 44.444.444 segundos |
| Cuatrocientos cuarenta y cuatro millones de segundos | 444.444.444 segundos |
| Cuarenta y cuatro millones de respiraciones | 44.444.444 respiraciones |
| Cuarenta y cuatro millones de parpadeos | 44.444.444 parpadeos |
| Cuatrocientos cuarenta y cuatro millones de latidos | 444.444.444 latidos |
| Cuarenta y cuatro meses | 44 meses |
| Cuatrocientos cuarenta y cuatro meses | 444 meses |
| Semana 444 | 444 semanas |

## Otros secretos: reloj y calendario (8)
No requieren la barrera de los 444 días. Basta que la aplicación esté activa durante el minuto o día indicado; no es obligatorio iniciarla en ese instante.

| Nombre | Condición |
|---|---|
| La hora exacta | 1:36 a. m. local |
| Cuatro cuatro cuatro | 4:44 a. m. o p. m. local |
| Nuestro primer día, otra vez | 11 de septiembre, fecha en Colombia, tras al menos 300 días desde conocerse (en la práctica, primer aniversario o posteriores) |
| El día de los dos | 3 de noviembre, fecha en Colombia, tras al menos 300 días desde el noviazgo |
| Cuatro del cuatro | 4 de abril, fecha local |
| Cuatro, cuatro y 4:44 | 4 de abril a las 4:44 a. m. o p. m., fecha y hora locales |
| Pide un deseo | 11:11 a. m. o p. m. local |
| La hora exacta, de tarde | 1:36 p. m. local |

## Easter eggs añadidos (5)
No requieren 444 días. Se descubren en Inicio, tocando el corazón original. No hay nuevos botones ni menús.

| Nombre | Condición |
|---|---|
| El cuarto latido | Cuatro toques en un máximo de 2,4 segundos, sin intervalos superiores a 600 ms |
| Eco de cuatro | Dos grupos de cuatro toques, con pausa de 900–2.200 ms entre grupos |
| Latido digital | Cuatro toques mientras Machine Love está reproduciéndose durante los cuatro toques |
| Latido dorado | Cuatro toques mientras Yellow está reproduciéndose durante los cuatro toques |
| Constelación oculta | Desbloquear los cuatro anteriores |

El detector se reinicia al salir de Inicio o cambiar visibilidad. Los descubrimientos se guardan en `aurora_stats_v1` y se desbloquean mediante el motor existente `aurora_logros_v1`. Se reutilizan los avisos y efectos chiptune existentes, sujetos a sus preferencias. Sin cambios al corazón, al karaoke, a los fondos, al juego, a Firebase ni a la firma.

## Heartmint (12)

| Nombre | Condición efectiva |
|---|---|
| Furra | Obtener la reacción rara «furra»: probabilidad del 2,5 % por reacción elegible, excluyendo muerte e inicio de nivel |
| Todavía late | Vencer un jefe con una vida |
| Ni una sola grieta | Vencer un jefe sin daño y con combo de al menos 44 |
| Cuatro latidos | Completar un tramo con exactamente cuatro vidas y combo de al menos 44 |
| Menta bajo la lluvia | Recoger un corazón dorado durante lluvia dorada |
| No pasarás | Bloquear un obstáculo con escudo |
| Devuélvesela | Devolver una nota de Feid con una vida |
| Ignore y niegue | Esquivar por muy poco un obstáculo con una vida |
| Otra vez, mi vida | Reintentar tres veces en la misma sesión |
| Sin respirar | Alcanzar combo de 144 o superior |
| El número secreto | Completar un tramo con combo exactamente 44 |
| Un pequeño milagro | Completar un objetivo táctico con una vida |

## Sorpresas independientes del catálogo
En cada edición de cumpleaños, apagar las velas y tocar la tarta cuatro veces. Aurora: `te quiero mucho esposa satanica`. Ismael: `4:44`. Progreso separado por edición y año; la vista previa no modifica el progreso real.

## Verificación
48/48 suites Node; prueba Chromium de la integración completa de los cinco nuevos logros, persistencia simulada en localStorage y recuento del catálogo. No se ha compilado el APK ni probado en Android físico. No se han validado individualmente todos los 60 secretos preexistentes durante esta actualización. Los nombres nuevos son propuestas de etiquetas de logros, no mensajes románticos escritos en nombre del usuario.
