# ISMAMINT V6.0 — Chiptune Renaissance Alpha 2

Base: Alpha 1. Se conserva el identificador Android, los recursos de firma y Firebase. No se han eliminado archivos existentes ni se han cambiado las reglas de Firestore. Las canciones, metadatos, letras, escenas, ritmos, presets y arranque se mantienen. No se añaden copias de seguridad ni diagnóstico.

## Cambios
- Calendario integrado desde Más e Inicio; fechas y categorías, navegación a elementos, horarios locales para eventos con hora y fecha de Colombia para las ocasiones sin hora. Los logros ocultos no se revelan.
- Distribuciones de Inicio minimalista, equilibrada y completa, accesos y configuración existentes. Selección de unidad de Datos persistente y botones de copia.
- Biblioteca musical: recientes, mezcla de favoritas, retorno a biblioteca completa; guardado periódico de posición y mejora de reintento de colocación de letras. La cola de favoritas es temporal por sesión.
- Chat: reconciliación por ID de mensajes y actualización de recibos sin sustituir burbujas sin cambios; anclaje de lectura, borradores al salir, búsqueda conservada en sesión, ID estable y persistencia del texto saliente antes del envío, reintento con consulta previa al servidor. Los adjuntos mantienen su flujo existente; navegación entre adjuntos, zoom de imagen y posición de audio por sesión.
- Herramientas: buscador, favoritos, navegación atrás al catálogo. Heartmint: récord e instrucciones y pausa al salir durante partida.
- CSS retro en ventanas, chat, controles multimedia, herramientas y ajustes. Fondo ambiental suspendido en chat y movimiento reducido; cálculo visual omitido cuando documento oculto.
- Programación de avisos: puente Android por lote y reconciliación de cambios, con fallback anterior. No se alteran la lógica de fechas, IDs, restricciones ni deduplicación existente.

## Validación realizada
- Sintaxis Node de todos los scripts internos y externos, IDs HTML únicos, archivos y recursos originales comparados.
- Chromium con HTML/JS/CSS integrados y almacenamiento/puente nativo simulados: inicialización sin excepciones, calendario, 55 pistas, 5 herramientas, filtro favoritos, navegación herramienta/catálogo, dos mensajes simulados con actualización de lectura sin reconstruir nodo, llegada de tercero sin sustituir nodo, persistencia y confirmación de un envío de texto simulado con ID de 20 caracteres, mezcla de favoritas, guardado de unidad de Datos.
- No se dispone de Android SDK/Gradle completo en este entorno. Pendiente compilación, migración real sobre una instalación existente, llamadas al puente Java, pruebas con Firebase real, recepción de avisos en Android y reproducción de recursos de audio. No es release estable.

Instalar como actualización con el mismo package y firma. Si la herramienta de compilación usa appVersionCode/appVersionName, incrementar el versionCode anterior; no desinstalar ni borrar datos.
