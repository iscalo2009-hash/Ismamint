# Alpha 8 — Heartmint: Infinite Bosses

Jefes 1–5 (niveles 5, 10, 15, 20 y 25): Feid, Justin Bieber, La distancia, Seven, Celos. Los primeros cuatro tienen familias de ataques fijas, con variaciones. Celos empieza la generación combinatoria por semilla de partida y número de jefe; su ataque Espejo está garantizado. Los siguientes jefes se generan bajo demanda sin catálogo de niveles ni final definido.

- 12 familias de ataque, seis patrones de movimiento, tres fases de combate, sprites generados a partir del cuarto jefe (los primeros tres conservan sus sprites).
- Oleadas anunciadas con un corredor seguro de al menos tres columnas; no se programa otra oleada hostil hasta que la anterior desaparezca. Daño doble durante ventanas de vulnerabilidad periódicas. Los corazones de ataque favorecen la zona segura.
- Música sintetizada localmente: cada jefe tiene perfil de raíz, escala, motivo, ritmo, progresión, timbres y percusión; se adapta a fases, peligro, vidas y vulnerabilidad. No se añaden MP3.
- Escala de vida logarítmica, densidad/velocidad acotadas y mejoras con rendimientos decrecientes para partidas largas. Se preservan claves de almacenamiento, skins, logros y récords.

Pruebas: `node tests/heartmint-bosses.test.js` verifica 6000 perfiles y 162000 oleadas. Chromium comprobó inicio, generación de notas, habilidades, aparición/ataque/victoria y recompensa de los jefes 1–7, y pausa al salir. No sustituye pruebas de equilibrio a largo plazo, audio ni compilación en Android.
