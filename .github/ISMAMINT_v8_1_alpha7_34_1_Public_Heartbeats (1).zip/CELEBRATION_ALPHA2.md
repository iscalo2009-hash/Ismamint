# ISMAMINT V8.0 Alpha 2 — Birthday Editions
Base: V8.0 Alpha 1 Celebration Engine. Mantener identidad pixel art / chiptune, música existente y datos previos.

- Aurora Edition (20 agosto): rosas, menta, motivo original de pulso cuadrado y bajo triangular, partículas de cruz/estrella.
- Yellow ZK (26 diciembre): amarillo, rojo, motivo original más rápido, partículas de píxel cuadrado. El nombre de presentación es Yellow ZK; el identificador interno `solar` de paleta se mantiene por compatibilidad.
- Boot: edición, edad, corazón recoloreado y sonido de entrada especial; respeta modo directo/clásico/cinemático, ajustes de sonido y movimiento reducido. No se fuerza una reproducción automática.
- Tarjeta del inicio con tarta pixel interactiva y cuatro velas. Al apagarlas se guarda el estado anual local. Cuatro toques posteriores revelan el secreto. Escuchar tema permite repetir la melodía por acción explícita. No crea logros globales ni escribe Firebase. Al cambiar de año se usa otra clave; vista previa completamente separada.
- Chiptune original sintetizado por Web Audio: pulsos cuadrados, bajo triangular, eco corto y variantes anuales deterministas; usa volumen de efectos, atenúa la radio durante el motivo y cancela ante navegación, ocultación o grabación. Sin cambios en pistas ni Heartmint.
- Cinco widgets nativos: paleta y fondo de cumpleaños según fecha civil local, conservando los datos y acciones. El widget principal muestra la edición; el widget de latido usa la misma frecuencia de actualización horaria que los demás. Android controla el instante efectivo de actualización; no hay alarma exacta de medianoche. Vista previa no afecta los widgets.
- Clave nueva aislada `ismamint_birthday_v1`. Sin migraciones, cambios en IDs, relojes, reglas, permisos, ni calendario de notificaciones.

Validación: 26 scripts `tests/*.test.js` pasan, incluido birthday-core; `tests/celebration-browser.py` pasa en Chromium aislado, con media/red bloqueadas (calendario, ambas ediciones, tarta, secreto, aislamiento de vista previa, persistencia real, boot simulado y restauración). Sin compilación Gradle/SDK Android, prueba física de widgets o escucha en dispositivo. Próximo paso: Gift Studio offline; no cápsulas del tiempo.
