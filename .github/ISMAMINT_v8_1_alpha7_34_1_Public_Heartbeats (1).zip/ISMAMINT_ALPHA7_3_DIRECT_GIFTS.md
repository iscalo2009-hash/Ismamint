# ISMAMINT v8.0 Alpha 7.3 — Direct Gifts

Base: Alpha 7.2. Changes limited to the gift editor and its browser regression test.

- New visual gifts use a dedicated simple editing mode. Add text in one tap; the keyboard field is focused immediately. Font, color, size, bold and italic are available in the same bottom sheet. Changes are previewed on the canvas before being committed. Cancel leaves the existing layer untouched, and canceling a new text does not create a blank layer. Android Back confirms the text sheet before returning to the editor.
- Tap a selected text or its contextual Text button to edit. The persistent toolbar adds text, images, shapes and sprites. Optional layers, background and library panels can be opened independently. Advanced object properties remain available under Adjustments. The background includes twelve quick swatches and custom color controls. Import errors appear outside the hidden library panel.
- The canvas uses more available screen width. The header is compact; the manual Save button appears if automatic saving fails. Global undo/redo remains available. The legacy editor for non-visual gifts is retained.
- New text objects carry an optional wrapWidth of 276 logical units, retained by normalization and used by the same Konva renderer for editing and recipient preview. Existing objects without this property retain their layout. Both devices should update to render long new text consistently. No Firestore rules or native bridge changes were needed.
- No new romantic messages, templates or composer. Heartmint and the original app assets are untouched.

Verification: 39 JavaScript tests passed; one mobile-sized Chromium integration script passed (390x844), with simulated local/session storage and media library: focused text input, cancel, auto wrap, undo/redo, layer order, background swatches/custom color, imported image, recipient preview, local delivery. Font selection and data persistence were checked; the browser environment blocks external resource requests and does not verify actual Android keyboard behavior, IndexedDB or live Firebase. No APK compilation was performed.
