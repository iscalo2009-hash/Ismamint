# ISMAMINT Chat V3.0 Beta — Multimedia

Actualización sobre V3.0 Alpha. No requiere Blaze, Storage, servicios de terceros ni pago. Publicar firestore.rules antes de instalar en ambos teléfonos. Conserva los documentos de fotos y mensajes anteriores.

## Funciones
- Adjuntos agrupados con selección múltiple de hasta cinco fotos, compresión automática, descripción individual, rotación 90°, descarte y vista previa. Cámara mediante cámara del teléfono (captura de previsualización, no resolución completa).
- Notas de voz AAC mono, 24 kbps, máximo 120 segundos. Permiso al grabar. Grabar, terminar, escuchar, descartar, enviar. Grabación se cancela al salir de la app. Reproductor propio con búsqueda temporal, pausa y velocidades 1/1.5/2.
- MP4 y documentos pequeños (hasta 449000 bytes; no hay transcodificación de vídeo). Stickers estáticos JPEG creados de una foto, sin transparencia. Documentos se guardan para abrirlos con una app externa.
- Galería por tipo, carga de historial manual y descarga bajo demanda. Estimación parcial de almacenamiento de mensajes cargados, no cuota real de Firestore. Exportar adjuntos en Android 10+ a Descargas/Ismamint. Eliminar para ambos borra el documento multimedia propio. No se borran recuerdos automáticamente.
- Envío por lotes secuencial, conserva los pendientes en memoria al fallar. No persisten tras reiniciar app; el envío en cola de Firestore puede esperar a la conexión.
- Caché limitada de 12 adjuntos en memoria (además de la caché del SDK de Firestore). Sin E2EE. Acceso Firestore limitado a las dos cuentas existentes.

## Límites y pendientes
Fotos y stickers: máximo 240000 caracteres Base64 incluyendo cabecera (~180 KB binarios). Resto: máximo 600000 caracteres (~450 KB). Spark puede rechazar operaciones al agotar cuota; no hay cobros automáticos mientras permanezca en Spark. El almacenamiento incluye índices, datos codificados y otros documentos. No hay límite global personalizado ni compresión de vídeo, editor avanzado, gestos de grabación o galería offline persistente. No hay push de chat aún. La cámara usa el selector/cámara del sistema, la reproducción y las vistas previas son de Ismamint.

## Validación
Sintaxis JS y XML, comprobación de estructura del ZIP. No se ha compilado Android ni ejecutado Firestore Emulator; comprobar permisos, envíos entre dispositivos, reproducción, eliminación y compatibilidad de las reglas antes de uso habitual. Probar primero texto y una foto antigua, una foto nueva, audio corto, adjunto pequeño, y eliminación de un adjunto de prueba. Mantener copia de las reglas y del proyecto anterior.
