# Heartbound Alpha 2 — Evolution

Base: Heartbound Alpha 1. Catálogo cosmético separado de las físicas: 13 sprites y adornos animados, galería con desbloqueos por progreso, corazones, bosses, esquivas perfectas, parries y resonancias. Las apariencias antiguas obtenidas migran a diseños equivalentes; el guardado antiguo permanece intacto. La instalación sin progreso comienza con Origen. La hitbox no depende de las apariencias.

## Combate
- Seis estados (Libertad, Protección, Gravedad, Vínculo, Resonancia, Distorsión). Resonancia premia pulsaciones cerca del pulso visual; Distorsión cambia de lado si el destino no está ocupado. No hay sincronización exacta con Web Audio todavía.
- Gravedad: plataformas, salto y caída a través de plataforma. Protección: proyectiles direccionales con tiempo para llegar y señales visuales. Vínculo: patrones horizontales además de verticales y objetivos de reconexión.
- 20 familias de patrones, incluidos anillos expansivos, láseres con aviso, portales, pulsos rítmicos, fuego cruzado, saltos, vínculo lateral y salvas. Selección compatible; sin validador espacio-temporal exhaustivo de rutas seguras.
- Contraataque explícito en apertura, sin disparo mantenido que lo active automáticamente. Ventana de 5.5 s más 0.7 s tras una oleada limpia. Disparo sostenido contra enemigos normales. Recuperación limitada por salud baja, energía por rozar proyectiles desde nivel 9, parry y ritmo.
- Enemigos: aviso antes de disparar, centinela con abanico, director coordina ráfagas, protector con conexión visible y prioridad contextual, divisor puede crear un fragmento, acechador con seguimiento limitado.
- Primeros 25 niveles con introducción planificada; 18 introduce Resonancia y 23 Distorsión. Mundos siguientes combinan tipos de encuentro sin repetición dentro de los cuatro primeros tramos. Conserva mundos de cinco niveles y checkpoints. Bosses con secuencias diferenciadas, incluidas Seven, Celos y los exes; combate conjunto secuencial.

## Validación
- `heartbound-core.test.js`: 10.000 niveles, compatibilidad y simulación de 12 bosses con invulnerabilidad.
- `heartbound-evolution.test.js`: 1.990 rutas, seis estados, veinte patrones, trece sprites únicos, desbloqueos, migración y pruebas específicas de controles y láser.
- `heartbound-integration.test.js`: pausa, mapa, migración y persistencia de apariencia, adaptador simulado.
- `rebirth-core.test.js`, `heartmint-bosses.test.js`, `heartmint-audio.test.js`: módulos reutilizados.
- `heartbound-browser-smoke.py`: Chromium con HTML/JS/CSS incorporados en página aislada, almacenamiento simulado, red bloqueada; comprueba galería, selección programática, navegación y pausa. No equivale a prueba táctil o WebView real.

## Pendiente
Prueba táctil y balance humano, dos estados adicionales (Impulso y Absorción), validador de trayectorias exhaustivo, director adaptativo completo, progresión horizontal adicional, sincronización musical exacta y combate simultáneo de los exes. No se ha compilado el APK. Canciones y reglas Firebase sin cambios.
