# Alpha 3.2.4 — Scenes & Presentation
- Optional 12 independent scenes, each with title, caption, canvas (80 objects), transition and duration. Add, duplicate, reorder and delete; existing main canvas and blocks remain independent.
- Manual previous/next navigation, five entrance transitions, reduced-motion support. Four additional opening buttons; existing chiptune opening cue retained. Preview preserves current scene and opening state across edits.
- Existing localStorage v1 key; no cloud delivery. Storage quota still applies. No automatic cinematic playback, camera or branching yet. Canvas undo is session-local and resets when switching scene editors.
- 28 Node suites and isolated scene/canvas Chromium tests passed; full app advanced browser regression timed out, Android build/device untested.
