# Heartmint — Secret Radio

- 151 logros: 139 existentes + 12 secretos independientes con condiciones ocultas hasta el desbloqueo. No se modifica el identificador del guardado.
- Reacciones contextuales, anti-repetición, intervalo mínimo normal de 9 s y reacción rara (2,5% en ocasiones elegibles). Se muestran debajo de controles, no sobre el tablero.
- Mayor contraste de sprites del jefe, corazones verdes/dorados, mejoras y amenazas bloqueables; guía de símbolos y objetivos más explícitos.
- Audio 8-bit independiente en todo p4: mapa, partida, derrota. El reproductor principal queda silenciado por toda la sección; las opciones de audio de Heartmint no dependen del botón de reproducción principal. Se restablecen los puentes de ritmo y motivo musical.
- Radio virtual basada en tiempo real: 55 duraciones obtenidas con ffprobe, rotación secuencial o aleatoria persistente, repetición, cola de favoritos, checkpoint con fecha de reloj. Cuando está suspendida, no se contabiliza tiempo escuchado. Reanuda en la pista y posición correspondiente, sin avisos atrasados. Pausa explícita detiene el reloj. La rotación aleatoria permanece fija hasta cambiar el modo o la cola. No es reproducción audible mediante servicio Android en segundo plano.
- Pruebas: 24 suites Node, prueba Chromium de juego y prueba Chromium de radio con Audio simulado y reloj acelerado. APK y audio/háptica en Android físico pendientes.
