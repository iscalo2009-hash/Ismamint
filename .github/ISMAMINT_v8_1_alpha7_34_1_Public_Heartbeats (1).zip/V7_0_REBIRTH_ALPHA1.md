# ISMAMINT V7.0 Rebirth — Alpha 1

Base: V6.0 Renaissance Alpha 2. Primera etapa del remake arquitectónico, no una reescritura completa.

## Núcleo
- `rebirth-core.js`: cálculo temporal puro y compartido por contador y estado de logros; caché acotada del calendario; bus de acontecimientos; historial de navegación; ciclo de vida de los bucles gráficos.
- `rebirth-ui.js` y `rebirth.css`: nueva capa de presentación, que reutiliza los nodos y motores previos. Inicio, Nosotros, Música, Chat y Explorar. Perfil y ajustes desde la cabecera. Las rutas/identificadores antiguos se mantienen.
- Nosotros obtiene la historia de las fechas originales, canciones y logros desbloqueados. Datos, catálogo de logros y calendario siguen siendo accesibles.
- Inicio conserva los módulos originales y añade próximo acontecimiento calculado a partir del calendario, modo ambiental y accesos directos. Las preferencias existentes tienen prioridad sobre los nuevos valores predeterminados.
- Música separa biblioteca, reproductor y dedicatorias; un único reproductor, escenas y letras originales. Aviso compacto con acceso a los detalles originales. Efectos prioritarios en Inicio y reproductor expandido.
- Explorar accede al juego Heartmint y a las cinco herramientas originales.
- Se cancelan los bucles de reloj, fondo y letras al ocultar la página y se reanudan cuando es visible. El tiempo se reconstruye desde el reloj real.

## Compatibilidad
No se cambian los archivos de audio, letras, escenas, reglas Firebase, proyecto Android, paquete, firma ni claves anteriores. No se añade un sistema de copias de seguridad ni diagnóstico. Las nuevas preferencias de vistas se almacenan en `isma_rebirth_ui_v1`; se amplía de forma compatible `isma_v6_ui` con un módulo de acontecimientos. No se reescriben mensajes románticos.

## Verificación
- Pruebas unitarias del núcleo: `node tests/rebirth-core.test.js`.
- Pruebas Chromium a 360 × 780 y 390 × 844 con recursos HTML/JS/CSS integrados y puente nativo simulado: navegación, historia, filtros, 55 pistas, cinco herramientas, calendario, chat, recibos y cola de envíos.
- Pruebas estáticas de sintaxis JS e integridad del paquete. Las pruebas de navegador no sustituyen la compilación ni las pruebas reales Android/Firebase. No se han validado audio real, fuentes locales, ni migración de una instalación Android en este entorno.
- Pendiente: separar más motores de dominio, unificar reglas temporales nativas, probar notificaciones/widgets en Android, optimizar audio y chat nativo, y realizar pruebas de usabilidad con ambos usuarios.

Instalar como actualización con el mismo paquete y firma; utilizar un versionCode superior al instalado. No desinstalar ni borrar datos.
