# Alpha 10 — Flow
- Centralized Heartmint pause, explicit 3-second resume countdown, cancellable, frozen simulation, input reset, single cancellable animation loop, pause on navigation/background, native resume guard, reward selection uses same countdown. Game audio pauses immediately (victory music remains during reward selection).
- New bounded motion layer: pixel touch waves, staggered visible card entrances, active navigation icons, modal transitions and control glints. No additional permanent rendering loop. Excludes gameplay/chat interaction and respects reduced motion.
- Chromium: pause/resume, countdown cancel, navigation, simulated native resume, reward, animation cleanup. Core and boss Node tests passed. Android build/device not tested.
