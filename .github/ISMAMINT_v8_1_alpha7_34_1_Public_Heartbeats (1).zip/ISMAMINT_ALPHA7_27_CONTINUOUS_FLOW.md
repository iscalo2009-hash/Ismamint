# ISMAMINT v8.1 · Alpha 7.27 — Continuous Flow

Base: Alpha 7.26 Karaoke Híbrido. No cambio de dependencias, de firma, de audio Opus, de reglas Firebase, de los 55 perfiles musicales, ni de las marcas de karaoke.

## Rendimiento
- Fondo musical: compositor con objetivo de 60 actualizaciones/s en pantallas de 60 Hz, raster artístico 180×320 cacheado a 30 intervalos/s durante la reproducción. La composición, los movimientos de cámara y los efectos locales conservan su reloj de audio.
- El antiguo canvas de primer plano, que ya no dibujaba efectos, queda inactivo con backing store 1×1; se eliminan sus máscaras y lecturas de geometría periódicas. La detección de colisiones de la letra se conserva al posicionar cada frase.
- Canvas de fondo limitado a DPR 1 y a 480×850 píxeles máximos, con adaptación de calidad si la cadencia cae. El tamaño CSS sigue siendo pantalla completa.
- Prueba de integración Chromium, viewport 420×850 CSS, DPR 3: Alpha 7.26 dos superficies de 525×1063 = 1.116.150 píxeles; Alpha 7.27 420×850 + 1×1 = 357.001, reducción de 68,0% en esas superficies, no equivalente a un incremento de FPS medido.
- La capa de universo genérica se suspende al activar la escena musical y vuelve cuando se desactiva; el fondo temático base sigue presente y reduce su cadencia a unos 15 Hz mientras hay escena musical (aprox. 30 Hz sin ella).
- Muestreo acústico sin asignaciones de mapas intermedios ni lectura repetida de tres bandas por ventana; se mantienen las mismas ponderaciones. Colores del raster con caché acotada. Karaoke evita escrituras de propiedades CSS idénticas y reduce sondeo cuando está inactivo. Contador principal y datos rápidos repintan aproximadamente 30 Hz, sin modificar el valor real por milisegundo; detalles de logros en vivo a 10 Hz.
- Heartmint: sprites pixel art prerenderizados con caché acotada, simulación fija 120 Hz conservada, compactación de listas en el sitio, búsqueda lineal de enemigo cercano sin ordenaciones, validación de caminos de obstáculos por máscara de carriles en vez de recorrer toda la matriz. Registro/HUD con cadencias separadas.

## Heartmint continuo
- Al superar un nivel de recogida normal se conservan corazones, obstáculos, enemigos, disparos, partículas, posición, invulnerabilidad restante, potenciadores y sus duraciones, la formación de aparición, sus temporizadores y cualquier exceso sobre el objetivo. La animación del escenario usa tiempo acumulado. Se mantienen las recompensas, progreso y objetivos originales por nivel.
- Velocidad y densidad de nuevas apariciones interpoladas en unos segundos; los objetos en vuelo conservan su velocidad. Las transiciones a jefes siguen siendo encuentros separados como en la versión anterior. No se modifican sus mecánicas ni el mapa de progreso.
- Obstáculos: aviso de 340 ms de simulación, visual de entrada en la parte superior, presupuesto agregado de peligro en pantalla al generar amenazas, conservación de rutas de escape comprobadas con la misma función de movimiento y menos trabajo por validación. Cinco grupos de siluetas visuales para familias existentes y mejor correspondencia del ancho visible con el área peligrosa; no se añaden familias ni se eliminan las existentes.

## Pruebas
- 43 suites Node, todas aprobadas. Nueva prueba: 240 transiciones ordinarias entre niveles 1–400, preservación de objetos/poderes/temporizadores/control y simulaciones extendidas con tope de entidades.
- Chromium: pantalla principal con fondo y karaoke; navegación, control táctil, pausa/reanudación de Heartmint; 55 escenas animadas en cuatro intervalos; validación del karaoke híbrido (1.701 líneas / 11.937 segmentos).
- No se compiló el APK ni se midieron FPS, latencia o consumo en un Android físico. El objetivo de 60 Hz no es una garantía de 60 FPS en el dispositivo. No se realizó una auditoría exhaustiva de módulos ajenos a los bucles de pantalla y Heartmint.
