package com.example;

import android.Manifest;
import android.app.*;
import android.app.job.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.*;
import android.provider.Settings;
import com.google.firebase.Timestamp;
import com.google.firebase.auth.*;
import com.google.firebase.firestore.*;
import org.json.JSONObject;
import java.util.*;

/** Local chat alerts. No server secrets, exact alarms or permanent background service. */
public final class ChatNotifications {
    static final String PULSE_TEXT="♥ Latido";
    static final String PULSE_CHANNEL="ismamint_heartbeat_v1";
    static final int PULSE_NOTICE=38423;
    static boolean pulse(DocumentSnapshot d){return HeartbeatActions.isPulse(d.getString("text"))&&d.getString("kind")==null&&!Boolean.TRUE.equals(d.getBoolean("edited"));}
    static final String CHANNEL = "ismamint_chat_messages_v1";
    static final String A = "MCbwjlCpBnhTHxfQTuvcOVWLN3w2", I = "MIPr6C3HW5QPp9GXd5ZjlHCmFQJ3";
    static final int JOB = 38421, NOTICE = 38422;
    private static volatile boolean foreground, inChat;
    private static volatile java.util.function.Consumer<String> pulseListener;
    void setPulseListener(java.util.function.Consumer<String> listener){pulseListener=listener;}
    private final Activity activity;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final FirebaseAuth auth = FirebaseAuth.getInstance();
    private final FirebaseAuth.AuthStateListener authListener = a -> refresh();
    private ListenerRegistration registration;
    private int generation;
    private boolean resumed, permissionAsked;
    private String lastAccount;

    ChatNotifications(Activity a) { activity=a; ensureChannel(a); }
    static SharedPreferences prefs(Context c) { return c.getSharedPreferences("isma_chat_notifications",Context.MODE_PRIVATE); }
    static String uid() { FirebaseUser u=FirebaseAuth.getInstance().getCurrentUser(); return u!=null&&(A.equals(u.getUid())||I.equals(u.getUid()))?u.getUid():null; }
    static CollectionReference messages() { return FirebaseFirestore.getInstance().collection("ismamint_chat/private/messages"); }
    static boolean isForeground() { return foreground; }
    static boolean enabled(Context c) { return prefs(c).getBoolean("enabled",true); }
    static boolean anyEnabled(Context c) { return enabled(c)||NoticePreferences.on(c,"pulses"); }
    static boolean muted(Context c) { return prefs(c).getLong("mute",0)>System.currentTimeMillis(); }
    static NotificationManager manager(Context c) { return c.getSystemService(NotificationManager.class); }
    static void ensureChannel(Context c) {
        NotificationManager n=manager(c); if(n==null)return;
        if(n.getNotificationChannel(PULSE_CHANNEL)==null){NotificationChannel h=new NotificationChannel(PULSE_CHANNEL,"Latidos",NotificationManager.IMPORTANCE_HIGH);h.enableVibration(true);h.setVibrationPattern(new long[]{0,65,110,45});h.setSound(null,null);h.setLockscreenVisibility(Notification.VISIBILITY_PRIVATE);n.createNotificationChannel(h);}
        if(n.getNotificationChannel(CHANNEL)!=null)return;
        NotificationChannel ch=new NotificationChannel(CHANNEL,"Mensajes de chat",NotificationManager.IMPORTANCE_HIGH);
        ch.setDescription("Mensajes nuevos de vuestra conversación privada"); ch.enableVibration(true); ch.setLockscreenVisibility(Notification.VISIBILITY_PRIVATE); n.createNotificationChannel(ch);
    }
    static boolean permitted(Context c) {
        ensureChannel(c); NotificationManager n=manager(c);
        if(n==null||!n.areNotificationsEnabled())return false;
        if(Build.VERSION.SDK_INT>=33&&c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)return false;
        NotificationChannel ch=n.getNotificationChannel(CHANNEL);return ch!=null&&ch.getImportance()!=NotificationManager.IMPORTANCE_NONE;
    }
    static void clear(Context c) { NotificationManager n=manager(c);if(n!=null)n.cancel(NOTICE); }
    static void schedule(Context c) {
        JobScheduler s=c.getSystemService(JobScheduler.class);if(s==null)return;
        if(!anyEnabled(c)||uid()==null){s.cancel(JOB);s.cancel(JOB+10);return;}
        if(s.getPendingJob(JOB)!=null)return;
        try{s.schedule(new JobInfo.Builder(JOB,new ComponentName(c,ChatNotificationJob.class)).setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY).setPeriodic(15*60*1000L).setPersisted(true).build());}catch(RuntimeException e){android.util.Log.w("Ismamint","Chat notification schedule failed",e);}
    }
    private static void scheduleCatchup(Context c){JobScheduler s=c.getSystemService(JobScheduler.class);String u=uid();if(s==null||u==null||!anyEnabled(c))return;long now=System.currentTimeMillis();if(now-prefs(c).getLong(u+"_catchup",0)<300000)return;try{if(s.schedule(new JobInfo.Builder(JOB+10,new ComponentName(c,ChatNotificationJob.class)).setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY).setMinimumLatency(30000).build())==JobScheduler.RESULT_SUCCESS)prefs(c).edit().putLong(u+"_catchup",now).apply();}catch(RuntimeException ignored){}}
    void resume(boolean chat) { if(resumed)return;resumed=true;foreground=true;inChat=chat;if(chat)clear(activity);auth.addAuthStateListener(authListener); }
    void pause() { if(!resumed)return;resumed=false;foreground=false;inChat=false;auth.removeAuthStateListener(authListener);detach();schedule(activity);scheduleCatchup(activity); }
    void chat(boolean value) { inChat=resumed&&value;if(inChat){clear(activity);NotificationManager nm=manager(activity);if(nm!=null)nm.cancel(PULSE_NOTICE);askPermissionOnce();} }
    void destroy(){if(resumed)pause();else detach();pulseListener=null;}
    private void detach(){generation++;if(registration!=null){registration.remove();registration=null;}}
    private void refresh(){String account=uid();if(!Objects.equals(account,lastAccount)){clear(activity);NotificationManager nm=manager(activity);if(nm!=null)nm.cancel(PULSE_NOTICE);lastAccount=account;}HeartbeatWidgetProvider.refresh(activity);detach();if(!resumed)return;schedule(activity);if(uid()==null){clear(activity);NotificationManager nm=manager(activity);if(nm!=null)nm.cancel(PULSE_NOTICE);return;}if(inChat)askPermissionOnce();listen();}
    void askPermissionOnce(){if(!resumed||uid()==null||!anyEnabled(activity)||permissionAsked||Build.VERSION.SDK_INT<33||activity.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)==PackageManager.PERMISSION_GRANTED)return;
        if(prefs(activity).getBoolean("asked",false))return;permissionAsked=true;prefs(activity).edit().putBoolean("asked",true).apply();requestPermission();}
    void requestPermission(){if(Build.VERSION.SDK_INT>=33&&activity.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED){activity.requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},WebAppInterface.REQ_POST_NOTIFICATIONS);}else openSettings();}
    void openSettings(){Intent i=new Intent(Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE,activity.getPackageName()).putExtra(Settings.EXTRA_CHANNEL_ID,CHANNEL);try{activity.startActivity(i);}catch(Exception e){activity.startActivity(new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE,activity.getPackageName()));}}
    String options(){try{return new JSONObject().put("enabled",enabled(activity)).put("preview",prefs(activity).getBoolean("preview",true)).put("mute",prefs(activity).getLong("mute",0)).put("allowed",permitted(activity)).toString();}catch(Exception e){return "{}";}}
    void configure(boolean on,boolean preview,long mute){prefs(activity).edit().putBoolean("enabled",on).putBoolean("preview",preview).putLong("mute",Math.max(0,mute)).apply();if(!on||muted(activity))clear(activity);refresh();if(on)askPermissionOnce();}

    static final class Cursor {
        final Timestamp time;final String id;
        Cursor(Timestamp t,String i){time=t;id=i;}
    }
    static Cursor cursor(Context c,String u){SharedPreferences p=prefs(c);if(!p.contains(u+"_sec"))return null;return new Cursor(new Timestamp(p.getLong(u+"_sec",0),p.getInt(u+"_nano",0)),p.getString(u+"_id",""));}
    static Query query(Context c,String u){Cursor k=cursor(c,u);if(k==null)return messages().orderBy("created",Query.Direction.DESCENDING).orderBy(FieldPath.documentId(),Query.Direction.DESCENDING).limit(1);
        Query q=messages().orderBy("created").orderBy(FieldPath.documentId());return (k.id.isEmpty()?q.whereGreaterThan("created",k.time):q.startAfter(k.time,k.id)).limit(100);}
    private void listen(){String u=uid();if(!resumed||u==null)return;int g=++generation;boolean initial=cursor(activity,u)==null;
        registration=query(activity,u).addSnapshotListener(MetadataChanges.INCLUDE,(s,e)->{if(g!=generation||!resumed||!u.equals(uid())||e!=null||s==null||s.getMetadata().isFromCache()||s.getMetadata().hasPendingWrites())return;
            consume(activity,u,s.getDocuments(),inChat);
            if(initial||s.size()>=100)main.post(()->{if(g==generation&&resumed){detach();listen();}});
        });}
    private static int cmp(Cursor a,Cursor b){int t=a.time.compareTo(b.time);return t==0?a.id.compareTo(b.id):t;}
    /** Both listeners and scheduled jobs use one persistent server-time cursor, including edits and own messages. */
    static synchronized void consume(Context c,String u,List<DocumentSnapshot> docs,boolean suppress){
        if(!u.equals(uid()))return; Cursor old=cursor(c,u);Cursor high=old==null?new Cursor(new Timestamp(0,0),""):old;List<DocumentSnapshot> fresh=new ArrayList<>();
        for(DocumentSnapshot d:docs){if(d.getMetadata().hasPendingWrites())continue;Timestamp t=d.getTimestamp("created");if(t==null)continue;Cursor k=new Cursor(t,d.getId());if(cmp(k,high)>0)high=k;
            if(old!=null&&cmp(k,old)>0&&!u.equals(d.getString("sender"))&&!Boolean.TRUE.equals(d.getBoolean("deleted"))){if(System.currentTimeMillis()-t.toDate().getTime() <= 24L*60*60*1000)fresh.add(d);}}
        // Commit before notifying so an edit, reconnect or overlapping fetch cannot replay an alert.
        if(old==null||cmp(high,old)>0){if(!prefs(c).edit().putLong(u+"_sec",high.time.getSeconds()).putInt(u+"_nano",high.time.getNanoseconds()).putString(u+"_id",high.id).commit())return;}
        if(fresh.isEmpty())return;
        List<DocumentSnapshot> pulses=new ArrayList<>();for(DocumentSnapshot d:fresh)if(pulse(d))pulses.add(d);
        fresh.removeAll(pulses);pulses.removeIf(d->System.currentTimeMillis()-d.getTimestamp("created").toDate().getTime()>2L*60*60*1000);if(!pulses.isEmpty()&&NoticePreferences.on(c,"pulses")){
            pulses.sort((a,b)->cmp(new Cursor(a.getTimestamp("created"),a.getId()),new Cursor(b.getTimestamp("created"),b.getId())));
            DocumentSnapshot latest=pulses.get(pulses.size()-1);
            java.util.function.Consumer<String> listener=pulseListener;
            if(foreground&&listener!=null){for(DocumentSnapshot pulse:pulses)listener.accept(pulse.getString("text"));}else postPulse(c,u,latest,pulses.size());
        }
        if(fresh.isEmpty()||suppress||!enabled(c)||muted(c)||!permitted(c))return;
        fresh.sort((a,b)->cmp(new Cursor(a.getTimestamp("created"),a.getId()),new Cursor(b.getTimestamp("created"),b.getId())));
        post(c,u,fresh);
    }
    private static void postPulse(Context c,String u,DocumentSnapshot latest,int count){
        ensureChannel(c);NotificationManager nm=manager(c);if(nm==null||!nm.areNotificationsEnabled())return;
        if(Build.VERSION.SDK_INT>=33&&c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)return;
        NotificationChannel ch=nm.getNotificationChannel(PULSE_CHANNEL);if(ch==null||ch.getImportance()==NotificationManager.IMPORTANCE_NONE)return;
        String sender=A.equals(u)?"Ismael":"Aurora";boolean preview=prefs(c).getBoolean("preview",true);
        for(android.service.notification.StatusBarNotification active:nm.getActiveNotifications())if(active.getId()==PULSE_NOTICE){count+=Math.max(0,active.getNotification().number);break;}
        String body=count>1?count+" latidos recibidos":HeartbeatActions.pattern(latest.getString("text"))!=null?"♥ Patrón de latidos recibido":"♥ Latido recibido";
        Notification.Builder b=new Notification.Builder(c,PULSE_CHANNEL).setSmallIcon(R.drawable.ic_notification).setContentTitle(preview?sender:"Ismamint").setContentText(body).setNumber(count).setContentIntent(WidgetDataHelper.createOpenTabPendingIntent(c,"p10",PULSE_NOTICE)).setVisibility(Notification.VISIBILITY_PRIVATE).setAutoCancel(true).setCategory(Notification.CATEGORY_MESSAGE).setColor(0xffee90b9)
            .addAction(new Notification.Action.Builder(null,"Devolver latido",HeartbeatActions.intent(c,u,latest.getId(),false,false)).build());
        b.setPublicVersion(new Notification.Builder(c,PULSE_CHANNEL).setSmallIcon(R.drawable.ic_notification).setContentTitle("Ismamint").setContentText("Latido recibido").build());
        b.addAction(new Notification.Action.Builder(null,"Sentir de nuevo",HeartbeatActions.replayIntent(c,u,latest.getId(),latest.getString("text"))).build());
        Bundle extras=new Bundle();extras.putString("isma_source",latest.getId());b.addExtras(extras);
        try{
            // Custom timing is played once, separately from the silent visual alert.
            // Keep ordinary notification behavior when vibration is disabled by Android.
            boolean custom=ch.shouldVibrate()&&nm.getCurrentInterruptionFilter()==NotificationManager.INTERRUPTION_FILTER_ALL&&HeartbeatActions.pattern(latest.getString("text"))!=null;
            if(custom)b.setGroup("isma_custom_pulse").setGroupAlertBehavior(Notification.GROUP_ALERT_SUMMARY);
            nm.notify(PULSE_NOTICE,b.build());
            if(custom)TactileEngine.replay(c,HeartbeatActions.pattern(latest.getString("text")));
        }catch(SecurityException ignored){}
    }
    private static String text(DocumentSnapshot d){String kind=d.getString("kind"),t=d.getString("text");String label=kind==null?"":kind.equals("photo")?"Foto":kind.equals("voice")?"Nota de voz":kind.equals("video")?"Vídeo":kind.equals("sticker")?"Sticker":"Documento";String body=label.isEmpty()?(t==null?"Mensaje nuevo":t):label+(t==null||t.trim().isEmpty()?"":": "+t);return body.length()>180?body.substring(0,180)+"…":body;}
    private static void post(Context c,String u,List<DocumentSnapshot> docs){NotificationManager nm=manager(c);if(nm==null)return;String sender=A.equals(u)?"Ismael":"Aurora";boolean preview=prefs(c).getBoolean("preview",true);int count=docs.size();
        // Keep the pending count across separate deliveries until the user opens/dismisses the alert.
        for(android.service.notification.StatusBarNotification active:nm.getActiveNotifications())if(active.getId()==NOTICE) {count+=Math.max(0,active.getNotification().number);break;}
        String body=preview?(count==1?text(docs.get(0)):count+" mensajes nuevos · "+text(docs.get(docs.size()-1))):count==1?"Mensaje nuevo":count+" mensajes nuevos";
        PendingIntent tap=WidgetDataHelper.createOpenTabPendingIntent(c,"p10",NOTICE);
        Notification pub=new Notification.Builder(c,CHANNEL).setSmallIcon(R.drawable.ic_notification).setContentTitle("Ismamint").setContentText("Mensaje nuevo").build();
        Notification.Builder b=new Notification.Builder(c,CHANNEL).setSmallIcon(R.drawable.ic_notification).setContentTitle(preview?sender:"Ismamint").setContentText(body).setStyle(new Notification.BigTextStyle().bigText(body)).setContentIntent(tap).setAutoCancel(true).setCategory(Notification.CATEGORY_MESSAGE).setVisibility(Notification.VISIBILITY_PRIVATE).setPublicVersion(pub).setNumber(count).setColor(0xffa14f76);
        String source=docs.get(docs.size()-1).getId();
        RemoteInput reply=new RemoteInput.Builder(HeartbeatActions.REPLY_KEY).setLabel("Mensaje").build();
        b.addAction(new Notification.Action.Builder(null,"Responder",HeartbeatActions.intent(c,u,source,true,false)).addRemoteInput(reply).setAllowGeneratedReplies(false).build());
        Bundle extras=new Bundle();extras.putString("isma_source",source);b.addExtras(extras);
        try{nm.notify(NOTICE,b.build());}catch(SecurityException ignored){}
    }
}
