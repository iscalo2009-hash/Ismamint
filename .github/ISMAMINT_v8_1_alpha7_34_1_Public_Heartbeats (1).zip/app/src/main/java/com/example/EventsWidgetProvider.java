package com.example;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.RemoteViews;

import java.util.List;

public class EventsWidgetProvider extends AppWidgetProvider {

    private static final int PINK = 0xFFEE90B9;
    private static final int GOLD = 0xFFEBC65C;
    private static final int TEXT = 0xFFF0D5E5;
    private static final int DIM = 0xFFBDA0B4;

    private static final int[] ROW_IDS = {
            R.id.widget_events_row1,
            R.id.widget_events_row2,
            R.id.widget_events_row3
    };
    private static final int[] TITLE_IDS = {
            R.id.widget_ev1_title,
            R.id.widget_ev2_title,
            R.id.widget_ev3_title
    };
    private static final int[] DATE_IDS = {
            R.id.widget_ev1_date,
            R.id.widget_ev2_date,
            R.id.widget_ev3_date
    };
    private static final int[] ETA_IDS = {
            R.id.widget_ev1_eta,
            R.id.widget_ev2_eta,
            R.id.widget_ev3_eta
    };

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        updateWidgets(context, appWidgetManager, appWidgetIds);
    }

    @Override
    public void onAppWidgetOptionsChanged(Context context, AppWidgetManager appWidgetManager,
                                          int appWidgetId, Bundle newOptions) {
        updateWidgets(context, appWidgetManager, new int[]{appWidgetId});
    }

    public static void updateWidgets(Context context, AppWidgetManager manager, int[] ids) {
        long now = System.currentTimeMillis();
        List<WidgetDataHelper.EventItem> events = WidgetDataHelper.getUpcomingEvents(context, now);

        BirthdayWidgetTheme birthday = BirthdayWidgetTheme.at(System.currentTimeMillis());
        for (int appWidgetId : ids) {
            int w = WidgetDataHelper.innerWidthPx(context, manager, appWidgetId);

            RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_events);
            birthday.apply(views, R.id.widget_events_root);
            PixelText.setWidget(views, R.id.widget_events_title, context, "PROXIMOS EVENTOS", PixelText.TITLE, 8, birthday.accent, w * 2 / 3);
            PixelText.setWidget(views, R.id.widget_events_badge, context, "LOCAL", PixelText.BODY, 15, birthday.dim, w / 4);

            for (int i = 0; i < 3; i++) {
                if (i < events.size()) {
                    WidgetDataHelper.EventItem item = events.get(i);
                    boolean urgent = WidgetDataHelper.isUrgentEvent(item.ts, now);
                    String eta = WidgetDataHelper.formatCountdownLabel(item.ts, now);

                    // Badge primero: el título usa el ancho que sobre.
                    int badgeText = (int) PixelText.measure(context, eta, PixelText.TITLE, 8);
                    int etaBox = badgeText + PixelText.dp(context, 12);
                    int textW = Math.max(PixelText.dp(context, 60),
                            w - PixelText.dp(context, 16) - etaBox - PixelText.dp(context, 8));

                    views.setViewVisibility(ROW_IDS[i], View.VISIBLE);
                    PixelText.setWidget(views, TITLE_IDS[i], context, item.title, PixelText.TITLE, 8, birthday.text, textW);
                    PixelText.setWidget(views, DATE_IDS[i], context, WidgetDataHelper.formatEventLocal(item.ts), PixelText.BODY, 15, birthday.dim, textW);
                    PixelText.setWidget(views, ETA_IDS[i], context, eta, PixelText.TITLE, 8,
                            urgent ? birthday.secondary : birthday.accent, w / 2);
                    views.setInt(ETA_IDS[i], "setBackgroundResource",
                            urgent ? R.drawable.widget_bg_gold_badge : R.drawable.widget_bg_red_badge);
                } else {
                    views.setViewVisibility(ROW_IDS[i], View.GONE);
                }
            }

            views.setOnClickPendingIntent(R.id.widget_events_root,
                    WidgetDataHelper.createOpenTabPendingIntent(context, "p8", 6003));

            manager.updateAppWidget(appWidgetId, views);
        }
    }
}
