package com.example;
import java.util.Calendar;
import android.widget.RemoteViews;
/** Local civil date, recomputed on every widget refresh. No saved theme mutation. */
final class BirthdayWidgetTheme {
    final int accent, secondary, text, dim, background;
    final String edition;
    private BirthdayWidgetTheme(int a,int b,int t,int d,int bg,String e){accent=a;secondary=b;text=t;dim=d;background=bg;edition=e;}
    static BirthdayWidgetTheme at(long ms){
        Calendar c=Calendar.getInstance(); c.setTimeInMillis(ms);
        int y=c.get(Calendar.YEAR),m=c.get(Calendar.MONTH)+1,d=c.get(Calendar.DAY_OF_MONTH);
        if(y>2003&&m==8&&d==20)return new BirthdayWidgetTheme(0xFFFF8FC8,0xFF9CE2CB,0xFFFFD0E9,0xFFE3B6D0,R.drawable.widget_bg_birthday_aurora,"Aurora Edition");
        if(y>2009&&m==12&&d==26)return new BirthdayWidgetTheme(0xFFFFCB45,0xFFFF7060,0xFFFFE5B5,0xFFE9C59C,R.drawable.widget_bg_birthday_zk,"Yellow ZK");
        return new BirthdayWidgetTheme(0xFFEE90B9,0xFFEBC65C,0xFFF0D5E5,0xFFBDA0B4,R.drawable.widget_bg_panel,"");
    }
    void apply(RemoteViews views,int id){views.setInt(id,"setBackgroundResource",background);}
}
