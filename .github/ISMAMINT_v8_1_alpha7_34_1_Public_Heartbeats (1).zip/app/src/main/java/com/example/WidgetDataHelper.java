package com.example;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.SimpleTimeZone;
import java.util.TimeZone;

public final class WidgetDataHelper {

    public static final String EXTRA_OPEN_TAB = "open_tab";
    public static final String ACTION_REFRESH_WIDGETS = "com.example.ACTION_REFRESH_WIDGETS";

    public static final long TZ_OFFSET_MS = 5L * 3600000L; // Colombia UTC-5
    public static final long DAY_MS = 86400000L;
    public static final long CONOCE_MS = 1757566800000L; // 11 sep 2025 00:00 COT
    public static final long JUNTOS_MS = 1762151760000L; // 03 nov 2025 01:36 COT

    private static final String PREFS_NAME = "ismamint_widget_prefs";
    private static final String KEY_SNAPSHOT = "widget_snapshot_json";
    private static final TimeZone COL_TZ = new SimpleTimeZone(-5 * 3600000, "COT");
    private static final String[] MONTHS_SHORT = {
            "ene", "feb", "mar", "abr", "may", "jun",
            "jul", "ago", "sep", "oct", "nov", "dic"
    };

    private WidgetDataHelper() {}

    public static final class TimeBreakdown {
        public final int totalMonths;
        public final int years;
        public final int remMonths;
        public final int days;
        public final long totalDays;
        public final long totalMs;

        public TimeBreakdown(int totalMonths, int days, long totalDays, long totalMs) {
            this.totalMonths = Math.max(0, totalMonths);
            this.years = this.totalMonths / 12;
            this.remMonths = this.totalMonths % 12;
            this.days = Math.max(0, days);
            this.totalDays = Math.max(0L, totalDays);
            this.totalMs = Math.max(0L, totalMs);
        }

        public String formatCompactYmd() {
            return years + "a · " + remMonths + "m · " + days + "d";
        }
    }

    public static final class EventItem {
        public final String title;
        public final long ts;
        public final String dateStr;

        public EventItem(String title, long ts, String dateStr) {
            this.title = title;
            this.ts = ts;
            this.dateStr = dateStr;
        }
    }

    public static void saveSnapshot(Context context, String json) {
        if (json == null || json.trim().isEmpty()) return;
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .putString(KEY_SNAPSHOT, json)
                .apply();
    }

    public static JSONObject loadSnapshot(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        String raw = prefs.getString(KEY_SNAPSHOT, null);
        if (raw == null || raw.isEmpty()) {
            return new JSONObject();
        }
        try {
            return new JSONObject(raw);
        } catch (Exception e) {
            return new JSONObject();
        }
    }

    public static TimeBreakdown computeBreakdown(long startMs, long nowMs) {
        long diff = Math.max(0L, nowMs - startMs);
        long totalDays = diff / DAY_MS;

        Calendar s = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        s.setTimeInMillis(startMs - TZ_OFFSET_MS);
        Calendar n = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        n.setTimeInMillis(nowMs - TZ_OFFSET_MS);

        int sy = s.get(Calendar.YEAR);
        int smo = s.get(Calendar.MONTH);
        int sd = s.get(Calendar.DAY_OF_MONTH);
        int sh = s.get(Calendar.HOUR_OF_DAY);
        int smi = s.get(Calendar.MINUTE);

        int m = (n.get(Calendar.YEAR) - sy) * 12 + (n.get(Calendar.MONTH) - smo);
        Calendar check = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        check.clear();
        check.set(sy, smo + m, sd, sh, smi, 0);
        if (check.getTimeInMillis() > (nowMs - TZ_OFFSET_MS)) {
            m--;
            check.clear();
            check.set(sy, smo + m, sd, sh, smi, 0);
        }
        if (m < 0) {
            return new TimeBreakdown(0, (int) totalDays, totalDays, diff);
        }
        long rem = Math.max(0L, (nowMs - TZ_OFFSET_MS) - check.getTimeInMillis());
        int remDays = (int) (rem / DAY_MS);
        return new TimeBreakdown(m, remDays, totalDays, diff);
    }

    public static String formatNumber(long value) {
        DecimalFormatSymbols symbols = new DecimalFormatSymbols(new Locale("es", "CO"));
        symbols.setGroupingSeparator('.');
        symbols.setDecimalSeparator(',');
        DecimalFormat df = new DecimalFormat("#,###", symbols);
        return df.format(Math.max(0L, value));
    }

    public static String formatShortBig(double value) {
        if (value >= 1e9) {
            return String.format(new Locale("es", "CO"), "%.2f B", value / 1e9);
        }
        if (value >= 1e6) {
            return String.format(new Locale("es", "CO"), "%.1f M", value / 1e6);
        }
        return formatNumber((long) Math.floor(value));
    }

    public static String todayCotKey(long nowMs) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
        sdf.setTimeZone(COL_TZ);
        return sdf.format(new Date(nowMs));
    }

    public static String todayLocalKey(long nowMs) {
        return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date(nowMs));
    }

    public static String formatClockLocal(long nowMs) {
        return new SimpleDateFormat("HH:mm", Locale.US).format(new Date(nowMs));
    }
    public static String formatEventLocal(long ts) {
        return new SimpleDateFormat("dd MMM · HH:mm", new Locale("es")).format(new Date(ts));
    }
    public static String formatClockCot(long nowMs) {
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm", Locale.US);
        sdf.setTimeZone(COL_TZ);
        return sdf.format(new Date(nowMs));
    }

    public static String formatDateCot(long tsMs) {
        Calendar cal = Calendar.getInstance(COL_TZ);
        cal.setTimeInMillis(tsMs);
        int day = cal.get(Calendar.DAY_OF_MONTH);
        int month = cal.get(Calendar.MONTH);
        int year = cal.get(Calendar.YEAR);
        String mName = (month >= 0 && month < MONTHS_SHORT.length) ? MONTHS_SHORT[month] : "";
        return String.format(Locale.US, "%02d %s %d", day, mName, year);
    }

    public static long dayStartCot(long tsMs) {
        return ((tsMs - TZ_OFFSET_MS) / DAY_MS) * DAY_MS + TZ_OFFSET_MS;
    }

    private static long localDay(long ts) { return Math.floorDiv(ts + TimeZone.getDefault().getOffset(ts), DAY_MS); }

    public static String formatCountdownLabel(long eventTs, long nowMs) {
        long diffDays = localDay(eventTs) - localDay(nowMs);
        if (diffDays <= 0) return "HOY";
        if (diffDays == 1) return "MAÑANA";
        return "En " + diffDays + " d";
    }

    public static boolean isUrgentEvent(long eventTs, long nowMs) {
        long diffDays = localDay(eventTs) - localDay(nowMs);
        return diffDays <= 1;
    }

    public static List<EventItem> getUpcomingEvents(Context context, long nowMs) {
        JSONObject snap = loadSnapshot(context);
        JSONArray arr = snap.optJSONArray("events");
        long todayStart = dayStartCot(nowMs);
        List<EventItem> list = new ArrayList<>();
        if (arr != null) {
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.optJSONObject(i);
                if (o == null) continue;
                String title = o.optString("title", "");
                long ts = o.optLong("ts", 0L);
                String dateStr = o.optString("dateStr", "");
                if (title.isEmpty() || ts < nowMs) continue;
                if (dateStr.isEmpty()) dateStr = formatDateCot(ts);
                list.add(new EventItem(numberedTitle(title, ts), ts, dateStr));
            }
        }
        if (list.isEmpty()) {
            list = buildFallbackEvents(nowMs);
        }
        list.removeIf(e -> e.ts < nowMs);
        Collections.sort(list, Comparator.comparingLong(e -> e.ts));
        return list;
    }

    private static List<EventItem> buildFallbackEvents(long nowMs) {
        List<EventItem> out = new ArrayList<>();
        long todayStart = dayStartCot(nowMs);
        Calendar col = Calendar.getInstance(COL_TZ);
        col.setTimeInMillis(nowMs);
        int curYear = col.get(Calendar.YEAR);
        todayStart = nowMs;

        addNextAnnual(out, "Cumpleaños de Aurora", Calendar.AUGUST, 20, curYear, todayStart);
        addNextAnnual(out, "El cumpleaños de Ismael", Calendar.DECEMBER, 26, curYear, todayStart);
        addNextAnnual(out, "San Valentín", Calendar.FEBRUARY, 14, curYear, todayStart);
        addNextAnnual(out, "Año nuevo", Calendar.JANUARY, 1, curYear, todayStart);
        addNextAnnual(out, "Día del 4:44", Calendar.APRIL, 4, curYear, todayStart);
        addNextAnnual(out, "Día Internacional del Beso", Calendar.JULY, 6, curYear, todayStart);
        addNextAnnual(out, "Día de la Novia", Calendar.AUGUST, 1, curYear, todayStart);
        addNextAnnual(out, "Día del Novio", Calendar.OCTOBER, 3, curYear, todayStart);
        addNextAnnual(out, "Halloween", Calendar.OCTOBER, 31, curYear, todayStart);
        addNextAnnual(out, "Nochebuena", Calendar.DECEMBER, 24, curYear, todayStart);
        addNextAnnual(out, "Navidad", Calendar.DECEMBER, 25, curYear, todayStart);
        addNextAnnual(out, "Fin de año juntos", Calendar.DECEMBER, 31, curYear, todayStart);
        for (boolean together : new boolean[]{false,true}) {
            Calendar base = Calendar.getInstance(COL_TZ); base.setTimeInMillis(together ? JUNTOS_MS : CONOCE_MS);
            for (int k=0;k<13;k++) {
                Calendar event = (Calendar) base.clone();
                int n=(curYear-base.get(Calendar.YEAR))*12+col.get(Calendar.MONTH)-base.get(Calendar.MONTH)+k;
                if(n<1) continue; event.add(Calendar.MONTH,n); long ts=event.getTimeInMillis();
                if(ts>=nowMs) out.add(new EventItem(relationshipTitle(n,together),ts,formatEventLocal(ts)));
            }
        }

        long d500Conoce = CONOCE_MS + 500L * DAY_MS;
        if (d500Conoce >= todayStart) {
            out.add(new EventItem("500 días desde que nos conocimos", d500Conoce, formatDateCot(d500Conoce)));
        }
        long d500Juntos = JUNTOS_MS + 500L * DAY_MS;
        if (d500Juntos >= todayStart) {
            out.add(new EventItem("500 días juntos", d500Juntos, formatDateCot(d500Juntos)));
        }
        Collections.sort(out, Comparator.comparingLong(e -> e.ts));
        return out;
    }

    private static String relationshipTitle(int n, boolean together) {
        boolean annual=n%12==0; int count=annual?n/12:n;
        return count+" "+(annual?(count==1?"año":"años"):(count==1?"mes":"meses"))+(together?" juntos":" desde que nos conocimos");
    }
    private static String numberedTitle(String title,long ts) {
        Calendar local=Calendar.getInstance(); local.setTimeInMillis(ts);
        if(title.equals("Cumpleaños de Aurora")) return "Aurora cumple "+(local.get(Calendar.YEAR)-2003)+" años";
        if(title.equals("El cumpleaños de Ismael")||title.equals("Cumpleaños de Ismael")) return "Ismael cumple "+(local.get(Calendar.YEAR)-2009)+" años";
        boolean together=title.equals("Mesiversario")||title.equals("Nuestro aniversario")||title.equals("Aniversario juntos");
        if(together||title.equals("Otro mes conociéndonos")||title.equals("Aniversario de conocernos")||title.equals("Aniversario de conocerse")) {
            Calendar c=Calendar.getInstance(COL_TZ); c.setTimeInMillis(ts);
            int n=(c.get(Calendar.YEAR)-2025)*12+c.get(Calendar.MONTH)-(together?Calendar.NOVEMBER:Calendar.SEPTEMBER);
            if(n>0)return relationshipTitle(n,together);
        }
        return title;
    }

    private static void addNextAnnual(List<EventItem> out, String title, int month, int day, int startYear, long todayStart) {
        for (int k = 0; k < 2; k++) {
            Calendar c = Calendar.getInstance();
            c.clear();
            c.set(startYear + k, month, day, 9, 0, 0);
            long ts = c.getTimeInMillis();
            if (ts >= todayStart) {
                out.add(new EventItem(numberedTitle(title, ts), ts, formatEventLocal(ts)));
                return;
            }
        }
    }

    /** Ancho útil (sin el padding de 10dp) del widget, en px. Usa el mínimo para no pasarse al girar. */
    public static int innerWidthPx(Context context, AppWidgetManager manager, int appWidgetId) {
        int dp = 0;
        try {
            Bundle o = manager.getAppWidgetOptions(appWidgetId);
            if (o != null) dp = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0);
        } catch (Exception ignored) {
        }
        if (dp <= 0) dp = 250;
        return Math.max(PixelText.dp(context, 110), PixelText.dp(context, dp - 20));
    }

    public static PendingIntent createOpenTabPendingIntent(Context context, String tab, int requestCode) {
        Intent intent = new Intent(context, MainActivity.class);
        intent.putExtra(EXTRA_OPEN_TAB, tab);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        return PendingIntent.getActivity(
                context,
                requestCode,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );
    }

    public static PendingIntent createRefreshPendingIntent(Context context) {
        Intent intent = new Intent(context, MainCounterWidgetProvider.class);
        intent.setAction(ACTION_REFRESH_WIDGETS);
        return PendingIntent.getBroadcast(
                context,
                7010,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );
    }

    private static long lastWidgetUpdate = 0L;

    /** Actualiza sin respetar el límite de frecuencia (botón de refrescar, datos nuevos). */
    public static void forceUpdateAllWidgets(Context context) {
        synchronized (WidgetDataHelper.class) { lastWidgetUpdate = 0L; }
        updateAllWidgets(context);
    }

    public static void updateAllWidgets(Context context) {
        // Evita redibujar 4 widgets (bitmaps) varias veces seguidas (pausa, reanudación, sync JS).
        long nowMs = android.os.SystemClock.elapsedRealtime();
        synchronized (WidgetDataHelper.class) {
            if (lastWidgetUpdate != 0L && nowMs - lastWidgetUpdate < 15000L) return;
            lastWidgetUpdate = nowMs;
        }
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        if (manager == null) return;

        HeartbeatWidgetProvider.refresh(context);
        int[] mainIds = manager.getAppWidgetIds(new ComponentName(context, MainCounterWidgetProvider.class));
        if (mainIds != null && mainIds.length > 0) {
            MainCounterWidgetProvider.updateWidgets(context, manager, mainIds);
        }

        int[] achIds = manager.getAppWidgetIds(new ComponentName(context, AchievementsWidgetProvider.class));
        if (achIds != null && achIds.length > 0) {
            AchievementsWidgetProvider.updateWidgets(context, manager, achIds);
        }

        int[] evIds = manager.getAppWidgetIds(new ComponentName(context, EventsWidgetProvider.class));
        if (evIds != null && evIds.length > 0) {
            EventsWidgetProvider.updateWidgets(context, manager, evIds);
        }

        int[] stIds = manager.getAppWidgetIds(new ComponentName(context, StatsStreakWidgetProvider.class));
        if (stIds != null && stIds.length > 0) {
            StatsStreakWidgetProvider.updateWidgets(context, manager, stIds);
        }
    }

    public static boolean canRequestPinWidget(Context context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return false;
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        return manager != null && manager.isRequestPinAppWidgetSupported();
    }

    public static boolean requestPinWidget(Context context, String kind) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return false;
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        if (manager == null || !manager.isRequestPinAppWidgetSupported()) return false;

        Class<?> cls;
        if ("ach".equals(kind)) {
            cls = AchievementsWidgetProvider.class;
        } else if ("events".equals(kind)) {
            cls = EventsWidgetProvider.class;
        } else if ("heartbeat".equals(kind)) {
            cls = HeartbeatWidgetProvider.class;
        } else if ("stats".equals(kind)) {
            cls = StatsStreakWidgetProvider.class;
        } else {
            cls = MainCounterWidgetProvider.class;
        }
        try {
            return manager.requestPinAppWidget(new ComponentName(context, cls), null, null);
        } catch (Exception e) {
            return false;
        }
    }
}
