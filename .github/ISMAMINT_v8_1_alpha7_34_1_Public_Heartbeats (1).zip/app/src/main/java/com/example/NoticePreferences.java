package com.example;
import android.app.*;
import android.content.*;
import org.json.JSONObject;
/** Independent delivery preferences. Android channel controls remain authoritative. */
final class NoticePreferences {
 static final String RECEIPTS="ismamint_gift_receipts_v1";
 static android.content.SharedPreferences prefs(Context c){return c.getSharedPreferences("isma_notice_categories",Context.MODE_PRIVATE);}
 static boolean on(Context c,String key){return prefs(c).getBoolean(key,true);}
 static boolean allowed(Context c,String id){NotificationManager n=c.getSystemService(NotificationManager.class);if(n==null||!n.areNotificationsEnabled())return false;if(android.os.Build.VERSION.SDK_INT>=33&&c.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)!=android.content.pm.PackageManager.PERMISSION_GRANTED)return false;NotificationChannel ch=n.getNotificationChannel(id);return ch!=null&&ch.getImportance()!=NotificationManager.IMPORTANCE_NONE;}
 static void channels(Context c){NotificationManager n=c.getSystemService(NotificationManager.class);if(n==null)return;if(n.getNotificationChannel(RECEIPTS)==null){NotificationChannel ch=new NotificationChannel(RECEIPTS,"Regalos abiertos",NotificationManager.IMPORTANCE_DEFAULT);ch.enableVibration(true);ch.setVibrationPattern(new long[]{0,35,65,45});ch.setLockscreenVisibility(Notification.VISIBILITY_PRIVATE);n.createNotificationChannel(ch);}}
 static String options(Context c){ChatNotifications.ensureChannel(c);GiftNotifications.channel(c);channels(c);try{return new JSONObject().put("messages",ChatNotifications.enabled(c)).put("pulses",on(c,"pulses")).put("gifts",on(c,"gifts")).put("receipts",on(c,"receipts")).put("messagesAllowed",allowed(c,ChatNotifications.CHANNEL)).put("pulsesAllowed",allowed(c,ChatNotifications.PULSE_CHANNEL)).put("giftsAllowed",allowed(c,GiftNotifications.CHANNEL)).put("receiptsAllowed",allowed(c,RECEIPTS)).put("muted",ChatNotifications.muted(c)).toString();}catch(Exception e){return "{}";}}
 static void set(Context c,String key,boolean value){NotificationManager n=c.getSystemService(NotificationManager.class);if("messages".equals(key)){ChatNotifications.prefs(c).edit().putBoolean("enabled",value).apply();if(!value)ChatNotifications.clear(c);}else if("pulses".equals(key)||"gifts".equals(key)||"receipts".equals(key)){prefs(c).edit().putBoolean(key,value).apply();if(!value&&n!=null){if("pulses".equals(key))n.cancel(ChatNotifications.PULSE_NOTICE);else for(android.service.notification.StatusBarNotification item:n.getActiveNotifications()){String tag=item.getTag();if(tag!=null&&tag.startsWith("gifts".equals(key)?"gift:":"gift-open:"))n.cancel(tag,item.getId());}}}else return;ChatNotifications.schedule(c);GiftNotifications.schedule(c);}
}
