package com.example;

import android.Manifest;
import android.app.*;
import android.app.job.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.*;
import android.webkit.WebView;
import com.google.firebase.Timestamp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.*;
import java.util.*;

/** Independent gift inbox. Only metadata is observed; sealed payloads are never downloaded here. */
public final class GiftNotifications {
    static final String CHANNEL="ismamint_gifts_v1";
    private static final int JOB=38451;
    private final Activity activity;
    private final WebView web;
    private final Handler main=new Handler(Looper.getMainLooper());
    private final FirebaseAuth auth=FirebaseAuth.getInstance();
    private final FirebaseAuth.AuthStateListener authListener=a->attach();
    private ListenerRegistration listener, receiptsListener;
    private List<DocumentSnapshot> inbox=Collections.emptyList();
    private String account;
    private boolean active, loaded;
    private int generation;
    private static volatile boolean foreground;
    private final Runnable tick=new Runnable(){public void run(){if(!active)return;update();main.postDelayed(this,30000);}};
    GiftNotifications(Activity activity,WebView web){this.activity=activity;this.web=web;channel(activity);}
    static String uid(){return ChatNotifications.uid();}
    static Query query(String uid){String peer=ChatNotifications.A.equals(uid)?ChatNotifications.I:ChatNotifications.A;return FirebaseFirestore.getInstance().collection("ismamint_gifts").document(peer).collection("deliveries").whereEqualTo("opened",false);}
    static Query receiptQuery(String uid){return FirebaseFirestore.getInstance().collection("ismamint_gifts").document(uid).collection("deliveries").whereEqualTo("opened",true);}
    static boolean isForeground(){return foreground;}
    static void channel(Context c){NotificationManager n=c.getSystemService(NotificationManager.class);if(n!=null&&n.getNotificationChannel(CHANNEL)==null){NotificationChannel ch=new NotificationChannel(CHANNEL,"Regalos",NotificationManager.IMPORTANCE_HIGH);ch.enableVibration(true);ch.setVibrationPattern(new long[]{0,40,60,75});ch.setLockscreenVisibility(Notification.VISIBILITY_PRIVATE);n.createNotificationChannel(ch);}NoticePreferences.channels(c);}
    static void schedule(Context c){try{JobScheduler j=c.getSystemService(JobScheduler.class);if(j!=null&&uid()!=null&&j.getPendingJob(JOB)==null)j.schedule(new JobInfo.Builder(JOB,new ComponentName(c,GiftNotificationJob.class)).setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY).setPeriodic(15*60*1000L).setPersisted(true).build());}catch(RuntimeException e){android.util.Log.w("Ismamint","Gift schedule",e);}}
    static void catchup(Context c){String u=uid();if(u==null)return;try{JobScheduler j=c.getSystemService(JobScheduler.class);SharedPreferences p=c.getSharedPreferences("isma_gift_alerts",Context.MODE_PRIVATE);long now=System.currentTimeMillis();if(j!=null&&now-p.getLong(u+"_catchup",0)>=300000&&j.schedule(new JobInfo.Builder(JOB+10,new ComponentName(c,GiftNotificationJob.class)).setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY).setMinimumLatency(30000).build())==JobScheduler.RESULT_SUCCESS)p.edit().putLong(u+"_catchup",now).apply();}catch(RuntimeException ignored){}}
    void resume(){if(active)return;active=true;foreground=true;schedule(activity);auth.addAuthStateListener(authListener);main.post(tick);}
    void permissionChanged(){update();}
    void pause(){if(!active)return;active=false;foreground=false;auth.removeAuthStateListener(authListener);detach();main.removeCallbacks(tick);schedule(activity);catchup(activity);}
    private void detach(){generation++;if(listener!=null){listener.remove();listener=null;}if(receiptsListener!=null){receiptsListener.remove();receiptsListener=null;}inbox=Collections.emptyList();account=null;loaded=false;}
    private void attach(){detach();if(!active)return;String u=uid();NotificationManager nm=activity.getSystemService(NotificationManager.class);if(nm!=null)for(android.service.notification.StatusBarNotification n:nm.getActiveNotifications()){String tag=n.getTag();if(tag!=null&&(tag.startsWith("gift:")||tag.startsWith("gift-open:"))&&(u==null||!(tag.startsWith("gift:"+u+":")||tag.equals("gift-open:"+u))))nm.cancel(tag,n.getId());}signal();if(u==null)return;schedule(activity);account=u;int g=generation;receiptsListener=receiptQuery(u).addSnapshotListener(MetadataChanges.INCLUDE,(s,e)->{if(active&&g==generation&&u.equals(uid())&&e==null&&s!=null&&!s.getMetadata().isFromCache()&&!s.getMetadata().hasPendingWrites())consumeReceipts(activity,u,s.getDocuments());});listener=query(u).addSnapshotListener(MetadataChanges.INCLUDE,(s,e)->{if(!active||g!=generation||!u.equals(uid()))return;if(e!=null){android.util.Log.w("Ismamint","Gift inbox listener",e);signal();return;}if(s==null||s.getMetadata().isFromCache()||s.getMetadata().hasPendingWrites())return;inbox=s.getDocuments();loaded=true;update();});}
    private void signal(){if(active)web.evaluateJavascript("window.IsmaGiftArrival?.refresh()",null);}
    private void update(){if(!active||!loaded||account==null||!account.equals(uid()))return;consume(activity,account,inbox);askPermission();signal();}
    private void askPermission(){if(Build.VERSION.SDK_INT<33||activity.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)==PackageManager.PERMISSION_GRANTED)return;SharedPreferences p=activity.getSharedPreferences("isma_gift_alerts",Context.MODE_PRIVATE);if(p.getBoolean("permissionAsked",false)||ChatNotifications.prefs(activity).getBoolean("asked",false))return;long now=System.currentTimeMillis();for(DocumentSnapshot d:inbox){Timestamp r=d.getTimestamp("release");if(r!=null&&r.toDate().getTime()<=now&&account.equals(d.getString("recipient"))){p.edit().putBoolean("permissionAsked",true).apply();ChatNotifications.prefs(activity).edit().putBoolean("asked",true).apply();activity.requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},WebAppInterface.REQ_POST_NOTIFICATIONS);break;}}}
    static synchronized void consume(Context c,String u,List<DocumentSnapshot> docs){
        if(!u.equals(uid()))return;
        NotificationManager nm=c.getSystemService(NotificationManager.class);if(nm==null)return;channel(c);
        SharedPreferences p=c.getSharedPreferences("isma_gift_alerts",Context.MODE_PRIVATE);
        Set<String> seen=new HashSet<>(p.getStringSet(u,Collections.emptySet()));
        Set<String> remaining=new HashSet<>();List<DocumentSnapshot> fresh=new ArrayList<>();long now=System.currentTimeMillis();
        for(DocumentSnapshot d:docs){if(d.getMetadata().hasPendingWrites()||!u.equals(d.getString("recipient"))||Boolean.TRUE.equals(d.getBoolean("opened")))continue;remaining.add(d.getId());Timestamp r=d.getTimestamp("release");if(r!=null&&r.toDate().getTime()<=now&&!seen.contains(d.getId()))fresh.add(d);}
        // No pruning on partial/error results; only authoritative snapshots reach here.
        for(String id:new HashSet<>(seen))if(!remaining.contains(id)){nm.cancel("gift:"+u+":"+id,JOB);seen.remove(id);}
        if(!NoticePreferences.on(c,"gifts")){for(DocumentSnapshot d:fresh)seen.add(d.getId());p.edit().putStringSet(u,seen).commit();return;}
        if(!nm.areNotificationsEnabled()||(Build.VERSION.SDK_INT>=33&&c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)){p.edit().putStringSet(u,seen).apply();return;}
        NotificationChannel ch=nm.getNotificationChannel(CHANNEL);if(ch==null||ch.getImportance()==NotificationManager.IMPORTANCE_NONE){p.edit().putStringSet(u,seen).apply();return;}
        for(DocumentSnapshot d:fresh){String id=d.getId();String sender=ChatNotifications.A.equals(u)?"Ismael":"Aurora";Intent i=new Intent(c,MainActivity.class).putExtra("isma_open_gift",id).setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP).setData(android.net.Uri.parse("ismamint://gift/"+id));PendingIntent tap=PendingIntent.getActivity(c,JOB,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            Notification n=new Notification.Builder(c,CHANNEL).setSmallIcon(R.drawable.ic_notification).setContentTitle("Regalo de "+sender).setContentText("Tienes un regalo sin abrir").setContentIntent(tap).setAutoCancel(true).setVisibility(Notification.VISIBILITY_PRIVATE).setCategory(Notification.CATEGORY_MESSAGE).setColor(0xffee90b9).setPublicVersion(new Notification.Builder(c,CHANNEL).setSmallIcon(R.drawable.ic_notification).setContentTitle("ISMAMINT").setContentText("Regalo recibido").build()).build();
            try{nm.notify("gift:"+u+":"+id,JOB,n);seen.add(id);}catch(SecurityException ignored){}
        }
        p.edit().putStringSet(u,seen).commit();
    }
    /** Opened is monotonic in Firestore. First authoritative snapshot is a silent baseline. */
    static synchronized void consumeReceipts(Context c,String u,List<DocumentSnapshot> docs){
        if(!u.equals(uid()))return;
        SharedPreferences p=c.getSharedPreferences("isma_gift_receipts",Context.MODE_PRIVATE);
        boolean initial=!p.contains(u);Set<String> seen=new HashSet<>(p.getStringSet(u,Collections.emptySet()));
        List<String> fresh=new ArrayList<>();
        for(DocumentSnapshot d:docs){if(d.getMetadata().hasPendingWrites()||!Boolean.TRUE.equals(d.getBoolean("opened"))||u.equals(d.getString("recipient")))continue;if(seen.add(d.getId()))fresh.add(d.getId());}
        if(!p.edit().putStringSet(u,seen).commit()||initial||fresh.isEmpty()||!NoticePreferences.on(c,"receipts"))return;
        NoticePreferences.channels(c);if(!NoticePreferences.allowed(c,NoticePreferences.RECEIPTS))return;
        NotificationManager nm=c.getSystemService(NotificationManager.class);String peer=ChatNotifications.A.equals(u)?"Ismael":"Aurora";
        String title=peer+" abrió tu regalo",body=fresh.size()==1?"Tu regalo ya fue abierto":fresh.size()+" regalos abiertos";
        if(fresh.size()>1)title=peer+" abrió tus regalos";
        Notification n=new Notification.Builder(c,NoticePreferences.RECEIPTS).setSmallIcon(R.drawable.ic_notification).setContentTitle(title).setContentText(body).setContentIntent(WidgetDataHelper.createOpenTabPendingIntent(c,"p15",38452)).setVisibility(Notification.VISIBILITY_PRIVATE).setAutoCancel(true).setColor(0xffee90b9).setPublicVersion(new Notification.Builder(c,NoticePreferences.RECEIPTS).setSmallIcon(R.drawable.ic_notification).setContentTitle("ISMAMINT").setContentText("Regalo abierto").build()).build();
        try{nm.notify("gift-open:"+u,38452,n);}catch(SecurityException ignored){}
    }
}
