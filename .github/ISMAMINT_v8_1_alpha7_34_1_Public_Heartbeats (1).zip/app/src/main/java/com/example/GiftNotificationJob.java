package com.example;
import android.app.job.*;
import android.os.*;
import com.google.firebase.firestore.Source;
/** Best-effort background delivery checks, independent of chat settings. */
public final class GiftNotificationJob extends JobService {
 private JobParameters running;
 private final Handler main=new Handler(Looper.getMainLooper());
 private final Runnable timeout=()->finish(true);
 @Override public boolean onStartJob(JobParameters p){if(running!=null||GiftNotifications.isForeground())return false;try{String u=GiftNotifications.uid();if(u==null)return false;running=p;main.postDelayed(timeout,20000);GiftNotifications.query(u).get(Source.SERVER).addOnCompleteListener(t->{if(running!=p)return;if(t.isSuccessful()&&t.getResult()!=null){if(!GiftNotifications.isForeground()&&u.equals(GiftNotifications.uid()))GiftNotifications.consume(this,u,t.getResult().getDocuments());GiftNotifications.receiptQuery(u).get(Source.SERVER).addOnCompleteListener(q->{if(running!=p)return;if(q.isSuccessful()&&q.getResult()!=null){if(!GiftNotifications.isForeground()&&u.equals(GiftNotifications.uid()))GiftNotifications.consumeReceipts(this,u,q.getResult().getDocuments());finish(false);}else finish(true);});}else finish(true);});return true;}catch(RuntimeException e){running=null;main.removeCallbacks(timeout);return false;}}
 private void finish(boolean retry){JobParameters p=running;running=null;main.removeCallbacks(timeout);if(p!=null)jobFinished(p,retry);}
 @Override public boolean onStopJob(JobParameters p){if(running==p){running=null;main.removeCallbacks(timeout);}return !GiftNotifications.isForeground();}
}
