package com.example;

import android.Manifest;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;
import android.util.Base64;
import android.widget.Toast;

import java.io.OutputStream;

/** Guarda y comparte imágenes (data URL) desde el WebView. */
public final class ImageSaver {

    public static final int REQ_WRITE_STORAGE = 1002;

    private ImageSaver() {}

    private static byte[] decode(String dataUrl) {
        if (dataUrl == null) return null;
        int comma = dataUrl.indexOf(',');
        if (comma < 0 || !dataUrl.startsWith("data:image")) return null;
        try {
            return Base64.decode(dataUrl.substring(comma + 1), Base64.DEFAULT);
        } catch (IllegalArgumentException e) {
            return null;
        }
    }

    private static void toast(Activity a, String msg) {
        a.runOnUiThread(() -> Toast.makeText(a, msg, Toast.LENGTH_SHORT).show());
    }

    /** Guarda la imagen en la galería (Pictures/ISMAMINT). Devuelve el Uri o null. */
    public static Uri save(Activity activity, String dataUrl, String name) {
        byte[] bytes = decode(dataUrl);
        if (bytes == null) {
            toast(activity, "No se pudo leer la imagen");
            return null;
        }
        boolean gif=dataUrl.startsWith("data:image/gif;base64,");
        if(gif&&Build.VERSION.SDK_INT<29){toast(activity,"Guardar GIF requiere Android 10 o posterior");return null;}
        if(bytes.length>12_000_000)return null;
        String fileName = (name == null || name.trim().isEmpty() ? "ismamint" : name.replaceAll("[^a-zA-Z0-9._-]", ""));
        fileName=fileName.replaceFirst("(?i)\\.(png|gif)$", "");
        fileName = fileName + "-" + System.currentTimeMillis() + (gif?".gif":".png");
        ContentResolver resolver = activity.getContentResolver();
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                ContentValues values = new ContentValues();
                values.put(MediaStore.Images.Media.DISPLAY_NAME, fileName);
                values.put(MediaStore.Images.Media.MIME_TYPE, gif?"image/gif":"image/png");
                values.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/ISMAMINT");
                values.put(MediaStore.Images.Media.IS_PENDING, 1);
                Uri uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
                if (uri == null) throw new Exception("insert");
                try (OutputStream out = resolver.openOutputStream(uri)) {
                    if (out == null) throw new Exception("stream");
                    out.write(bytes);
                }
                values.clear();
                values.put(MediaStore.Images.Media.IS_PENDING, 0);
                resolver.update(uri, values, null, null);
                return uri;
            } else {
                if (activity.checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                        != PackageManager.PERMISSION_GRANTED) {
                    activity.runOnUiThread(() -> activity.requestPermissions(
                            new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQ_WRITE_STORAGE));
                    toast(activity, "Da el permiso y toca GUARDAR otra vez");
                    return null;
                }
                Bitmap bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                String path = MediaStore.Images.Media.insertImage(resolver, bmp, fileName, "ISMAMINT");
                return path != null ? Uri.parse(path) : null;
            }
        } catch (Exception e) {
            toast(activity, "No se pudo guardar la imagen");
            return null;
        }
    }

    /** Guarda un archivo de texto en Descargas. Devuelve true si se guardó. */
    public static boolean saveText(Activity activity, String name, String text) {
        String fileName = (name == null || name.trim().isEmpty() ? "ismamint-respaldo.json" : name.replaceAll("[^a-zA-Z0-9._-]", ""));
        try {
            byte[] bytes = text.getBytes("UTF-8");
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                ContentResolver resolver = activity.getContentResolver();
                ContentValues values = new ContentValues();
                values.put(MediaStore.Downloads.DISPLAY_NAME, fileName);
                values.put(MediaStore.Downloads.MIME_TYPE, "application/json");
                values.put(MediaStore.Downloads.RELATIVE_PATH, "Download");
                Uri uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                if (uri == null) throw new Exception("insert");
                try (OutputStream out = resolver.openOutputStream(uri)) {
                    if (out == null) throw new Exception("stream");
                    out.write(bytes);
                }
            } else {
                if (activity.checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                        != PackageManager.PERMISSION_GRANTED) {
                    activity.runOnUiThread(() -> activity.requestPermissions(
                            new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQ_WRITE_STORAGE));
                    toast(activity, "Da el permiso y toca EXPORTAR otra vez");
                    return false;
                }
                java.io.File dir = android.os.Environment.getExternalStoragePublicDirectory(
                        android.os.Environment.DIRECTORY_DOWNLOADS);
                //noinspection ResultOfMethodCallIgnored
                dir.mkdirs();
                try (java.io.FileOutputStream out = new java.io.FileOutputStream(new java.io.File(dir, fileName))) {
                    out.write(bytes);
                }
            }
            return true;
        } catch (Exception e) {
            toast(activity, "No se pudo guardar el respaldo");
            return false;
        }
    }

    public static void saveWithToast(Activity activity, String dataUrl, String name) {
        Uri uri = save(activity, dataUrl, name);
        if (uri != null) toast(activity, "Imagen guardada en la galería (Pictures/ISMAMINT)");
    }

    public static void share(Activity activity, String dataUrl, String name) {
        Uri uri = save(activity, dataUrl, name);
        if (uri == null) return;
        activity.runOnUiThread(() -> {
            try {
                Intent send = new Intent(Intent.ACTION_SEND);
                send.setType(dataUrl.startsWith("data:image/gif;base64,")?"image/gif":"image/png");
                send.putExtra(Intent.EXTRA_STREAM, uri);
                send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                activity.startActivity(Intent.createChooser(send, "Enviar con"));
            } catch (Exception e) {
                Toast.makeText(activity, "No se pudo compartir", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
