package com.example;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.RemoteViews;

public class MainCounterWidgetProvider extends AppWidgetProvider {

    private static final int PINK = 0xFFEE90B9;
    private static final int RED = 0xFFEE90B9;
    private static final int GOLD = 0xFFEBC65C;
    private static final int TEXT = 0xFFF0D5E5;
    private static final int DIM = 0xFFBDA0B4;

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        updateWidgets(context, appWidgetManager, appWidgetIds);
    }

    @Override
    public void onAppWidgetOptionsChanged(Context context, AppWidgetManager appWidgetManager,
                                          int appWidgetId, Bundle newOptions) {
        updateWidgets(context, appWidgetManager, new int[]{appWidgetId});
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        if (intent != null && WidgetDataHelper.ACTION_REFRESH_WIDGETS.equals(intent.getAction())) {
            WidgetDataHelper.forceUpdateAllWidgets(context);
        }
    }

    public static void updateWidgets(Context context, AppWidgetManager manager, int[] ids) {
        long now = System.currentTimeMillis();
        WidgetDataHelper.TimeBreakdown conoce = WidgetDataHelper.computeBreakdown(WidgetDataHelper.CONOCE_MS, now);
        WidgetDataHelper.TimeBreakdown juntos = WidgetDataHelper.computeBreakdown(WidgetDataHelper.JUNTOS_MS, now);
        String amoresStr = WidgetDataHelper.formatNumber(conoce.totalMs);
        String clockStr = WidgetDataHelper.formatClockLocal(now);
        String conoceDays = WidgetDataHelper.formatNumber(conoce.totalDays) + (conoce.totalDays == 1 ? " día" : " días");
        String juntosDays = WidgetDataHelper.formatNumber(juntos.totalDays) + (juntos.totalDays == 1 ? " día" : " días");

        BirthdayWidgetTheme birthday = BirthdayWidgetTheme.at(System.currentTimeMillis());
        for (int appWidgetId : ids) {
            int w = WidgetDataHelper.innerWidthPx(context, manager, appWidgetId);
            int cell = (w - PixelText.dp(context, 8)) / 2 - PixelText.dp(context, 12);

            RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_main_counter);
            birthday.apply(views, R.id.widget_main_root);

            PixelText.setWidget(views, R.id.widget_main_title, context, !birthday.edition.isEmpty() ? (w < PixelText.dp(context, 210) && birthday.edition.equals("Aurora Edition") ? "AURORA" : birthday.edition.toUpperCase(java.util.Locale.ROOT)) : (w < PixelText.dp(context, 210) ? "AURORA" : "FUNCIÓN AURORA"), PixelText.TITLE, 8, birthday.accent, w / 2);
            PixelText.setWidget(views, R.id.widget_main_updated, context, clockStr, PixelText.BODY, 15, birthday.dim, w / 4);

            PixelText.fitWidget(views, R.id.widget_main_ms, context, amoresStr, PixelText.BODY, 30, 16, birthday.secondary, w);
            PixelText.setWidget(views, R.id.widget_main_ms_label, context, "+1 amor/ms · desde 11/09/2025",
                    PixelText.BODY, 15, birthday.text, w);

            PixelText.setWidget(views, R.id.widget_main_conoce_label, context, "NOS CONOCEMOS", PixelText.TITLE, 7, birthday.accent, cell);
            PixelText.fitWidget(views, R.id.widget_main_conoce_days, context, conoceDays, PixelText.BODY, 24, 16, birthday.secondary, cell);
            PixelText.setWidget(views, R.id.widget_main_conoce_detail, context, conoce.formatCompactYmd(),
                    PixelText.BODY, 15, birthday.text, cell);

            PixelText.setWidget(views, R.id.widget_main_juntos_label, context, "JUNTOS", PixelText.TITLE, 7, birthday.accent, cell);
            PixelText.fitWidget(views, R.id.widget_main_juntos_days, context, juntosDays, PixelText.BODY, 24, 16, birthday.accent, cell);
            PixelText.setWidget(views, R.id.widget_main_juntos_detail, context, juntos.formatCompactYmd(),
                    PixelText.BODY, 15, birthday.text, cell);

            views.setOnClickPendingIntent(R.id.widget_main_root,
                    WidgetDataHelper.createOpenTabPendingIntent(context, "p1", 6001));
            views.setOnClickPendingIntent(R.id.widget_main_refresh,
                    WidgetDataHelper.createRefreshPendingIntent(context));

            manager.updateAppWidget(appWidgetId, views);
        }
    }
}
