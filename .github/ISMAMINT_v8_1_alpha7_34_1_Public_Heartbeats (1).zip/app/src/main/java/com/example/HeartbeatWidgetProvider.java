package com.example;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.widget.RemoteViews;
public final class HeartbeatWidgetProvider extends AppWidgetProvider {
    @Override public void onAppWidgetOptionsChanged(Context c,AppWidgetManager m,int id,android.os.Bundle options){onUpdate(c,m,new int[]{id});}
    static void refresh(Context c){AppWidgetManager m=AppWidgetManager.getInstance(c);if(m!=null)new HeartbeatWidgetProvider().onUpdate(c,m,m.getAppWidgetIds(new android.content.ComponentName(c,HeartbeatWidgetProvider.class)));}
    @Override public void onUpdate(Context c,AppWidgetManager m,int[] ids){for(int id:ids){RemoteViews v=new RemoteViews(c.getPackageName(),R.layout.widget_heartbeat);BirthdayWidgetTheme t=BirthdayWidgetTheme.at(System.currentTimeMillis());t.apply(v,R.id.widget_heartbeat_root);v.setTextColor(R.id.widget_heartbeat_title,t.secondary);v.setTextColor(R.id.widget_heartbeat_label,t.text);String u=ChatNotifications.uid();v.setTextViewText(R.id.widget_heartbeat_label,u==null?"Abrir Ismamint":"Enviar latido");v.setOnClickPendingIntent(R.id.widget_heartbeat_root,u==null?WidgetDataHelper.createOpenTabPendingIntent(c,"p10",6005):HeartbeatActions.intent(c,u,"widget"+id,false,true));m.updateAppWidget(id,v);}}
}
