package com.example;
import android.content.Context;
import android.os.*;
import android.media.AudioAttributes;
/** Bounded, device-aware waveforms. No foreground service or persistent wake lock. */
final class TactileEngine {
 static Vibrator vibrator(Context c){if(Build.VERSION.SDK_INT>=31){VibratorManager m=c.getSystemService(VibratorManager.class);return m==null?null:m.getDefaultVibrator();}return (Vibrator)c.getSystemService(Context.VIBRATOR_SERVICE);}
 static void replay(Context c,long[] intervals){long[] d;if(intervals==null)d=new long[]{0,65,110,45};else{d=new long[intervals.length*2];for(int i=0;i<intervals.length;i++){d[i*2]=i==0?0:Math.max(0,intervals[i]-45);d[i*2+1]=45;}}play(c,d,true);}
 static void play(Context c,long[] d,boolean notification){Vibrator v=vibrator(c);if(v==null||!v.hasVibrator()||d==null||d.length<2||d.length>64)return;long sum=0;int[] amps=new int[d.length];for(int i=0;i<d.length;i++){if(d[i]<0||d[i]>8000)return;sum+=d[i];amps[i]=i%2==0?0:(i==1?210:i==3?135:175);}if(sum<=0||sum>8500)return;try{VibrationEffect e=v.hasAmplitudeControl()?VibrationEffect.createWaveform(d,amps,-1):VibrationEffect.createWaveform(d,-1);if(notification){AudioAttributes attr=new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION).build();v.vibrate(e,attr);}else v.vibrate(e);}catch(RuntimeException ignored){}}
}
