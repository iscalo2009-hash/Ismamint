/* Pure cosmetic catalogue. Physics never reads this module. */
(function(root){'use strict';
const heart=['01100110','11111111','11111111','11111111','01111110','00111100','00011000'];
const skins=[
 ['origin','Origen','#ff6385','#ffd0dd',0,'Disponible desde el inicio',heart,'spark'],
 ['mint','Menta','#77e4be','#d9fff1',0,'Supera el primer mundo',['01100110','12211221','12211221','11111111','01122110','00122100','00011000'],'leaf'],
 ['crystal','Prisma','#9edfff','#f3fdff',0,'Alcanza el nivel 11',['00011000','00122100','01211210','12122121','01211210','00122100','00011000'],'shard'],
 ['twin','Vínculo','#ee90b9','#ebc65c',0,'Alcanza el nivel 16',['01100220','11112222','11112222','11112222','01112220','00112200','00012000'],'twin'],
 ['ember','Ascua','#ff7652','#ffd36e',0,'Alcanza el nivel 21',['00010000','00110100','01111110','11211211','11222211','01122110','00111100'],'ember'],
 ['ghost','Espectro','#b4b9e7','#ffffff',0,'Recoge 150 corazones',['00111100','01111110','11211211','11211211','11111111','11011011','10010001'],'ghost'],
 ['orbit','Satélite','#b28bff','#e8d8ff',0,'Completa 12 oleadas perfectas',['00011000','00122100','01122110','11211211','01122110','00122100','00011000'],'orbit'],
 ['guardian','Centinela','#78deab','#f6e4a6',0,'Consigue 20 parries',['11111111','12222221','12111121','12122121','01222210','00122100','00011000'],'shield'],
 ['beat','Frecuencia','#ebc65c','#fff0b5',0,'Consigue 30 resonancias',['01100110','11111111','11211111','11212121','01121210','00111100','00011000'],'beat'],
 ['eclipse','Eclipse','#9d8cdb','#f5b366',0,'Alcanza el nivel 36',['00111100','01122210','11221111','11211111','11221111','01122210','00111100'],'orbit'],
 ['crown','Soberano','#edbd64','#fff2ca',0,'Derrota a 10 jefes',['10011001','11011011','11111111','12222221','01122110','00111100','00011000'],'crown'],
 ['nova','Supernova','#ff83cf','#a9efff',0,'Alcanza el nivel 76',['10011001','01122110','01122110','12211221','12211221','01122110','10011001'],'shard'],
 ['infinity','Infinito','#edb7ff','#7af2d8',0,'Alcanza el nivel 151',['01100110','12211221','12122121','11211211','12122121','12211221','01100110'],'twin']
].map(([id,name,color,accent,_,hint,rows,effect])=>({id,name,color,accent,hint,rows,effect}));
const rules=[()=>true,p=>p.max>=6,p=>p.max>=11,p=>p.max>=16,p=>p.max>=21,p=>p.hearts>=150,p=>p.clean>=12,p=>p.parries>=20,p=>p.resonances>=30,p=>p.max>=36,p=>p.bosses>=10,p=>p.max>=76,p=>p.max>=151];
const legacy=['origin','mint','crystal','nova','ghost','crown','guardian','eclipse','infinity'];
function reconcile(p={},previous={}){let owned=new Set(Array.isArray(previous.owned)?previous.owned.filter(id=>skins.some(s=>s.id===id)):[]);owned.add('origin');rules.forEach((r,i)=>{if(r(p))owned.add(skins[i].id);});for(const n of p.legacyUnlocked||[])if(legacy[n])owned.add(legacy[n]);const selected=owned.has(previous.selected)?previous.selected:owned.has(legacy[p.legacySelected])?legacy[p.legacySelected]:'origin';return {selected,owned:[...owned]};}
function get(id){return skins.find(s=>s.id===id)||skins[0];}
const api={skins,reconcile,get};if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.HeartboundSkins=api;
})(typeof window!=='undefined'?window:globalThis);
