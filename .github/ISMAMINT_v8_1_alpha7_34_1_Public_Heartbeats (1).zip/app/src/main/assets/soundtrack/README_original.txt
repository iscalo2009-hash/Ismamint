
la primera cancion tiene paréntesis especial, cuando pone se agrego a la playlist es que no tengo claro cuando nos la dedicamos, y las que no ponen nada ponen las fechas en que se dedicaron



cuando te dije esclava vi el futuro 5 oct 2026 — Ismael | Autor: Bryant Myers, Anuel AA, Anonimus, Almighty | Nombre: Esclava - Remix
3 nov 2025 — Ismael | Autor: d4vd | Nombre: Feel It (From “Invincible”)
15 nov 2025 — Ismael | Autor: Trueno | Nombre: SOLO POR VOS
22 nov 2025 — Ismael | Autor: Arcángel | Nombre: Hace Mucho Tiempo
se agrego a la playlist 29 nov 2025 — Ismael | Autor: Milo j, Bhavi | Nombre: OJALA
se agrego a la playlist 29 nov 2025 — Aurora | Autor: Doja Cat | Nombre: Can't Wait
se agrego a la playlist 29 nov 2025 — Aurora | Autor: Doja Cat | Nombre: Agora Hills
se agrego a la playlist 29 nov 2025 — Aurora | Autor: Sia, Diplo, Labrinth, LSD | Nombre: Mountains
se agrego a la playlist 29 nov 2025 — Aurora | Autor: Billie Eilish | Nombre: hostage
se agrego a la playlist 29 nov 2025 — Ismael | Autor: Blessd, Kris R., Young Fatty, TURY, CARABIN3 | Nombre: MIU MIU (feat. GeezyDee, CARABIN3)
2 dic 2025 — Ismael | Autor: Metro Boomin, Swae Lee, NAV, A Boogie Wit da Hoodie | Nombre: Calling (Spider-Man: Across the Spider-Verse)
4 dic 2025 — Aurora | Autor: Doja Cat | Nombre: Cyber Sex
10 dic 2025 — Ismael | Autor: Kris R., Prodmonja | Nombre: BLANQUITA
24 dic 2025 — Ismael | Autor: Blessd, Kris R. | Nombre: POLOS OPUESTOS REMIX - BLESSD VERSION
5 ene 2026 — Ismael | Autor: Duki | Nombre: Si Me Sobrara el Tiempo
14 feb 2026 — Ismael | Autor: Blessd | Nombre: Una
14 feb 2026 — Aurora | Autor: Billie Eilish | Nombre: Halley's Comet
1 mar 2026 — Ismael | Autor: Skillet | Nombre: Comatose
8 mar 2026 — Aurora | Autor: Bad Bunny | Nombre: A Tu Merced
8 mar 2026 — Aurora | Autor: Arroba Nat | Nombre: Apapáchame
8 mar 2026 — Ismael | Autor: Kris R., Prodmonja, Los Money Makers | Nombre: MIL D AURA
10 mar 2026 — Aurora | Autor: La Quinta Estacion | Nombre: Algo Más
13 mar 2026 — Ismael | Autor: Kodigo 36 | Nombre: Se Me Antoja
15 mar 2026 — Aurora | Autor: Oasis | Nombre: Wonderwall - Remastered
15 mar 2026 — Ismael | Autor: Bon Jovi | Nombre: Born To Be My Baby
15 mar 2026 — Aurora | Autor: TWICE | Nombre: The Feels
15 mar 2026 — Ismael | Autor: Adolescent's Orquesta | Nombre: Anhelo
15 mar 2026 — Ismael | Autor: Goose house | Nombre: 光るなら
18 mar 2026 — Aurora | Autor: Doja Cat | Nombre: Need to Know
7 abr 2026 — Aurora | Autor: Chevy | Nombre: Sweet Boi
7 abr 2026 — Aurora | Autor: Mon Laferte | Nombre: Amor Completo
15 abr 2026 — Ismael | Autor: Ethan Fields | Nombre: Cooler Than Me
23 abr 2026 — Ismael | Autor: Plan B | Nombre: Fanática Sensual
27 abr 2026 — Aurora | Autor: NATTI NATASHA, Ozuna | Nombre: Criminal
1 may 2026 — Ismael | Autor: Natanael Cano | Nombre: Mi Bello Angel
3 may 2026 — Ismael | Autor: Coldplay | Nombre: Yellow
11 may 2026 — Ismael | Autor: Milo j | Nombre: Tus Vueltas
14 may 2026 — Ismael | Autor: Michael Jackson | Nombre: You Rock My World
9 jun 2026 — Aurora | Autor: Billie Eilish | Nombre: Billie Bossa Nova
9 jun 2026 — Aurora | Autor: Doja Cat | Nombre: Stranger
9 jun 2026 — Aurora | Autor: Doja Cat | Nombre: Freak
15 jun 2026 — Ismael | Autor: Frank Sinatra, Count Basie | Nombre: Fly Me To The Moon - 2008 Remastered
17 jun 2026 — Aurora | Autor: Yuna | Nombre: Deeper Conversation
19 jun 2026 — Ismael | Autor: Blessd, Juhn, Fronti, TURY, Tutu | Nombre: ALO (feat. Tutu)
28 jun 2026 — Aurora | Autor: Carla Morrison | Nombre: Disfruto
3 jul 2026 — Ismael | Autor: Aerosmith | Nombre: I Don't Want to Miss a Thing - From "Armageddon" Soundtrack
21 ago 2026 — Ismael | Autor: Michael Jackson | Nombre: P.Y.T. (Pretty Young Thing)
30 ago 2026 — Ismael | Autor: Sergi | Nombre: Dopamina
16 sept 2026 — Ismael | Autor: Milo j, Yami Safdie | Nombre: CARENCIAS DE CORDURA
19 sept 2026 — Aurora | Autor: Mon Laferte | Nombre: Química Mayor
19 sept 2026 — Aurora | Autor: Cuco | Nombre: Lo Que Siento
4 oct 2026 — Aurora | Autor: Luvcat | Nombre: He's My Man
24 oct 2026 — Aurora | Autor: EME-15 | Nombre: El Mapa De Mi Interior - Remastered 2025
3 nov 2026 — Aurora | Autor: Valeria Jasso | Nombre: Tú y Yo
11 nov 2026 — Ismael | Autor: Jamie Paige | Nombre: Machine Love