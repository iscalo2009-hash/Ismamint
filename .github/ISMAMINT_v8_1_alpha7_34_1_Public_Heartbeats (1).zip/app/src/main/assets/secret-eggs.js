(function(root){'use strict';
const definitions=Object.freeze([
 {id:'egg_four',name:'El cuarto latido',hint:'El corazón también sabe contar.',condition:'Toca cuatro veces el corazón de Inicio en un máximo de 2,4 segundos, sin pausas de más de 600 ms.'},
 {id:'egg_echo',name:'Eco de cuatro',hint:'Un latido puede responder a otro.',condition:'Haz dos series de cuatro toques en el corazón, con una pausa de 900 a 2200 ms entre series.'},
 {id:'egg_machine',name:'Latido digital',hint:'Una máquina también puede seguir el compás.',condition:'Haz cuatro toques en el corazón de Inicio mientras suena Machine Love.'},
 {id:'egg_yellow',name:'Latido dorado',hint:'Hay una canción que ilumina el corazón.',condition:'Haz cuatro toques en el corazón de Inicio mientras suena Yellow.'},
 {id:'egg_complete',name:'Constelación oculta',hint:'Cuatro pequeños descubrimientos.',condition:'Desbloquea los cuatro secretos de interacción anteriores.'}
]);
function create(onFind){let taps=[],lastGroup=-Infinity;function reset(){taps=[];lastGroup=-Infinity;}function tap(now,song){if(!Number.isFinite(now))return;if(taps.length&&(now<taps.at(-1).at||now-taps.at(-1).at>600))taps=[];taps.push({at:now,song});if(taps.length<4)return;const first=taps[0].at,span=now-first;if(span<=2400){onFind('egg_four');if(first-lastGroup>=900&&first-lastGroup<=2200)onFind('egg_echo');if(taps.every(t=>t.song==='s55'))onFind('egg_machine');if(taps.every(t=>t.song==='s36'))onFind('egg_yellow');lastGroup=now;}taps=[];}return {tap,reset};}
const api={definitions,create};if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.IsmaSecretEggs=api;
})(typeof window!=='undefined'?window:globalThis);
