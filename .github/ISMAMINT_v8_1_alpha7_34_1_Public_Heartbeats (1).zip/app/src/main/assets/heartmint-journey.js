/* Heartmint Journey: local, constant-size checkpoint and deterministic encounter plans. */
(function(root){'use strict';
const KEY='heartmint_journey_v1', zones=[['ÓRBITA','#15112d','#a691ff'],['NEBULOSA','#30112e','#ee90b9'],['AURORA','#102b32','#72e4d5'],['ECLIPSE','#30201a','#ebc65c'],['CRISTAL','#132537','#7ce5ff'],['ABISMO','#19142d','#b18afa'],['COMETA','#34221c','#ffc080'],['CONSTELACIÓN','#182b27','#8ce4aa']];
const prefixes=['','Órbita','Nebulosa','Aurora','Eclipse','Cristal','Abismo','Cometa','Constelación'];
const weapons=[{id:'bolt',name:'Chispa',level:1,cd:40,damage:2,color:'#ffd34d',desc:'Disparo preciso y rápido'},{id:'fan',name:'Tridente',level:6,cd:65,damage:3,color:'#72e4d5',desc:'Tres rayos, amplio alcance'},{id:'beam',name:'Rayo',level:11,cd:85,damage:5,color:'#a691ff',desc:'Haz concentrado, daño alto'},{id:'nova',name:'Nova',level:21,cd:115,damage:5,color:'#ff83be',desc:'Explosión que limpia peligros'},{id:'echo',name:'Eco',level:51,cd:68,damage:4,color:'#82cfff',desc:'Doble disparo amplio'}];
const items=[
 {id:'heal',name:'Botiquín',level:1,max:2,color:'#7af3a3',desc:'Recupera 2 vidas'},
 {id:'barrier',name:'Barrera',level:6,max:2,color:'#7dffe8',desc:'Escudo y 1 segundo de invulnerabilidad'},
 {id:'freeze',name:'Crono',level:11,max:2,color:'#b388ff',desc:'Ralentiza el combate durante 5 s'},
 {id:'bomb',name:'Estallido',level:16,max:1,color:'#ffad69',desc:'Limpia peligros y daña al jefe'},
 {id:'battery',name:'Batería',level:21,max:2,color:'#ffe16b',desc:'Carga el pulso al 100%'},
 {id:'overdrive',name:'Sobrecarga',level:31,max:1,color:'#ff6f9d',desc:'Disparos más rápidos y fuertes durante 6 s'},
 {id:'magnet',name:'Atracción',level:41,max:2,color:'#69c8ff',desc:'Imán y plataforma ancha durante 6 s'},
 {id:'prism',name:'Prisma',level:51,max:1,color:'#d9a5ff',desc:'Cancela amenazas y daña al jefe un 9% (máx. 24)'}];
const perks=[
 {id:'wide',name:'Amplitud',level:1,desc:'Mayor alcance de recogida',cap:3}, {id:'charge',name:'Energía',level:1,desc:'Carga más rápida del pulso',cap:12}, {id:'guard',name:'Protección',level:1,desc:'Escudo, vida e invulnerabilidad',cap:12}, {id:'rapid',name:'Cadencia',level:6,desc:'Reduce recarga del arma',cap:12}, {id:'magnet',name:'Atracción',level:6,desc:'Imán pasivo de corazones',cap:12},
 {id:'power',name:'Potencia',level:11,desc:'Daño adicional del arma',cap:8}, {id:'agility',name:'Agilidad',level:16,desc:'Impulso se recarga antes',cap:8}, {id:'fortune',name:'Fortuna',level:21,desc:'Más corazones dorados',cap:8}, {id:'supply',name:'Reserva',level:31,desc:'Recarga objetos al derrotar jefes',cap:2}, {id:'focus',name:'Concentración',level:41,desc:'Mayor ventana de daño doble',cap:8}, {id:'recovery',name:'Resistencia',level:51,desc:'Conserva el combo al fallar más corazones',cap:3}];
function cleanPerks(p={}){return Object.fromEntries(perks.map(k=>[k.id,Math.max(0,Math.min(k.cap,Math.floor(Number(p?.[k.id])||0)))]));}
function loadout(ids,max){const a=Array.isArray(ids)?ids:[],valid=id=>items.some(x=>x.id===id&&x.level<=max);const first=valid(a[0])?a[0]:'heal';return [first,valid(a[1])&&a[1]!==first?a[1]:null];}
function rewards(n,seed,p){const pool=perks.filter(k=>k.level<=n&&(p[k.id]||0)<k.cap);const sorted=pool.sort((a,b)=>hash(seed^hash(n)^hash(perks.indexOf(a)+71))-hash(seed^hash(n)^hash(perks.indexOf(b)+71)));const out=sorted.slice(0,3).map(k=>k.id);if(out.length<3)out.push('restock');return out;}
const enemies={drifter:{name:'Errante',color:'#ff85bd',hp:1,sprite:['0011100','0111110','1121211','1111111','0101010']},hunter:{name:'Acechador',color:'#ff985a',hp:2,sprite:['1000001','0111110','1121211','0111110','0010100']},turret:{name:'Centinela',color:'#b9a1ff',hp:2,sprite:['0011100','0112110','1111111','0011100','0011100']},splitter:{name:'Fragmento',color:'#70d9ff',hp:2,sprite:['0010100','0110110','1210121','0110110','0010100']},mine:{name:'Mina',color:'#f5a75c',hp:1,sprite:['0010100','0111110','1121211','0111110','0010100']}};
function hash(n){n>>>=0;n=Math.imul(n^(n>>>16),0x21f0aaad);n=Math.imul(n^(n>>>15),0x735a2d97);return (n^(n>>>15))>>>0;}
const stage=n=>Math.max(1,Math.min(Number.MAX_SAFE_INTEGER-10,Math.floor(Number(n)||1))),world=n=>Math.floor((stage(n)-1)/5)+1,entry=w=>stage((stage(w)-1)*5+1);
const worldNames=['VÉRTICE','PRISMA','PULSAR','UMBRAL','MAREA','ESPEJO','VÓRTICE','ESTELA','ALBOR','HORIZONTE','SANTUARIO','TRÁNSITO','NEXO','ECO','ÓRBITA','NEBULOSA'];
const worldTones=['CARMESÍ','LUNAR','DORADO','SILENTE','IRIDISCENTE','GLACIAL','ELÉCTRICO','VIOLETA','NOCTURNO','CELESTE','ESMERALDA','AMBARINO'];
function zone(n){const w=world(n),z=zones[(w-1)%zones.length],h=hash(hash(w)^hash(Math.floor(w/4294967296))^311),hue=h%360;return {n:w<=8?z[0]:worldNames[h%worldNames.length]+' '+worldTones[(h>>>8)%worldTones.length]+' · '+w,c:w<=8?z[1]:`hsl(${hue},32%,13%)`,a:w<=8?z[2]:`hsl(${hue},78%,72%)`,world:w,style:w<=8?(w-1)%5:(h>>>16)%8,seed:h};}
// A bounded learning curve; level numbers remain unbounded. All times in simulation frames.
const unlocks={fire:3,pulse:4,heal:6,dash:7,wall:8,arena:9,blue:12,orange:16};
const lessons=[
 [1,'Recoge corazones','Desliza el dedo sobre el tablero para moverte. Atrapa corazones para avanzar antes; sobrevivir también suma progreso.'],
 [2,'Primer peligro','Esquiva las cruces. Los avisos te indican dónde aparecerá un ataque.'],
 [3,'Arma y enemigos','Los disparos automáticos destruyen enemigos cercanos. También puedes pulsar FUEGO. Muévete para apuntar.'],
 [4,'Pulso','Recoge corazones para cargar el pulso. Al 100%, cancela peligros y daña al jefe. Los corazones convertidos no recargan el pulso.'],
 [5,'Primer jefe','Esquiva las oleadas; los disparos no las destruyen. Ataca al jefe y recoge corazones. Cuando se proteja, supera su patrón; las esquivas perfectas también lo dañan.'],
 [6,'Objetos y fallos','Usa el botiquín para recuperar vidas. Los corazones perdidos afectan al combo, no a tu vida. Tridente y Barrera se equipan automáticamente.'],
 [7,'Impulso','Pulsa IMPULSO para moverte más rápido y esquivar con invulnerabilidad breve.'],
 [8,'Muros y rotores','Busca el hueco verde antes de que caiga el muro. Los rotores se mueven de lado a lado.'],
 [9,'Ataques de arena','Las zonas de color avisan antes de activarse. Sitúa el núcleo blanco de la plataforma en el corredor verde.'],
 [11,'Centinelas y armadura','Los centinelas disparan tras un aviso. Rayo y Crono se desbloquean. Ataca a los jefes con armadura cuando sean vulnerables.'],
 [12,'Ataque azul','AZUL: si estás dentro de la zona peligrosa, no te muevas. Fuera de ella puedes moverte libremente.'],
 [13,'Lanzas','Las lanzas aceleran al caer. Esquívalas pronto o destrúyelas con tu arma.'],
 [16,'Ataque naranja','NARANJA: muévete dentro de la zona peligrosa o busca el corredor verde. Se desbloquea Estallido. Los fragmentos disparan dos veces.'],
 [18,'Anillos','Los anillos oscilan mientras caen. Anticipa su trayectoria.'],
 [21,'Minas y combinaciones','Las minas aceleran y disparan. Nova y Batería se desbloquean. Las mejoras de jefe se aplican solas. Guarda objetos para las fases difíciles.'],
 [31,'Sobrecarga','Sobrecarga aumenta temporalmente el daño y la cadencia. Puedes usarla desde el cinturón de objetos.'],
 [41,'Atracción','El objeto Atracción activa el imán y ensancha la plataforma. Concentración amplía la vulnerabilidad de los jefes.'],
 [51,'Eco y Prisma','Eco dispara a varios objetivos. Prisma cancela amenazas y daña al jefe; tiene una carga por intento.']
].map(([level,title,body])=>({level,title,body}));
function enabled(n,id){return stage(n)>=(unlocks[id]||1);}
function difficulty(n){n=stage(n);const t=1-Math.exp(-(n-1)/70),early=1-Math.exp(-(n-1)/18);return {t,fall:2.25+1.85*t+.35*early,interval:Math.max(13,24-8*t-3*early),hazard:n<2?0:.09+.18*t,cap:n<3?1:n<8?2:n<16?3:n<30?4:5+Math.floor(t*2),enemies:n<3?0:n<11?1:n<25?2:3,enemyInterval:Math.round(250-115*t-35*early),eventInterval:Math.round(360-135*t-65*early),wallGap:n<20?4:3,misses:n<6?Infinity:n<16?5:4,bossHp:Math.round(48+118*(1-Math.exp(-Math.floor(n/5)/14)))};}
function arenaTypes(n){n=stage(n);return n<9?[]:n<12?[0,1,4]:n<16?[0,1,2,3,4,5]:n<21?[0,1,2,3,4,5,6,7]:[0,1,2,3,4,5,6,7,8,9];}
function pickups(n){return (n>=4?'p':'')+(n>=6?'smi':'')+(n>=8?'w':'')+(n>=10?'tqj':'')+(n>=12?'k':'')+(n>=16?'u':'');}
function bossHealth(n,raw){const fixed=[66,78,90,99,108,103,100,107,114,145];return n<=10?fixed[n-1]:Math.min(166,Math.max(108,Math.round(78+raw*.35+26*(1-Math.exp(-n/45)))));}
function target(n){return 9+Math.min(4,Math.floor(Math.log2(stage(n))/2))+(stage(n)%5===4?1:0);}
// A world is an authored/procedural sequence of encounters, not a boss timer.
// Timings are local safety gates and a recovery fallback; objectives drive progression.
const beats={
 gather:{name:'Recogida',goal:'hearts',unit:'corazones',event:1.25,enemy:1.3,hazard:.72},
 hunt:{name:'Cacería',goal:'kills',unit:'enemigos',event:1.35,enemy:.60,hazard:.85},
 evade:{name:'Evasión',goal:'clears',unit:'oleadas',event:.64,enemy:1.5,hazard:.80},
 rush:{name:'Resistencia',goal:'time',unit:'s',event:.78,enemy:.85,hazard:1},
 mix:{name:'Desafío',goal:'points',unit:'progreso',event:.90,enemy:.92,hazard:1},
 rest:{name:'Respiro',goal:'hearts',unit:'corazones',event:1.7,enemy:2.5,hazard:.12}
};
// Each entry describes the four encounters leading to the fixed boss milestone.
const authored=[
 [['gather',10,15],['gather',11,16],['hunt',14,23],['mix',15,24]],
 [['mix',14,25],['hunt',19,31],['evade',20,34],['evade',23,38]],
 [['rest',10,16],['evade',24,38],['hunt',17,29],['rush',25,33]],
 [['evade',18,30],['rush',26,35],['mix',20,34],['hunt',23,38]],
 [['hunt',21,35],['mix',23,38],['evade',26,42],['rush',28,36]],
 [['rest',10,18],['hunt',16,28],['mix',18,30],['evade',20,34]],
 [['hunt',10,19],['rush',12,19],['hunt',11,20],['mix',12,21]],
 [['evade',15,26],['rest',9,15],['evade',18,30],['mix',15,26]],
 [['rush',15,22],['hunt',17,27],['rush',18,25],['evade',20,31]],
 [['mix',23,38],['hunt',26,42],['evade',30,46],['rush',30,38]]
];
const routes=[['rest','gather','hunt','mix'],['hunt','hunt','evade','rush'],['evade','mix','evade','rush'],['gather','rush','hunt','evade'],['rush','rest','rush','mix'],['mix','hunt','evade','mix']];
function encounter(n,seed=0){n=stage(n);const w=world(n),slot=(n-1)%5,h=hash(hash(seed)^hash(w)^hash(Math.floor(w/4294967296))^0x35bc7),v=hash(h^hash(slot+43));if(slot===4)return {kind:'boss',name:'Jefe',goal:'points',required:1,min:0,max:0,event:1,enemy:1,hazard:1};let spec=authored[w-1]?.[slot];if(!spec){const style=(w+((h>>>8)%3))%routes.length,route=routes[style],kind=route[slot],lo=kind==='rest'?9:kind==='gather'?12:kind==='evade'?19:kind==='rush'?20:17;const min=style===0?10+v%5:style===2?Math.min(36,lo+8+v%9):lo+v%10+((h>>>20)%5),max=min+(kind==='rush'?7:10+(v>>>12)%10);spec=[kind,min,max];}const [kind,baseMin,baseMax]=spec,b=beats[kind];const scale=w<=10?[1.40,1.48,1.52,1.55,1.60,1.60,1.48,1.53,1.58,1.65][w-1]:1.40+((h>>>13)%31)/100+.12*(1-Math.exp(-(w-10)/35));const min=Math.round(baseMin*scale),max=min+Math.min(24,Math.max(8,Math.round((baseMax-baseMin)*1.25)));const required=b.goal==='hearts'?Math.max(6,Math.round(min*.65)):b.goal==='kills'?Math.min(5,Math.max(2,Math.round(min/7))):b.goal==='clears'?Math.min(3,Math.max(1,Math.round(min/11))):b.goal==='time'?min:Math.min(24,Math.round(min*.9));return {kind,...b,required,min:min*60,max:max*60};}
function value(e,c,age){return e.goal==='time'?age/60:Number(c?.[e.goal])||0;}
function minStageFrames(n,seed=0){return encounter(n,seed).min;}
function maxStageFrames(n,seed=0){return encounter(n,seed).max;}
function ready(n,c,age,seed=0,e=encounter(n,seed)){return e.kind!=='boss'&&age>=e.min&&(value(e,c,age)>=e.required||age>=e.max);}
function closing(n,c,age,seed=0,e=encounter(n,seed)){return (e.goal==='time'&&age>=e.min-300)||age>=e.max-300||(value(e,c,age)>=e.required&&age>=e.min-180);}
function meter(n,c,age,seed=0,e=encounter(n,seed)){return e.kind==='boss'?0:Math.min(1,Math.max(Math.min(value(e,c,age)/e.required,age/e.min),age/e.max));}
function automaticKit(n){n=stage(n);const w=weapons.filter(w=>w.level<=n),i=items.filter(it=>it.id!=='heal'&&it.level<=n);return {weapon:w[w.length-1].id,items:['heal',i.length?i[i.length-1].id:null]};}
function kit(p,n){const a=automaticKit(n);return {weapon:p.customWeapon&&weapons.some(w=>w.id===p.weapon&&w.level<=n)?p.weapon:a.weapon,items:p.customItems?loadout(p.items,n):a.items};}
// The final slice of each phase is protected until its attack sequence resolves.
// Progress stays bounded even at extreme world numbers; no HP inflation forever.
function bossPhase(n,ph){const tier=1-Math.exp(-Math.max(0,n-1)/18),i=Math.max(0,Math.min(2,ph-1));return {frames:Math.round(60*([8,10,12][i]+4*tier+(n===10?2:0))),waves:i===0||n<=2?1:2};}
function phaseFloor(max,ph){return ph===1?Math.floor(max*.66)+1:ph===2?Math.floor(max*.33)+1:1;}
function phaseReady(n,ph,age,clears){const q=bossPhase(n,ph);return age>=q.frames&&clears>=q.waves;}
function bossDamageCap(n,max){return Math.max(2,Math.ceil(max*(n<=2?.065:.06)));}
function phaseDamage(b,amount){const floor=phaseFloor(b.max,b.ph),ready=phaseReady(b.n,b.ph,b.phaseAge,b.phaseClears);const next=b.ph===3?0:floor-1;return Math.max(0,Math.min(amount,b.hp-(ready?next:floor)));}
function autoReward(options,p){return options.filter(id=>id!=='restock').sort((a,b)=>(p[a]||0)/perks.find(k=>k.id===a).cap-(p[b]||0)/perks.find(k=>k.id===b).cap)[0]||'restock';}
function interval(n){return difficulty(n).interval;}
function plan(n,seed,i){const h=hash(hash(seed)^hash(n)^hash(i+101)),r=(h>>>0)/4294967296,keys=Object.keys(enemies),pool=keys.slice(0,n<6?1:n<11?2:n<16?3:n<21?4:5),kind=pool[h%pool.length];return {kind,lane:1+(h>>>8)%8,style:(h>>>16)%5,pattern:['formation','gate','cross','rain','duel'][(h>>>20)%5],roll:r};}
function read(storage,legacy=1){let s={};try{s=JSON.parse(storage.getItem(KEY)||'{}')||{};}catch{}const max=Math.max(stage(legacy),stage(s.max));const cp=s.checkpoint&&typeof s.checkpoint==='object'?s.checkpoint:{};const at=Math.min(max,stage(cp.stage||entry(world(max))));return {max,checkpoint:{stage:at,seed:Number.isFinite(cp.seed)?cp.seed>>>0:hash(at+91),perks:cleanPerks(cp.perks)},items:loadout(s.items,max),auto:s.autoConfigured?s.auto!==false:true,autoConfigured:!!s.autoConfigured,manualRewards:false,customWeapon:s.customWeapon===true,customItems:s.customItems===true,weapon:weapons.some(w=>w.id===s.weapon&&w.level<=max)?s.weapon:'bolt'};}
function save(storage,p){try{storage.setItem(KEY,JSON.stringify(p));return true;}catch{return false;}}
function checkpoint(p,n,seed,perks){n=stage(n);if(n<p.max)return false;p.max=n;p.checkpoint={stage:n,seed:seed>>>0,perks:cleanPerks(perks)};return true;}
// Assistance reacts to recent damage, never raises the base difficulty.
function pressure(n,lives,recent=0){const d=difficulty(n),aid=Math.min(1,(lives<=1?.72:lives===2?.42:0)+Math.max(0,Math.min(.28,recent*.14)));return {aid,cap:Math.max(1,d.cap-(aid>=.45?2:aid>0?1:0)),enemies:Math.max(0,d.enemies-(aid>=.45?1:0)),hazard:1-.45*aid,event:1+.28*aid,enemy:1+.35*aid,warning:Math.round(18*aid),recovery:Math.round(720-300*aid)};}
function replayPerks(n,seed){const p=cleanPerks();const count=Math.min(Math.floor((stage(n)-1)/5),perks.reduce((a,k)=>a+k.cap,0)+12);for(let i=1;i<=count;i++){const at=i*5+1,id=autoReward(rewards(at,seed,p),p);if(id!=='restock')p[id]++;}return p;}
function comboGrace(n,perks=0){return (n<6?3:2)+Math.min(3,Math.max(0,perks));}
const api={pressure,replayPerks,comboGrace,unlocks,lessons,enabled,difficulty,arenaTypes,pickups,bossHealth,KEY,zones,weapons,items,perks,cleanPerks,loadout,rewards,enemies,world,entry,zone,target,encounter,value,minStageFrames,maxStageFrames,ready,closing,meter,automaticKit,kit,bossDamageCap,bossPhase,phaseFloor,phaseReady,phaseDamage,autoReward,interval,plan,read,save,checkpoint};if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.HeartmintJourney=api;
})(typeof window!=='undefined'?window:globalThis);
