/* Alpha 7.13 — refined world renderer with stronger figurative staging. */
(()=>{'use strict';
const TAU=Math.PI*2,mod=(n,m)=>((n%m)+m)%m,clamp=(n,a,b)=>Math.max(a,Math.min(b,n)),W=90,H=160;
const hash=(n)=>{n=Math.imul(n^n>>>16,0x45d9f3b);n=Math.imul(n^n>>>16,0x45d9f3b);return ((n^n>>>16)>>>0)/4294967296};
const HEART=['0110110','1111111','1111111','0111110','0011100','0001000'],STAR=['0001000','0001000','1111111','0111110','0011100','0110110','1100011'],BOLT=['00011','00110','01100','11111','00110','01100','11000'];
const mix=(a,b,t)=>{const hex=s=>s.replace('#','');const A=hex(a),B=hex(b),x=i=>parseInt(A.slice(i,i+2),16),y=i=>parseInt(B.slice(i,i+2),16),h=v=>v.toString(16).padStart(2,'0');return '#'+h(Math.round(x(0)*(1-t)+y(0)*t))+h(Math.round(x(2)*(1-t)+y(2)*t))+h(Math.round(x(4)*(1-t)+y(4)*t))};
function painter(c,p,t,b,seed){
const a=p.color,d=p.dark,h=p.accent,rand=i=>hash(seed*1091+i*127),S=Math.sin,C=Math.cos;
let tx=0,ty=0,sc=1;
const T=(x,y)=>[tx+x*sc,ty+y*sc], SZ=v=>Math.max(.8,v*sc);
function use(x,y,s,fn){const otx=tx,oty=ty,osc=sc;tx+=x;ty+=y;sc*=s;fn();tx=otx;ty=oty;sc=osc}
function place(cx,cy,s,fn){use(cx-45*s,cy-80*s,s,fn)}
function r(x,y,w,hh,col=a){c.fillStyle=col;const [X,Y]=T(x,y);c.fillRect(Math.round(X),Math.round(Y),Math.max(1,Math.round(SZ(w))),Math.max(1,Math.round(SZ(hh))))}
function line(x,y,X,Y,col=a,width=1){const steps=Math.max(1,Math.ceil(Math.max(Math.abs(X-x),Math.abs(Y-y))*sc));for(let j=0;j<=steps;j++)r(x+(X-x)*j/steps,y+(Y-y)*j/steps,width,width,col)}
function path(points,col=a,width=1){for(let i=1;i<points.length;i++)line(...points[i-1],...points[i],col,width)}
function disk(x,y,rr,col=a,ring=false){rr=Math.max(.5,rr);for(let j=-Math.ceil(rr);j<=rr;j++){let q=Math.floor(Math.sqrt(Math.max(0,rr*rr-j*j)));if(ring){r(x-q,y+j,1,1,col);r(x+q,y+j,1,1,col)}else r(x-q,y+j,q*2+1,1,col)}}
function ellipse(x,y,rx,ry,col=a,rot=0){let prev;for(let i=0;i<=72;i++){let q=i*TAU/72,u=rx*C(q),v=ry*S(q),pt=[x+u*C(rot)-v*S(rot),y+u*S(rot)+v*C(rot)];if(prev)line(...prev,...pt,col);prev=pt}}
function sprite(rows,x,y,z,col=a){rows.forEach((row,j)=>[...row].forEach((v,i)=>{if(v==='1')r(x+i*z,y+j*z,z,z,col)}))}
function box(x,y,w,hh,col=a){r(x,y,w,1,col);r(x,y+hh,w,1,col);r(x,y,1,hh,col);r(x+w,y,1,hh,col)}
function diamond(x,y,s,col=a){for(let i=-s;i<=s;i++)r(x-(s-Math.abs(i)),y+i,2*(s-Math.abs(i))+1,1,col)}
function stars(count=26,parallax=1){for(let i=0;i<count;i++){let x=rand(i+3)*W,y=rand(i+55)*H;let z=rand(i+98)>.85?2:1;r(x+S(t*.12+i)*parallax,y+mod(t*(.1+i*.003),H)*0, z,z,(i+Math.floor(t*.7))%5===0?h:mix(a,'#ffffff',.18))}}
function scanlines(opacity=.12){for(let y=0;y<H;y+=4)r(0,y,W,1,mix(d,'#000000',.15+opacity*.6))}
function skyBands(){for(let j=0;j<8;j++){let col=mix(d,a,(j/8)*.22);r(0,j*20,W,20,col)}r(0,118,W,42,mix(d,'#000000',.18))}
function panelBorder(kind){if(kind==='frame'||kind==='window'||kind==='photo')for(let i=0;i<2;i++)box(3+i*3,3+i*3,W-6-i*6,H-6-i*6,i?h:a);if(kind==='signal'||kind==='pixel'||kind==='portal'){for(let i=0;i<6;i++)r(i*16,0,8,2,h),r(i*16,H-2,8,2,h)}if(kind==='meteor'||kind==='orbit'){for(let i=0;i<10;i++)diamond(8+i*8,8+(i%2)*2,1,h)}if(kind==='petal'||kind==='feather'){for(let i=0;i<7;i++)disk(8+i*12,8+(i%2)*2,1,h)} }
function classify(k){if(['city','suburb','street','sea','tide','mountain','map','curtain','shutters','stage','runway','disco'].includes(k))return 'bg';if(['moon','sun','planet','eclipse','globe','comet','stars','cloud','rain','rainbow','lighthouse','rocket'].includes(k))return 'sky';if(['window','door','screen','phone','film','photo','comic','clock','hourglass','paper','patch','envelope','heart','rose','cage','vinyl','piano','guitar','lab','magnet','bridge','path','terminal','bubble','crown','eye','glasses','mask','spider'].includes(k))return 'hero';return 'fx'}
function anchor(k,role,slot){const kind=classify(k);const v=slot||0;
 if(role==='bg')return kind==='sky'?[45,46,.72]:kind==='hero'?[45,85,.92]:kind==='fx'?[45,80,.92]:[45,88,1];
 if(role==='mid')return kind==='sky'?[64,44,.58]:kind==='hero'?[45,83,1.02]:kind==='fx'?[45,82,.98]:[45,90,1.04];
 return kind==='sky'?[69-v*10,42+v*8,.55]:kind==='hero'?[26+v*38,88+v*6,.66]:kind==='fx'?[45+v*18,82-v*6,.75]:[45+v*14,100-v*5,.76];}
 function motif(k,j=0){const y=64+12*j,x=45,ph=t*.36+j*.7;
 switch(k){
 case 'stars':stars(48,0);break;
 case 'city':case 'suburb':{let rural=k==='suburb';for(let layer=0;layer<2;layer++){let offset=mod(t*(layer+1)*.55,15);for(let i=-1;i<8;i++){let xx=i*15-offset,hh=(rural?10:19)+rand(i+20+layer*20)*(rural?12:39),yy=133-hh+layer*12;r(xx,yy,13,hh+22,layer?mix(d,a,.22):mix(a,d,.12));if(rural){for(let q=0;q<6;q++)r(xx+q,yy-q,13-q*2,1,h)}for(let n=0;n<4;n++)for(let m=0;m<3;m++)if(rand(i*29+n*11+m+40)>.42)r(xx+2+m*4,yy+4+n*6,2,2,h)}}break;}
 case 'street':{for(let side of [0,1])for(let i=0;i<7;i++){let xx=side?90-i*5:i*5,yy=30+i*10;box(side?xx-10:xx,yy,10,75-i*9,i%2?a:h)}for(let i=0;i<7;i++){let yy=97+i*i*1.6;line(45-(yy-95),yy,45+(yy-95),yy,h)}break;}
 case 'shutters':for(let i=0;i<8;i++){r(i*13,0,6,160,mix(d,'#000000',.08));r(i*13+6,0,1,160,h)}break;
 case 'moon':case 'sun':case 'planet':case 'eclipse':case 'globe':{const xx=k==='moon'?65:45,yy=k==='moon'?33:51,rad=k==='globe'?20:k==='planet'?24:19;disk(xx,yy,rad,k==='moon'?h:a);if(k==='moon'||k==='eclipse')disk(xx+(k==='moon'?7:3),yy-5,rad-2,d);if(k==='globe'){for(let q=0;q<18;q++){let ang=q*TAU/18+t*.12;let u=xx+C(ang)*14,v=yy+S(ang)*12;diamond(u,v,2+q%3,d)}ellipse(xx,yy,rad,7,h);ellipse(xx,yy,7,rad,h)}if(k==='planet')ellipse(xx,yy,33,9,h,-.3);if(k==='sun')for(let q=0;q<12;q++){let ang=q*TAU/12;line(xx+C(ang)*24,yy+S(ang)*24,xx+C(ang)*(28+b*3),yy+S(ang)*(28+b*3),h)}break;}
 case 'sunset':{for(let i=0;i<8;i++)r(0,70+i*9,W,8,i%2?mix(a,h,.15):mix(d,a,.18));disk(45,70,24,h);for(let i=0;i<7;i++)r(0,73+i*4,W,1,d);break;}
 case 'sea':case 'tide':{for(let i=0;i<11;i++){let yy=89+i*7;for(let q=0;q<90;q+=2){let off=S(q*.12+t*(k==='tide'?1.6:.65)+i)*2;r(q,yy+off,2,1+i%2,i%3===0?h:a)}}break;}
 case 'mountain':{for(let layer=0;layer<3;layer++){let pts=[];for(let i=0;i<19;i++){let xx=i*5,yy=106+layer*12-rand(i+layer*31)*38;pts.push([xx,yy]);if(i>0){let p=pts[i-1];for(let q=p[0];q<xx;q++){let Y=p[1]+(yy-p[1])*(q-p[0])/5;r(q,Y,1,160-Y,layer===0?mix(a,d,.08):layer===1?mix(d,h,.08):mix(h,a,.2))}}}path(pts,layer===0?h:a)}break;}
 case 'cloud':for(let i=0;i<7;i++){let xx=mod(rand(i+5)*110+t*.6*(i%2+1),110)-10,yy=18+rand(i+20)*75;for(let q=0;q<4;q++)disk(xx+q*6,yy-S(q)*4,6+(q%2)*2,h);r(xx-6,yy,30,5,h)}break;
 case 'rain':for(let i=0;i<42;i++){let xx=mod(rand(i+5)*W-t*1.6,W),yy=mod(rand(i+50)*H+t*(8+rand(i+60)*12),H);line(xx,yy,xx-2,yy+6,i%4?h:a)}break;
 case 'rainbow':{let cols=['#ef888e','#f2ad79','#f8d97a','#91d6b8','#89b9ed','#c7a5ed'];for(let i=0;i<6;i++)for(let q=0;q<=48;q++){let v=Math.PI+q*Math.PI/48;r(45+C(v)*(38-i*4),110+S(v)*(38-i*4),2,2,cols[i])}break;}
 case 'orbit':case 'portal':case 'kaleido':{for(let i=0;i<4;i++){let rot=k==='orbit'?ph+i*.7:k==='kaleido'?ph*1.7+i*Math.PI/4:0;ellipse(45,75,12+i*7,k==='portal'?18+i*9:7+i*9,i%2?a:h,rot)}for(let q=0;q<6;q++){let z=ph+q*TAU/6;diamond(45+C(z)*32,75+S(z)*46,2+q%2,q%2?h:a)}break;}
 case 'comet':{let q=mod(t*.12+.2,1),xx=8+q*75,yy=22+q*59;for(let i=0;i<15;i++)r(xx-i*2,yy+i,Math.max(1,4-i*.24),2,i%2?h:a);disk(xx,yy,4+b,h);break;}
 case 'birds':case 'wing':{for(let i=0;i<(k==='birds'?5:2);i++){let xx=k==='wing'?45+(i?13:-13):mod(12+i*18+t*.8,100)-5,yy=k==='wing'?73:28+i*8,dir=i%2?1:-1;for(let j=0;j<(k==='wing'?8:3);j++)path([[xx,yy+j*3],[xx+dir*(9+j),yy-7-j*2],[xx+dir*(15+j),yy-12-j]],j%2?h:a)}break;}
 case 'window':case 'door':case 'screen':case 'phone':{let ww=k==='phone'?26:48,hh=k==='phone'?55:k==='door'?71:40,xx=(90-ww)/2,yy=65-hh/2;box(xx-3,yy-3,ww+6,hh+6,a);r(xx,yy,ww,hh,d);box(xx,yy,ww,hh,h);if(k==='window'){line(45,yy,45,yy+hh,h);line(xx,65,xx+ww,65,h);disk(xx+12,yy+12,5,a)}else if(k==='phone'){for(let i=0;i<4;i++)r(xx+4,yy+8+i*9,ww-9,5,i%2?a:h);r(42,yy+hh-3,6,1,h)}else if(k==='door')r(xx+ww-7,yy+hh*.55,3,3,h);else for(let i=0;i<5;i++)r(xx+4,yy+5+i*6,ww*(.4+rand(i)*.45),2,i%2?h:a);break;}
 case 'film':case 'photo':case 'comic':{for(let i=0;i<3;i++){let xx=7+i*23,yy=48+i*15+S(ph+i)*3;box(xx-2,yy-2,27,34,h);r(xx,yy,23,26,d);disk(xx+15,yy+8,4,a);path([[xx,yy+22],[xx+8,yy+10],[xx+18,yy+22]],a,2);r(xx,yy+28,18,2,h);if(k==='film')for(let n=0;n<4;n++){r(xx-4,yy+n*8,2,3,a);r(xx+25,yy+n*8,2,3,a)}if(k==='comic')sprite(BOLT,xx+3,yy+4,2,h)}break;}
 case 'speed':case 'shock':case 'beam':{for(let i=0;i<19;i++){let z=i*TAU/19,rr=10+mod(t*(k==='speed'?13:5)+i*4,45);line(45+C(z)*rr,76+S(z)*rr,45+C(z)*(rr+12+b*9),76+S(z)*(rr+12+b*9),i%2?a:h)}break;}
 case 'bolt':sprite(BOLT,34,53,4,h);break;
 case 'clock':{disk(45,65,24,d);disk(45,65,25,h,true);for(let i=0;i<12;i++){let z=i*TAU/12;line(45+C(z)*20,65+S(z)*20,45+C(z)*23,65+S(z)*23,a)}line(45,65,45+C(-ph)*19,65+S(-ph)*19,h,2);line(45,65,45+C(-ph*.09)*13,65+S(-ph*.09)*13,a,2);break;}
 case 'hourglass':{r(27,40,36,3,h);r(27,94,36,3,h);path([[30,43],[36,57],[45,68],[54,57],[60,43]],a);path([[45,68],[36,82],[30,94],[60,94],[54,82],[45,68]],a);for(let i=0;i<18;i++){let q=mod(i*.09+t*.14,1);r(45+S(i)*q*12,68+q*23,1,1,h)}break;}
 case 'paper':case 'patch':case 'envelope':{let xx=20,yy=52;r(xx,yy,49,45,h);box(xx-1,yy-1,50,46,a);if(k==='envelope')path([[xx,yy],[45,yy+23],[xx+49,yy]],d,2);else for(let i=0;i<7;i++)r(xx+6,yy+7+i*5,20+rand(i)*18,1,d);if(k==='patch'){for(let i=0;i<6;i++){r(38+i*2,yy+3+i*6,5,2,a);r(42+i*2,yy+3+i*6,2,5,d)}}break;}
 case 'heart':sprite(HEART,31,60,4,h);break;
 case 'star':for(let i=0;i<5;i++)sprite(STAR,rand(i+4)*72,25+rand(i+15)*100,1+i%2,i%2?h:a);break;
 case 'rose':{for(let i=0;i<3;i++){let xx=23+i*21,yy=61+S(i)*12;path([[xx,125],[xx-3,96],[xx,yy]],h);for(let j=0;j<6;j++){let q=j*TAU/6;disk(xx+C(q)*5,yy+S(q)*5,4,a)}disk(xx,yy,3,h);diamond(xx+6,yy+20,4,h)}break;}
 case 'curtain':{for(let side of [0,1])for(let i=0;i<8;i++){let xx=side?89-i*4:i*4;for(let yy=0;yy<160;yy+=2){let inward=S(yy/160*Math.PI)*i*.65;r(side?xx-inward:xx+inward,yy,3,2,i%2?a:d)}}r(0,0,90,7,h);break;}
 case 'cage':{box(13,22,64,117,h);for(let i=0;i<8;i++){let xx=15+i*8;r(xx+S(t*.4)*1,23,2,116,a)}r(13,35,64,2,h);r(13,126,64,2,h);break;}
 case 'thread':case 'web':case 'circuit':case 'neuron':{let n=k==='web'?12:k==='circuit'?9:8;for(let i=0;i<n;i++){let z=i*TAU/n,xx=45+C(z)*39,yy=78+S(z)*61;if(k==='circuit'){path([[45,78],[xx,78],[xx,yy]],i%2?a:h);r(xx-2,yy-2,5,5,h);let f=mod(t*.3+i*.12,1);r(45+(xx-45)*f,78,2,2,h)}else{line(45,78,xx,yy,a);if(k==='thread')path([[xx,yy],[45+S(z)*18,78+C(z)*25],[45,78]],h);if(k==='neuron')disk(xx,yy,3+b,h)}}if(k==='web')for(let i=0;i<5;i++)ellipse(45,78,7+i*7,10+i*11,h);break;}
 case 'spider':{ellipse(45,74,12,9,a);disk(45,86,9,a);disk(45,72,7,h);for(let i=0;i<4;i++){let dy=i*5;path([[40,79+dy],[25-dy,70+dy],[13-dy,60+dy]],h,1);path([[50,79+dy],[65+dy,70+dy],[77+dy,60+dy]],h,1)}for(let i=0;i<3;i++)ellipse(45,80,16+i*7,25+i*11,mix(h,a,.3));break;}
 case 'pearl':for(let i=0;i<9;i++){let q=ph*.4+i*TAU/9,xx=45+C(q)*30,yy=70+S(q)*42;disk(xx,yy,3+i%2,h);r(xx-1,yy-2,2,1,'#fff5ec')}break;
 case 'gem':case 'prism':for(let i=0;i<6;i++){let xx=rand(i+22)*75+5,yy=rand(i+90)*95+28,ss=3+i%4;diamond(xx,yy,ss,a);path([[xx-ss,yy],[xx,yy-ss],[xx+ss,yy],[xx,yy+ss],[xx-ss,yy]],h);line(xx,yy-ss,xx,yy+ss,d)}break;
 case 'runway':case 'disco':{for(let i=0;i<8;i++){let yy=95+i*i;for(let n=0;n<8;n++){let xx=n*13-6;let sz=5+i;r(xx,yy,sz,Math.max(2,i),((i+n+Math.floor(t*(k==='disco'?3:1)))%3===0?h:a))}}for(let i=0;i<5;i++)line(45,92,i*24-3,160,h);break;}
 case 'stage':{r(0,121,90,39,d);r(0,120,90,2,h);for(let i=0;i<5;i++){let xx=i*21+3;line(xx,5,45+S(ph+i)*30,112,i%2?h:a,2);r(xx-2,4,6,4,h)}for(let i=0;i<14;i++){let xx=i*7,yy=125+rand(i)*10;disk(xx,yy,3,a)}break;}
 case 'vinyl':{disk(45,78,28,d);disk(45,78,28,a,true);for(let i=0;i<4;i++)disk(45,78,8+i*5,a,true);disk(45,78,7,h);let q=t*.8;line(45+C(q)*9,78+S(q)*9,45+C(q)*24,78+S(q)*24,h);break;}
 case 'piano':{r(0,122,90,38,d);for(let i=0;i<15;i++){r(i*6,122,5,33,h);if(i%7!==2&&i%7!==6)r(i*6+4,122,3,18,a)}r(mod(t*8,15)*6,145,5,10,a);break;}
 case 'guitar':{disk(44,87,14,a);disk(44,72,10,a);disk(44,77,4,d);r(42,30,5,46,h);r(39,25,11,9,a);for(let i=0;i<3;i++)line(43+i,31,43+i,93,d);break;}
 case 'lab':{for(let i=0;i<3;i++){let xx=14+i*25,yy=60+i%2*18;box(xx,yy,13,43,h);r(xx+2,yy+20,10,21,a);r(xx-2,yy-2,17,3,h);for(let q=0;q<5;q++)disk(xx+3+rand(q+i*7)*7,yy+19+mod(25-t*2+q*5,25),1,h)}break;}
 case 'magnet':{for(let i of [-1,1]){let xx=45+i*(17-b*3);box(xx-7,57,14,32,i===1?h:a);r(xx-5,59,10,11,i===1?h:a);r(xx-5,76,10,11,d)}for(let i=0;i<5;i++)ellipse(45,72,12+i*5,13+i*6,i%2?h:a);break;}
 case 'bridge':{for(let i=0;i<90;i++)r(i,98-S(i/90*Math.PI)*12,1,3,h);for(let i=0;i<9;i++){let xx=i*11;line(xx,98-S(xx/90*Math.PI)*12,xx,120,a)}path([[0,101],[0,64],[45,87],[89,64],[89,101]],h);break;}
 case 'path':for(let i=0;i<10;i++){let yy=80+i*8,xx=45+S(i*.55+ph*.25)*(4+i*1.4);r(xx-i*2,yy,i*4+2,3,i%2?h:a)}break;
 case 'map':{let pts=[[7,124],[22,106],[16,83],[39,71],[53,92],[68,59],[80,36]];path(pts,h,2);pts.forEach(([x,y],i)=>{diamond(x,y,3,a);if(i===Math.floor(t*.5)%pts.length)disk(x,y,5,h,true)});for(let i=0;i<8;i++)box(i*12,0,11,160,a);break;}
 case 'lighthouse':{r(62,59,12,62,a);r(60,56,16,6,h);r(65,49,7,7,h);for(let i=0;i<4;i++)r(62,68+i*14,12,4,d);let xx=68+S(ph)*60;line(68,54,xx,20,h,2);break;}
 case 'rocket':{let xx=45+C(ph)*25,yy=72+S(ph)*25;diamond(xx,yy-4,5,h);r(xx-4,yy,9,12,a);r(xx-6,yy+7,3,6,h);r(xx+4,yy+7,3,6,h);r(xx-1,yy+12,3,5+b*3,h);break;}
 case 'neon':case 'signal':{for(let i=0;i<7;i++){let yy=34+i*15,xx=mod(t*(k==='signal'?10:3)+i*13,110)-10;path([[xx-10,yy],[xx,yy],[xx+4,yy-6],[xx+8,yy+5],[xx+13,yy],[xx+25,yy]],i%2?h:a,2)}break;}
 case 'terminal':case 'pixel':{for(let i=0;i<5;i++){let xx=5+i*15,yy=15+i*24;box(xx,yy,24,27,h);r(xx+1,yy+1,22,4,a);for(let n=0;n<4;n++)r(xx+3,yy+9+n*4,5+Math.floor(rand(i*5+n)*14),1,h)}if(k==='pixel')sprite(HEART,31,65,4,a);break;}
 case 'bubble':{for(let i=0;i<2;i++){let xx=7+i*42,yy=50+i*27;box(xx,yy,34,20,i?h:a);path([[xx+5,yy+20],[xx+5,yy+25],[xx+11,yy+20]],h);for(let j=0;j<3;j++)r(xx+7+j*8,yy+9,3,3,h)}break;}
 case 'fracture':{for(let i=0;i<10;i++){let z=i*TAU/10;path([[45,76],[45+C(z)*13,76+S(z)*20],[45+C(z+.2)*26,76+S(z+.2)*42],[45+C(z)*62,76+S(z)*85]],i%2?a:h,1)}break;}
 case 'crown':sprite(['1000001','1101011','1111111','0111110','0111110','0111110'],27,48,5,h);break;
 case 'eye':{path([[8,75],[24,61],[45,56],[66,61],[82,75],[66,89],[45,94],[24,89],[8,75]],h,2);disk(45,75,14,a);disk(45+S(ph)*3,75,6,d);r(42,69,3,3,h);break;}
 case 'glasses':{for(let i of [-1,1]){let xx=45+i*24-16;box(xx,62,32,22,h);r(xx+2,64,29,18,d);line(xx+3,80,xx+23,65,a,2)}line(37,68,53,68,h,2);break;}
 case 'mask':{for(let i of [-1,1]){let xx=45+i*20;disk(xx,69,14,i===1?h:a);r(xx-8,65,5,3,d);r(xx+3,65,5,3,d);path([[xx-6,78],[xx,78+i*3],[xx+6,78]],d)}break;}
 case 'confetti':for(let i=0;i<35;i++){let xx=mod(rand(i+2)*90+S(t+i)*4,90),yy=mod(rand(i+60)*160+t*(4+i%5),160);r(xx,yy,2+i%2,2,i%3?h:a)}break;
 }}
 return {motif,stars,sprite,box,r,line,disk,diamond,ellipse,path,rand,place,panelBorder,skyBands,scanlines,anchor};}
function draw(c,k,p,t,power,b,alpha,seed,en){if(alpha<.002)return;c.save();c.scale(4,4);c.imageSmoothingEnabled=false;c.globalAlpha=alpha*.72;const q=painter(c,p,t,b,seed),list=(k==='climax'?p.climax:p.verse)||[];q.skyBands();q.stars(list.includes('stars')?26:14);q.scanlines(.1);q.panelBorder(p.signature||p.event||'');
 const roles=['bg','mid','fg'];
 list.forEach((m,i)=>{const [x,y,s]=q.anchor?q.anchor(m,roles[i]||'fg',i):[45,80,1];c.save();c.globalAlpha=alpha*([.46,.62,.88][i]||.7);q.place(x,y,s,()=>q.motif(m,i));c.restore()});
 if(k==='climax'){c.save();c.globalAlpha=alpha*.28;q.place(45,84,1.08,()=>q.motif(p.event==='thread'?'web':p.event==='frame'?'photo':p.event==='signal'?'neon':p.event==='petal'?'rose':p.event==='meteor'?'comet':p.event==='pixel'?'terminal':list[1]||list[0],3));c.restore();}
 c.restore();}
function event(c,e,p,t,power){const u=clamp((t-e.t)/e.life,0,1);if(u<=0||u>=1)return;const a=Math.sin(u*Math.PI)*Math.min(.48,power*.4)*e.size;c.save();c.scale(4,4);c.globalAlpha=a;const q=painter(c,p,t,1,Number(p.id.slice(1)));const x=e.x/4,y=e.y/4,s=3+u*8;
 switch(e.kind){case 'frame':case 'shutter':q.box(x-s,y-s,s*2,s*2,p.accent);q.box(x-s-2,y-s-2,s*2+4,s*2+4,p.color);break;case 'crack':for(let i=0;i<5;i++){let z=i*TAU/5;q.path([[x,y],[x+Math.cos(z)*s,y+Math.sin(z)*s],[x+Math.cos(z+.3)*s*1.6,y+Math.sin(z+.3)*s*1.6]],p.accent)}break;case 'meteor':case 'feather':case 'sand':for(let i=0;i<9;i++)q.r(x-i*2+u*9,y+i*2-u*6,Math.max(1,3-i*.22),2,i%2?p.color:p.accent);break;case 'gem':q.diamond(x,y,Math.floor(s*.7),p.accent);break;case 'petal':for(let i=0;i<6;i++){let z=i*TAU/6;q.disk(x+Math.cos(z)*s,y+Math.sin(z)*s,2,p.color)}break;case 'pixel':q.sprite(HEART,x-7,y-6,2,p.accent);break;case 'beam':case 'burst':case 'spark':for(let i=0;i<8;i++){let z=i*TAU/8;q.line(x+Math.cos(z)*s*.5,y+Math.sin(z)*s*.5,x+Math.cos(z)*s*1.6,y+Math.sin(z)*s*1.6,p.accent)}break;case 'wave':case 'thread':case 'signal':for(let i=0;i<3;i++)q.path(Array.from({length:13},(_,j)=>[x+j-6,y+i*3+Math.sin(j*.7+u*3)*s*.4]),p.accent);break;case 'confetti':case 'rainbow':for(let i=0;i<12;i++){let z=i*TAU/12;q.r(x+Math.cos(z)*s,y+Math.sin(z)*s,2,2,i%2?p.color:p.accent)}break;default:q.ellipse(x,y,s,s*.65,p.accent,u*2);q.diamond(x,y,2,p.color);}
 c.restore();}
window.IsmaDirector={draw,event};
})();
