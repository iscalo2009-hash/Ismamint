/* Local civil calendar, deterministic presentation, no effects on domain clocks. */
(function(root){'use strict';
const palettes={pink:['#ff8fc8','#ffd0e9','#291226','#9ce2cb'],solar:['#ffcb45','#ff7060','#28160b','#ff902b'],love:['#ff81a9','#ffd0df','#291322','#ebc65c'],cosmos:['#baa4ff','#f3c7ed','#1e1739','#9ce2cb'],halloween:['#ffad5c','#d2b4ff','#21142e','#9262ce'],winter:['#9ce2cb','#e9f5ff','#11262a','#f17882'],gold:['#ebc65c','#f8e5ad','#242039','#c4b1ff'],four:['#bda3ff','#ebc65c','#211735','#ee90b9']};
const rows=[['aurora',8,20,'Cumpleaños de Aurora',4,'pink',2003,'cumple'],['ismael',12,26,'Cumpleaños de Ismael',4,'solar',2009,'ismael'],['anniversary',11,3,'Nuestro aniversario',4,'love',2025,'anniversary'],['meeting',9,11,'Aniversario de conocernos',4,'cosmos',2025,'meeting'],['valentine',2,14,'San Valentín',3,'love',0,'valentin'],['halloween',10,31,'Halloween',3,'halloween',0,'halloween'],['christmas-eve',12,24,'Nochebuena',3,'winter',0,'navidad'],['christmas',12,25,'Navidad',3,'winter',0,'navidad'],['new-year',1,1,'Año Nuevo juntos',3,'gold',0,'ano'],['year-end',12,31,'Fin de año juntos',3,'gold',0,'ano'],['four',4,4,'Día del 4:44',3,'four',0,'444'],['kiss',7,6,'Día del Beso',1,'love'],['girlfriend',8,1,'Día de la Novia',1,'pink'],['boyfriend',10,3,'Día del Novio',1,'solar']];
const events=Object.freeze(rows.map(([id,month,day,label,level,palette,birth=0,boot='normal'])=>Object.freeze({id,month,day,label,level,palette,birth,boot})));
function relationshipLabel(n,together){const yearly=n%12===0,v=yearly?n/12:n;return `${v} ${yearly?(v===1?'año':'años'):(v===1?'mes':'meses')} ${together?'juntos':'desde que nos conocimos'}`}
function birthdayLabel(id,y){return `${id==='aurora'?'Aurora':'Ismael'} cumple ${y-(id==='aurora'?2003:2009)} años`}
const civil=d=>Date.UTC(d.getFullYear(),d.getMonth(),d.getDate());
function seed(s){let h=2166136261;for(const c of s){h=Math.imul(h^c.charCodeAt(0),16777619)}return h>>>0}
function resolve(d=new Date()){
 const y=d.getFullYear(),m=d.getMonth()+1,day=d.getDate(),hour=d.getHours();if(!Number.isFinite(y))return null;
 const candidates=events.filter(e=>e.month===m&&e.day===day&&(!e.birth||y>e.birth));
 if(day===3&&(y>2025||y===2025&&m>11))candidates.push({id:'mesiversario',label:relationshipLabel((y-2025)*12+m-11,true),level:2,palette:'love',boot:'normal'});
 if(day===11&&(y>2025||y===2025&&m>9))candidates.push({id:'known-month',label:relationshipLabel((y-2025)*12+m-9,false),level:1,palette:'cosmos',boot:'normal'});
 candidates.sort((a,b)=>b.level-a.level);let e=candidates[0],remaining=0,phase='active';
 if(!e){const upcoming=events.filter(e=>e.id==='aurora'||e.id==='ismael').map(e=>({e,days:(Date.UTC(y,e.month-1,e.day)-civil(d))/86400000})).filter(x=>x.days>=1&&x.days<=7).sort((a,b)=>a.days-b.days)[0];if(!upcoming)return null;e=upcoming.e;remaining=upcoming.days;phase='anticipation'}
 const birthday=e.id==='aurora'||e.id==='ismael';const part=hour<6?'night':hour<12?'morning':hour<18?'day':hour<22?'evening':'final';
 return Object.freeze({...e,label:birthday?birthdayLabel(e.id,y):e.id==='anniversary'?relationshipLabel((y-2025)*12,true):e.id==='meeting'?relationshipLabel((y-2025)*12,false):e.label,year:y,age:birthday?y-e.birth:null,phase,remaining,part,level:phase==='anticipation'?1:e.level,key:`${e.id}:${y}`,seed:seed(`${e.id}:${y}`),colors:Object.freeze([...palettes[e.palette]]),secondary:Object.freeze(candidates.slice(1).map(x=>x.id))});
}
const api=Object.freeze({resolve,events,relationshipLabel,birthdayLabel});if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.IsmaCelebrationCore=api;
})(typeof window==='undefined'?globalThis:window);
