/* V4.7 original song-specific choreography */
window.IsmaDirector=(()=>{const T=Math.PI*2,cl=(v,a,b)=>Math.max(a,Math.min(b,v));
function draw(c,k,p,t,power,b,alpha,seed,en){if(alpha<.005)return;const id=Number(k.slice(-2)), chorus=seed>97, u=chorus?1:0, s=1+b*.13, z=t*.3; c.save();c.globalAlpha=alpha;c.strokeStyle=p.color;c.fillStyle=p.color;c.lineWidth=2;c.lineJoin='round';c.lineCap='round';
const line=(a,close=false,fill=false)=>{c.beginPath();a.forEach(([x,y],i)=>i?c.lineTo(x,y):c.moveTo(x,y));if(close)c.closePath();fill?c.fill():c.stroke()}, R=(x,y,w,h,f=false)=>f?c.fillRect(x,y,w,h):c.strokeRect(x,y,w,h), C=(x,y,r,f=false)=>{c.beginPath();c.arc(x,y,Math.max(.1,r),0,T);f?c.fill():c.stroke()}, E=(x,y,a,d,rot=0)=>{c.beginPath();c.ellipse(x,y,Math.max(.1,a),Math.max(.1,d),rot,0,T);c.stroke()}, A=(x,y,r,a,d)=>{c.beginPath();c.arc(x,y,r,a,d);c.stroke()}, col=(i)=>{c.strokeStyle=c.fillStyle=i%2?p.accent:p.color}, at=(x,y,a,fn)=>{c.save();c.translate(x,y);c.rotate(a);fn();c.restore()}, poly=(x,y,r,n,a=0,f=false)=>line(Array.from({length:n},(_,i)=>[x+r*Math.cos(a+i*T/n),y+r*Math.sin(a+i*T/n)]),true,f), H=(x,y,r)=>{c.beginPath();c.moveTo(x,y+r*.65);c.bezierCurveTo(x-r*1.6,y-r*.45,x-r*.5,y-r*1.15,x,y-r*.35);c.bezierCurveTo(x+r*.5,y-r*1.15,x+r*1.6,y-r*.45,x,y+r*.65);c.stroke()}, wave=(y,a,f=.025)=>line(Array.from({length:32},(_,i)=>[i*12,y+Math.sin(i*12*f-z)*a])), star=(x,y,r)=>poly(x,y,r,4,Math.PI/4), frame=(x,y,w,h)=>{R(x,y,w,h);R(x+5,y+5,w-10,h-10)}, text=(x,y,v,size=15)=>{c.font=size+'px monospace';c.textAlign='center';c.fillText(v,x,y)}, curve=(x,y,a,d,e,f,g,h)=>{c.beginPath();c.moveTo(x,y);c.bezierCurveTo(a,d,e,f,g,h);c.stroke()};
switch(id){
case 1:{for(let i=0;i<9;i++){let x=i*43-12;R(x,70,25,500);line([[x,70],[x+25,110+b*24]])}C(180,320,85+u*35);C(200,310,72,true);break;}
case 2:{for(let i=0;i<5;i++){let y=90+i*105;at(180,y,-.17,()=>{R(-150,-40,300,80);for(let j=0;j<6;j++)line([[-140+j*17,-35],[-105+j*17,35]])})}if(u)text(180,320,'!',75+b*15);break;}
case 3:{C(90,160,45*s,true);C(270,460,51*s);C(284,448,42,true);curve(90,160,350,170,10,480,270,460);break;}
case 4:{for(let i=0;i<4;i++){let x=65+i*78;frame(x-35,220+Math.sin(z+i)*65,70,112);for(let j=0;j<4;j++)R(x-31,226+j*26+Math.sin(z+i)*65,5,9,true)}if(u)frame(45,135,270,350);break;}
case 5:{at(180,340,Math.sin(z)*.12,()=>{R(-100,-110,200,220);for(let i=0;i<6;i++)line([[-75,-65+i*26],[65-i*5,-65+i*26]]);line([[-100,-110],[0,-10],[100,-110]])});if(u)for(let i=0;i<5;i++)A(180,340,125+i*18,0,Math.PI);break;}
case 6:{for(let i=0;i<12;i++)A(180,320,120,i*T/12,i*T/12+.25);line([[180,320],[180+100*Math.sin(t*.45),320-100*Math.cos(t*.45)]]);if(u)H(180,320,46*s);break;}
case 7:{for(let i=0;i<3;i++)at(95+i*85,200+i*90,Math.sin(z+i)*.24,()=>{R(-50,-65,100,130);R(-42,-57,84,89);H(0,-10,18*s)});break;}
case 8:{for(let i=0;i<4;i++){col(i);line([[0,470+i*35],[70,280+i*24-b*18],[125,380],[215,210+i*39],[360,480+i*24]],false)}if(u)C(215,210,48*s);break;}
case 9:{for(let i=0;i<6;i++){let a=i*T/6+z*.1;line([[180+Math.cos(a)*60,320+Math.sin(a)*90],[180+Math.cos(a)*150,320+Math.sin(a)*260]])}poly(180,320,70+u*24,6,z*.2);break;}
case 10:{for(let i=0;i<5;i++){let y=160+i*85;poly(180,y,32*s,4,z+i);line([[20,y],[145,y],[215,y],[340,y]])}if(u)poly(180,320,120,4,z*.2);break;}
case 11:{for(let i=0;i<4;i++)E(180,320,55+i*26,90+i*42,z*.2+i*.4);for(let i=0;i<3;i++){let a=z+i*T/3;poly(180+110*Math.cos(a),320+180*Math.sin(a),22,6,a)}break;}
case 12:{for(let i=0;i<3;i++){let x=35+i*28,y=140+i*105;R(x,y,235,128);R(x,y,235,20,true);text(x+115,y+70,i===1?'CONNECTED':'•••',15)}if(u)line([[30,540],[330,540]]);break;}
case 13:{for(let i=0;i<5;i++)E(180,320,48+i*22,125+i*15,z*.1+i*.28);if(u)poly(180,320,85,6,z*.25);break;}
case 14:{for(let i=0;i<6;i++){let q=i*13;col(i);curve(0,170+q,120,170+q,240,470-q,360,470-q)}R(18,260,36,120,true);R(306,260,36,120,true);if(u)H(180,320,40*s);break;}
case 15:{for(let i=0;i<12;i++)line([[180+105*Math.cos(i*T/12),320+105*Math.sin(i*T/12)],[180+120*Math.cos(i*T/12),320+120*Math.sin(i*T/12)]]);C(180,320,130);line([[180,320],[180+95*Math.cos(-t*.8),320+95*Math.sin(-t*.8)]]);if(u)E(180,320,150,35,z);break;}
case 16:{for(let i=0;i<7;i++){let x=40+i*47;H(x,330,15);if(i===Math.floor(t/3)%7){C(x,330,31*s);line([[x,290],[x,220]])}}break;}
case 17:{E(180,320,145,220,-.45);let a=z*.55;let x=180+135*Math.cos(a),y=320+205*Math.sin(a);for(let j=0;j<6;j++)line([[x-j*12,y+j*7],[x-j*24-15,y+j*14]]);C(x,y,12*s,true);break;}
case 18:{for(let i=0;i<8;i++){let a=i*T/8;line([[180,320],[180+Math.cos(a)*65,320+Math.sin(a)*65],[180+Math.cos(a+.2)*170,320+Math.sin(a+.2)*280]])}if(u)poly(180,320,100*s,7,z);break;}
case 19:{for(let i=0;i<6;i++)wave(370+i*37,15+i*3+b*8);C(270,150,44);if(u)E(180,400,165,45,z*.08);break;}
case 20:{for(let i of [-1,1])at(180+i*(55-u*23),320,i*Math.sin(z)*.3,()=>{line([[-55,-90],[55,-90],[65,65],[0,100],[-65,65]],true);line([[-55,-90],[0,-35],[55,-90]])});if(u)H(180,320,40*s);break;}
case 21:{for(let i=0;i<3;i++)poly(180,320,90+i*28,8,z*.2+i*.3);at(180,170,0,()=>line([[-65,20],[-45,-25],[-10,8],[0,-40],[20,8],[50,-25],[65,20]],true));break;}
case 22:{for(let i=0;i<9;i++){let x=i*45;line([[x,350],[x,420],[180,220]])}curve(0,350,100,240,260,240,360,350);if(u)H(180,220,35*s);break;}
case 23:{for(let i=0;i<4;i++){col(i);E(180,320,45+i*29,125-i*14,z+i*.7)}if(u)poly(180,320,100*s,5,-z);break;}
case 24:{for(let i=0;i<5;i++){let x=i*72;R(x,155,72,330);for(let j=0;j<5;j++)line([[x,155+j*66],[x+72,155+j*66]])}R(137,250,86,140,true);if(u)R(152,260,56,120);break;}
case 25:{for(let i=0;i<5;i++){let x=40+i*70;line([[x,60],[180+(x-180)*.3,390],[x+60,390]],true)}for(let i=0;i<6;i++)R(35+i*52,480-b*20,28,45,true);break;}
case 26:{at(180,320,Math.sin(z)*.15,()=>{R(-100,-65,200,130);line([[-100,-65],[0,12],[100,-65]]);H(0,5,36*s)});if(u)for(let i=0;i<5;i++)E(180,320,80+i*15,30+i*12,i*.7);break;}
case 27:{for(let i=0;i<8;i++){let x=180+105*Math.cos(z+i*T/8),y=320+170*Math.sin(z+i*T/8);E(x,y,17,35,z+i)}if(u)C(180,320,72*s);break;}
case 28:{for(let i=0;i<7;i++){c.strokeStyle=['#ffb7b5','#ffd37c','#fff0a1','#9edcc5','#93c7fb','#c9b3ff','#efb9e4'][i];A(180,440,65+i*18,Math.PI,T)}C(180,420,42*s,true);break;}
case 29:{C(180,320,75*s,true);E(180,320,160,46,-.5);E(180,320,120,70,.7);if(u)for(let i=0;i<5;i++)A(180,320,95+i*15,z,z+2);break;}
case 30:{at(180,320,Math.sin(z)*.08,()=>{R(-105,-145,210,290);for(let i=0;i<6;i++)line([[-90,-110+i*42],[90,-110+i*42]]);H(0,0,47*s);star(65,-70,20)});break;}
case 31:{for(let i=0;i<9;i++)at(180,320,i*T/9+z*.15,()=>E(0,-55-u*25,27,65));C(180,320,22*s,true);break;}
case 32:{at(180,320,-.08,()=>{R(-142,-45,120,90);R(22,-45,120,90);line([[-22,-12],[22,-12]]);line([[-125,25],[-45,-25]]);line([[39,25],[119,-25]])});if(u)poly(180,320,150,4,z);break;}
case 33:{for(let i=0;i<3;i++)at(180,190+i*135,Math.sin(z+i)*.12,()=>{frame(-115,-50,230,100);C(0,0,24*s);line([[-90,35],[90,35]])});break;}
case 34:{for(let i=0;i<4;i++)A(180,320,55+i*24,z+i,z+i+2.5);poly(180,320,52*s,3,-Math.PI/2);if(u)text(180,320,'!',45);break;}
case 35:{for(let i of [-1,1])for(let j=0;j<6;j++)curve(180,320,180+i*130,160+j*27,180+i*145,320+j*12,180+i*25,400+j*8);E(180,210,48*s,12);break;}
case 36:{C(180,320,105*s,true);c.strokeStyle=p.dark;for(let i=0;i<5;i++)E(180,320,105,15+i*20);for(let i=0;i<3;i++)E(180,320,25+i*35,105,z*.15);col(1);if(u)for(let i=0;i<8;i++)star(180+145*Math.cos(i*T/8),320+145*Math.sin(i*T/8),10*s);break;}
case 37:{for(let i=0;i<6;i++)E(180,320,35+i*19,25+i*32,z*.2);let a=z;R(180+110*Math.cos(a)-13,320+150*Math.sin(a)-13,26,26,true);break;}
case 38:{for(let i=0;i<4;i++)at(180,320,i*Math.PI/4+z*.1,()=>{R(-140,-8,280,16);C(0,0,36*s)});if(u)for(let i=0;i<6;i++)poly(180,320,70+i*12,4,z);break;}
case 39:{for(let i=0;i<8;i++){let x=i*48;curve(x,0,x+45,150,x-30,430,x,640)}if(u)E(180,320,130,170);break;}
case 40:{for(let i=0;i<5;i++){let x=60+i*60,y=190+Math.sin(z+i)*90;C(x,y,18);line([[x,y+18],[x,440],[180,500]])}if(u)H(180,500,38*s);break;}
case 41:{for(let i=0;i<4;i++)at(180,320,i*Math.PI/2+z*.1,()=>{line([[-100,-80],[100,-80],[60,0],[-60,0]],true);C(0,-45,18*s)});break;}
case 42:{C(250,150,63);C(270,133,56,true);E(180,350,135,180,-.6);at(180+90*Math.cos(z),350+130*Math.sin(z),z,()=>line([[-24,0],[18,0],[0,-8],[0,8]],true));break;}
case 43:{for(let i of [-1,1]){R(180+i*72-62,220+i*35,124,72);for(let j=0;j<3;j++)C(180+i*72-22+j*22,255+i*35,4+b*2,true)}curve(110,290,100,400,270,220,252,325);break;}
case 44:{at(180,320,Math.sin(z)*.12,()=>{R(-65,-145,130,290);R(-52,-115,104,180);C(0,115,12);for(let i=0;i<4;i++)A(0,-160,25+i*17,3.5,5.9)});break;}
case 45:{for(let i=0;i<3;i++)at(180,230+i*100,Math.sin(z+i)*.09,()=>{frame(-95,-45,190,90);C(-42,0,19);C(42,0,19);line([[-22,0],[22,0]])});break;}
case 46:{C(180,320,80*s);for(let i=0;i<8;i++)A(180,320,100+i*15,z*.1+i*.4,z*.1+i*.4+1.2);if(u)line([[20,320],[340,320]]);break;}
case 47:{for(let i=0;i<7;i++)for(let j=0;j<5;j++){col(i+j+Math.floor(t*2));let y=220+i*42;R(40+j*56,y,50,36,(i+j+Math.floor(t*2))%4===0)}break;}
case 48:{for(let i=0;i<9;i++){let a=i*T/9;let x=180+100*Math.cos(a),y=320+170*Math.sin(a);C(x,y,8+s*4);line([[180,320],[x,y]]);C(180+(x-180)*((t*.9+i*.17)%1),320+(y-320)*((t*.9+i*.17)%1),4,true)}C(180,320,20*s);break;}
case 49:{for(let i=0;i<7;i++){let a=i*T/7;at(180,320,a+z*.1,()=>line([[0,-40],[-35,-120],[15,-190],[35,-95]],true))}if(u)C(180,320,55*s);break;}
case 50:{for(let i of [-1,1]){C(180+i*(76-u*30),320,42*s);for(let j=0;j<5;j++){let a=j*T/5+z;C(180+i*76+65*Math.cos(a),320+65*Math.sin(a),8);}}line([[140,320],[220,320]]);break;}
case 51:{R(35,170,290,290);R(50,190,260,185);line([[180,190],[180,375]]);line([[50,280],[310,280]]);C(110,237,22,true);for(let i=0;i<3;i++)wave(400+i*14,4);break;}
case 52:{for(let i=0;i<6;i++)at(180,320,i*T/6+z*.12,()=>E(0,-72,30,58));for(let i=0;i<4;i++)A(180,320,110+i*8,Math.PI, T);break;}
case 53:{let pts=[[25,480],[90,410],[55,300],[180,240],[250,370],[320,150]];line(pts);pts.forEach(([x,y],i)=>{C(x,y,8);if(i===Math.floor(t/3)%pts.length)C(x,y,20*s)});break;}
case 54:{for(let i of [-1,1]){curve(180+i*140,580,180+i*110,340,180+i*20,360,180,160);C(180+i*75*(1-u*.6),320,25*s)}if(u)H(180,160,30);break;}
case 55:{c.fillStyle=p.color;for(let i=0;i<12;i++){let x=25+i*28;R(x,120,12,45+((i*17+Math.floor(t*4)*7)%70),true)}col(1);at(180,320,0,()=>{const bitmap=['01100110','11111111','11111111','01111110','00111100','00011000'];bitmap.forEach((row,y)=>[...row].forEach((v,x)=>{if(v==='1')R((x-4)*14*s,(y-3)*14*s,13*s,13*s,true)}))});for(let i of [-1,1])line([[180+i*65,320],[180+i*110,320],[180+i*110,480],[180+i*150,480]]);if(u)for(let i=0;i<4;i++)R(45+i*75,490,48,12+b*12,true);break;}
}c.restore();}
function event(c,e,p,t,power){const q=(t-e.t)/e.life;if(q<=0||q>=1)return;c.save();c.translate(180,320);const scale=.94+.1*q;c.scale(scale,scale);c.translate(-180,-320);draw(c,e.kind,p,t,power,Math.sin(q*Math.PI),Math.min(.28,Math.sin(q*Math.PI)*power*.23),100,.8);c.restore();}return {draw,event};})();