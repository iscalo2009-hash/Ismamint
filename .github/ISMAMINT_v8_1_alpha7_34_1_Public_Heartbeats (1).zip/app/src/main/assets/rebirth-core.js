/* Rebirth core: deterministic time, event subscriptions, navigation and lifecycle.
   Existing keys and original domain engines remain authoritative. */
(function(root){'use strict';
const DAY=86400000, listeners=new Map();
const emit=(type,payload)=>{for(const fn of [...(listeners.get(type)||[])]){try{fn(payload)}catch(e){console.error('IsmaCore subscriber',type,e)}}};
const on=(type,fn)=>{if(!listeners.has(type))listeners.set(type,new Set());listeners.get(type).add(fn);return()=>listeners.get(type)?.delete(fn)};
let known=0,together=0,offset=18000000,lastNow=null,lastSnapshot;
const elapsed=(start,now=Date.now())=>Math.max(0,now-start),days=(start,now)=>Math.floor(elapsed(start,now)/DAY);
function breakdown(start,now=Date.now()){
 if(now<start)return [0,0,0,0,0];
 const S=new Date(start-offset),N=now-offset,n=new Date(N),y=S.getUTCFullYear(),mo=S.getUTCMonth(),d=S.getUTCDate(),h=S.getUTCHours(),mi=S.getUTCMinutes();
 let m=(n.getUTCFullYear()-y)*12+n.getUTCMonth()-mo;
 if(Date.UTC(y,mo+m,d,h,mi)>N)m--;
 const r=N-Date.UTC(y,mo+m,d,h,mi);
 return [m,Math.floor(r/DAY),Math.floor(r%DAY/3600000),Math.floor(r%3600000/60000),Math.floor(r%60000/1000)];
}
function snapshot(now=Date.now()){
 if(now===lastNow)return lastSnapshot;
 const part=start=>Object.freeze({ms:elapsed(start,now),days:days(start,now),parts:Object.freeze(breakdown(start,now))});
 lastNow=now;return lastSnapshot=Object.freeze({now,known:part(known),together:part(together)});
}
const time={configure(a,b,z){known=a;together=b;offset=z;lastNow=null},elapsed,days,breakdown,snapshot,colombiaDate:ts=>new Date(ts-offset).toISOString().slice(0,10)};
let provider=null,revision=0,calendarCache=new Map();
function invalidate(){revision++;calendarCache.clear()}
const events={on,emit,setCalendarProvider(fn){provider=fn;invalidate()},calendar(year,month){if(!provider)return [];const key=`${year}:${month}:${revision}:${new Date().getTimezoneOffset()}:${new Date().toDateString()}`;if(!calendarCache.has(key)){if(calendarCache.size>=6)calendarCache.delete(calendarCache.keys().next().value);calendarCache.set(key,provider(year,month));}return calendarCache.get(key).slice()},invalidate};
on('achievements:changed',invalidate);
let current='p1', history=[],replaying=false;
const groups={p1:'home',p5:'us',p3:'us',p13:'us',p4:'explore',p6:'explore',p14:'explore',p15:'explore',p10:'chat',p12:'music',p7:'profile',p8:'profile',p9:'profile',p11:'profile'};
const navigation={group:id=>groups[id]||'profile',current:()=>current,quiet:()=>!['p1','p12'].includes(current),changed(id){if(id===current)return;const prev=current;if(!replaying){history.push(prev);if(history.length>50)history.shift()}replaying=false;current=id;emit('navigation:changed',{from:prev,to:id,group:groups[id]})},back(){while(history.length){let target=history.pop();if(['p7','p8','p9'].includes(target))target='p11';if(target!==current){replaying=true;return target}}replaying=false;return null},clear(){history=[];replaying=false}};
const tasks=new Map();let raf=0,timer=0,dispatching=false;
function cancel(){if(raf)root.cancelAnimationFrame(raf);if(timer)root.clearTimeout(timer);raf=timer=0}
function schedule(){if(dispatching||root.document?.hidden)return;cancel();if(!tasks.size)return;const now=root.performance.now();let delay=Infinity;for(const t of tasks.values())delay=Math.min(delay,Math.max(0,t.next-now));if(delay>20){timer=root.setTimeout(()=>{timer=0;schedule()},Math.max(1,delay-8));return}raf=root.requestAnimationFrame(dispatch)}
function dispatch(ts){raf=0;dispatching=true;try{for(const [key,t] of [...tasks]){if(tasks.get(key)!==t||ts+.5<t.next)continue;tasks.delete(key);try{t.fn(ts)}catch(e){console.error('IsmaCore frame',key,e)}}}finally{dispatching=false;schedule()}}
const lifecycle={frame(key,fn,delay=0){const next=root.performance.now()+Math.max(0,Number(delay)||0);tasks.set(key,{fn,next});if(!dispatching)schedule()},stop(key){tasks.delete(key);schedule()}};
root.document?.addEventListener('visibilitychange',()=>{if(root.document.hidden)cancel();else schedule();emit('lifecycle:visibility',{visible:!root.document.hidden})});
root.IsmaCore=Object.freeze({time,events,navigation,lifecycle});
})(typeof window==='undefined'?globalThis:window);
