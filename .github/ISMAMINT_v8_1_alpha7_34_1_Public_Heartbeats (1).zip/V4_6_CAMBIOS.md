# ISMAMINT V4.6 — Lyric & Identity Fix

## Cambios principales
- Nuevo posicionamiento de letras por slots cinematográficos fijos.
- Las letras ya no se teletransportan ni se ocultan por comprobaciones agresivas de solapamiento.
- Entrada y salida de letra más limpias, estilo edit.
- Machine Love rediseñada: paleta roja, acentos de Teto y cameo persistente.
- Teto reforzada con mayor presencia visual y animación ligada al beat.
- Ajustes visuales reiniciados a versión 46 para aplicar la nueva opacidad y lógica.

## Problemas atacados
- Letra dibujada sobre tarjetas o cortada.
- Desaparición de la letra en Machine Love.
- Similitud excesiva entre Machine Love y Cyber Sex.
- Reapariciones bruscas al cambiar de línea.

## Pendiente de comprobar
- Render real en Android.
- Que los nuevos slots no necesiten microajustes en todas las resoluciones.
