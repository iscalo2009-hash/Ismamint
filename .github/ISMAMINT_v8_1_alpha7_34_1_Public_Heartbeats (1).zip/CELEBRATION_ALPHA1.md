# ISMAMINT V8.0 Alpha 1 — Celebration Engine
Base: ISMAMINT_v7_0_Calendar.zip. No migration or change to Firebase, IDs, saved progress, notifications, widgets, audio tracks or domain clocks.

- `celebration-core.js`: pure civil-local date resolver, 14 annual events plus recurring month celebrations, priority, birth years 2003/2009, seven-day birthday anticipation (current celebrations take priority), five daily phases, deterministic annual seed, palette and secondary event IDs. Birthdays and relationship anniversaries level 4; seasonal level 3; mesiversarios level 2; minor level 1.
- `celebration.js`: single temporary presentation state, home card inserted after original layout initialization, root palette overlay for level 3/4 only, visibility/focus/navigation refresh and 15-second foreground poll. No alteration of stored user theme. Preview in Settings > Personalizar > Celebraciones expires after two minutes or manual restore, and does not set phone date, write history or unlock rewards.
- `celebration.css`: low-cost decorative gradients and home-only CSS animation; reduced-motion supported. Native chat/game visuals with independently configured palettes retain their behavior. Not a global animation scheduler.
- `boot.js`: reuses resolver for boot labels and accent; no song-anniversary boot screens. Local 4:44 remains. Existing boot mode/preferences remain. Startup samples event on load; ongoing screen responds to date changes separately.
- `index.html`: monthly dialog wording corrected; underlying Colombian relationship clock unchanged.

Next phases: Birthday Editions (unique cinematic, cake, audio, secrets, widgets); Gift Studio offline editor; authenticated Gift Sync and security rules; memories/export; expanded seasonal visuals; Heartmint content. **No time capsules.** Firebase and native widgets unchanged in this alpha. No Android APK/device test. Preview tests run in isolated Chromium without media/network.
