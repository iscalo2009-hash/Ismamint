# Alpha 7.9 — Explore Gifts
Regalos se abre desde una tarjeta de Explorar, debajo de Heartmint. Se recuperan cinco destinos inferiores; p15 conserva el taller y pertenece al grupo Explorar. Heartmint/Heartbound no se separan. Sin cambios en Firestore ni audio. 41 pruebas Node y prueba de navegador superadas; Android pendiente.
