# ISMAMINT v8.1 Alpha 7.31 — Experience Refinement
Base: Alpha 7.30 Classic Flow.

## Heartmint
- Perder un corazón rosa al cruzar la línea de recogida vuelve a causar daño mediante la función hurt existente. Cuenta la pérdida una sola vez, rompe el combo y la perfección del tramo incluso durante la invulnerabilidad. El escudo consume una carga si no hay invulnerabilidad. El daño conserva el intervalo de invulnerabilidad de 1,1 s. Los corazones verdes y dorados y los potenciadores son opcionales, en particular la lluvia dorada no obliga a atrapar todos los bonus.
- El contador de pérdidas acumula durante toda la partida, no se reinicia con los niveles. El tutorial inicial explica la penalización. No se modifican las rutas, los jefes o los archivos de sonido.

## Chat
- Evita volver a enviar recibos de lectura confirmados y limita los intentos sin confirmar a uno por mensaje cada 20 s; permite un nuevo intento al recuperar la conexión cuando el chat está activo. No reenvía mensajes de usuario automáticamente.
- Los controles multimedia no propagan gestos a la burbuja; el progreso no desplaza el control mientras se arrastra. Barra con progreso visual. No se ha añadido extracción de forma de onda ni modificado la autenticación.

## Regalos
- Guías inteligentes al mover objetos: bordes y centros del lienzo y de objetos visibles. Se precalculan los objetivos al iniciar el arrastre. Se conserva el modo de ajuste a cuadrícula.
- Miniaturas de 160 px, estáticas incluso para fondos parallax, cargadas cuando entran cerca de la zona visible. En borradores visuales y regalos locales abiertos/enviados. Los regalos remotos muestran miniatura solo tras haber consultado un regalo ya abierto o enviado durante la sesión (caché de 24), sin descargar automáticamente contenidos ni revelar sorpresas. No se modifica la apertura obligatoria.
- Orden de inventario conectado: recientes, antiguos y fecha de entrega.

## Pruebas y límites
- 47 suites de Node, incluyendo daño, escudo, invulnerabilidad, derrota y continuidad de las pérdidas.
- Chromium: perfil con confirmación simulada, recepción/escena obligatoria de regalos con Firebase simulado, controles y pausa de Heartmint, guías de alineación y persistencia y miniaturas de 160 px.
- Pendientes: validación del rendimiento y equilibrio de dificultad en Android físico, compilación APK, Firebase real, forma de onda de audio del chat, selección múltiple y edición no destructiva del editor, respaldo global y servicio push FCM. No se afirma que Experience esté completada al 100 %.
- Sin dependencias nuevas ni cambios en Firebase, workflow, firma, audio Opus, fondos musicales o calendario de Alpha 7.30.
