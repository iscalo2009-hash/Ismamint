# Cambios de notificaciones y hora

- Los avisos programados ahora tienen una protección persistente contra entregas duplicadas en Android/MIUI. El mismo ID lógico solo puede mostrarse una vez.
- Los desbloqueos inmediatos de logros se deduplican por ID y también eliminan duplicados dentro de un mismo lote.
- Se conserva la regla de un aviso inteligente no diario por día de Colombia; la diaria se mantiene separada.
- La notificación diaria de las 4:44 p. m. ahora se calcula con la zona horaria local del dispositivo.
- El logro `hora444` usa la hora local del dispositivo.
- El logro del 4 de abril mantiene la fecha de Colombia, pero comprueba las 4:44 con la hora del dispositivo.
- Los contadores, aniversarios, hitos y demás calendario siguen anclados a Colombia (UTC-5), incluida la hora primigenia del 3 de noviembre de 2025 a la 1:36 a. m.

Validación realizada: los cuatro bloques JavaScript del HTML pasan `node --check`.
No se generó un APK: el proyecto recibido no incluye `gradlew` ni `gradle-wrapper.jar`, y no hay una instalación de Gradle disponible en el entorno.

## Notis personalizadas y hora del dispositivo

- Nuevo interruptor «NOTIS PERSONALIZADAS» en Avisos (apagado por defecto): activa la tarjeta con fuentes pixel; apagado, el aviso sale como notificación normal del sistema. El ajuste se guarda también en Android (`setCustomCards`) para que valga con la app cerrada.
- Todos los avisos y la lista «Próximos avisos» muestran fecha y hora del dispositivo. Los eventos siguen ocurriendo en hora de Colombia: el aviso suena en ese mismo instante (p. ej. el mes juntos: día 3 a la 1:36 a. m. COL = 12:36 a. m. en CDMX).
- El aviso mensual ahora es en el instante exacto del mes («Llevamos N meses juntos»).
- Avisos de cada día (semanal, mitad de semana, 7 días antes) usan la hora del dispositivo; la madrugada (22:00–08:00) también es la del dispositivo. La racha sigue atada al día de Colombia (21:15 COL).
- Si cambia la zona horaria con la app abierta, se replanifica en menos de 1 minuto; con la app cerrada, al abrirla.

## Logros del juego recortados

- De los logros del minijuego solo quedan los de múltiplos de 1000 y los que llevan el número 4 (105 → 17), más los 4 secretos de cuatros (44 puntos, 444 puntos, 4.444 corazones y 44 partidas).
- Se quitaron por completo los de jefes, impecables, escudo, intacto, sin X, sin rasguños y partidas de 100.
- Lo ya desbloqueado se conserva en los datos guardados, pero los logros quitados dejan de contar y de aparecer en el total.
