# Heartmint — lanzamiento independiente / QoL

Sustituye al minijuego anterior en el mismo panel de ISMAMINT. Guardado local `heartmint_release_v1` independiente de `best`, `aurora_stats_v1`, Journey y `heartbound_progress_v1`; no se importan puntuación, niveles, skins ni logros de las versiones anteriores. Los datos antiguos se dejan intactos y sus logros no están en el catálogo activo. El resto de los logros de ISMAMINT se conserva. Los 78 logros nuevos usan IDs `hmr_`.

Puntuación base: rosa 10, verde 15, dorado 30; enemigo 60, élite 150; oleada perfecta 80; objetivo táctico 60; contraataque 120 + calidad ×30; jefe 600 (+300 perfecto), tramo 100 (+100 perfecto). Técnicas y otras acciones puntuables también aportan puntos. Combo +5% cada cinco acciones después de las primeras cinco, máximo ×2; se rompe al recibir daño. Récord independiente por nivel de inicio, expedición desde nivel 1 como récord principal. Reiniciar/salir finaliza la partida actual y conserva checkpoint y récord; al cerrar el proceso se continúa desde el checkpoint, no desde el fotograma exacto.

Pausa manual y por navegación, pérdida de foco y cambio a segundo plano; cuenta atrás configurable de 1/3/5 s; confirmación de reinicio/salida; botón de pausa arriba, control Android Atrás y teclado P/Esc; preferencias de movimiento, sensibilidad, audio, vibración y efectos reducidos. Avisos de logros de Heartmint solo dentro de la aplicación. Las 13 skins conservan su arte y deben desbloquearse desde cero. La simulación se detiene en pausa y el bucle de dibujo se detiene en mapa y derrota.

Pruebas: Node y Chromium aislado (se fuerza la apertura del contenedor principal para omitir el arranque de la app). No se compiló ni se probó un APK en Android físico.

Controles fijos: joystick a la izquierda y acciones a la derecha; se descarta la preferencia antigua de mano dominante.
