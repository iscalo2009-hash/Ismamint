# Alpha 7.12 — Dirección artística individual

55 perfiles, basados en los créditos de la biblioteca, letras locales (53 pistas), referencias externas y una interpretación visual original. Las voces descritas corresponden a la identidad de la grabación de referencia, no a una separación vocal del MP3 chiptune. Las fuentes son de calidad variable; el significado es una interpretación, salvo declaraciones directas. Dopamina: coincidencia de título/artista encontrada, significado y voz no confirmados. Tú y Yo: contexto externo, no letra sincronizada. No se descargaron ni copiaron portadas.

## s01 · Esclava - Remix — Bryant Myers, Anuel AA, Anonimus, Almighty
- Voz: Voces masculinas alternadas, trap grave
- Contexto: Encuentro secreto, tensión y deseo
- Dirección: Medianoche clandestina; verso: city, shutters, moon; clímax: eclipse, city, neon; efecto: shutter
- Paleta: #c86a9a / #f1a67d / #1a101f
- LRC: 94 líneas; referencia: https://www.musica.com/anuel/esclava-remix-ft-bryant-myers-anonimus-almighty/analisis-cancion
- Arte: Portada no verificada 

## s02 · Feel It (From “Invincible”) — d4vd
- Voz: d4vd, voz melódica y funk
- Contexto: Euforia del enamoramiento; banda sonora Invincible
- Dirección: Viñetas de un flechazo; verso: comic, city, bolt; clímax: speed, comic, star; efecto: burst
- Paleta: #ffd448 / #f95876 / #142646
- LRC: 43 líneas; referencia: https://www.universalmusic.ca/2024/03/27/d4vd-debuts-new-song-feel-it-from-the-original-series-invincible/
- Arte: Portada no verificada 

## s03 · SOLO POR VOS — Trueno
- Voz: Trueno, rap melódico
- Contexto: Elegir a alguien frente a la soledad
- Dirección: El sol y la luna; verso: sunset, moon, path; clímax: orbit, sunset, heart; efecto: orbit
- Paleta: #ed9a59 / #ffe2a1 / #241a38
- LRC: 54 líneas; referencia: https://www.cifraclub.com/trueno/solo-por-vos/letra/
- Arte: Portada no verificada 

## s04 · Hace Mucho Tiempo — Arcángel
- Voz: Arcángel, voz nasal melódica
- Contexto: Persona soñada durante mucho tiempo
- Dirección: Una espera de película; verso: film, clock, window; clímax: window, film, star; efecto: frame
- Paleta: #c9a06b / #f4d8a1 / #30201c
- LRC: 52 líneas; referencia: https://www.musica.com/arcangel/hace-mucho-tiempo/analisis-cancion
- Arte: Portada no verificada 

## s05 · OJALA — Milo j, Bhavi
- Voz: Milo j y Bhavi, dos voces urbanas
- Contexto: Compañía ante heridas y vulnerabilidad
- Dirección: Refugio en la tormenta; verso: rain, paper, window; clímax: rainbow, window, heart; efecto: petal
- Paleta: #7899c7 / #e7b6c9 / #15243e
- LRC: 65 líneas; referencia: https://www.musica.com/milo-j/ojala-ft-bhavi/analisis-cancion
- Arte: Portada no verificada 

## s06 · Can't Wait — Doja Cat
- Voz: Doja Cat, rap y canto
- Contexto: Anticipación y compromiso, no algo pasajero
- Dirección: Tejer el futuro; verso: thread, clock, pearl; clímax: thread, heart, pearl; efecto: thread
- Paleta: #b44060 / #f7d8d7 / #2c1423
- LRC: 58 líneas; referencia: https://music.apple.com/us/song/1707932018
- Arte: Dos arañas nacaradas, Scarlet https://pitchfork.com/reviews/albums/doja-cat-scarlet/

## s07 · Agora Hills — Doja Cat
- Voz: Doja Cat, rap susurrado y canto
- Contexto: Mostrar públicamente el vínculo; sueño adolescente
- Dirección: Amor a la vista; verso: suburb, photo, pearl; clímax: photo, thread, heart; efecto: frame
- Paleta: #ef9cbd / #ffcfdf / #312136
- LRC: 85 líneas; referencia: https://readdork.com/track/doja-cat-agora-hills-2024
- Arte: Dos arañas nacaradas, Scarlet https://pitchfork.com/reviews/albums/doja-cat-scarlet/

## s08 · Mountains — Sia, Diplo, Labrinth, LSD
- Voz: Sia y Labrinth; producción LSD
- Contexto: Devoción capaz de mover montañas
- Dirección: Cordillera psicodélica; verso: mountain, rainbow, sun; clímax: kaleido, mountain, star; efecto: burst
- Paleta: #46d5ca / #ffba64 / #282452
- LRC: 47 líneas; referencia: https://www.musica.com/lsd/mountains/analisis-cancion
- Arte: Portada no verificada 

## s09 · hostage — Billie Eilish
- Voz: Billie Eilish, voz íntima
- Contexto: Apego posesivo y vulnerabilidad; metáfora inquietante
- Dirección: Habitación que se encierra; verso: cage, window, thread; clímax: cage, fracture, heart; efecto: crack
- Paleta: #c9ab76 / #a34c54 / #201b20
- LRC: 32 líneas; referencia: https://www.musica.com/billie-eilish/hostage-en-espanol/analisis-cancion
- Arte: Portada no verificada 

## s10 · MIU MIU (feat. GeezyDee, CARABIN3) — Blessd, Kris R., Young Fatty, TURY, CARABIN3
- Voz: Voces alternadas de trap; productores según créditos
- Contexto: Lujo, estilo y exceso
- Dirección: Medallo cromado; verso: city, runway, gem; clímax: gem, runway, neon; efecto: gem
- Paleta: #9fc7eb / #f3e4bc / #151c31
- LRC: 120 líneas; referencia: https://www.musica.com/letras.asp?letra=2633300
- Arte: Portada no verificada 

## s11 · Calling (Spider-Man: Across the Spider-Verse) — Metro Boomin, Swae Lee, NAV, A Boogie Wit da Hoodie
- Voz: Swae Lee, NAV y A Boogie; Metro Boomin productor
- Contexto: Rescate y entrega en Spider-Verse
- Dirección: Señal entre universos; verso: city, web, portal; clímax: portal, web, bolt; efecto: portal
- Paleta: #519afa / #fb527d / #171a3d
- LRC: 69 líneas; referencia: https://www.pluggedin.com/track-reviews/metro-boomin-calling/
- Arte: Portada no verificada 

## s12 · Cyber Sex — Doja Cat
- Voz: Doja Cat, rap y melodía
- Contexto: Conexión digital y estética futurista
- Dirección: Terminal Hot Pink; verso: terminal, screen, signal; clímax: screen, neon, pixel; efecto: signal
- Paleta: #ff68af / #a892fc / #32113b
- LRC: 58 líneas; referencia: https://hypebeast.com/2019/11/doja-cat-cyber-sex-music-video
- Arte: Portada no verificada 

## s13 · BLANQUITA — Kris R., Prodmonja
- Voz: Kris R., voz de trap melódico; Prodmonja producción
- Contexto: Admiración y homenaje a un gran amor
- Dirección: Luz de porcelana; verso: cloud, wing, star; clímax: wing, prism, sun; efecto: feather
- Paleta: #e9e8dc / #9cc9fd / #1c314c
- LRC: 41 líneas; referencia: https://www.musica.com/kris-r/blanquita/analisis-cancion
- Arte: Portada no verificada 

## s14 · POLOS OPUESTOS REMIX - BLESSD VERSION — Blessd, Kris R.
- Voz: Blessd y Kris R., alternancia urbana
- Contexto: Atracción entre opuestos
- Dirección: Campos contrarios; verso: magnet, thread, city; clímax: orbit, magnet, bolt; efecto: orbit
- Paleta: #519dff / #ff6f84 / #1e2042
- LRC: 81 líneas; referencia: https://www.qobuz.com/ar-es/album/polos-opuestos-remix-blessd-kris-r/h0hnj1huhxjmb
- Arte: Portada no verificada 

## s15 · Si Me Sobrara el Tiempo — Duki
- Voz: Duki, cambios de flow
- Contexto: Paso del tiempo, deseo de dedicarlo a alguien
- Dirección: Horas que se escapan; verso: clock, hourglass, path; clímax: hourglass, portal, star; efecto: sand
- Paleta: #bd9f76 / #e8d6b0 / #28202d
- LRC: 49 líneas; referencia: https://los40.com/2024/06/08/asi-es-la-letra-y-el-significado-de-la-cancion-si-me-sobrara-el-tiempo-de-duki/
- Arte: Portada no verificada 

## s16 · Una — Blessd
- Voz: Blessd, melodía urbana
- Contexto: Preferencia por una sola persona y vida cotidiana compartida
- Dirección: Una sola luna; verso: suburb, moon, path; clímax: sea, moon, heart; efecto: wave
- Paleta: #8bc7ed / #f7c1b2 / #142942
- LRC: 57 líneas; referencia: https://www.cifraclub.com/blessd/una/letra/
- Arte: Portada no verificada 

## s17 · Halley's Comet — Billie Eilish
- Voz: Billie Eilish, voz contenida
- Contexto: Enamorarse pese a la resistencia, sueño e intimidad
- Dirección: Cometa improbable; verso: stars, comet, window; clímax: comet, orbit, star; efecto: meteor
- Paleta: #d7c7ae / #9ebcea / #202634
- LRC: 28 líneas; referencia: https://pitchfork.com/reviews/albums/billie-eilish-happier-than-ever/
- Arte: Retrato íntimo con lágrimas, Happier Than Ever https://pitchfork.com/reviews/albums/billie-eilish-happier-than-ever/

## s18 · Comatose — Skillet
- Voz: John Cooper, rock de voz áspera
- Contexto: Romper la apatía; despertar y búsqueda de redención
- Dirección: Despertar de la noche; verso: fracture, cage, bolt; clímax: sun, fracture, shock; efecto: crack
- Paleta: #dc555c / #f0d5bf / #211820
- LRC: 58 líneas; referencia: https://lyricsweb.com/song/skillet/skillet-comatose
- Arte: Portada no verificada 

## s19 · A Tu Merced — Bad Bunny
- Voz: Bad Bunny, voz grave y cadencia reguetón
- Contexto: Atracción y deseo nocturno
- Dirección: Calor de madrugada; verso: sea, moon, neon; clímax: tide, city, signal; efecto: wave
- Paleta: #36b5b7 / #f7ad71 / #172b32
- LRC: 61 líneas; referencia: https://www.cifraclub.com/bad-bunny/a-tu-merced/letra/
- Arte: Portada no verificada 

## s20 · Apapáchame — Arroba Nat
- Voz: Arroba Nat, interpretación íntima
- Contexto: Buscar consuelo y un abrazo
- Dirección: Papel que se repara; verso: paper, window, patch; clímax: patch, heart, petal; efecto: petal
- Paleta: #efb6c6 / #f6d4a3 / #30232d
- LRC: 19 líneas; referencia: https://www.cifraclub.com/arroba-nat/apapachame/letra/
- Arte: Portada no verificada 

## s21 · MIL D AURA — Kris R., Prodmonja, Los Money Makers
- Voz: Kris R., trap; Prodmonja y Los Money Makers producción
- Contexto: Actitud, brillo y afirmación urbana
- Dirección: Aura del barrio; verso: city, crown, gem; clímax: crown, neon, shock; efecto: gem
- Paleta: #d2a84f / #8ee0bc / #202a2a
- LRC: 60 líneas; referencia: https://www.musica.com/kris-r/mil-d-aura/analisis-cancion
- Arte: Portada no verificada 

## s22 · Algo Más — La Quinta Estacion
- Voz: Natalia Jiménez, voz de balada intensa
- Contexto: Amor que trasciende distancia y tiempo
- Dirección: Más allá de la distancia; verso: bridge, sea, clock; clímax: bridge, sun, petal; efecto: petal
- Paleta: #e3a491 / #f5db9e / #34242f
- LRC: 54 líneas; referencia: https://www.musica.com/la-quinta-estacion/algo-mas/analisis-cancion
- Arte: Portada no verificada 

## s23 · Se Me Antoja — Kodigo 36
- Voz: Kodigo 36, rap
- Contexto: Flechazo y fascinación al mirar
- Dirección: Hechizo en la mirada; verso: vinyl, eye, city; clímax: eye, star, prism; efecto: spark
- Paleta: #d47ca7 / #e8b268 / #312039
- LRC: 50 líneas; referencia: https://www.cifraclub.com/kodigo-36/se-me-antoja/letra/
- Arte: Portada no verificada 

## s24 · Wonderwall - Remastered — Oasis
- Voz: Liam Gallagher, voz britpop
- Contexto: Esperanza de encontrar a alguien que rescate; interpretación abierta
- Dirección: Un refugio en la calle; verso: street, window, guitar; clímax: door, street, star; efecto: frame
- Paleta: #b1b5c0 / #dfca9e / #25282f
- LRC: 44 líneas; referencia: https://www.radiox.co.uk/artists/oasis/who-was-wonderwall-written-about/
- Arte: Portada no verificada 

## s25 · Born To Be My Baby — Bon Jovi
- Voz: Jon Bon Jovi, rock de estadio
- Contexto: Pareja trabajadora que encuentra apoyo mutuo
- Dirección: Juntos contra el mundo; verso: stage, suburb, beam; clímax: stage, bridge, shock; efecto: beam
- Paleta: #e75b53 / #ffd49a / #291c23
- LRC: 56 líneas; referencia: https://twostorytown.com/born-to-be-my-baby
- Arte: Portada no verificada 

## s26 · The Feels — TWICE
- Voz: TWICE, voces de grupo pop
- Contexto: Flechazo, reciprocidad y baile retro
- Dirección: Invitación al baile; verso: envelope, disco, lab; clímax: disco, confetti, heart; efecto: confetti
- Paleta: #f9a5d3 / #acc4ff / #312044
- LRC: 76 líneas; referencia: https://rollingstoneindia.com/watch-twice-shimmer-under-the-stars-in-the-feels/
- Arte: Concepto de estudio del amor, Formula of Love (no portada verificada) https://www.elle.com/culture/music/a38209395/twice-formula-of-love-album-interview/

## s27 · Anhelo — Adolescent's Orquesta
- Voz: Adolescent’s Orquesta, voz salsera
- Contexto: Nostalgia y deseo de estar con la persona amada
- Dirección: Salón del anhelo; verso: disco, rose, window; clímax: disco, rose, petal; efecto: petal
- Paleta: #d1a060 / #ee9b95 / #30211f
- LRC: 51 líneas; referencia: https://www.cifraclub.com/los-adolecentes/585563/letra/
- Arte: Portada no verificada 

## s28 · 光るなら — Goose house
- Voz: Goose house, voces colectivas
- Contexto: Esperanza, música y luz; Your Lie in April
- Dirección: La luz después de la lluvia; verso: rain, piano, stars; clímax: rainbow, sun, piano; efecto: rainbow
- Paleta: #f6d16c / #83cbf7 / #1d2948
- LRC: 53 líneas; referencia: https://en.wikipedia.org/wiki/Hikaru_Nara_(Goose_House_song)
- Arte: Portada no verificada 

## s29 · Need to Know — Doja Cat
- Voz: Doja Cat, rap y canto
- Contexto: Curiosidad y estética extraterrestre del video
- Dirección: Planeta Her; verso: planet, city, portal; clímax: portal, planet, neon; efecto: portal
- Paleta: #bb91ed / #6bdec7 / #20153c
- LRC: 79 líneas; referencia: https://www.postmagazine.com/press-center/studios/2021/music-video-doja-cat-need-to-know/
- Arte: Portada no verificada 

## s30 · Sweet Boi — Chevy
- Voz: Chevy, voz suave indie
- Contexto: Afecto tierno y admiración
- Dirección: Dibujo dulce; verso: paper, heart, star; clímax: patch, confetti, star; efecto: spark
- Paleta: #f8bac2 / #f9dda0 / #382a35
- LRC: 36 líneas; referencia: https://chevy.bandcamp.com/track/sweet-boi
- Arte: Portada no verificada 

## s31 · Amor Completo — Mon Laferte
- Voz: Mon Laferte, voz expresiva
- Contexto: Entrega y conexión intensa
- Dirección: Floración completa; verso: rose, vinyl, window; clímax: rose, heart, sun; efecto: petal
- Paleta: #dc7284 / #efc28c / #321a29
- LRC: 39 líneas; referencia: https://www.musica.com/mon-laferte/amor-completo/analisis-cancion
- Arte: Portada no verificada 

## s32 · Cooler Than Me — Ethan Fields
- Voz: Ethan Fields, versión de Cooler Than Me
- Contexto: Distancia social y pose de superioridad
- Dirección: Gafas y fachada; verso: glasses, prism, city; clímax: fracture, glasses, neon; efecto: crack
- Paleta: #94cfff / #e0e5f1 / #192a40
- LRC: 41 líneas; referencia: https://musicbrainz.org/release/caaa61be-d6f6-4892-987d-b7554bc35108
- Arte: Portada no verificada 

## s33 · Fanática Sensual — Plan B
- Voz: Chencho y Maldy, dúo de reguetón
- Contexto: Fascinación por imagen y voz; escena de club abstracta
- Dirección: Fotografía en neón; verso: photo, city, screen; clímax: film, runway, neon; efecto: frame
- Paleta: #d762a5 / #eeb48e / #30182c
- LRC: 72 líneas; referencia: https://www.elespectador.com/el-magazin-cultural/resena-de-fanatica-sensual-article-867393/
- Arte: Portada no verificada 

## s34 · Criminal — NATTI NATASHA, Ozuna
- Voz: Natti Natasha y Ozuna, dúo
- Contexto: Atracción irresistible en diálogo musical
- Dirección: Alerta de atracción; verso: neon, signal, city; clímax: signal, shock, heart; efecto: signal
- Paleta: #f36665 / #f7b66c / #2c1823
- LRC: 83 líneas; referencia: https://www.musica.com/ozuna/criminal-ft-natti-natasha/analisis-cancion
- Arte: Portada no verificada 

## s35 · Mi Bello Angel — Natanael Cano
- Voz: Natanael Cano, corrido tumbado
- Contexto: Admiración de una figura que ilumina su rumbo
- Dirección: Ángel y contraste; verso: wing, path, cloud; clímax: wing, sun, star; efecto: feather
- Paleta: #e7ca91 / #b7d9f7 / #20354d
- LRC: 39 líneas; referencia: https://www.puroraza.com/song/mi-bello-angel
- Arte: Portada no verificada 

## s36 · Yellow — Coldplay
- Voz: Chris Martin, voz melódica
- Contexto: Devoción; globo dorado de Parachutes
- Dirección: Parachutes bajo las estrellas; verso: stars, globe, moon; clímax: globe, stars, sun; efecto: meteor
- Paleta: #f2c34e / #ffedac / #14212d
- LRC: 45 líneas; referencia: https://usstore.coldplay.com/products/parachutes-cd
- Arte: Globo amarillo iluminado, Parachutes https://usstore.coldplay.com/products/parachutes-cd

## s37 · Tus Vueltas — Milo j
- Voz: Milo j, voz urbana íntima
- Contexto: Fascinación y recuerdo de una persona que baila
- Dirección: Vueltas de la plaza; verso: street, vinyl, orbit; clímax: orbit, disco, star; efecto: orbit
- Paleta: #7fb49f / #e5bb82 / #23312f
- LRC: 32 líneas; referencia: https://www.cifraclub.com/milo-j/tus-vueltas/letra/
- Arte: Portada no verificada 

## s38 · You Rock My World — Michael Jackson
- Voz: Michael Jackson, voz rítmica y ad-libs
- Contexto: Atracción que transforma su mundo; corto cinematográfico
- Dirección: Groove de Invincible; verso: stage, film, disco; clímax: disco, beam, star; efecto: beam
- Paleta: #b6a7eb / #f3d4a4 / #231e37
- LRC: 112 líneas; referencia: https://www.youtube.com/watch?v=1-7ABIM2qjU
- Arte: Portada no verificada 

## s39 · Billie Bossa Nova — Billie Eilish
- Voz: Billie Eilish, interpretación susurrada
- Contexto: Romance discreto, bossa nova
- Dirección: Secreto de terciopelo; verso: curtain, window, vinyl; clímax: curtain, film, moon; efecto: frame
- Paleta: #cdb89b / #b69979 / #2b2328
- LRC: 41 líneas; referencia: https://pitchfork.com/reviews/albums/billie-eilish-happier-than-ever/
- Arte: Retrato íntimo con lágrimas, Happier Than Ever https://pitchfork.com/reviews/albums/billie-eilish-happier-than-ever/

## s40 · Stranger — Doja Cat
- Voz: Doja Cat, power ballad
- Contexto: Dos personas fuera de lo convencional que conectan; era Vie
- Dirección: Extraños en la misma frecuencia; verso: signal, orbit, neon; clímax: orbit, heart, star; efecto: orbit
- Paleta: #b8b9ed / #ee8dbc / #25233e
- LRC: 49 líneas; referencia: https://music.apple.com/us/album/jealous-type/1834042903
- Arte: Portada no verificada 

## s41 · Freak — Doja Cat
- Voz: Doja Cat, rap y canto
- Contexto: Juego de personalidad y estética retro excéntrica
- Dirección: Cabaret excéntrico; verso: curtain, vinyl, mask; clímax: kaleido, curtain, star; efecto: frame
- Paleta: #e977a4 / #c99af2 / #321b3a
- LRC: 63 líneas; referencia: https://ratedrnb.com/2020/08/doja-cat-releases-new-single-freak/
- Arte: Portada no verificada 

## s42 · Fly Me To The Moon - 2008 Remastered — Frank Sinatra, Count Basie
- Voz: Frank Sinatra, crooner; orquesta Count Basie
- Contexto: Amor expresado como viaje astral; swing 1964
- Dirección: Swing hacia la luna; verso: moon, rocket, stars; clímax: orbit, disco, rocket; efecto: meteor
- Paleta: #c1d3e8 / #f3d69c / #132b40
- LRC: 21 líneas; referencia: https://www.allmusic.com/song/fly-me-to-the-moon-mt0008651961
- Arte: Portada no verificada 

## s43 · Deeper Conversation — Yuna
- Voz: Yuna, voz acústica íntima
- Contexto: Conocer el interior de la otra persona
- Dirección: Dos voces y una conversación; verso: window, bubble, thread; clímax: bubble, bridge, heart; efecto: signal
- Paleta: #83c4ad / #e5d4a7 / #193334
- LRC: 42 líneas; referencia: https://lyricsweb.com/song/yuna/yuna-deeper-conversation
- Arte: Portada no verificada 

## s44 · ALO (feat. Tutu) — Blessd, Juhn, Fronti, TURY, Tutu
- Voz: Blessd, Juhn, Tutu y colaboradores acreditados
- Contexto: Llamada y añoranza después del encuentro
- Dirección: Aló, señales de barrio; verso: city, phone, signal; clímax: phone, neon, screen; efecto: signal
- Paleta: #6bc5aa / #efc576 / #142b31
- LRC: 104 líneas; referencia: https://music.amazon.com/tracks/B0H5YVKLWZ
- Arte: Portada no verificada 

## s45 · Disfruto — Carla Morrison
- Voz: Carla Morrison, voz íntima
- Contexto: Disfrutar de la presencia y los gestos cotidianos
- Dirección: Guardar los instantes; verso: photo, window, heart; clímax: film, rose, sun; efecto: frame
- Paleta: #e6aa93 / #f5dab8 / #392924
- LRC: 56 líneas; referencia: https://carlamorrisonf.substack.com/p/los-frutos-de-disfruto
- Arte: Portada no verificada 

## s46 · I Don't Want to Miss a Thing - From "Armageddon" Soundtrack — Aerosmith
- Voz: Steven Tyler, voz áspera de balada rock
- Contexto: No perder ni un instante junto a alguien; Armageddon
- Dirección: El cielo que no se duerme; verso: comet, planet, stars; clímax: eclipse, comet, sun; efecto: meteor
- Paleta: #a7bfee / #f8d5aa / #16243b
- LRC: 61 líneas; referencia: https://www.shortlist.com/news/diane-warren-how-i-wrote-i-dont-want-to-miss-a-thing-if-i-could-turn-back-time-and-nothings-gonna-stop-us-now
- Arte: Portada no verificada 

## s47 · P.Y.T. (Pretty Young Thing) — Michael Jackson
- Voz: Michael Jackson y coros, funk disco
- Contexto: Flechazo y energía de baile; contraste blanco y negro de Thriller
- Dirección: Pista Thriller; verso: disco, vinyl, beam; clímax: disco, confetti, star; efecto: confetti
- Paleta: #eee5d9 / #d6a257 / #1d1d29
- LRC: 76 líneas; referencia: https://musicbrainz.org/release/b8f457c0-a943-4225-878f-65d2301bd111
- Arte: Traje blanco sobre fondo oscuro, Thriller https://www.mjworld.net/news/2011/03/10/michael-and-zimmerman/

## s48 · Dopamina — Sergi
- Voz: Sergi, identidad vocal no confirmada
- Contexto: Metáfora artística del título; letra local ausente
- Dirección: Sinapsis eléctrica; verso: lab, neuron, bolt; clímax: neuron, signal, shock; efecto: signal
- Paleta: #f5a65f / #ec78b3 / #302039
- LRC: 0 líneas; referencia: https://www.youtube.com/watch?v=m6yZJCis4F8
- Arte: Portada no verificada 

## s49 · CARENCIAS DE CORDURA — Milo j, Yami Safdie
- Voz: Milo j y Yami Safdie, dúo
- Contexto: Fragilidad, distancia emocional y búsqueda de comprensión
- Dirección: Dos lunas imperfectas; verso: fracture, moon, thread; clímax: orbit, moon, patch; efecto: crack
- Paleta: #a4b4d2 / #d6bad9 / #24263b
- LRC: 30 líneas; referencia: https://www.musica.com/letras.asp?letra=2603012
- Arte: Portada no verificada 

## s50 · Química Mayor — Mon Laferte
- Voz: Mon Laferte, voz expresiva
- Contexto: Atracción y química íntima
- Dirección: Química de dos; verso: lab, magnet, neuron; clímax: orbit, lab, heart; efecto: orbit
- Paleta: #cca6e1 / #e7a585 / #30233d
- LRC: 40 líneas; referencia: https://www.cifraclub.com/mon-laferte/quimica-mayor/letra/
- Arte: Portada no verificada 

## s51 · Lo Que Siento — Cuco
- Voz: Cuco, voz melódica bilingüe
- Contexto: Confesión amorosa y sueño despierto
- Dirección: Ensoñación lo-fi; verso: window, sunset, vinyl; clímax: sunset, cloud, heart; efecto: petal
- Paleta: #7cc5bb / #efb1c6 / #25313c
- LRC: 53 líneas; referencia: https://songsense.io/es/cuco/lo-que-siento
- Arte: Portada no verificada 

## s52 · He's My Man — Luvcat
- Voz: Luvcat, voz teatral de cabaret
- Contexto: Balada de asesinato ficticia: posesión inquietante, contraste con romance
- Dirección: Vals de sombras; verso: curtain, rose, mask; clímax: cage, rose, moon; efecto: petal
- Paleta: #c7475d / #eabca7 / #28151f
- LRC: 47 líneas; referencia: https://www.nme.com/features/music-interviews/luvcat-interview-radar-breakout-dinner-at-brasserie-zedel-3809564
- Arte: Portada no verificada 

## s53 · El Mapa De Mi Interior - Remastered 2025 — EME-15
- Voz: EME-15, voces pop grupales
- Contexto: Ser comprendido en la propia complejidad
- Dirección: Cartografía del alma; verso: map, sea, lighthouse; clímax: lighthouse, bridge, star; efecto: beam
- Paleta: #b8a4df / #a7d8ed / #242b45
- LRC: 44 líneas; referencia: https://www.musica.com/letras.asp?letra=2069392
- Arte: Portada no verificada 

## s54 · Tú y Yo — Valeria Jasso
- Voz: Valeria Jasso, voz íntima y acústica
- Contexto: Sueños compartidos, calma y vuelo sobre el mar; sin LRC local
- Dirección: Sobre el mar; verso: sea, cloud, birds; clímax: sunset, birds, heart; efecto: feather
- Paleta: #edb7c8 / #9dd9d4 / #263d45
- LRC: 0 líneas; referencia: https://hgmedia.com.mx/valeria-jasso-convierte-los-suenos-en-refugio-con-tu-y-yo/
- Arte: Portada no verificada 

## s55 · Machine Love — Jamie Paige
- Voz: Kasane Teto SV; Jamie Paige, autor y productor
- Contexto: Máquina que busca sentir y ser real; identidad de voz sintética
- Dirección: Corazón fuera del algoritmo; verso: circuit, terminal, heart; clímax: circuit, pixel, heart; efecto: pixel
- Paleta: #ed526d / #ffd8dd / #2c1528
- LRC: 70 líneas; referencia: https://jamiepaige.bandcamp.com/track/machine-love-3
- Arte: Portada no verificada 

## Implementación y límites
Motor nuevo de composición pixel en cuadrícula 90×160, dos composiciones por pista, partículas/eventos temáticos, color contextual de reproductor y contador, Teto estática. Se reutiliza el reloj de reproducción y las estimaciones de secciones/ataques; no hay detección separada de voz. Los temas normales, regalos, MP3, letra y Firebase permanecen intactos. 41 suites anteriores superadas; prueba nueva de los 55 perfiles con contexto de dibujo simulado. Prueba integral Chromium agotó su tiempo; APK y audio Android no comprobados.
