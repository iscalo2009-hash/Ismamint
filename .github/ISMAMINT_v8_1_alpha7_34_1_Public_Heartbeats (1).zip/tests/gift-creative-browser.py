from playwright.sync_api import sync_playwright
from pathlib import Path
root=Path(__file__).resolve().parents[1]/'app/src/main/assets'
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox']);page=b.new_page(reduced_motion='reduce');errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.set_content('<main id="root"></main><main id="preview"></main>')
 for name in ['vendor/konva.min.js','gift-experience.js','gift-canvas.js']:page.add_script_tag(path=root/name)
 page.add_style_tag(path=root/'gift-studio.css')
 page.evaluate('''()=>{window.saved=[];document.querySelector('#root').append(IsmaGiftCanvas.sceneEditor([],v=>window.saved=v));document.querySelector('#root details').open=true}''')
 page.get_by_role('button',name='Añadir plantilla').click();assert page.evaluate('saved.length')==2
 page.evaluate("document.querySelector('#preview').append(IsmaGiftCanvas.sceneView(saved))")
 for i in range(1,4):page.locator('#preview .ge-hotspot').get_by_text('Estrella '+str(i),exact=True).click()
 page.locator('#preview').get_by_role('button',name='Abrir sorpresa').click();assert page.locator('#preview h4').inner_text()=='Tu sorpresa'
 assert not errors,errors;b.close();print('Creative browser OK')
