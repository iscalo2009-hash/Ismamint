from playwright.sync_api import sync_playwright
from pathlib import Path
import base64
root=Path(__file__).resolve().parents[1]/'app/src/main/assets'
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox']);page=b.new_page();errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.route('http://localhost:8765/**',lambda r:r.fulfill(status=200,content_type='text/html',body='<div id="root"></div><div id="preview"></div>'))
 page.goto('http://localhost:8765/');
 for x in ['vendor/konva.min.js','gift-media.js','gift-canvas.js']:page.add_script_tag(path=root/x)
 page.evaluate('''()=>{let e=IsmaGiftCanvas.editor(null,v=>{window.saved=v;document.querySelector('#preview').replaceChildren(IsmaGiftCanvas.view(v))});document.querySelector('#root').append(e);e.open=true}''')
 page.get_by_text('Imágenes y recursos',exact=True).click()
 data=page.evaluate("""()=>{let c=document.createElement('canvas');c.width=80;c.height=40;let x=c.getContext('2d');x.fillStyle='#ff0000';x.fillRect(0,0,80,40);return c.toDataURL().split(',')[1]}""")
 page.get_by_label('Importar imagen').set_input_files({'name':'test.png','mimeType':'image/png','buffer':base64.b64decode(data)})
 page.wait_for_function("window.saved?.objects[0]?.kind==='image'")
 page.wait_for_function("document.querySelector('.gc-preview-img')?.src.startsWith('data:image/png')")
 assert page.evaluate("""async()=>{let i=document.querySelector('.gc-preview-img');await i.decode();let c=document.createElement('canvas');c.width=c.height=640;let x=c.getContext('2d');x.drawImage(i,0,0);let a=x.getImageData(320,320,1,1).data;return a[0]>220&&a[1]<40}""")
 saved=page.evaluate('saved');page.reload()
 for x in ['vendor/konva.min.js','gift-media.js','gift-canvas.js']:page.add_script_tag(path=root/x)
 assert page.evaluate('(id)=>IsmaGiftMedia.get(id).then(x=>x.width===80&&x.height===40)',saved['objects'][0]['assetId'])
 assert not errors,errors
 b.close();print('Gift Media browser OK')
