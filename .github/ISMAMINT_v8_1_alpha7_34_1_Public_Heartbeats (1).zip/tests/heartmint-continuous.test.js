const assert=require('node:assert/strict'), C=require('../app/src/main/assets/heartbound-core');
// Every ordinary level boundary retains the same live entities, timers, and powerups.
for(let n=1;n<400;n++){
 if(n%5>=4||n%5===0)continue;
 const g=C.create({stage:n,seed:44});let s=g.state;g.input.targetX=180;
 s.player.x=180;s.player.inv=0;s.catch.magnet=4;s.catch.shield=1;s.catch.slow=2;s.catch.rain=3;s.catch.nextHazard=9;s.catch.nextPower=7;s.catch.enemyTimer=6;s.spawn=.17;s.catch.seq=19;s.catch.left=3;s.catch.lane=172;s.catch.flowSpeed=160;s.catch.flowRate=.23;
 const h={kind:'pink',x:85,y:100,vy:150,t:5},o={kind:'spike',x:60,bx:60,y:80,vy:100,t:5,age:0,sign:1,warn:0};s.hearts.push(h);s.catch.obstacles.push(o);s.done=s.route.goal;
 g.update(1/120);assert.equal(g.state.stage,n+1);assert.equal(g.state.hearts[0],h);assert.equal(g.state.catch.obstacles[0],o);assert(g.state.catch.magnet>3.9);assert.equal(g.state.catch.shield,1);assert(g.state.catch.slow>1.9);assert(g.state.catch.rain>2.9);assert(g.state.spawn>.15&&g.state.spawn<.18);assert.equal(g.state.catch.seq,19);assert.equal(g.input.targetX,180);assert.equal(g.state.player.x,180);assert(g.state.catch.nextHazard>8.9);assert(g.state.catch.nextPower>6.9);assert(g.state.catch.flowSpeed>159&&g.state.catch.flowSpeed<161);assert.equal(g.state.player.inv,0);assert(g.state.total>0);
}
// Warning stage actually freezes the obstacle before it falls, and uses same physics in path validation.
const o={kind:'spike',x:50,bx:50,y:28,vy:150,t:8,age:0,warn:.34,sign:1};C.hazardMotion(o,.12,100);assert.equal(o.y,28);assert.equal(o.age,0);assert(o.warn>0);C.hazardMotion(o,.3,100);C.hazardMotion(o,.1,100);assert(o.y>28);assert(o.radius>0);
// 120Hz fixed simulation over extended runs, with deterministic resets only for actual bosses.
for(const start of [1,2,11,21,41,61,101]){const g=C.create({stage:start,seed:99});for(let i=0;i<120*100;i++){const s=g.state;if(s.status!=='play'||s.boss)break;const target=s.hearts.filter(h=>h.y<s.player.y&&h.kind==='pink').sort((a,b)=>b.y-a.y)[0];g.input.targetX=target?.x??120;g.update(1/120);assert(s.hearts.length<=36);assert(s.catch.obstacles.length<=4);assert(Number.isFinite(s.player.x));}}
console.log('240 ordinary transitions preserve live entities and buffs, warnings freeze until activation, extended catch simulation bounded.');
