from playwright.sync_api import sync_playwright
from pathlib import Path
root=Path(__file__).resolve().parents[1]/'app/src/main/assets'
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox']);page=b.new_page(viewport={'width':390,'height':900});page.set_default_timeout(5000);errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.route('http://localhost:8765/**',lambda r:r.fulfill(status=200,content_type='text/html',body='<meta name="viewport" content="width=device-width"><div id="root"></div>'))
 page.set_content('<meta name="viewport" content="width=device-width"><div id="root"></div>');page.add_style_tag(path=root/'gift-studio.css')
 for x in ['vendor/konva.min.js','gift-media.js','gift-art.js','gift-canvas.js']:page.add_script_tag(path=root/x)
 page.evaluate('''()=>{const items=new Map();IsmaGiftMedia.importFile=async(file,options)=>{if(!options.lossless)throw Error('Expected lossless');const bitmap=await createImageBitmap(file);const a={id:'art-test',name:file.name,width:bitmap.width,height:bitmap.height,blob:file,createdAt:Date.now()};items.set(a.id,a);return a};IsmaGiftMedia.get=async id=>items.get(id);IsmaGiftMedia.list=async()=>[...items.values()];IsmaGiftMedia.image=async id=>createImageBitmap(items.get(id).blob)}''')
 page.evaluate('''()=>{let e=IsmaGiftCanvas.editor(null,v=>window.saved=v);document.querySelector('#root').append(e);e.open=true}''')
 page.get_by_text('Art Studio · Crear dibujo',exact=True).click();c=page.locator('.ga-canvas');c.scroll_into_view_if_needed();r=c.bounding_box();page.mouse.click(r['x']+r['width']*.3,r['y']+r['height']*.3)
 assert page.evaluate("document.querySelector('.ga-canvas').getContext('2d').getImageData(9,9,1,1).data[3]")==255
 page.get_by_role('button',name='Deshacer dibujo',exact=True).click();assert page.evaluate("document.querySelector('.ga-canvas').getContext('2d').getImageData(9,9,1,1).data[3]")==0
 page.get_by_role('button',name='Rehacer dibujo',exact=True).click();page.get_by_role('button',name='+ Capa',exact=True).click();page.get_by_role('button',name='Simetría',exact=True).click();c.scroll_into_view_if_needed();r=c.bounding_box();page.mouse.click(r['x']+r['width']*.2,r['y']+r['height']*.5)
 assert page.evaluate("document.querySelector('.ga-canvas').getContext('2d').getImageData(25,16,1,1).data[3]")==255
 page.get_by_role('button',name='Guardar e insertar dibujo',exact=True).click();page.wait_for_function("window.saved?.objects[0]?.kind==='image'")
 aid=page.evaluate('saved.objects[0].assetId');assert page.evaluate('(id)=>IsmaGiftMedia.get(id).then(x=>x.width===256&&x.blob.type==="image/png")',aid)
 assert not errors,errors
 b.close();print('Gift Art browser OK (simulated storage)')
