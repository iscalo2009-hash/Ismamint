const assert=require('node:assert/strict'),J=require('../app/src/main/assets/heartmint-journey.js');
const kinds=new Set(),durations=new Set(),sequences=new Set();
for(let n=1;n<=10000;n++){
 const e=J.encounter(n,123),t=e.min,max=e.max;assert.deepEqual(e,J.encounter(n,123));
 if(n%5!==0){const full={hearts:100,kills:100,clears:100,points:100},zero={};kinds.add(e.kind);assert(t>=720&&t<=4200&&max>=t&&max<=5700);assert(!J.ready(n,full,t-1,123));assert(J.ready(n,full,t,123));assert(J.ready(n,zero,max,123));assert(J.closing(n,zero,max-300,123));assert.equal(J.meter(n,zero,max,123),1);if(e.goal!=='time'){assert(!J.ready(n,zero,t,123));assert(!J.ready(n,zero,max-1,123));}}
 if(n%5===1){const path=Array.from({length:4},(_,i)=>J.encounter(n+i,123));const total=path.reduce((a,p)=>a+p.min/60,0);durations.add(total);sequences.add(path.map(p=>p.kind).join(','));assert(total>=60&&total<=250);assert(path.reduce((a,p)=>a+p.max/60,0)<=350);}
 const perks=J.cleanPerks(),options=J.rewards(n,123,perks);assert(options.includes(J.autoReward(options,perks)));const k=J.automaticKit(n);assert(J.weapons.find(w=>w.id===k.weapon).level<=n);assert(k.items.every(id=>!id||J.items.find(it=>it.id===id).level<=n));
}
assert.equal(kinds.size,6);assert(durations.size>30);assert(sequences.size>=6);assert.notDeepEqual(J.encounter(101,1),J.encounter(101,2));
const m=new Map(),store={getItem:k=>m.get(k),setItem:(k,v)=>m.set(k,v)};
let p=J.read(store);assert.equal(p.manualRewards,false);assert.equal(p.auto,true);p.manualRewards=true;p.auto=false;J.save(store,p);assert.equal(J.read(store).manualRewards,false);assert.equal(J.read(store).auto,true);p.autoConfigured=true;J.save(store,p);assert.equal(J.read(store).auto,false);assert.deepEqual(J.kit(p,51),{weapon:'echo',items:['heal','prism']});p.customWeapon=true;p.weapon='bolt';assert.equal(J.kit(p,51).weapon,'bolt');
const full=Object.fromEntries(J.perks.map(k=>[k.id,k.cap]));assert.equal(J.autoReward(J.rewards(1000,1,full),full),'restock');
console.log('10000 encounter gates, six objectives, variable world routes, bounded fallback and automatic rewards verified');