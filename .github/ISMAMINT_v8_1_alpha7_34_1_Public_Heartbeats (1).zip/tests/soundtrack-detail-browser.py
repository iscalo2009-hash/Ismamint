from pathlib import Path
from playwright.sync_api import sync_playwright
from PIL import Image, ImageDraw, ImageFont, ImageChops
import json,io,base64,hashlib,html,sys
root=Path(__file__).resolve().parents[1]/'app/src/main/assets'
out=Path(sys.argv[1]) if len(sys.argv)>1 else Path('/tmp/isma717-gallery');out.mkdir(parents=True,exist_ok=True)
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage']);page=b.new_page();errs=[];page.on('pageerror',lambda e:errs.append(str(e)))
 page.set_content('<canvas width="360" height="640"></canvas>')
 for f in ['soundtrack-data.js','soundtrack-presets.js','soundtrack-scenes.js','soundtrack-worlds.js','soundtrack-world-render.js','soundtrack-rhythm.js','soundtrack-atelier.js']:page.add_script_tag(path=root/f)
 result=page.evaluate('''()=>{const cv=document.querySelector('canvas'),c=cv.getContext('2d');const img=(p,t,q,theme=null)=>{c.clearRect(0,0,360,640);let a=IsmaAtelier.score(p.id,t);IsmaDirector.drawScene(c,p,t,1,.5,1,1,a.energy,q,theme);return cv.toDataURL('image/png')};return ISMA_SONGS.map(s=>{const p=ISMA_SCENES[s.id],r=ISMA_RHYTHM[s.id],ss=r.sections,quiet=ss.find(x=>x[1]==='verse'&&x[0]>4)||ss.find(x=>x[1]!=='chorus'&&x[1]!=='climax'&&x[0]>4)||ss[0],strong=ss.filter(x=>x[1]==='chorus'||x[1]==='climax'),first=strong.find(x=>x[1]==='chorus')||strong[0]||ss[Math.floor(ss.length/2)],last=strong.filter(x=>x[1]==='chorus').at(-1)||strong.at(-1)||ss.at(-2)||first;const ts=[quiet[0]+.6,first[0]+.7,Math.min(r.duration-.1,last[0]+.7)];const frames=ts.map((t,i)=>img(p,t,i===0?0:i===1?.84:1));return {id:s.id,title:s.title,artist:s.artist,name:p.name,meaning:p.meaning,source:p.source,ts,phases:ts.map(t=>IsmaAtelier.score(s.id,t).phase),frames,motion:img(p,ts[0]+3,0),theme:img(p,ts[0],0,{main:'#ffd04d',dark:'#302010'})}})}''')
 assert len(result)==55 and not errs,errs
 b.close()
notes=json.loads((root/'soundtrack-detail-notes.json').read_text())
font='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf';f=ImageFont.truetype(font,14);h=ImageFont.truetype(font,22)
def im(v):return Image.open(io.BytesIO(base64.b64decode(v.split(',')[1]))).convert('RGB')
unique=set();motions=0;themes=0;climaxes=0
for r in result:
 a,b,c=map(im,r['frames']);unique.add(hashlib.sha256(a.tobytes()).hexdigest());motions+=a.tobytes()!=im(r['motion']).tobytes();themes+=a.tobytes()!=im(r['theme']).tobytes();climaxes+=a.tobytes()!=b.tobytes()
assert len(unique)==55 and motions==55 and climaxes==55,(len(unique),motions,climaxes)
for j,n in enumerate(['verso','coro','final']):
 tw,th=180,320;cw,ch=196,365;sheet=Image.new('RGB',(5*cw+16,11*ch+55),'#191521');d=ImageDraw.Draw(sheet);d.text((14,12),'ISMAMINT · 55 ESCENAS · '+n.upper(),font=h,fill='#f5e7ed')
 for i,r in enumerate(result):
  x=14+i%5*cw;y=52+i//5*ch;sheet.paste(im(r['frames'][j]).resize((tw,th),Image.Resampling.NEAREST),(x,y));label=r['id']+' · '+r['title'];d.text((x,y+th+4),label[:24],font=f,fill='#f5e7ed');d.text((x,y+th+23),f'{int(r["ts"][j]//60)}:{int(r["ts"][j]%60):02d} · {r["phases"][j]}',font=f,fill='#c0a8c4')
 sheet.save(out/('ISMAMINT_7_17_'+n+'.png'))
def esc(s):return html.escape(str(s or ''))
parts=['<!doctype html><html lang="es"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>ISMAMINT · Soundtrack 7.17</title><style>body{margin:0;background:#18131f;color:#f4e7ef;font:16px system-ui}header,main{max-width:1080px;margin:auto;padding:24px}h1{font-size:30px}h2{font-size:20px;margin-bottom:4px}small,p{color:#c7b3c8}article{border-top:1px solid #46384d;padding:20px 0}.frames{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px}figure{margin:0}img{width:100%;max-width:300px;height:auto;image-rendering:pixelated;border:1px solid #66516b}figcaption{font-size:13px;margin-top:6px}input{width:100%;box-sizing:border-box;padding:12px;background:#2d2335;color:white;border:1px solid #695470;font:inherit}a{color:#efabc9}.tag{color:#f7ce79}</style><header><h1>ISMAMINT · Soundtrack 7.17</h1><p>55 pistas. Capturas del motor real, sin superposición de interfaz. La intensidad de coro se fija para mostrar la composición; tiempos elegidos a partir del análisis rítmico existente, no detección vocal exacta.</p><input id="search" placeholder="Buscar canción o artista" aria-label="Buscar canción o artista"></header><main>']
for r in result:
 n=notes[r['id']];parts.append(f'<article><h2><span class="tag">{esc(r["id"])}</span> · {esc(r["title"])}</h2><small>{esc(r["artist"])}</small><p><b>{esc(n["style"])}</b> · {esc(n["detail"])}.</p><div class="frames">')
 for i,cap in enumerate(['Verso / reposo','Entrada de clímax','Clímax posterior']):
  t=r['ts'][i];parts.append(f'<figure><img loading="lazy" src="{r["frames"][i]}" alt="{esc(r["title"])}: {cap}"><figcaption>{cap} · {int(t//60)}:{int(t%60):02d}</figcaption></figure>')
 parts.append('</div></article>')
parts.append('</main><script>document.querySelector("#search").addEventListener("input",e=>{for(const a of document.querySelectorAll("article"))a.hidden=!a.textContent.toLowerCase().includes(e.target.value.toLowerCase())})</script></html>')
(out/'ISMAMINT_7_17_Catalogo.html').write_text(''.join(parts),encoding='utf8')
print(f'{len(unique)} distinct tracks; {motions} moving; {climaxes} changed climax; {themes} changed theme; no JS errors')
