from playwright.sync_api import sync_playwright
from pathlib import Path
root=Path(__file__).resolve().parents[1]/'app/src/main/assets'
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox']); page=b.new_page(); errors=[]; page.on('pageerror',lambda e:errors.append(str(e)))
 page.route('**/*',lambda route:route.fulfill(status=200,content_type='text/html',body='<html><body></body></html>'))
 page.goto('http://localhost:8765/'); page.evaluate("window.user='aurora';window.NativeGifts={profile:()=>user}")
 for name in ['gift-experience.js','gift-canvas.js','gift-core.js','gift-media.js','gift-sync.js','gift-backup.js']:page.add_script_tag(path=root/name)
 result=page.evaluate('''async()=>{const c=document.createElement('canvas');c.width=c.height=4;c.getContext('2d').fillRect(0,0,4,4);const blob=await new Promise(r=>c.toBlob(r));const a=await IsmaGiftMedia.importFile(new File([blob],'test.png',{type:'image/png'}));const g=IsmaGiftCore.create('aurora');g.canvas=IsmaGiftCanvas.normalize({objects:[{kind:'image',assetId:a.id,x:100,y:100}]});const raw=await IsmaGiftBackup.pack(g);const copy=await IsmaGiftBackup.restore(raw,IsmaGiftCore,'aurora');const newId=copy.canvas.objects[0].assetId;const all=await IsmaGiftMedia.list();user='ismael';const filtered=await IsmaGiftMedia.list();return {raw:raw.length,original:a.id,newId,copyId:copy.id,giftId:g.id,all:all.length,filtered:filtered.length,stored:(await IsmaGiftMedia.get(newId)).blob.size}}''')
 assert result['original']!=result['newId'] and result['copyId']!=result['giftId'] and result['all']==2 and result['filtered']==0 and result['stored']>0,result
 page.reload();page.evaluate("window.user='aurora';window.NativeGifts={profile:()=>user}")
 for name in ['gift-media.js','gift-sync.js']:page.add_script_tag(path=root/name)
 assert page.evaluate('async()=> (await IsmaGiftMedia.list()).length')==2
 assert not errors,errors;b.close();print('Gift backup and real browser IndexedDB reload OK')
