import numpy as np, subprocess, json, base64, pathlib, concurrent.futures
from scipy.signal import stft
root=pathlib.Path(__file__).resolve().parents[1]/'app/src/main/assets'
def run(p):
 raw=subprocess.check_output(['ffmpeg','-v','error','-i',str(p),'-f','f32le','-ac','1','-ar','32000','-']);x=np.frombuffer(raw,dtype=np.float32)
 f,t,z=stft(x,fs=32000,nperseg=3200,noverlap=1600,nfft=4096); mag=np.abs(z); channels=[]
 for a,b in [(35,220),(220,2100),(2100,15000),(35,15000)]:
  e=np.sqrt(np.sum(mag[(f>=a)&(f<b)]**2,axis=0)); mx=max(float(np.percentile(e,97)),1e-7); channels.append(np.clip(e/mx,0,1))
 flux=np.maximum(0,np.diff(np.log1p(mag*120),axis=1,prepend=np.log1p(mag[:,:1]*120))).mean(axis=0);channels.append(np.clip(flux/max(float(np.percentile(flux,97)),1e-7),0,1))
 q=np.round(np.stack(channels,axis=1)*255).astype(np.uint8);return p.stem,base64.b64encode(q.tobytes()).decode()
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as ex: data=dict(ex.map(run,sorted((root/'soundtrack').glob('s*.opus'))))
(root/'soundtrack-spectrum.js').write_text('window.ISMA_SPECTRUM='+json.dumps(data,separators=(',',':'))+';\n');print('analyzed',len(data))
