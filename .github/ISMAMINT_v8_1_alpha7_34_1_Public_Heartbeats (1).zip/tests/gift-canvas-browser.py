from playwright.sync_api import sync_playwright
from pathlib import Path
root=Path(__file__).resolve().parents[1]/'app/src/main/assets'
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox']);page=b.new_page(viewport={'width':360,'height':800},has_touch=True,is_mobile=True)
 errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.set_content('<meta name="viewport" content="width=device-width, initial-scale=1"><div id="root"></div><div id="preview"></div>')
 page.add_style_tag(path=root/'gift-studio.css');page.add_script_tag(path=root/'vendor/konva.min.js');page.add_script_tag(path=root/'gift-canvas.js')
 page.evaluate('''()=>{window.saved=null;let e=IsmaGiftCanvas.editor(null,v=>{window.saved=v;document.querySelector('#preview').replaceChildren(IsmaGiftCanvas.view(v))});document.querySelector('#root').append(e);e.open=true}''')
 page.get_by_label('Tipo de objeto').select_option('rect');page.get_by_role('button',name='+ Añadir objeto').click()
 page.get_by_text('Más personalización',exact=True).click();page.get_by_label('Relleno',exact=True).select_option('linear');page.get_by_label('Segundo color',exact=True).fill('#123456');page.get_by_label('Redondez',exact=True).evaluate("e=>{e.value=22;e.dispatchEvent(new Event('change'))}")
 assert page.evaluate('saved.objects[0].color2')=='#123456';assert page.evaluate('saved.objects[0].radius')==22
 page.get_by_role('button',name='Copiar apariencia').click();page.get_by_label('Tipo de objeto').select_option('circle');page.get_by_role('button',name='+ Añadir objeto').click();page.get_by_role('button',name='Pegar apariencia').click();assert page.evaluate('saved.objects[1].color2')=='#123456'
 page.get_by_role('button',name='Ocultar',exact=True).first.click();assert page.evaluate('saved.objects[1].hidden');page.get_by_role('button',name='Deshacer lienzo').click();assert not page.evaluate('saved.objects[1].hidden');page.get_by_role('button',name='Rehacer lienzo').click();assert page.evaluate('saved.objects[1].hidden')
 page.wait_for_function("document.querySelector('.gc-preview-img')?.src.startsWith('data:image/png')")
 assert page.locator('.gc-holder').evaluate('(e)=>e.scrollWidth<=e.clientWidth+1');assert not errors,errors
 page.evaluate("document.querySelector('#root').replaceChildren()")
 b.close();print('Gift Canvas browser OK')
