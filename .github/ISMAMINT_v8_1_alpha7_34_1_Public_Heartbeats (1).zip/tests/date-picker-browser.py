from playwright.sync_api import sync_playwright
from pathlib import Path
import re
root=Path(__file__).resolve().parents[1]/'app/src/main/assets'; h=(root/'index.html').read_text()
def scripts(m):
 f=root/m.group(1)
 return '<script>\n'+f.read_text().replace('</script','<\\/script')+'\n</script>' if f.is_file() else ''
h=re.sub(r'<script\s+src="([^"]+)"\s*>\s*</script>',scripts,h)
h=re.sub(r'<link\s+rel="stylesheet"\s+href="([^"]+)"\s*/?>',lambda m:'<style>'+ (root/m.group(1)).read_text()+'</style>' if (root/m.group(1)).is_file() else '',h)
pre='''<script>for(const name of ['localStorage','sessionStorage']){const m=new Map();Object.defineProperty(window,name,{value:{getItem:k=>m.has(k)?m.get(k):null,setItem:(k,v)=>m.set(k,String(v)),removeItem:k=>m.delete(k),clear:()=>m.clear(),key:i=>[...m.keys()][i],get length(){return m.size}}});}</script>'''
h=re.sub(r'<head[^>]*>',lambda m:m.group(0)+pre,h,count=1,flags=re.I)
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox']); page=b.new_page(viewport={'width':390,'height':844},is_mobile=True,has_touch=True,timezone_id='America/Mexico_City');page.route('**/*',lambda r:r.abort());errors=[];page.on('pageerror',lambda e:errors.append(str(e)));page.clock.install(time=__import__('datetime').datetime(2026,11,25,17,tzinfo=__import__('datetime').timezone.utc));page.set_content(h,wait_until='domcontentloaded',timeout=12000)
 page.evaluate("window.result='pending';void IsmaGiftDate.pick('2026-12-01',true).then(x=>window.result=x)")
 assert page.locator('.gd-controls').is_hidden()
 page.get_by_role('button',name='Programar entrega').click()
 assert page.locator('.gd-special').inner_text().find('13 meses juntos')>=0
 assert '15 meses desde que nos conocimos' in page.locator('.gd-special').inner_text()
 assert 'Ismael cumple 17 años' in page.locator('.gd-special').inner_text()
 page.get_by_role('button',name='03 · 13 meses juntos').click()
 assert page.get_by_label('Hora',exact=True).input_value()=='00'
 assert page.get_by_label('Minuto',exact=True).input_value()=='36'
 page.get_by_role('button',name='Confirmar programación').click()
 assert page.evaluate('result.release')==1796279760000, page.evaluate('result')
 page.evaluate("window.result='pending';void IsmaGiftDate.pick('2026-12-01',true).then(x=>window.result=x)")
 page.get_by_role('button',name='En este instante').click();assert page.evaluate('result.release')==0
 page.evaluate("window.result='pending';void IsmaGiftDate.pick('2026-12-01',true).then(x=>window.result=x)")
 page.get_by_role('button',name='Cancelar').click();assert page.evaluate('result') is None
 assert not errors,errors
 print('Special dates, timezone, immediate and cancellation OK'); b.close()
