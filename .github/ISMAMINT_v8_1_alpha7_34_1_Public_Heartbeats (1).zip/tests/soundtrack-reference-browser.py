from pathlib import Path
from playwright.sync_api import sync_playwright
import json
root=Path(__file__).resolve().parents[1]
a=root/'app/src/main/assets'
report=json.loads((root/'KARAOKE_ALIGNMENT_AUDIT.json').read_text())
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox']); page=b.new_page(); page.set_content('<div id="lyric"></div>')
 for f in ['soundtrack-lyrics.js','soundtrack-karaoke.js']:page.add_script_tag(path=a/f)
 result=page.evaluate('''()=>{let lines=0,words=0,est=0,invalid=0,tracks=0,group=0;const el=document.getElementById('lyric');for(const [id,item] of Object.entries(ISMA_LYRICS)){let track=0;for(let i=0;i<item.rows.length;i++){const row=item.rows[i];if(!row.text)continue;const tl=IsmaKaraoke.timeline(id,item.rows,i);if(!row.wordTiming){est++;continue}if(tl.mode!==row.wordTiming){invalid++;continue}if(tl.words.length!==row.words.length)throw Error(id+' token count');if(tl.start!==row.t||tl.parts.map(p=>p.text).join('')!==row.text)throw Error(id+' changed line');for(let j=0;j<tl.words.length;j++){const w=tl.words[j];if(!Number.isFinite(w.t)||w.end<=w.t||w.t<row.t-1e-7||w.end>Math.min(row.t+8,item.rows[i+1]?.t??row.t+4)+1e-6)throw Error(id+' bounds '+i);if(j&&w.t<tl.words[j-1].end-1e-8)throw Error(id+' overlap');words++}lines++;track++;if(tl.mode==='reference-chunk')group++;if(tl.words.length>1){IsmaKaraoke.mount(el,id,item.rows,i);let first=tl.words[0],last=tl.words.at(-1);IsmaKaraoke.update(el,id,(last.t+last.end)/2);if(el.querySelectorAll('.is-word').length!==1)throw Error(id+' last');IsmaKaraoke.update(el,id,(first.t+first.end)/2);if(el.querySelector('.is-word')!==el.querySelector('.sm-kw'))throw Error(id+' rewind')}}if(track)tracks++}return {lines,words,est,invalid,tracks,group}}''')
 print(result);assert result['invalid']==0;assert result['tracks']==47;assert result['lines']==sum(x['referenceLines'] for x in report.values());assert result['words']==sum(x['referenceWords'] for x in report.values());b.close()
