const assert=require('node:assert/strict'),C=require('../app/src/main/assets/heartbound-core'),B=require('../app/src/main/assets/heartmint-bosses');
const make=(stage,emit)=>C.create({stage,seed:44,profile:n=>B.profile(n,44),emit});
const tick=(g,n)=>{for(let i=0;i<n;i++)g.update(1/120)};
for(let n=1;n<=10000;n++){const r=C.route(n,44);assert.equal(r.type,n%5?'collect':'boss');assert.deepEqual(r,C.route(n,44));assert(r.goal>=1);if(n%5){assert.equal(r.enemies,n>=3&&((n-1)%5===2||n>=11&&(n-1)%5===3));}else for(const p of C.bossPlan(C.world(n),B.profile(C.world(n),44)))assert(C.pool[p.mode].includes(p.pattern));}
let events=[];let g=make(3,id=>events.push(id)),s=g.state,p=s.player;
assert(s.catch&&!s.boss);g.input.targetX=200;g.input.y=-1;tick(g,40);assert.equal(p.x,200);assert.equal(p.y,C.B.b-12);assert(!g.action());assert(!g.defense());
s.spawn=999;s.catch.nextHazard=999;s.catch.nextPower=999;tick(g,420);assert(s.enemies.length>0);const e=s.enemies[0];e.x=p.x;e.y=120;e.fire=100;e.hp=2;s.catch.enemyTimer=999;g.input.targetX=p.x;for(let i=0;i<4;i++){s.hearts.push({kind:'pink',x:p.x,y:p.y,vy:0,t:1});tick(g,1);}assert.equal(s.done,4);assert(s.shots.length>=2);tick(g,150);assert.equal(s.kills,1);assert(events.includes('enemy:kill'));assert(s.catch&&!s.boss&&p.y===C.B.b-12);assert(!g.action());
// Gold heart charges a shot immediately, normal enemy bullets respect catch shield.
s.enemies.push({type:C.enemyTypes[0],hp:1,x:p.x,y:120,t:0,fire:99});s.hearts.push({kind:'gold',x:p.x,y:p.y,vy:0,t:1});tick(g,1);assert(s.shots.some(x=>x.catchAuto));s.catch.shield=1;p.inv=0;s.bullets.push({x:p.x,y:p.y,vx:0,vy:0,t:1,r:3,age:0});const hp=s.health;tick(g,1);assert.equal(s.catch.shield,0);assert.equal(s.health,hp);
// Stage changes preserve horizontal control only until the boss.
g=make(3);s=g.state;g.input.targetX=190;tick(g,40);s.done=s.route.goal;tick(g,1);assert.equal(g.state.stage,4);assert(g.state.catch);assert.equal(g.state.player.x,190);assert.equal(g.input.targetX,190);g.state.done=g.state.route.goal;tick(g,1);assert.equal(g.state.stage,5);assert(g.state.boss&&!g.state.catch);assert.equal(g.input.targetX,null);
// Boss defeat restores the catcher. Keep actual counter logic.
g=make(5);s=g.state;for(let i=0;i<s.boss.plan.length;i++){s.boss.state='open';s.boss.challenge=null;s.boss.ready=false;s.boss.timer=10;s.mode='free';s.player.x=120;s.player.y=140;s.player.cd=0;assert(g.action());}assert.equal(g.state.stage,6);assert(g.state.catch&&!g.state.boss);assert.equal(g.state.player.y,C.B.b-12);assert(!g.action());
console.log('Catch-first: 10000 deterministic routes, automatic enemy shots, gold, shields, uninterrupted catcher, boss transition and return');
