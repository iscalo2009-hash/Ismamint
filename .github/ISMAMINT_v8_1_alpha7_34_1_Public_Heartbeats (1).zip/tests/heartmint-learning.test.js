const assert=require('node:assert/strict'),J=require('../app/src/main/assets/heartmint-journey.js'),B=require('../app/src/main/assets/heartmint-bosses.js');
for(const [id,n] of Object.entries(J.unlocks)){assert(!J.enabled(n-1,id));assert(J.enabled(n,id));assert(J.lessons.some(l=>l.level===n));}
assert.equal(J.difficulty(1).hazard,0);assert.equal(J.difficulty(1).enemies,0);assert.equal(J.difficulty(1).misses,Infinity);assert.equal(J.pickups(1),'');
let last=J.difficulty(1);
for(let n=1;n<=10000;n++){const d=J.difficulty(n);assert(d.fall>=last.fall&&d.fall<=4.45+1e-10);assert(d.interval<=last.interval&&d.interval>=13);assert(d.cap<=7&&d.enemies<=3);assert(d.hazard<=.27+1e-10);assert(d.wallGap>=3);assert(d.enemyInterval>=100&&d.eventInterval>=160);assert(d.bossHp>=last.bossHp&&d.bossHp<=166);last=d;const pool=J.arenaTypes(n);assert.equal(pool.includes(5),n>=12);assert.equal(pool.includes(6),n>=16);if(n%5===0){const raw=B.profile(n/5,321).hp;assert(J.bossHealth(n/5,raw)<=166);}}
for(const n of [1000000,1000000000,Number.MAX_SAFE_INTEGER-20]){const d=J.difficulty(n);assert(Number.isFinite(d.fall)&&d.bossHp<=166&&d.cap<=7);}
console.log('10000 difficulty stages, unlocks, arena pools, tutorial levels and late-game limits verified');
