from pathlib import Path
from playwright.sync_api import sync_playwright
import sys
new=Path(__file__).resolve().parents[1]/'app/src/main/assets';old=Path(sys.argv[1])
files=['soundtrack-data.js','soundtrack-presets.js','soundtrack-scenes.js','soundtrack-worlds.js','soundtrack-world-render.js','soundtrack-rhythm.js','soundtrack-atelier.js']
ids=[3,5,7,8,9,12,13,14,17,19,22,41,46,55]
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox']);results=[]
 for root in [old,new]:
  page=b.new_page();page.set_content('<canvas width="180" height="320"></canvas>')
  for f in files:page.add_script_tag(path=root/f)
  results.append(page.evaluate('''ids=>{const cv=document.querySelector('canvas'),c=cv.getContext('2d');return ids.map(i=>{const id='s'+String(i).padStart(2,'0'),p=ISMA_SCENES[id],dur=ISMA_RHYTHM[id].duration;return [dur*.08,dur*.34,dur*.67,dur*.92].flatMap(t=>[0,.6,1].map(q=>{c.clearRect(0,0,180,320);IsmaAtelier.paint(c,p,t,q,.7,.65);return cv.toDataURL()}))})}''',ids));page.close()
 b.close()
assert results[0]==results[1]
print('14 approved scenes: 168 pixel-identical render pairs')
