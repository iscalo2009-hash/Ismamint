from playwright.sync_api import sync_playwright
from pathlib import Path
import re
root=Path(__file__).resolve().parents[1]/'app/src/main/assets'
h=(root/'index.html').read_text()
h=re.sub(r'<script\s+src="([^"]+)"\s*>\s*</script>',lambda m:'<script>\n'+(root/m.group(1)).read_text().replace('</script','<\\/script')+'\n</script>' if (root/m.group(1)).is_file() else '',h)
h=re.sub(r'<link\s+rel="stylesheet"\s+href="([^"]+)"\s*/?>',lambda m:'<style>'+(root/m.group(1)).read_text()+'</style>' if (root/m.group(1)).is_file() else '',h)
pre="""<script>for(const name of ['localStorage','sessionStorage']){const m=new Map();Object.defineProperty(window,name,{value:{getItem:k=>m.has(k)?m.get(k):null,setItem:(k,v)=>m.set(k,String(v)),removeItem:k=>m.delete(k),clear:()=>m.clear(),key:i=>[...m.keys()][i],get length(){return m.size}}});}</script>"""
h=re.sub(r'<head[^>]*>',lambda m:m.group(0)+pre,h,count=1,flags=re.I)
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox']);page=b.new_page(viewport={'width':390,'height':844},is_mobile=True,has_touch=True);page.set_default_timeout(4500);errors=[];page.on('pageerror',lambda e:errors.append(str(e)));page.route('**/*',lambda r:r.abort());page.set_content(h,wait_until='domcontentloaded',timeout=12000);page.add_script_tag(path=root/'vendor/konva.min.js');page.wait_for_timeout(300)
 page.evaluate("""()=>{const items=new Map();let n=0;window.IsmaGiftMedia={list:async()=>[...items.values()],getProject:async id=>items.get(id)?.spriteProject||null,importFile:async(file,options={})=>{const image=await createImageBitmap(file);const a={id:'asset-'+(++n),name:file.name,width:image.width,height:image.height,blob:file,image,spriteProject:options.spriteProject};items.set(a.id,a);return a},image:async id=>items.get(id).image}}""")
 page.evaluate("document.querySelector('main').style.display='block';document.querySelector('#start').style.display='none';document.querySelector('#tabs').style.display='flex';document.querySelector('[data-root=explore]').click();document.querySelector('[data-explore-gifts]').click()")
 assert page.locator('#p15').evaluate("e=>e.classList.contains('on')");assert page.locator('#p15 #gift-studio').count()==1;assert page.locator('#p13 #gift-studio').count()==0
 page.get_by_role('button',name='Crear regalo').click();page.locator('.gc-holder canvas').first.wait_for();assert page.evaluate('IsmaGiftCore.read(localStorage)[0].visualOnly');assert page.locator('.gs-workbench').get_by_text('♫ Música',exact=True).count()==0;assert page.locator('.gs-work-tools').is_hidden();assert page.locator('.gp-viewport').bounding_box()['height']>200

 page.get_by_role('button',name='Formas',exact=True).click();page.get_by_role('button',name='Añadir Cuadro',exact=True).click();page.get_by_role('button',name='Formas',exact=True).click();page.get_by_role('button',name='Añadir Círculo',exact=True).click()
 page.evaluate("""()=>{let st=Konva.stages.filter(s=>s.container()?.isConnected).at(-1),a=st.find(n=>n.getAttr('gpIndex')===0)[0],b=st.find(n=>n.getAttr('gpIndex')===1)[0];a.position({x:90,y:90});b.position({x:91,y:200});b.fire('dragstart');b.fire('dragmove');if(Math.abs(b.x()-90)>.01)throw Error('Alignment '+b.x());b.fire('dragend')}""")
 assert page.evaluate('IsmaGiftCore.read(localStorage)[0].canvas.objects[1].x')==90
 page.evaluate("""()=>{const t=IsmaGiftCanvas.view({parallax:'px-forest-02',objects:[{kind:'rect',x:160,y:160,size:80}]},true);t.id='thumb-test';document.body.append(t)}""")
 page.locator('#thumb-test img[src]').wait_for(state='attached');assert page.locator('#thumb-test .gp-parallax-preview').count()==0;assert page.locator('#thumb-test img').evaluate('(n)=>n.naturalWidth')==160
 assert not errors,errors;print('Editor smart alignment, persistence and static 160px parallax thumbnail verified');b.close()
