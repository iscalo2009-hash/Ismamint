const assert=require('node:assert/strict');
const J=require('../app/src/main/assets/heartmint-journey.js');
for(let n=1;n<=10000;n++){
 const max=J.bossHealth(n,140);let hp=max;
 for(let ph=1;ph<=3;ph++){
  const q=J.bossPhase(n,ph),floor=J.phaseFloor(max,ph);
  const b={n,ph,max,hp,phaseAge:0,phaseClears:0};
  assert(q.frames>=480&&q.frames<=1080&&q.waves>=1&&q.waves<=2);
  b.hp-=J.phaseDamage(b,1000000);assert.equal(b.hp,floor);
  assert.equal(J.phaseDamage(b,1000000),0);
  b.phaseAge=q.frames;assert.equal(J.phaseDamage(b,1000000),0);
  b.phaseClears=q.waves;b.phaseAge=q.frames-1;assert.equal(J.phaseDamage(b,1000000),0);
  b.phaseAge=q.frames;b.hp-=J.phaseDamage(b,1000000);
  assert.equal(b.hp,ph===3?0:floor-1);hp=b.hp;
 }
 assert.equal(hp,0);assert(max<=166);
}
console.log('10000 bosses: phase gates, burst damage, minimum combat sequences and bounded HP verified');
