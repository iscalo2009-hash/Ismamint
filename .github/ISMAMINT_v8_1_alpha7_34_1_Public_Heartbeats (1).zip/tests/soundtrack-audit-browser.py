from pathlib import Path
from playwright.sync_api import sync_playwright
import json, sys
root=Path(__file__).resolve().parents[1]/'app/src/main/assets'
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage']); page=b.new_page(); errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.set_content('<canvas width="180" height="320"></canvas>')
 for f in ['soundtrack-data.js','soundtrack-presets.js','soundtrack-scenes.js','soundtrack-worlds.js','soundtrack-world-render.js','soundtrack-rhythm.js','soundtrack-atelier.js']:page.add_script_tag(path=root/f)
 report=page.evaluate('''()=>{const c=document.querySelector('canvas').getContext('2d',{willReadFrequently:true});const draw=(p,t,q,b)=>{c.clearRect(0,0,180,320);IsmaAtelier.paint(c,p,t,q,b,.6);return c.getImageData(0,0,180,320).data};const diff=(a,b)=>{let n=0;for(let i=0;i<a.length;i+=4)if(a[i]!==b[i]||a[i+1]!==b[i+1]||a[i+2]!==b[i+2])n++;return n};let tracks=ISMA_SONGS.map(s=>{const p=ISMA_SCENES[s.id],r=ISMA_RHYTHM[s.id],t=r.beats[Math.min(16,r.beats.length-1)]??60/r.bpm;const pulse=IsmaAtelier.rhythmPulse(s.id,t,true);return {id:s.id,bpm:r.bpm,confidence:r.confidence,beatTime:t,pulse,off:IsmaAtelier.rhythmPulse(s.id,t,false),differentPixels:diff(draw(p,t,.55,0),draw(p,t,.55,pulse)),stable:IsmaAtelier.rhythmPulse(s.id,t,true)===pulse}});let anchors=[];for(const [id,x,y,ww,hh] of [['s02',90,270,64,58],['s12',62,155,50,50],['s48',90,160,42,40]]){const p=ISMA_SCENES[id];let vals=[];for(const q of [0,.35,.7,1]){const a=draw(p,42,q,.6),idx=(y*180+x)*4;let minX=180,maxX=-1,minY=320,maxY=-1;for(let yy=y-Math.floor(hh/2);yy<=y+Math.floor(hh/2);yy++)for(let xx=x-Math.floor(ww/2);xx<=x+Math.floor(ww/2);xx++){let i=(yy*180+xx)*4;if(a[i]===a[idx]&&a[i+1]===a[idx+1]&&a[i+2]===a[idx+2]){minX=Math.min(minX,xx);maxX=Math.max(maxX,xx);minY=Math.min(minY,yy);maxY=Math.max(maxY,yy)}}vals.push({q,cx:(minX+maxX+1)/2,cy:(minY+maxY+1)/2,width:maxX-minX+1,height:maxY-minY+1})}anchors.push({id,x,y,vals})}return {tracks,anchors}}''')
 assert not errors, errors
 b.close()
for t in report['tracks']:
 assert t['pulse']>0 and t['off']==0 and t['stable'] and t['differentPixels']>0,t
for a in report['anchors']:
 for v in a['vals']:
  assert abs(v['cx']-a['x'])<=1 and abs(v['cy']-a['y'])<=1.5,(a['id'],v)
print('55/55 pistas responden al pulso temporal; 12 estados de corazones con centro estable:',report['anchors'])
if len(sys.argv)>1:Path(sys.argv[1]).write_text(json.dumps(report,indent=2))
