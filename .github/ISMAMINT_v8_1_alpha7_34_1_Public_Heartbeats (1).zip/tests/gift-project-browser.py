"""Real IndexedDB storage, simulated origin and no network requests."""
from pathlib import Path
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1]/'app/src/main/assets'
with sync_playwright() as p:
    b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
    page=b.new_page()
    page.route('https://ismamint.test/**',lambda r:r.fulfill(status=200,content_type='text/html',body='<!DOCTYPE html><html><body></body></html>'))
    page.goto('https://ismamint.test/',timeout=10000)
    page.add_script_tag(path=root/'gift-media.js')
    result=page.evaluate('''async()=>{let owner='ismael';window.IsmaGiftSync={profile:()=>owner};const cv=document.createElement('canvas');cv.width=cv.height=16;const ctx=cv.getContext('2d');ctx.fillStyle='#ff0000';ctx.fillRect(2,3,1,1);const d=ctx.getImageData(0,0,16,16).data;const blob=await new Promise(r=>cv.toBlob(r));const project={n:16,active:1,layers:[{name:'Base',visible:true,opacity:1,data:d},{name:'Superior',visible:false,opacity:.5,data:new Uint8ClampedArray(1024)}]};const a=await IsmaGiftMedia.importFile(new File([blob],'Sprite-test.png',{type:'image/png'}),{lossless:true,spriteProject:project});const saved=await IsmaGiftMedia.getProject(a.id);if(saved.layers[0].data[(3*16+2)*4]!==255||saved.active!==1||saved.layers[1].visible!==false||saved.layers[1].opacity!==.5)throw Error('Proyecto incorrecto');owner='aurora';if(await IsmaGiftMedia.getProject(a.id)!==null)throw Error('Proyecto disponible a otra cuenta');owner='ismael';return a.id}''')
    page.reload(timeout=10000);page.add_script_tag(path=root/'gift-media.js')
    assert page.evaluate('''async id=>{window.IsmaGiftSync={profile:()=> 'ismael'};const a=await IsmaGiftMedia.getProject(id);return a.layers.length===2&&a.layers[0].data[(3*16+2)*4]===255}''',result)
    print('IndexedDB actual: sprite project persisted after reload; account filter verified')
    b.close()
