from playwright.sync_api import sync_playwright
from pathlib import Path
import re
root=Path(__file__).resolve().parents[1]/'app/src/main/assets'; h=(root/'index.html').read_text()
def scripts(m):
 f=root/m.group(1)
 return '<script>\n'+f.read_text().replace('</script','<\\/script')+'\n</script>' if f.is_file() else ''
h=re.sub(r'<script\s+src="([^"]+)"\s*>\s*</script>',scripts,h)
h=re.sub(r'<link\s+rel="stylesheet"\s+href="([^"]+)"\s*/?>',lambda m:'<style>'+ (root/m.group(1)).read_text()+'</style>' if (root/m.group(1)).is_file() else '',h)
pre='''<script>for(const name of ['localStorage','sessionStorage']){const m=new Map();Object.defineProperty(window,name,{value:{getItem:k=>m.has(k)?m.get(k):null,setItem:(k,v)=>m.set(k,String(v)),removeItem:k=>m.delete(k),clear:()=>m.clear(),key:i=>[...m.keys()][i],get length(){return m.size}}});}</script>'''
h=re.sub(r'<head[^>]*>',lambda m:m.group(0)+pre,h,count=1,flags=re.I)
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox']); page=b.new_page(viewport={'width':390,'height':844},is_mobile=True,has_touch=True,timezone_id='America/Bogota');page.route('**/*',lambda r:r.abort());errors=[];page.on('pageerror',lambda e:errors.append(str(e)));page.set_content(h,wait_until='domcontentloaded',timeout=12000);page.wait_for_timeout(300)
 page.evaluate("document.querySelector('main').style.display='block';document.querySelector('#start').style.display='none'")
 assert page.evaluate('IsmaBoot.eventFor(new Date(2027,7,20,0)).type')=='cumple'
 assert '24 AÑOS' in page.evaluate('IsmaBoot.eventFor(new Date(2027,7,20,0)).label')
 before=page.evaluate("localStorage.getItem('aurora_theme2')")
 orig=page.evaluate("document.documentElement.style.getPropertyValue('--red')")
 page.evaluate("IsmaCelebration.showPreview('aurora')")
 assert page.locator('.ce-card').is_visible()
 assert page.locator('.ce-card').inner_text().startswith('✦')
 assert page.locator('.bd-label').inner_text().startswith('AURORA EDITION')
 page.locator('.bd-action').click()
 assert page.locator('.bd-cake').evaluate("el=>el.classList.contains('bd-blown')")
 for _ in range(4):page.locator('.bd-cake').click()
 assert '4:44' in page.locator('.bd-hint').inner_text()
 assert page.evaluate("localStorage.getItem('ismamint_birthday_v1')") is None
 assert page.evaluate("getComputedStyle(document.documentElement).getPropertyValue('--red').strip?.()||getComputedStyle(document.documentElement).getPropertyValue('--red').trim()")=='#ff8fc8'
 page.evaluate("IsmaCelebration.showPreview('ismael')")
 assert page.evaluate("getComputedStyle(document.documentElement).getPropertyValue('--red').trim()")=='#ffcb45'
 assert 'Ismael cumple' in page.locator('.ce-card').inner_text()
 assert page.locator('.bd-label').inner_text().startswith('YELLOW ZK')
 assert page.locator('.bd-action').is_enabled()
 page.locator('.ce-end').click()
 assert page.evaluate("!document.documentElement.hasAttribute('data-ce-preview')")
 assert page.evaluate("document.documentElement.style.getPropertyValue('--red')")==orig
 assert page.evaluate("localStorage.getItem('aurora_theme2')")==before
 assert page.evaluate("IsmaCelebration.actual()?.key===IsmaCelebration.state?.key")
 assert page.locator('#ms').count()==1
 assert not errors,errors
 # Real birthday simulation in independent browser page; no preview.
 actual=b.new_page(viewport={'width':390,'height':844},is_mobile=True,has_touch=True,timezone_id='America/Bogota');actual.route('**/*',lambda r:r.abort());actual.clock.install(time=__import__('datetime').datetime(2026,12,26,17,tzinfo=__import__('datetime').timezone.utc));actual_errors=[];actual.on('pageerror',lambda e:actual_errors.append(str(e)));actual.set_content(h,wait_until='domcontentloaded',timeout=12000)
 assert actual.locator('#start').get_attribute('data-birthday')=='ismael'
 assert 'Yellow ZK' in actual.locator('#bootDate').inner_text()
 actual.evaluate("document.querySelector('main').style.display='block';document.querySelector('#start').style.display='none'")
 assert actual.locator('.bd-action').is_enabled()
 actual.locator('.bd-action').click()
 for _ in range(4):actual.locator('.bd-cake').click()
 assert actual.evaluate("JSON.parse(localStorage.getItem('ismamint_birthday_v1'))['ismael:2026'].secret")
 actual.evaluate("IsmaCelebration.showPreview('aurora');IsmaCelebration.stopPreview()")
 assert actual.locator('.bd-action').is_disabled()
 assert actual.locator('.bd-hint').inner_text()=='4:44'
 assert not actual_errors,actual_errors
 print('Celebration and Birthday browser OK');b.close()
