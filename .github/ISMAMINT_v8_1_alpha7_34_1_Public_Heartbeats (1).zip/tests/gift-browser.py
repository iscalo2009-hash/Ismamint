from playwright.sync_api import sync_playwright
from pathlib import Path
import re
root=Path(__file__).resolve().parents[1]/'app/src/main/assets'; h=(root/'index.html').read_text()
def scripts(m):
 f=root/m.group(1)
 return '<script>\n'+f.read_text().replace('</script','<\\/script')+'\n</script>' if f.is_file() else ''
h=re.sub(r'<script\s+src="([^"]+)"\s*>\s*</script>',scripts,h)
h=re.sub(r'<link\s+rel="stylesheet"\s+href="([^"]+)"\s*/?>',lambda m:'<style>'+ (root/m.group(1)).read_text()+'</style>' if (root/m.group(1)).is_file() else '',h)
pre='''<script>for(const name of ['localStorage','sessionStorage']){const m=new Map();Object.defineProperty(window,name,{value:{getItem:k=>m.has(k)?m.get(k):null,setItem:(k,v)=>m.set(k,String(v)),removeItem:k=>m.delete(k),clear:()=>m.clear(),key:i=>[...m.keys()][i],get length(){return m.size}}});}</script>'''
h=re.sub(r'<head[^>]*>',lambda m:m.group(0)+pre,h,count=1,flags=re.I)
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox']); page=b.new_page(viewport={'width':390,'height':844},is_mobile=True,has_touch=True,timezone_id='America/Bogota');page.route('**/*',lambda r:r.abort());errors=[];page.on('pageerror',lambda e:errors.append(str(e)));page.set_content(h,wait_until='domcontentloaded',timeout=12000);page.wait_for_timeout(300)
 page.evaluate("document.querySelector('main').style.display='block';document.querySelector('#start').style.display='none';IsmaGiftStudio.open()")
 page.get_by_role('button',name='+ Nuevo regalo').click()
 page.get_by_label('Título',exact=True).fill('Una sorpresa')
 page.locator('#gift-studio').get_by_label('Mensaje',exact=True).fill('<script>literal</script>\nTe amo')
 page.get_by_label('Paleta',exact=True).select_option('night')
 page.get_by_label('Ocasión',exact=True).select_option('aurora')
 assert page.locator('.gs-preview').get_attribute('data-style')=='night'
 assert page.locator('.gs-letter').inner_text()=='<script>literal</script>\nTe amo'
 assert page.locator('.gs-letter script').count()==0
 page.get_by_role('button',name='Marcar como preparado').click()
 assert page.evaluate("IsmaGiftCore.read(localStorage)[0].status")=='ready'
 page.get_by_role('button',name='‹ Mis regalos').click()
 page.get_by_label('Preparar como').select_option('aurora')
 assert page.locator('.gs-item').count()==0
 page.get_by_label('Preparar como').select_option('ismael')
 page.locator('.gs-item').click()
 assert page.get_by_label('Título',exact=True).input_value()=='Una sorpresa'
 page.locator('#gift-studio').get_by_label('Mensaje',exact=True).fill('Actualizado')
 assert page.evaluate("IsmaGiftCore.read(localStorage)[0].status")=='draft'
 page.evaluate("IsmaCelebration.showPreview('aurora')")
 assert page.locator('.gs-ce-link').count()==0
 page.evaluate("IsmaCelebration.stopPreview()")
 # Reinitialize the DOM with the persisted store to simulate reload.
 stored=page.evaluate("localStorage.getItem(IsmaGiftCore.KEY)")
 page2=b.new_page(viewport={'width':390,'height':844},is_mobile=True,has_touch=True);page2.route('**/*',lambda r:r.abort());page2.on('pageerror',lambda e:errors.append(str(e)));page2.set_content(h,wait_until='domcontentloaded',timeout=12000)
 page2.evaluate("v=>localStorage.setItem(IsmaGiftCore.KEY,v)",stored)
 page2.evaluate("document.querySelector('main').style.display='block';document.querySelector('#start').style.display='none';IsmaGiftStudio.open()")
 page2.locator('.gs-item').click()
 assert page2.locator('#gift-studio').get_by_label('Mensaje',exact=True).input_value()=='Actualizado'
 page2.on('dialog',lambda d:d.accept());page2.get_by_role('button',name='Eliminar',exact=True).click()
 assert page2.evaluate('IsmaGiftCore.read(localStorage).length')==0
 assert not errors,errors
 print('Gift Studio browser OK');b.close()
