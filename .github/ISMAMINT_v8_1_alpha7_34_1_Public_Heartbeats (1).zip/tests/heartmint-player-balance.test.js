const assert=require('node:assert/strict'),J=require('../app/src/main/assets/heartmint-journey.js');
for(const n of [1,2,5,10,21,51,100,1000,1000000,Number.MAX_SAFE_INTEGER-20]){
 const d=J.difficulty(n),normal=J.pressure(n,5,0),hurt=J.pressure(n,2,2),critical=J.pressure(n,1,4);
 assert.equal(normal.cap,d.cap);assert.equal(normal.enemies,d.enemies);assert.equal(normal.hazard,1);assert.equal(normal.warning,0);
 assert(critical.cap<=hurt.cap&&hurt.cap<=normal.cap);assert(critical.enemies<=normal.enemies);assert(critical.hazard<hurt.hazard&&hurt.hazard<1);assert(critical.warning>=hurt.warning&&hurt.warning>0);assert(critical.recovery>=420&&critical.recovery<=720);assert(critical.event>=1&&critical.enemy>=1);
 const p=J.replayPerks(n,123);assert.deepEqual(p,J.replayPerks(n,123));for(const k of J.perks)assert(p[k.id]>=0&&p[k.id]<=k.cap);assert(Object.values(p).reduce((a,b)=>a+b,0)<=Math.floor((n-1)/5));
}
assert.equal(Object.values(J.replayPerks(1,123)).reduce((a,b)=>a+b,0),0);assert.equal(Object.values(J.replayPerks(6,123)).reduce((a,b)=>a+b,0),1);assert.equal(Object.values(J.replayPerks(1000000,123)).reduce((a,b)=>a+b,0),J.perks.reduce((a,k)=>a+k.cap,0));
assert(J.comboGrace(1)>J.comboGrace(10));assert(J.comboGrace(100,3)>J.comboGrace(100,0));
console.log('Player assistance, bounded replay perks and forgiving combos verified at early and extreme levels');
