const assert=require('node:assert/strict'),C=require('../app/src/main/assets/heartbound-core'),B=require('../app/src/main/assets/heartmint-bosses');
const make=()=>C.create({stage:5,seed:123,profile:n=>B.profile(n,123)});function incoming(g){for(let i=0;i<1500&&!g.state.boss.challenge;i++){g.state.player.inv=2;g.update(1/120);}assert(g.state.boss.challenge.incoming);g.state.player.inv=0;return g.state.boss.challenge;}
let g=make(),c=incoming(g),s=g.state;assert(c.note.y<c.points[0].y);for(let i=0;i<150&&s.boss.round===0;i++)g.update(1/120);assert.equal(s.health,4);assert.equal(s.boss.round,1);
g=make();c=incoming(g);s=g.state;g.input.x=1;for(let i=0;i<150&&s.boss.round===0;i++)g.update(1/120);assert.equal(s.health,5);assert.equal(s.boss.round,1);
g=make();c=incoming(g);s=g.state;while(c.time<c.flight-.08)g.update(1/120);assert(g.action());assert.equal(s.health,5);assert.equal(s.boss.round,1);console.log('Incoming note: impact, dodge and return verified');
