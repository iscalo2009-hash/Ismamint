const assert=require('node:assert/strict'),R=require('../app/src/main/assets/heartmint-release'),radio=require('../app/src/main/assets/soundtrack-radio');
const keys=Object.keys(radio.durations),d=radio.durations,cycle=keys.reduce((n,k)=>n+d[k],0),next=id=>keys[(keys.indexOf(id)+1)%keys.length];
assert.equal(keys.length,55);assert(keys.every(k=>d[k]>0));
let x=radio.advance(keys[0],10,d[keys[0]]+d[keys[1]]+5,keys,'ordered',next);assert.equal(x.id,keys[2]);assert(Math.abs(x.position-15)<1e-6);
x=radio.advance(keys[0],10,cycle*100+20,keys,'ordered',next);assert.equal(x.id,keys[0]);assert(Math.abs(x.position-30)<1e-6);
x=radio.advance(keys[0],10,d[keys[0]]*3+2,keys,'repeat',next);assert.equal(x.id,keys[0]);assert(Math.abs(x.position-12)<1e-6);
const reverse=[...keys].reverse(),n2=id=>reverse[(reverse.indexOf(id)+1)%reverse.length];x=radio.advance(reverse[0],0,cycle*50+d[reverse[0]]+1,reverse,'shuffle',n2);assert.equal(x.id,reverse[1]);assert(Math.abs(x.position-1)<1e-6);
const secrets=R.achievements.filter(a=>a.secret),p=R.read({getItem:()=>JSON.stringify({max:51,metrics:{best:23456},bossWins:{1:true}})});assert.equal(secrets.length,12);assert.equal(R.achievements.length,151);assert(secrets.every(a=>R.value(p,a.field)===0));p.metrics.secret_furra=1;assert.equal(R.value(R.read({getItem:()=>JSON.stringify(p)}),'secret_furra'),1);assert.equal(p.metrics.best,23456);
console.log('55 measured tracks; multiple tracks, 100 loops, repeat and persistent shuffle; 12 append-only secret achievements.');
