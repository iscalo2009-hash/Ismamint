from pathlib import Path
from playwright.sync_api import sync_playwright
import json, sys
root=Path(__file__).resolve().parents[1]/'app/src/main/assets'
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage']); page=b.new_page(); errs=[];page.on('pageerror',lambda e:errs.append(str(e)))
 page.set_content('<canvas width="180" height="320"></canvas>')
 for f in ['soundtrack-data.js','soundtrack-presets.js','soundtrack-scenes.js','soundtrack-worlds.js','soundtrack-world-render.js','soundtrack-rhythm.js','soundtrack-atelier.js']:page.add_script_tag(path=root/f)
 report=page.evaluate('''()=>{const c=document.querySelector('canvas').getContext('2d',{willReadFrequently:true});const draw=(p,t,q,b)=>{const start=performance.now();IsmaAtelier.paint(c,p,t,q,b,.6);const ms=performance.now()-start;return [c.getImageData(0,0,180,320).data,ms]};const diff=(a,b)=>{let n=0;for(let i=0;i<a.length;i+=4){if(a[i]!==b[i]||a[i+1]!==b[i+1]||a[i+2]!==b[i+2])n++}return n};return ISMA_SONGS.map(s=>{const p=ISMA_SCENES[s.id],r=ISMA_RHYTHM[s.id],segs=r.sections;const starts=[Math.max(.3,r.duration*.08),r.duration*.34,r.duration*.64,r.duration*.90];let ambient=[],climax=[],cost=[];for(const t of starts){for(const q of [0,.9]){let [prev,ms]=draw(p,t,q,0);cost.push(ms);let changed=0,max=0;for(let i=1;i<=8;i++){const [cur,ms]=draw(p,t+i/15,q,0);cost.push(ms);let d=diff(prev,cur);if(d>0)changed++;max=Math.max(max,d);prev=cur;}(q?climax:ambient).push({changed,max});}}return {id:s.id,ambient,climax,meanMs:cost.reduce((a,b)=>a+b,0)/cost.length,maxMs:Math.max(...cost)}})}''')
 assert not errs,errs
 b.close()
fail=[r['id'] for r in report if any(v['changed']<4 for v in r['ambient']+r['climax'])]
print('Low motion sample:',fail)
print('Minimum changed frame pairs:',min(x['changed'] for r in report for x in r['ambient']+r['climax']),'of 8')
print('Maximum of per-track mean canvas paint milliseconds:',round(max(r['meanMs'] for r in report),2))
if len(sys.argv)>1: Path(sys.argv[1]).write_text(json.dumps(report,indent=2))
assert not fail,fail
print('55/55 tracks animate within all four sampled intervals at fixed intensity, beat=0; no JS errors')
