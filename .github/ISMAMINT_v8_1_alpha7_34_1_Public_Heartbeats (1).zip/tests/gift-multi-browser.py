from playwright.sync_api import sync_playwright
from pathlib import Path
root=Path(__file__).resolve().parents[1]/'app/src/main/assets'
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox']); page=b.new_page(viewport={'width':360,'height':800},has_touch=True,is_mobile=True)
 errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.set_content('<meta name="viewport" content="width=device-width, initial-scale=1"><div id="root"></div>');page.add_style_tag(path=root/'gift-studio.css');page.add_script_tag(path=root/'vendor/konva.min.js');page.add_script_tag(path=root/'gift-canvas.js')
 page.evaluate('''()=>{let e=IsmaGiftCanvas.editor({objects:[{kind:'rect',x:80,y:100},{kind:'circle',x:140,y:160}]},v=>window.saved=v);document.querySelector('#root').append(e);e.open=true}''')
 page.get_by_role('button',name='Seleccionar todo').click();page.get_by_label('Color colectivo').fill('#123456');assert page.evaluate('saved.objects.every(o=>o.color==="#123456")')
 page.get_by_role('button',name='→',exact=True).click();assert page.evaluate('saved.objects.map(o=>o.x)')==[88,148]
 page.get_by_role('button',name='Alinear horizontalmente').click();assert page.evaluate('saved.objects.map(o=>o.y)')==[100,100]
 page.get_by_role('button',name='Agrupar selección').click();assert page.evaluate('saved.objects[0].group && saved.objects[0].group===saved.objects[1].group')
 page.get_by_text('Variaciones de color',exact=True).click();page.get_by_role('button',name='Cálido',exact=True).click();assert page.evaluate('saved.objects[0].color')=='#ffd04d'
 page.get_by_role('button',name='Duplicar selección').click();assert page.evaluate('saved.objects.length')==4
 page.get_by_role('button',name='Eliminar selección').click();assert page.evaluate('saved.objects.length')==2
 page.get_by_role('button',name='Deshacer lienzo').click();assert page.evaluate('saved.objects.length')==4
 page.get_by_label('Buscar capas').fill('Círculo');assert page.locator('.gc-layer').count()==2
 assert not errors,errors;b.close();print('Gift multi browser OK')
