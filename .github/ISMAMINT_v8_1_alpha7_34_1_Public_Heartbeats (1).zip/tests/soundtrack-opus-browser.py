from pathlib import Path
from playwright.sync_api import sync_playwright
import json,base64
root=Path(__file__).resolve().parents[1]/'app/src/main/assets'
songs=json.loads((root/'soundtrack-data.js').read_text().split('=',1)[1].strip().rstrip(';'))
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--autoplay-policy=no-user-gesture-required']);page=b.new_page();page.set_content('<html><body></body></html>');results=[]
 for s in songs:
  result=page.evaluate('''async({encoded,id})=>{const bytes=Uint8Array.from(atob(encoded),x=>x.charCodeAt(0));const url=URL.createObjectURL(new Blob([bytes],{type:'audio/ogg; codecs=opus'}));const a=new Audio();a.muted=true;a.src=url;const meta=await new Promise(resolve=>{const timer=setTimeout(()=>resolve(false),2500);a.addEventListener('loadeddata',()=>{clearTimeout(timer);resolve(true)},{once:true});a.addEventListener('error',()=>{clearTimeout(timer);resolve(false)},{once:true});a.load()});let playing=false;if(meta){try{await a.play();playing=!a.paused;a.pause()}catch{}}const r={id,meta,playing,duration:a.duration};a.removeAttribute('src');a.load();URL.revokeObjectURL(url);return r}''',{'id':s['id'],'encoded':base64.b64encode((root/s['file']).read_bytes()).decode()});results.append(result)
 b.close();print(json.dumps(results));assert all(x['meta'] and x['playing'] for x in results),results
 print('55/55 Opus decoded and playback started in Chromium through Blob')
