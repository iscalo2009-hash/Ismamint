from playwright.sync_api import sync_playwright
from pathlib import Path
root=Path(__file__).resolve().parents[1]/'app/src/main/assets'
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox']);page=b.new_page(reduced_motion='reduce');errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.set_content('<main id="root"></main><main id="preview"></main>')
 for name in ['vendor/konva.min.js','gift-experience.js','gift-canvas.js','gift-core.js']:page.add_script_tag(path=root/name)
 page.evaluate('''()=>{window.saved=[{id:'a',title:'Inicio',experience:{branchOnly:true,actions:[{kind:'add',label:'Recoger estrella',variable:'stars',value:1,once:true},{kind:'code',label:'Abrir secreto',condition:'stars',minimum:1,code:'444',target:'b'}]}},{id:'b',title:'Final',caption:'Hola',experience:{actions:[{kind:'message',label:'Leer',message:'Te quiero'}]}}];document.querySelector('#preview').append(IsmaGiftCanvas.sceneView(saved));document.querySelector('#root').append(IsmaGiftCanvas.sceneEditor(saved,v=>window.saved=v));document.querySelector('#root details').open=true}''')
 assert page.get_by_role('button',name='Abrir secreto').count()==0
 page.get_by_role('button',name='Recoger estrella').click();assert page.get_by_role('button',name='Recoger estrella').count()==0
 page.locator('#preview').get_by_label('Respuesta secreta',exact=True).fill('123');page.get_by_role('button',name='Abrir secreto').click();assert page.get_by_text('Inténtalo otra vez.').is_visible()
 page.locator('#preview').get_by_label('Respuesta secreta',exact=True).fill('444');page.get_by_role('button',name='Abrir secreto').click();assert page.locator('#preview h4').inner_text()=='Final'
 page.get_by_role('button',name='Leer',exact=True).click();assert page.get_by_text('Te quiero',exact=True).is_visible()
 page.get_by_text('Interacciones, decisiones y secretos',exact=True).click();page.get_by_role('button',name='+ Añadir interacción').click();assert page.evaluate('saved[0].experience.actions.length')==3
 assert not errors,errors;b.close();print('Experience browser OK')
