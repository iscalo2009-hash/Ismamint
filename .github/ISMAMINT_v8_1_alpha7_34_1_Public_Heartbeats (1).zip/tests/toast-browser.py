from playwright.sync_api import sync_playwright
from pathlib import Path
import re
root=Path(__file__).resolve().parents[1]/'app/src/main/assets'; h=(root/'index.html').read_text()
def scripts(m):
 f=root/m.group(1)
 return '<script>\n'+f.read_text().replace('</script','<\\/script')+'\n</script>' if f.is_file() else ''
h=re.sub(r'<script\s+src="([^"]+)"\s*>\s*</script>',scripts,h)
h=re.sub(r'<link\s+rel="stylesheet"\s+href="([^"]+)"\s*/?>',lambda m:'<style>'+ (root/m.group(1)).read_text()+'</style>' if (root/m.group(1)).is_file() else '',h)
pre='''<script>for(const name of ['localStorage','sessionStorage']){const m=new Map();Object.defineProperty(window,name,{value:{getItem:k=>m.has(k)?m.get(k):null,setItem:(k,v)=>m.set(k,String(v)),removeItem:k=>m.delete(k),clear:()=>m.clear(),key:i=>[...m.keys()][i],get length(){return m.size}}});}</script>'''
h=re.sub(r'<head[^>]*>',lambda m:m.group(0)+pre,h,count=1,flags=re.I)
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox']); page=b.new_page(viewport={'width':420,'height':850},is_mobile=True,has_touch=True);page.route('**/*',lambda r:r.abort());errors=[];page.on('pageerror',lambda e:errors.append(str(e)));page.set_content(h,wait_until='domcontentloaded',timeout=12000);page.wait_for_timeout(300)

 page.evaluate("document.querySelector('main').style.setProperty('display','block','important');TQ.length=0;tBusy=false;toast(ACH.find(a=>a.cat!=='se'))")
 page.wait_for_timeout(450);assert page.locator('#toast').is_visible();page.wait_for_timeout(3900);assert not page.locator('#toast').is_visible();assert page.locator('#toast').evaluate('e=>e.hidden && !e.children.length');assert not errors,errors;print('toast lifecycle OK');b.close()
