const assert=require('node:assert/strict'),C=require('../app/src/main/assets/heartbound-core'),B=require('../app/src/main/assets/heartmint-bosses');
const make=(stage,emit)=>C.create({stage,seed:123,profile:n=>B.profile(n,123),emit});const tick=(g,n)=>{for(let i=0;i<n;i++)g.update(1/120)};
for(const t of C.techniques){assert(!C.has(t.stage-1,t.id));assert(C.has(t.stage,t.id));}
let g=make(14),s=g.state;assert(s.catch&&!g.action()&&!g.defense());
// Flanking permits shots through the unprotected side, not through the shield.
function flank(x){const g=make(27),s=g.state;s.spawn=100;s.mode='free';s.enemies=[{type:C.enemyTypes[2],hp:3,x:120,y:150,t:0,fire:4},{type:C.enemyTypes[3],hp:3,x:90,y:150,t:0,fire:4}];s.shots.push({x,y:150,vx:x>120?-260:260,vy:0,t:1});tick(g,2);return s.enemies[0].hp;}
assert.equal(flank(130),2);assert.equal(flank(110),3);
assert.equal(C.route(1,123).goal,7);assert.equal(C.route(4,123).type,'collect');assert.equal(C.route(3,123).type,'collect');assert.equal(C.route(50,123).type,'boss');
// A kill during collection does not advance the heart counter.
g=make(11);s=g.state;s.spawn=100;s.enemies.push({type:C.enemyTypes[0],hp:1,x:120,y:150,t:0,fire:3});s.shots.push({x:120,y:150,vx:0,vy:0,t:1,r:3});tick(g,1);assert.equal(s.kills,1);assert.equal(s.done,0);

console.log('Finale: unlocks, catch-first route, flanking and collection counter verified; legacy standalone tests archived.');
