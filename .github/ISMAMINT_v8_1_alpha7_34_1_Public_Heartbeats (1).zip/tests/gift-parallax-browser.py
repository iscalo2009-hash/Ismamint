from playwright.sync_api import sync_playwright
from pathlib import Path
import re
root=Path(__file__).resolve().parents[1]/'app/src/main/assets'
h=(root/'index.html').read_text()
h=re.sub(r'<script\s+src="([^"]+)"\s*>\s*</script>',lambda m:'<script>\n'+(root/m.group(1)).read_text().replace('</script','<\\/script')+'\n</script>' if (root/m.group(1)).is_file() else '',h)
h=re.sub(r'<link\s+rel="stylesheet"\s+href="([^"]+)"\s*/?>',lambda m:'<style>'+(root/m.group(1)).read_text()+'</style>' if (root/m.group(1)).is_file() else '',h)
pre="""<script>for(const name of ['localStorage','sessionStorage']){const m=new Map();Object.defineProperty(window,name,{value:{getItem:k=>m.has(k)?m.get(k):null,setItem:(k,v)=>m.set(k,String(v)),removeItem:k=>m.delete(k),clear:()=>m.clear(),key:i=>[...m.keys()][i],get length(){return m.size}}});}</script>"""
h=re.sub(r'<head[^>]*>',lambda m:m.group(0)+pre,h,count=1,flags=re.I)
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox']);page=b.new_page(viewport={'width':390,'height':844},is_mobile=True,has_touch=True);page.set_default_timeout(4500);errors=[];page.on('pageerror',lambda e:errors.append(str(e)));page.route('**/*',lambda r:r.abort());page.set_content(h,wait_until='domcontentloaded',timeout=12000);page.add_script_tag(path=root/'vendor/konva.min.js');page.wait_for_timeout(300)
 page.evaluate("""()=>{const items=new Map();let n=0;window.IsmaGiftMedia={list:async()=>[...items.values()],getProject:async id=>items.get(id)?.spriteProject||null,importFile:async(file,options={})=>{const image=await createImageBitmap(file);const a={id:'asset-'+(++n),name:file.name,width:image.width,height:image.height,blob:file,image,spriteProject:options.spriteProject};items.set(a.id,a);return a},image:async id=>items.get(id).image}}""")
 page.evaluate("document.querySelector('main').style.display='block';document.querySelector('#start').style.display='none';IsmaGiftStudio.open()")
 page.get_by_role('button',name='+ Nuevo regalo').click();page.locator('.gc-holder canvas').first.wait_for();assert page.evaluate('IsmaGiftCore.read(localStorage)[0].visualOnly');assert page.locator('.gs-workbench').get_by_text('♫ Música',exact=True).count()==0;assert page.locator('.gs-work-tools').is_hidden();assert page.locator('.gp-viewport').bounding_box()['height']>350

 page.evaluate("""()=>{const P=IsmaGiftParallax, hashes=new Set();for(const item of P.catalog){const x=P.painter(item.id);const a=x.canvas.toDataURL();hashes.add(a);x.paint(5);if(a===x.canvas.toDataURL())throw Error('No motion '+item.id)}if(hashes.size!==100)throw Error('Duplicate background');}""")
 page.get_by_role('button',name='Aa Texto',exact=True).click();page.get_by_role('textbox',name='Texto',exact=True).fill('Texto propio');page.get_by_role('button',name='Listo',exact=True).click()
 page.get_by_role('button',name='◈ Fondo',exact=True).click();assert page.locator('.gp-parallax-gallery button').count()==10
 page.get_by_role('button',name='Bosques',exact=True).click();page.get_by_role('button',name='Bosque de jade',exact=True).click();assert page.evaluate("IsmaGiftCore.read(localStorage)[0].canvas.parallax")=='px-forest-02'
 page.get_by_role('button',name='Pausar movimiento',exact=True).click();assert page.evaluate("IsmaGiftCore.read(localStorage)[0].canvas.parallaxMotion") is False
 page.get_by_role('button',name='Activar movimiento',exact=True).click();assert page.evaluate("IsmaGiftCore.read(localStorage)[0].canvas.parallaxMotion") is True
 page.get_by_role('button',name='Cerrar',exact=True).last.click();page.wait_for_timeout(150);a=page.locator('.gp-holder canvas').first.evaluate('(c)=>c.toDataURL()');page.wait_for_timeout(900);assert a!=page.locator('.gp-holder canvas').first.evaluate('(c)=>c.toDataURL()')
 page.get_by_role('button',name='▶ Probar').click();page.locator('.gs-test-overlay .gc-preview-img[src]').wait_for();bg=page.locator('.gs-test-overlay .gp-parallax-preview');a=bg.evaluate('(c)=>c.toDataURL()');fg=page.locator('.gs-test-overlay .gc-preview-img').get_attribute('src');page.wait_for_timeout(900);assert a!=bg.evaluate('(c)=>c.toDataURL()');assert fg==page.locator('.gs-test-overlay .gc-preview-img').get_attribute('src');page.emulate_media(reduced_motion='reduce');page.wait_for_timeout(200);a=bg.evaluate('(c)=>c.toDataURL()');page.wait_for_timeout(500);assert a==bg.evaluate('(c)=>c.toDataURL()');page.emulate_media(reduced_motion='no-preference')
 page.get_by_role('button',name='‹ Volver a editar').click();page.get_by_role('button',name='✓ Finalizar').click();page.on('dialog',lambda d:d.accept());page.get_by_role('button',name='Entregar localmente').click();assert page.evaluate('IsmaGiftCore.inventory(localStorage).length')==1
 assert not errors,errors;print('100 unique animated backgrounds, gallery, save, pause, preview foreground, reduced motion, local delivery passed');b.close()
