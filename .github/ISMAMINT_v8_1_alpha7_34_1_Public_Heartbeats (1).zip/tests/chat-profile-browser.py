from playwright.sync_api import sync_playwright
from pathlib import Path
import re
root=Path(__file__).resolve().parents[1]/'app/src/main/assets'; h=(root/'index.html').read_text()
def scripts(m):
 f=root/m.group(1)
 return '<script>\n'+f.read_text().replace('</script','<\\/script')+'\n</script>' if f.is_file() else ''
h=re.sub(r'<script\s+src="([^"]+)"\s*>\s*</script>',scripts,h)
h=re.sub(r'<link\s+rel="stylesheet"\s+href="([^"]+)"\s*/?>',lambda m:'<style>'+ (root/m.group(1)).read_text()+'</style>' if (root/m.group(1)).is_file() else '',h)
pre='''<script>for(const name of ['localStorage','sessionStorage']){const m=new Map();Object.defineProperty(window,name,{value:{getItem:k=>m.has(k)?m.get(k):null,setItem:(k,v)=>m.set(k,String(v)),removeItem:k=>m.delete(k),clear:()=>m.clear(),key:i=>[...m.keys()][i],get length(){return m.size}}});}</script>'''
h=re.sub(r'<head[^>]*>',lambda m:m.group(0)+pre,h,count=1,flags=re.I)
mock="""<script>window.profileCalls=[];window.NativeChat=new Proxy({saveProfile(...a){profileCalls.push(a)}},{get:(t,k)=>k in t?t[k]:(()=>{})});</script>"""
h=h.replace(pre,pre+mock,1)
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox']);page=b.new_page(viewport={'width':390,'height':844});page.route('**/*',lambda r:r.abort());errors=[];page.on('pageerror',lambda e:errors.append(str(e)));page.set_content(h,wait_until='domcontentloaded',timeout=12000)
 page.evaluate("document.querySelector('main').style.setProperty('display','block','important');document.querySelector('#start').style.display='none';IsmaChat.receive(JSON.stringify({type:'session',value:'MCbwjlCpBnhTHxfQTuvcOVWLN3w2'}));document.querySelector('#chat-profile-menu').click()")
 import base64
 png=base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+/kF0AAAAASUVORK5CYII=')
 page.locator('#chat-v2-sheet input[type=file]').set_input_files({'name':'avatar.png','mimeType':'image/png','buffer':png});page.get_by_text('Imagen preparada.',exact=True).wait_for(timeout=5000)
 save=page.get_by_role('button',name='Guardar perfil');save.click();assert not save.is_enabled();assert page.evaluate('profileCalls[0][2].startsWith("data:image/jpeg;base64,")');assert page.locator('#chat-v2-overlay').is_visible()
 page.evaluate("IsmaChat.receive(JSON.stringify({type:'profileError',value:'Acceso denegado'}))");assert save.is_enabled();assert page.locator('.isma-profile-status').inner_text()=='Acceso denegado';save.click();page.evaluate("IsmaChat.receive(JSON.stringify({type:'profileSaved',value:true}))");assert page.locator('#chat-v2-overlay').is_hidden();assert not errors,errors;b.close();print('Profile save acknowledgement and retry OK')
