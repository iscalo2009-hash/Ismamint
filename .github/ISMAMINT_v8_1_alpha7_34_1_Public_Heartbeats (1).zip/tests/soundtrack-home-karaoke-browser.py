from playwright.sync_api import sync_playwright
from pathlib import Path
import re
root=Path(__file__).resolve().parents[1]/'app/src/main/assets'; h=(root/'index.html').read_text()
def scripts(m):
 f=root/m.group(1)
 return '<script>\n'+f.read_text().replace('</script','<\\/script')+'\n</script>' if f.is_file() else ''
h=re.sub(r'<script\s+src="([^"]+)"\s*>\s*</script>',scripts,h)
h=re.sub(r'<link\s+rel="stylesheet"\s+href="([^"]+)"\s*/?>',lambda m:'<style>'+ (root/m.group(1)).read_text()+'</style>' if (root/m.group(1)).is_file() else '',h)
pre='''<script>for(const name of ['localStorage','sessionStorage']){const m=new Map();Object.defineProperty(window,name,{value:{getItem:k=>m.has(k)?m.get(k):null,setItem:(k,v)=>m.set(k,String(v)),removeItem:k=>m.delete(k),clear:()=>m.clear(),key:i=>[...m.keys()][i],get length(){return m.size}}});}</script>'''
h=re.sub(r'<head[^>]*>',lambda m:m.group(0)+pre,h,count=1,flags=re.I)

mock="""<script>
const realNow=Date.now.bind(Date);window.radioTestOffset=0;Date.now=()=>realNow()+window.radioTestOffset;
window.Audio=class extends EventTarget{constructor(){super();this.paused=true;this.currentTime=0;this.duration=0;this.readyState=0;this.volume=1;this.error=null;}load(){this.paused=true;this.currentTime=0;this.duration=window.IsmaRadio?.durations[(this.src||'').match(/(s\\d+)\\.(?:opus|mp3)/)?.[1]]||180;this.readyState=1;queueMicrotask(()=>this.dispatchEvent(new Event('loadedmetadata')));}play(){this.paused=false;this.dispatchEvent(new Event('play'));return Promise.resolve();}pause(){this.paused=true;this.dispatchEvent(new Event('pause'));}};
localStorage.setItem('ismamint_music_prefs',JSON.stringify({id:'s01',mode:'ordered',enabled:true,position:10}));
</script>"""
h=h.replace(pre,pre+mock,1)
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox']);page=b.new_page(viewport={'width':420,'height':850},is_mobile=True,has_touch=True);page.route('**/*',lambda r:r.abort());errors=[];page.on('pageerror',lambda e:errors.append(str(e)));page.set_content(h,wait_until='domcontentloaded',timeout=12000);page.wait_for_timeout(250)
 page.evaluate('IsmaMusic.start()');page.wait_for_timeout(100);assert page.evaluate('IsmaMusic.state().id')=='s01';assert page.evaluate('IsmaMusic.state().playing');assert abs(page.evaluate('IsmaMusic.state().time')-10)<.1

 page.evaluate("document.querySelector('main').style.setProperty('display','block','important');document.querySelector('.tabs button[data-p=p1]').click()")
 page.evaluate("IsmaMusic.select('s03')");page.wait_for_timeout(150);page.evaluate("IsmaMusic.seek(ISMA_LYRICS.s03.rows.find(x=>x.text).t+.2)");page.wait_for_timeout(300);print('Home integration',page.evaluate("({track:IsmaMusic.state().id,playing:IsmaMusic.state().playing,background:document.querySelector('.sm-director-back')?.classList.contains('on'),karaoke:document.querySelector('.sm-lyric')?.classList.contains('sm-karaoke'),active:document.querySelectorAll('.sm-lyric .is-word').length,panel:document.querySelector('#p1').classList.contains('on')})"));assert page.evaluate("document.querySelector('.sm-director-back').classList.contains('on')&&document.querySelector('.sm-lyric.sm-karaoke')&&document.querySelector('#p1').classList.contains('on')");assert not errors,errors;b.close()
