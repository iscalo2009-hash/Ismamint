const assert=require('node:assert/strict');
const H=require('../app/src/main/assets/heartmint-bosses.js');
const names=['FEID','JUSTIN BIEBER','LA DISTANCIA','SEVEN','CELOS'];
let signatures=new Set(),patterns=new Set(),count=0;
for(let run=0;run<6;run++)for(let n=1;n<=1000;n++){
 const p=H.profile(n,run);assert.deepEqual(p,H.profile(n,run));
 if(n<=5)assert.equal(p.name,names[n-1]);
 assert(p.hp>0&&p.sprite.every(r=>r.length===14));signatures.add(JSON.stringify(p.music));p.patterns.forEach(x=>patterns.add(x));
 for(let phase=1;phase<=3;phase++)for(let index=0;index<9;index++){
  const w=H.wave(p,phase,index,(n*73+index*11)%200+20);assert(w.shots.length>0&&w.warning>=35);
  for(const s of w.shots){assert(s.lane<w.start||s.lane>=w.start+w.width);assert(Math.abs(s.x-w.safe)-s.drift>=24);assert(s.speed<=4.5);}count++;
 }
}
assert.equal(patterns.size,12);assert.equal(signatures.size,6000);
assert(H.profile(1000000,3).hp>H.profile(1000,3).hp);
console.log(`6000 profiles, ${count} waves, ${patterns.size} attack families, ${signatures.size} score profiles`);
for(let run=0;run<6;run++){
 const reunion=H.profile(10,run);assert.equal(reunion.name,'EXES MALVADOS');assert.equal(reunion.trio.length,3);
 reunion.trio.forEach((e,i)=>{const solo=H.profile(7+i,run);assert.equal(solo.name,'EX MALVADO '+(i+1));for(const k of ['name','col','sprite','patterns','movement'])assert.deepEqual(solo[k],e[k]);assert.deepEqual(solo.music.motif,e.music.motif);assert.deepEqual(reunion.music.medley[i].motif,solo.music.motif);for(let phase=1;phase<=3;phase++)for(let j=0;j<30;j++){const w=H.wave({...reunion,patterns:e.patterns},phase,j,120);assert(e.patterns.includes(w.type));assert(w.shots.every(s=>s.lane<w.start||s.lane>=w.start+w.width));}});
 assert(!H.profile(6,run).trio);assert(!H.profile(11,run).trio);
}
console.log('Ex trilogy: solo identities, shared sprites, attacks and medley verified');
const themesSeen=new Set(), silhouettes=new Set(),rarities=[0,0,0,0];
for(let run=0;run<20;run++)for(let n=11;n<=500;n++){
 const p=H.profile(n,run);themesSeen.add(p.theme);silhouettes.add(p.shape);rarities[p.rarity]++;
 assert(p.name.includes(p.theme.toUpperCase()));assert(/^#[0-9a-f]{6}$/i.test(p.col));assert(/^#[0-9a-f]{6}$/i.test(p.accent));assert.equal(p.sprite.length,14);assert(p.sprite.every(row=>/^[0-4]{14}$/.test(row)));
 if(n%25===0){assert(p.special);assert(p.rarity>=2);}if(n%100===0)assert.equal(p.rarity,3);
}
assert.equal(H.profile(1,0).col,'#39ed65');assert.equal(H.profile(4,0).col,'#ff303e');assert(themesSeen.size>=14);assert(silhouettes.size>=10);
console.log('Alpha 9:',themesSeen.size,'themes,',silhouettes.size,'silhouettes, rarity counts',rarities);
