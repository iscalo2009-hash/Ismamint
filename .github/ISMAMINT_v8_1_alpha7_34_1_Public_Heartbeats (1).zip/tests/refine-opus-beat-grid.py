from pathlib import Path
import json,base64,numpy as np
from scipy.ndimage import gaussian_filter1d
root=Path(__file__).resolve().parents[1]; a=root/'app/src/main/assets'; audit=root/'OPUS_AUDIO_AUDIT.json'
def load(p):return json.loads(p.read_text().split('=',1)[1].rstrip().rstrip(';'))
reports=json.loads(audit.read_text()); data=load(a/'soundtrack-spectrum.js'); rhythm=load(a/'soundtrack-rhythm.js')
for row in reports:
 id=row['id']; r=rhythm[id]; v=np.frombuffer(base64.b64decode(data[id]),np.uint8).reshape(-1,5)/255.; y=v[:,4]+.4*np.maximum(0,np.diff(v[:,0],prepend=v[0,0])); y=y-gaussian_filter1d(y,12); n=2**int(np.ceil(np.log2(len(y)*16))); f=np.fft.rfftfreq(n,.05)*60; power=np.abs(np.fft.rfft(y*np.hanning(len(y)),n)); prior=row['bpm_old']; valid=(f>prior*.94)&(f<prior*1.06); score=power+.4*np.interp(2*f,f,power)+.15*np.interp(3*f,f,power); idx=np.where(valid)[0][np.argmax(score[valid])]; sal=float(score[idx]/(np.median(score[valid])+1e-9)); bpm=round(float(f[idx]),2) if sal>=3 else prior; period=60/bpm; t=np.arange(len(v))*.05; phases=np.arange(0,period,.01); strength=np.maximum(0,v[:,4]-.2)+.4*np.maximum(0,np.diff(v[:,0],prepend=v[0,0])); phase=float(phases[np.argmax([np.sum(strength*np.exp(-((np.mod(t-g+period/2,period)-period/2)/.065)**2)) for g in phases])]); r['bpm']=bpm;r['beats']=[round(float(x),3) for x in np.arange(phase,r['duration'],period)];row['bpm_new']=bpm;row['tempo_peak_to_median']=round(sal,2);row['tempo_estimated']=True
(a/'soundtrack-rhythm.js').write_text('window.ISMA_RHYTHM='+json.dumps(rhythm,separators=(',',':'))+';\n');audit.write_text(json.dumps(reports,ensure_ascii=False,indent=2))
