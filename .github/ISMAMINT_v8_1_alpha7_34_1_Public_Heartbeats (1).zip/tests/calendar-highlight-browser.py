from playwright.sync_api import sync_playwright
from pathlib import Path
import re
root=Path(__file__).resolve().parents[1]/'app/src/main/assets'; h=(root/'index.html').read_text()
def scripts(m):
 f=root/m.group(1)
 return '<script>\n'+f.read_text().replace('</script','<\\/script')+'\n</script>' if f.is_file() else ''
h=re.sub(r'<script\s+src="([^"]+)"\s*>\s*</script>',scripts,h)
h=re.sub(r'<link\s+rel="stylesheet"\s+href="([^"]+)"\s*/?>',lambda m:'<style>'+ (root/m.group(1)).read_text()+'</style>' if (root/m.group(1)).is_file() else '',h)
pre='''<script>for(const name of ['localStorage','sessionStorage']){const m=new Map();Object.defineProperty(window,name,{value:{getItem:k=>m.has(k)?m.get(k):null,setItem:(k,v)=>m.set(k,String(v)),removeItem:k=>m.delete(k),clear:()=>m.clear(),key:i=>[...m.keys()][i],get length(){return m.size}}});}</script>'''
h=re.sub(r'<head[^>]*>',lambda m:m.group(0)+pre,h,count=1,flags=re.I)
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox']);page=b.new_page(viewport={'width':390,'height':844},is_mobile=True,has_touch=True,timezone_id='America/Bogota');page.route('**/*',lambda r:r.abort());errors=[];page.on('pageerror',lambda e:errors.append(str(e)));page.clock.install(time=__import__('datetime').datetime(2026,11,25,17,tzinfo=__import__('datetime').timezone.utc));page.set_content(h,wait_until='domcontentloaded',timeout=12000)
 page.evaluate('IsmaCalendar.open()');assert page.locator('.r2-cal [data-date="2026-11-03"]').get_attribute('data-occasion')=='anniversary';assert page.locator('.r2-cal [data-date="2026-11-11"]').get_attribute('data-occasion')=='monthly';page.evaluate("document.querySelector('.r2-calhead button:last-child').click()");assert page.locator('.r2-cal [data-date="2026-12-26"]').get_attribute('data-occasion')=='ismael';assert page.locator('.r2-cal [data-date="2026-12-25"]').get_attribute('data-occasion')=='occasion';page.evaluate("document.querySelector('[data-date=\"2026-12-26\"]').click()");assert '17 años' in page.locator('.r2-event').first.inner_text() or '17 años' in page.locator('.r2-sheet').inner_text();assert page.locator('.r2-cal [data-date="2026-12-26"]').get_attribute('aria-pressed')=='true';page.evaluate("(()=>{const f=document.querySelector('.r2-sheet select');f.value='achievement';f.onchange()})()");assert page.locator('.r2-cal [data-importance]').count()==0;assert not errors,errors;print('Calendar priority, birthday, annual and monthly events, selection and filter OK');b.close()
