// Run with: node tests/rebirth-core.test.js
const assert=require('node:assert/strict');
require('../app/src/main/assets/rebirth-core.js');
const {time,events,navigation}=globalThis.IsmaCore;
const a=1757566800000,b=Date.UTC(2025,10,3,6,36),z=18000000;
time.configure(a,b,z);
assert.equal(time.elapsed(a,a+1234),1234);assert.equal(time.days(a,a+86400000),1);
assert.deepEqual(time.breakdown(b,b-1),[0,0,0,0,0]);
assert.deepEqual(time.breakdown(a,Date.UTC(2025,9,11,5)),[1,0,0,0,0]);
assert.deepEqual(time.breakdown(b,Date.UTC(2025,11,3,6,35)),[0,29,23,59,0]);
assert.equal(time.colombiaDate(Date.UTC(2026,0,1,4,59)),'2025-12-31');
assert.equal(time.colombiaDate(Date.UTC(2026,0,1,5)),'2026-01-01');
const t=time.snapshot(b+86400000);assert.equal(t.together.days,1);assert.equal(t.known.ms,b+86400000-a);assert.equal(time.snapshot(t.now),t);
let seen=0;const unsubscribe=events.on('test',()=>seen++);events.emit('test',{});unsubscribe();events.emit('test',{});assert.equal(seen,1);
let loads=0;events.setCalendarProvider(()=>{loads++;return [{title:'test'}]});events.calendar(2026,0);events.calendar(2026,0);assert.equal(loads,1);events.emit('achievements:changed',{});events.calendar(2026,0);assert.equal(loads,2);
navigation.changed('p13');navigation.changed('p5');assert.equal(navigation.group('p5'),'us');assert.equal(navigation.back(),'p13');navigation.changed('p13');assert.equal(navigation.back(),'p1');navigation.changed('p1');assert.equal(navigation.quiet(),false);assert.equal(navigation.back(),null);
navigation.changed('p11');navigation.changed('p7');navigation.changed('p12');assert.equal(navigation.back(),'p11');navigation.changed('p11');assert.equal(navigation.back(),'p1');
console.log('Rebirth Core: all assertions passed');
