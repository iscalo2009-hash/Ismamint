const assert=require('node:assert/strict');const {due}=require('../app/src/main/assets/gift-arrival.js');
const now=1000,items=[{id:'future',release:1001,created:0},{id:'opened',release:10,opened:true},{id:'immediate',release:0,created:10},{id:'due',release:1000,created:20},{id:'invalid',release:NaN}];
assert.deepEqual(due(items,now).map(x=>x.id),['immediate','due']);assert.deepEqual(due(items,1001).map(x=>x.id),['immediate','due','future']);assert.deepEqual(due(null,now),[]);console.log('Gift arrival queue: immediate, scheduled, opened and invalid metadata');
