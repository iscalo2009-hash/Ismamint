const assert=require('node:assert/strict'),C=require('../app/src/main/assets/heartbound-core'),B=require('../app/src/main/assets/heartmint-bosses'),A=require('../app/src/main/assets/heartmint-audio');
assert.equal(C.patterns.length,118);assert.equal(new Set(C.patterns).size,118);assert.equal(Object.keys(C.attackCatalog).length,96);assert.equal(Object.keys(C.catchHazards).length,112);
const signatures=new Map();for(const m of Object.values(C.attackCatalog)){
 assert(C.pool[m.mode].includes(m.id));assert(A.recipes['attack:expanded:'+m.family]);
 const g=C.create({stage:50,seed:821,profile:n=>B.profile(n,821)});g.state.boss.plan=[{mode:m.mode,pattern:m.id}];g.state.boss.members=null;
 let count=0,seen=new Set(),signature=[];for(let i=0;i<120*7;i++){const s=g.state;if(s.boss?.state==='open'||s.stage!==50)break;s.player.inv=2;g.update(1/120);for(const q of [...s.bullets,...s.lasers])if(!seen.has(q)){seen.add(q);count++;signature.push([i,Math.round(q.x||0),Math.round(q.y||0),Math.round(q.vx||0),Math.round(q.vy||0),q.axis||'',q.bounce||0,q.home||0,q.r||0]);}assert(s.bullets.length<=64);assert(s.lasers.length<=12);}
 assert(count>0,m.id+' empty');const key=JSON.stringify(signature);if(signatures.has(key))console.log('identical observed sample',signatures.get(key),m.id);signatures.set(key,m.id);
}
const selected=new Set();for(let i=1;i<=1000;i++){for(const r of C.bossPlan(i,B.profile(i,44),44)){assert(C.pool[r.mode].includes(r.pattern));selected.add(r.pattern);}}
assert(C.patterns.every(k=>selected.has(k)),'not all 118 attacks selected: '+C.patterns.filter(k=>!selected.has(k)));assert.equal(signatures.size,96);
const hazards=new Set();for(let seed=1;seed<=30;seed++){let g=C.create({stage:44,seed,emit:id=>{if(id.startsWith('catch:warn:'))hazards.add(id.split(':').pop());}});g.state.route.goal=9999;for(let i=0;i<120*35;i++){g.state.player.inv=2;g.update(1/120);assert(g.state.catch.obstacles.length<=4);}}
assert(hazards.size>=12);for(const k of hazards)assert(A.recipes['catch:warn:'+k]);
console.log('Century: all 96 attacks emitted real threats; distinct sampled trajectories:',signatures.size,'; all 118 selected in 1000 boss plans; obstacles generated: '+hazards.size+'.');
