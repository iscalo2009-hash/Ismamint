const assert=require('node:assert/strict');
const A=require('../app/src/main/assets/heartmint-audio.js');
const B=require('../app/src/main/assets/heartmint-bosses.js');
const arena=require('../app/src/main/assets/heartmint-arena.js');
const J=require('../app/src/main/assets/heartmint-journey.js');
for(const name of Object.keys(B.labels))for(const k of ['warn:','attack:'])assert(A.recipes[k+name]);
for(let i=0;i<arena.names.length;i++)for(const k of ['arena:warn:','arena:fire:'])assert(A.recipes[k+i]);
for(const w of J.weapons)assert(A.recipes['weapon:'+w.id]);
for(const e of Object.keys(J.enemies))assert(A.recipes['enemy:'+e]);
for(const k of 'mwtsqp')assert(A.recipes['power:'+k]);
for(const [id,r] of Object.entries(A.recipes))for(const [type,a,b,d,v,delay] of r){assert(['square','triangle','sawtooth','sine','noise'].includes(type),id);assert([a,b,d,v,delay].every(Number.isFinite),id);assert(a>0&&b>0&&d>=.025&&v>0&&delay>=0,id);}
for(let n=1;n<=1000;n++){const p=B.profile(n,123).music;for(let bar=0;bar<8;bar++)assert(A.phrase(p,bar).every(Number.isFinite));assert.deepEqual(A.phrase(p,0),A.phrase(p,0));}
assert.notDeepEqual(A.phrase(A.profile(1),0),A.phrase(A.profile(1),5));
// Minimal WebAudio graph simulation for lifecycle and polyphony invariants.
const param=()=>({value:0,setValueAtTime(){},linearRampToValueAtTime(){},exponentialRampToValueAtTime(){},setTargetAtTime(){},cancelScheduledValues(){}});
const node=()=>({gain:param(),frequency:param(),Q:param(),pan:param(),threshold:param(),ratio:param(),attack:param(),release:param(),connect(){},disconnect(){},start(){},stop(){}});
const ctx={state:'running',currentTime:0,sampleRate:8000,createGain:node,createDynamicsCompressor:node,createOscillator:node,createBufferSource:node,createBiquadFilter:node,createStereoPanner:node,createBuffer:(_,n)=>({getChannelData:()=>new Float32Array(n)})};
const e=A.createEngine(()=>({ctx,master:node(),fx:node(),hidden:false}));const i={stg:1,cb:30,lv:5,phase:1};e.tick(i,true);assert(e.debug().running);assert(e.debug().voices>0);assert(e.cue('heart'));assert(!e.cue('heart'));for(const id of Object.keys(A.recipes))e.cue(id);assert(e.debug().voices<=64);e.stop();assert.equal(e.debug().voices,0);assert(!e.debug().running);const beat=e.debug().beat;e.tick(i,true);assert(e.debug().beat>beat);e.reset();assert.equal(e.debug().beat,0);assert(e.bossCue(B.profile(1,44).music));assert(e.rhythmSync(.4,0));ctx.currentTime=.02;e.tick({...i,rhythmPeriod:.4},true);assert.equal(e.debug().tempo,150);assert(e.debug().voices<=64);e.stop();assert.equal(e.debug().voices,0);
console.log(Object.keys(A.recipes).length+' sound recipes; all weapons, enemies, powers, 22 attack families, 1000 boss scores, voice cap and lifecycle verified');
