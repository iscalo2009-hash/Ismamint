from playwright.sync_api import sync_playwright
from pathlib import Path
root=Path(__file__).resolve().parents[1]/'app/src/main/assets'
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox']);page=b.new_page(viewport={'width':360,'height':800}); errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.set_content('<section id="p13"></section>');page.evaluate('''()=>{let m=new Map();Object.defineProperty(window,'localStorage',{value:{getItem:k=>m.get(k)??null,setItem:(k,v)=>m.set(k,v)}});window.account='ismael';window.IsmaGiftSync={profile:()=>account,list:async()=>[{id:'one',created:1,release:0,opened:false,favorite:true},{id:'two',created:2,release:Date.now()+999999,opened:false,favorite:false}]};window.IsmaCelebration={actual:()=>null};window.IsmaCore={events:{on(){}}}}''')
 page.add_style_tag(path=root/'gift-studio.css')
 for name in ['gift-core.js','gift-studio.js']:page.add_script_tag(path=root/name)
 page.get_by_role('button',name='Abrir Gift Studio').click();assert page.get_by_label('Preparar como').count()==0
 page.get_by_role('button',name='Inventario',exact=True).click();page.get_by_text('Regalo programado',exact=True).wait_for();page.get_by_label('Filtrar inventario conectado').select_option('favorite');assert page.get_by_text('Regalo programado',exact=True).count()==0
 page.get_by_label('Filtrar inventario conectado').select_option('scheduled');page.get_by_text('Regalo programado',exact=True).wait_for();assert page.get_by_text('Regalo sin abrir',exact=False).count()==0
 assert not errors,errors;b.close();print('Gift final browser OK')
