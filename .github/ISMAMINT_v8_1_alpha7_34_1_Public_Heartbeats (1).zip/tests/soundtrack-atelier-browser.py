from pathlib import Path
from playwright.sync_api import sync_playwright
from PIL import Image,ImageDraw,ImageFont
import io,base64,hashlib,time
root=Path(__file__).resolve().parents[1]/'app/src/main/assets'
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage']);page=b.new_page(viewport={'width':390,'height':844});errs=[];page.on('pageerror',lambda e:errs.append(str(e)))
 page.set_content('<canvas id="c" width="360" height="640"></canvas>')
 for f in ['soundtrack-data.js','soundtrack-presets.js','soundtrack-scenes.js','soundtrack-worlds.js','soundtrack-world-render.js','soundtrack-atelier.js']:page.add_script_tag(path=root/f)
 res=page.evaluate('''()=>{const c=document.querySelector('canvas'),x=c.getContext('2d'),arr=[];for(const s of ISMA_SONGS){const p=ISMA_SCENES[s.id],frames=[];for(const [k,t] of [['verse',10],['verse',13],['climax',10]]){x.clearRect(0,0,360,640);IsmaDirector.draw(x,k,p,t,1,.5,1,1,.75);frames.push(c.toDataURL())}arr.push({id:s.id,title:s.title,frames})}return arr}''')
 assert len(res)==55 and not errs,errs
 hashes=set();thumbs=[];frames2=[]
 for entry in res:
  f=[base64.b64decode(v.split(',')[1]) for v in entry['frames']];assert f[0]!=f[1],f'No movement {entry["id"]}';assert f[0]!=f[2],f'No climax change {entry["id"]}';hashes.add(hashlib.sha256(f[0]).hexdigest());im=Image.open(io.BytesIO(f[0])).convert('RGB');assert len(im.getcolors(200000))>12,entry['id'];thumbs.append((entry,im));frames2.append((entry,Image.open(io.BytesIO(f[2])).convert('RGB')))
 assert len(hashes)==55
 def gallery(items,path):
  cols=5;tw=180;th=320;cw=tw+14;ch=th+34;sheet=Image.new('RGB',(cols*cw+14,11*ch+40),'#171321');d=ImageDraw.Draw(sheet);font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',11);titlefont=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',18);d.text((14,10),'ISMAMINT · SOUNDTRACK ATELIER · 55 ESCENAS',font=titlefont,fill='#ffffff')
  for i,(entry,im) in enumerate(items):
   x=14+(i%cols)*cw;y=40+(i//cols)*ch;sheet.paste(im.resize((tw,th),Image.Resampling.NEAREST),(x,y));label=entry['id']+' · '+entry['title'];d.text((x,y+th+5),label[:27],font=font,fill='#f1d8e6')
  sheet.save(path)
 import sys
 if len(sys.argv)>1:
  gallery(thumbs,sys.argv[1]);gallery(frames2,sys.argv[1].replace('.png','_climax.png'))
 print('55/55 browser canvas: individual frames, animation, distinct climax; no JS errors');b.close()
