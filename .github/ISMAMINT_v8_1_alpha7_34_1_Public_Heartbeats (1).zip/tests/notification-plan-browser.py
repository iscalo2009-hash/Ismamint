from playwright.sync_api import sync_playwright
from pathlib import Path
import re
root=Path(__file__).resolve().parents[1]/'app/src/main/assets'; h=(root/'index.html').read_text()
def scripts(m):
 f=root/m.group(1)
 return '<script>\n'+f.read_text().replace('</script','<\\/script')+'\n</script>' if f.is_file() else ''
h=re.sub(r'<script\s+src="([^"]+)"\s*>\s*</script>',scripts,h)
h=re.sub(r'<link\s+rel="stylesheet"\s+href="([^"]+)"\s*/?>',lambda m:'<style>'+ (root/m.group(1)).read_text()+'</style>' if (root/m.group(1)).is_file() else '',h)
pre='''<script>for(const name of ['localStorage','sessionStorage']){const m=new Map();Object.defineProperty(window,name,{value:{getItem:k=>m.has(k)?m.get(k):null,setItem:(k,v)=>m.set(k,String(v)),removeItem:k=>m.delete(k),clear:()=>m.clear(),key:i=>[...m.keys()][i],get length(){return m.size}}});}</script>'''
pre+= '''<script>localStorage.setItem('aurora_notif2',JSON.stringify({on:1,ach:1,events:1,daily:1,smart:1}));window.noticeOpts={messages:true,pulses:true,gifts:true,receipts:true,messagesAllowed:true,pulsesAllowed:true,giftsAllowed:true,receiptsAllowed:true};window.Android={hasNotificationPermission:()=>true,noticeCategories:()=>JSON.stringify(noticeOpts),setNoticeCategory:(k,v)=>noticeOpts[k]=v,deliveredNoticeIds:()=>JSON.stringify(window.delivered||[]),noticeDelivered:id=>(window.delivered||[]).includes(String(id)),reconcileNotifications:p=>(window.plan=JSON.parse(p),true),canScheduleExactAlarms:()=>true};</script>'''
h=re.sub(r'<head[^>]*>',lambda m:m.group(0)+pre,h,count=1,flags=re.I)
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 import datetime
 for zone,month_hour,daily_hour in [('America/Bogota',6,21),('America/Mexico_City',6,22)]:
  page=b.new_page(viewport={'width':390,'height':844},is_mobile=True,has_touch=True,timezone_id=zone);page.route('**/*',lambda r:r.abort());errors=[];page.on('pageerror',lambda e:errors.append(str(e)));page.clock.install(time=datetime.datetime(2026,11,26,8,tzinfo=datetime.timezone.utc));page.set_content(h,wait_until='domcontentloaded',timeout=12000)
  page.evaluate('window.__refreshNotificationUi()');plan=page.evaluate('window.plan');assert plan,errors
  import json
  ids=[x['id'] for x in plan];assert len(ids)==len(set(ids)) and len(ids)<=400
  birth=[x for x in plan if x['kind']=='occasion' and 'cumpleaños' in x['text'].lower()];assert len(birth)==1,birth
  assert birth[0]['wall']=='2026-12-26T09:00:00'
  daily=next(x for x in plan if x['kind']=='daily');assert daily['wall'].endswith('T16:44:00');assert datetime.datetime.fromtimestamp(daily['ts']/1000,datetime.timezone.utc).hour==daily_hour
  rel=next(x for x in plan if x['kind']=='occasion' and 'meses juntos' in x['title']);assert rel['wall']=='';assert datetime.datetime.fromtimestamp(rel['ts']/1000,datetime.timezone.utc).hour==month_hour
  assert page.locator('#ntLiveT button').count()==4
  page.evaluate("document.querySelector('#ntLiveT button:nth-child(2)').click()");assert page.evaluate('noticeOpts.pulses')==False and page.evaluate('noticeOpts.messages')==True
  page.evaluate('(id)=>window.delivered=[String(id)]',birth[0]['id']);page.evaluate('window.__refreshNotificationUi()');assert birth[0]['id'] not in [x['id'] for x in page.evaluate('window.plan')]
  page.evaluate("document.querySelector('#ntT [data-k=events]').click()");assert all(x['kind'] not in ['occasion','occasion_pre'] for x in page.evaluate('window.plan'))
  assert not errors,errors
  print(zone,'recurring occasions, local 4:44, anchored months, dedup and independent toggles OK');page.close()
 b.close()
