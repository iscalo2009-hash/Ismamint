from playwright.sync_api import sync_playwright
from pathlib import Path
import re
root=Path(__file__).resolve().parents[1]/'app/src/main/assets'; h=(root/'index.html').read_text()
def scripts(m):
 f=root/m.group(1)
 return '<script>\n'+f.read_text().replace('</script','<\\/script')+'\n</script>' if f.is_file() else ''
h=re.sub(r'<script\s+src="([^"]+)"\s*>\s*</script>',scripts,h)
h=re.sub(r'<link\s+rel="stylesheet"\s+href="([^"]+)"\s*/?>',lambda m:'<style>'+ (root/m.group(1)).read_text()+'</style>' if (root/m.group(1)).is_file() else '',h)
pre='''<script>for(const name of ['localStorage','sessionStorage']){const m=new Map();Object.defineProperty(window,name,{value:{getItem:k=>m.has(k)?m.get(k):null,setItem:(k,v)=>m.set(k,String(v)),removeItem:k=>m.delete(k),clear:()=>m.clear(),key:i=>[...m.keys()][i],get length(){return m.size}}});}</script>'''
h=re.sub(r'<head[^>]*>',lambda m:m.group(0)+pre,h,count=1,flags=re.I)
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox']); page=b.new_page(viewport={'width':420,'height':850},is_mobile=True,has_touch=True);page.route('**/*',lambda r:r.abort());errors=[];page.on('pageerror',lambda e:errors.append(str(e)));page.set_content(h,wait_until='domcontentloaded',timeout=12000);page.wait_for_timeout(300)

 page.evaluate("document.querySelector('main').style.setProperty('display','block','important');document.querySelector('.tabs button[data-p=p4]').click();cfg.vib=true;window.hap=[];Object.defineProperty(navigator,'vibrate',{configurable:true,value:p=>{hap.push(p);return true}});GAME.progress().max=5;GAME.start(4)")
 page.wait_for_timeout(250)
 rect=lambda:page.locator('#gc').bounding_box()
 a=rect();assert a and a['y']>=0 and a['y']+a['height']<=850,a
 assert page.evaluate("document.body.classList.contains('hm-session')&&document.documentElement.classList.contains('hm-session')")
 page.evaluate("window.scrollTo(0,900)");page.wait_for_timeout(50);assert page.evaluate('window.scrollY')==0
 assert page.evaluate("IsmaFeel.gamePulse(16,2)");page.wait_for_timeout(70)
 assert page.evaluate("IsmaFeel.gamePulse([48,35,45],4)");assert not page.evaluate("IsmaFeel.gamePulse(16,2)");assert page.evaluate('hap.length')>=2
 page.evaluate('GAME.start(5)');page.wait_for_timeout(250);bb=rect();assert all(abs(a[k]-bb[k])<1 for k in ['x','y','width','height']),(a,bb)
 page.evaluate('GAME.pause()');page.wait_for_timeout(100);cc=rect();assert all(abs(bb[k]-cc[k])<1 for k in ['x','y','width','height']),(bb,cc)
 page.evaluate('GAME.map()');page.wait_for_timeout(100);assert not page.evaluate("document.body.classList.contains('hm-session')")
 page.wait_for_timeout(200);page.evaluate("hap.length=0;document.querySelector('.hb-gallery summary').click()");page.wait_for_timeout(80);assert page.evaluate('hap.length')>=1
 assert not errors,errors;print('stable playfield',a,bb,cc,'haptics, priority, lock and map release OK');b.close()
