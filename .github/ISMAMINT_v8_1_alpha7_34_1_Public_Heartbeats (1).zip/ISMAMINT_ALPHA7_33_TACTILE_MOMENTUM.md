# Alpha 7.33 — Tactile Momentum
Base: Alpha 7.32. Cambios en rebirth-feel.js, heartbound-core.js, heartbound-app.js, heartbound-ui.js y heartbound.css.

## Respuesta táctil
- El coordinador existente cubre botones, enlaces, controles semánticos, desplegables, selectores y casillas, incluyendo chat, regalos y menús del juego. Evita duplicar las vibraciones de acciones existentes y respeta cfg.vib, la preferencia táctil y la del juego.
- No vibra por cada movimiento de dedo o trazo de dibujo. Recogida rosa 16 ms; dorado 18/18 pausa/24 ms; verde 16/30 pausa/22 ms. Prioridades superiores para escudo, daño, jefe y fin de partida; las recogidas no cortan patrones prioritarios. Las recogidas demasiado próximas pueden fusionarse/omitirse por el límite temporal.
- Se usa el puente Android.vibrate existente, con navigator.vibrate como alternativa en navegador.

## Juego
- Velocidad objetivo de caída: 125–204 a 150–241 unidades/s (antes de ayuda dinámica). Intervalo de aparición base de .38–.21 a .32–.17 s; aceleración suavizada entre niveles.
- Desplazamiento de recogida 760 a 980 unidades/s; combate libre 158 a 183; gravedad horizontal 145 a 165. Se conservan penalización de rosas perdidos, corazones dorados opcionales y continuidad de niveles normales.
- Entrada de jefe desde recogida de 2.65 s: posición horizontal conservada, restos visuales de corazones se desvanecen, cuenta atrás y aviso en el campo, ataque inicial retrasado; protección y controles de habilidades desactivados durante la entrada. Inicio directo de jefe 1.1 s. Se conservan los patrones, logros y combate existente.
- Campo de juego en viewport fijo, bloqueo de desplazamiento y anclaje durante sesión, altura estable del HUD, mismo tamaño de campo al cambiar de modo. Pausa permite desplazarse por ajustes y restablece scroll al continuar. Navegación principal vuelve al salir al mapa.

## Pruebas
- node --test tests/*.test.js: 49/49.
- heartbound-browser-smoke.py: pasa (antes del ajuste menor final de guardas; nueva prueba posterior también pasa).
- heartmint-tactile-browser.py: pasa con viewport 420x850, rectángulo x15 y155 390x520 idéntico en recogida, jefe y pausa; bloqueo de scroll y liberación al mapa; vibración simulada y prioridades.
- heartmint-tactile-flow.test.js: verifica espera de jefe, ausencia de daño durante entrada, conservación de posición y aumento de velocidad.
- No se compiló APK ni se probó motor háptico físico. Las duraciones dependen del hardware y ajustes de Android; no se garantiza la sensación exacta ni FPS físicos. No se cambian Firebase, audio, logros, regalos o firma.
