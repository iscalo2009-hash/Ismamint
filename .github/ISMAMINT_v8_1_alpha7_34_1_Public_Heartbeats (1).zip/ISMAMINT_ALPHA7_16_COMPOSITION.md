# ISMAMINT 8.1 · Alpha 7.16 — Scene Logic

## A. Directriz maestra

1. **Contexto primero.** La letra, los créditos vocales y las referencias verificadas del videoclip o álbum definen el concepto. No confundir interpretación artística con un hecho sobre la canción. Conservar los archivos originales.
2. **Coherencia espacial.** Dibujar entorno, arquitectura, soporte, objeto e iluminación en ese orden. Evitar duplicados, líneas sin función, elementos flotantes fuera de su medio, y reflejos que atraviesen marcos. Los objetos reales tienen soporte; los elementos metafóricos se integran en un lugar o símbolo identificable.
3. **Lectura visual.** Priorizar un protagonista visual, silueta, contraste local, proporciones y espacios de separación. Usar luces de su fuente al receptor y texturas localizadas. No sacrificar la legibilidad de la interfaz.
4. **Clímax continuo.** Una composición por fotograma, interpolación de intensidad en 24 pasos. Los mismos objetos evolucionan con la música: una puerta se abre, un portal se expande, una ventana se ilumina, un matraz burbujea. Evitar la superposición de dos escenas completas. Los efectos flotantes aleatorios se retiran; los acentos contextuales existentes de la interfaz se mantienen. No hay flashes de pantalla completa.
5. **Identidad musical.** Las referencias al deseo se plasman en la ambientación, la estética retro, las comunicaciones y la iluminación; sin figuras humanas o imágenes explícitas. Kasane Teto original es la excepción visual y permanece inmóvil.
6. **Integración.** Pixel art de 180×320, render a 15 Hz, caché limitada a cuatro lienzos, relación de aspecto uniforme y fondo de relleno oscuro. Se conservan los ajustes de intensidad, el tema personal, el corazón rosa y amarillo, el movimiento reducido y los bloqueos de pantalla.

## B. Dirección de las 55 canciones

Los contextos y créditos parten del dossier Alpha 7.14 y las letras locales (53 pistas). Las referencias nuevas aparecen identificadas; no se han verificado nuevamente los 55 videoclips ni todas las portadas. Dopamina es una metáfora provisional del título; Tú y Yo no tiene LRC local. Los diseños son originales, no fotogramas copiados.

### s01 · Esclava - Remix — Bryant Myers, Anuel AA, Anonimus, Almighty
- Voz: Voces masculinas alternadas, trap grave.
- Contexto: Encuentro clandestino, trap nocturno.
- Objetos y composición: Fachada de motel al lado de la calle, persianas en su ventana y coche estacionado.
- Clímax: Se encienden las ventanas y el letrero; luces del coche sobre el asfalto.
- Evitar: Persianas cruzando todo el paisaje o coche flotante.
- Fuente anterior: https://www.musica.com/anuel/esclava-remix-ft-bryant-myers-anonimus-almighty/analisis-cancion
- Portada: Portada no verificada. 

### s02 · Feel It (From “Invincible”) — d4vd
- Voz: d4vd, voz melódica y funk.
- Contexto: Flechazo en lenguaje de cómic de Invincible.
- Objetos y composición: Tres viñetas con separación física: cielo, ciudad y símbolo de energía.
- Clímax: Las viñetas cambian de color y el rayo central se expande dentro de su marco.
- Evitar: Rayos que crucen los marcos sin propósito.
- Fuente anterior: https://www.universalmusic.ca/2024/03/27/d4vd-debuts-new-song-feel-it-from-the-original-series-invincible/
- Portada: Portada no verificada. 

### s03 · SOLO POR VOS — Trueno
- Voz: Trueno, rap melódico.
- Contexto: Elegir a alguien, sol y luna.
- Objetos y composición: Cordillera, horizonte y carretera hacia la luz.
- Clímax: El sol baja hacia el horizonte y el cielo se vuelve dorado; la carretera recibe el reflejo.
- Evitar: Astros duplicados y postes en la carretera.
- Fuente anterior: https://www.cifraclub.com/trueno/solo-por-vos/letra/
- Portada: Portada no verificada. 

### s04 · Hace Mucho Tiempo — Arcángel
- Voz: Arcángel, voz nasal melódica.
- Contexto: Espera y encuentro largamente imaginado.
- Objetos y composición: Reloj en pared, tres fotografías sobre aparador y lámpara.
- Clímax: Se ilumina la fotografía central y la lámpara calienta el interior.
- Evitar: Fotos suspendidas o proyector sobre objetos.
- Fuente anterior: https://www.musica.com/arcangel/hace-mucho-tiempo/analisis-cancion
- Portada: Portada no verificada. 

### s05 · OJALA — Milo j, Bhavi
- Voz: Milo j y Bhavi, dos voces urbanas.
- Contexto: Acompañar a alguien vulnerable.
- Objetos y composición: Casa bajo lluvia, paraguas cerrado apoyado junto a la puerta, jardín.
- Clímax: La ventana y el porche se encienden y la lluvia disminuye.
- Evitar: Paraguas gigante sin soporte o luz que cubra la casa.
- Fuente anterior: https://www.musica.com/milo-j/ojala-ft-bhavi/analisis-cancion
- Portada: Portada no verificada. 

### s06 · Can't Wait — Doja Cat
- Voz: Doja Cat, rap y canto.
- Contexto: Compromiso, hogar rural y vida compartida.
- Objetos y composición: Casa con jardín, valla, dos arañas pequeñas en alero (Scarlet).
- Clímax: Las ventanas se iluminan y florece el jardín.
- Evitar: Telarañas enormes en el cielo.
- Fuente anterior: https://music.apple.com/us/song/1707932018
- Portada: Dos arañas nacaradas, Scarlet. https://pitchfork.com/reviews/albums/doja-cat-scarlet/

### s07 · Agora Hills — Doja Cat
- Voz: Doja Cat, rap susurrado y canto.
- Contexto: Mostrar el vínculo, estética rosa liminal.
- Objetos y composición: Habitación rosa con teléfono en mesita y fotos en la pared.
- Clímax: El teléfono y el neón del dormitorio brillan; aparecen dos mensajes en la pantalla.
- Evitar: Fotos y sobres suspendidos sobre calles.
- Fuente anterior: https://readdork.com/track/doja-cat-agora-hills-2024
- Referencia adicional: https://uproxx.com/music/doja-cat-agora-hills/
- Portada: Dos arañas nacaradas, Scarlet. https://pitchfork.com/reviews/albums/doja-cat-scarlet/

### s08 · Mountains — Sia, Diplo, Labrinth, LSD
- Voz: Sia y Labrinth; producción LSD.
- Contexto: Devoción que mueve montañas, LSD psicodélico.
- Objetos y composición: Cordillera por planos con arco cromático en el cielo.
- Clímax: Picos se elevan y arco iris gana bandas; la luz se filtra por el valle.
- Evitar: Montañas superpuestas sobre el arco o círculos sin función.
- Fuente anterior: https://www.musica.com/lsd/mountains/analisis-cancion
- Portada: Portada no verificada. 

### s09 · hostage — Billie Eilish
- Voz: Billie Eilish, voz íntima.
- Contexto: Apego inquietante y encierro (videoclip blanco).
- Objetos y composición: Habitación vacía, dos sillas y sombras de un ventanal.
- Clímax: Los paneles laterales se cierran, estrechando el espacio sin tapar las sillas.
- Evitar: Barras dibujadas sobre muebles y grietas arbitrarias.
- Fuente anterior: https://www.musica.com/billie-eilish/hostage-en-espanol/analisis-cancion
- Portada: Portada no verificada. 

### s10 · MIU MIU (feat. GeezyDee, CARABIN3) — Blessd, Kris R., Young Fatty, TURY, CARABIN3
- Voz: Voces alternadas de trap; productores según créditos.
- Contexto: Lujo, estilo y trap.
- Objetos y composición: Escaparate con joyas sobre soportes y coche en la calle inferior.
- Clímax: Se encienden los focos del escaparate; reflejos sobre joyas y carrocería.
- Evitar: Joyas volando y coches sobre vitrinas.
- Fuente anterior: https://www.musica.com/letras.asp?letra=2633300
- Portada: Portada no verificada. 

### s11 · Calling (Spider-Man: Across the Spider-Verse) — Metro Boomin, Swae Lee, NAV, A Boogie Wit da Hoodie
- Voz: Swae Lee, NAV y A Boogie; Metro Boomin productor.
- Contexto: Rescate y conexión multiversal.
- Objetos y composición: Portal principal suspendido sobre edificios; redes ancladas a esquinas.
- Clímax: El portal se abre y revela una ciudad de otra paleta dentro de él.
- Evitar: Radios aleatorios por toda la pantalla.
- Fuente anterior: https://www.pluggedin.com/track-reviews/metro-boomin-calling/
- Portada: Portada no verificada. 

### s12 · Cyber Sex — Doja Cat
- Voz: Doja Cat, rap y melodía.
- Contexto: Conexión digital, deseo a distancia, Hot Pink.
- Objetos y composición: Escritorio con dos pantallas, cámara y teclado apoyados.
- Clímax: Las pantallas pasan de espera a conexión y muestran iconos de llamada.
- Evitar: Corazones dispersos y pantallas duplicadas.
- Fuente anterior: https://hypebeast.com/2019/11/doja-cat-cyber-sex-music-video
- Portada: Portada no verificada. 

### s13 · BLANQUITA — Kris R., Prodmonja
- Voz: Kris R., voz de trap melódico; Prodmonja producción.
- Contexto: Admiración, elevación y luz.
- Objetos y composición: Paisaje de nubes con un emblema alado estilizado entre ellas.
- Clímax: Alas se abren y nubes se iluminan alrededor del emblema.
- Evitar: Alas sin centro o destellos tapando silueta.
- Fuente anterior: https://www.musica.com/kris-r/blanquita/analisis-cancion
- Portada: Portada no verificada. 

### s14 · POLOS OPUESTOS REMIX - BLESSD VERSION — Blessd, Kris R.
- Voz: Blessd y Kris R., alternancia urbana.
- Contexto: Atracción entre opuestos.
- Objetos y composición: Dos imanes en banco de demostración, con polos enfrentados.
- Clímax: Se acercan y el campo se concentra exclusivamente entre los polos.
- Evitar: Campos atravesando objetos o edificios.
- Fuente anterior: https://www.qobuz.com/ar-es/album/polos-opuestos-remix-blessd-kris-r/h0hnj1huhxjmb
- Portada: Portada no verificada. 

### s15 · Si Me Sobrara el Tiempo — Duki
- Voz: Duki, cambios de flow.
- Contexto: Tiempo limitado y prioridades.
- Objetos y composición: Reloj de pared y reloj de arena sobre mesa.
- Clímax: La arena fluye más rápido y el reloj de arena se ilumina.
- Evitar: Relojes duplicados o libros flotantes.
- Fuente anterior: https://los40.com/2024/06/08/asi-es-la-letra-y-el-significado-de-la-cancion-si-me-sobrara-el-tiempo-de-duki/
- Portada: Portada no verificada. 

### s16 · Una — Blessd
- Voz: Blessd, melodía urbana.
- Contexto: Elegir una persona, caminar por el barrio.
- Objetos y composición: Acera y banco a un lado de la calle, farolas y casas.
- Clímax: Luces de casas y farolas se encienden sucesivamente.
- Evitar: Banco o flores en medio del carril.
- Fuente anterior: https://www.cifraclub.com/blessd/una/letra/
- Portada: Portada no verificada. 

### s17 · Halley's Comet — Billie Eilish
- Voz: Billie Eilish, voz contenida.
- Contexto: Insomnio y enamoramiento improbable.
- Objetos y composición: Ventana nocturna, cama y mesita. Cometa únicamente dentro del cristal.
- Clímax: El cometa se ilumina y cruza el cielo visible por la ventana.
- Evitar: Cometa atravesando marcos y habitación.
- Fuente anterior: https://pitchfork.com/reviews/albums/billie-eilish-happier-than-ever/
- Portada: Retrato íntimo con lágrimas, Happier Than Ever. https://pitchfork.com/reviews/albums/billie-eilish-happier-than-ever/

### s18 · Comatose — Skillet
- Voz: John Cooper, rock de voz áspera.
- Contexto: Despertar de la apatía.
- Objetos y composición: Pasillo oscuro con puerta al fondo.
- Clímax: La puerta se abre y su luz llega al suelo; paredes permanecen sólidas.
- Evitar: Líneas radiales sobre la puerta.
- Fuente anterior: https://lyricsweb.com/song/skillet/skillet-comatose
- Portada: Portada no verificada. 

### s19 · A Tu Merced — Bad Bunny
- Voz: Bad Bunny, voz grave y cadencia reguetón.
- Contexto: Deseo nocturno y llamadas, YHLQMDLG.
- Objetos y composición: Costanera, mar, coche aparcado y teléfono en panel del automóvil.
- Clímax: La pantalla del móvil recibe una llamada y el agua refleja la luna.
- Evitar: Teléfono gigante flotando sobre el mar.
- Fuente anterior: https://www.cifraclub.com/bad-bunny/a-tu-merced/letra/
- Portada: Portada no verificada. 

### s20 · Apapáchame — Arroba Nat
- Voz: Arroba Nat, interpretación íntima.
- Contexto: Consuelo y abrazo emocional.
- Objetos y composición: Cama con almohadas, lámpara de mesa y taza.
- Clímax: Se enciende la lámpara y sube el vapor de la taza.
- Evitar: Corazones sin relación con el entorno, almohadas fuera de cama.
- Fuente anterior: https://www.cifraclub.com/arroba-nat/apapachame/letra/
- Portada: Portada no verificada. 

### s21 · MIL D AURA — Kris R., Prodmonja, Los Money Makers
- Voz: Kris R., trap; Prodmonja y Los Money Makers producción.
- Contexto: Visita nocturna, obstáculos familiares.
- Objetos y composición: Casa en acera, reja frente a puerta, coche estacionado.
- Clímax: Se abre la reja y se ilumina el acceso.
- Evitar: Teléfono en carretera y rejas delante de luces sin coherencia.
- Fuente anterior: https://www.musica.com/kris-r/mil-d-aura/analisis-cancion
- Portada: Portada no verificada. 

### s22 · Algo Más — La Quinta Estacion
- Voz: Natalia Jiménez, voz de balada intensa.
- Contexto: Amor que supera distancia y tiempo.
- Objetos y composición: Puente real sobre el agua entre dos orillas.
- Clímax: Luces del puente se encienden de extremo a extremo.
- Evitar: Flores o farolas suspendidas sobre agua.
- Fuente anterior: https://www.musica.com/la-quinta-estacion/algo-mas/analisis-cancion
- Portada: Portada no verificada. 

### s23 · Se Me Antoja — Kodigo 36
- Voz: Kodigo 36, rap.
- Contexto: Flechazo y rap de barrio.
- Objetos y composición: Tocadiscos sobre consola, altavoz y una nota en pared.
- Clímax: Se ilumina el equipo y el disco gira con reflejos de la música.
- Evitar: Disco flotando sobre carretera.
- Fuente anterior: https://www.cifraclub.com/kodigo-36/se-me-antoja/letra/
- Portada: Portada no verificada. 

### s24 · Wonderwall - Remastered — Oasis
- Voz: Liam Gallagher, voz britpop.
- Contexto: Esperanza y refugio, britpop.
- Objetos y composición: Habitación modesta con guitarra apoyada, amplificador y ventana lluviosa.
- Clímax: Luz cálida en la ventana y piloto del amplificador.
- Evitar: Guitarra en una calle sin contexto.
- Fuente anterior: https://www.radiox.co.uk/artists/oasis/who-was-wonderwall-written-about/
- Portada: Portada no verificada. 

### s25 · Born To Be My Baby — Bon Jovi
- Voz: Jon Bon Jovi, rock de estadio.
- Contexto: Pareja trabajadora y apoyo mutuo.
- Objetos y composición: Casa humilde vista desde la calle lluviosa, dos tazas en ventana.
- Clímax: El hogar adquiere calidez mientras la lluvia continúa.
- Evitar: Instrumentos o tazas en mitad de la carretera.
- Fuente anterior: https://twostorytown.com/born-to-be-my-baby
- Portada: Portada no verificada. 

### s26 · The Feels — TWICE
- Voz: TWICE, voces de grupo pop.
- Contexto: Invitación al baile y pop retro.
- Objetos y composición: Pista de fiesta con bola de espejos, altavoces e invitación sobre caballete.
- Clímax: Pista iluminada y confeti limitado al espacio superior.
- Evitar: Sobre gigante tapando los altavoces.
- Fuente anterior: https://rollingstoneindia.com/watch-twice-shimmer-under-the-stars-in-the-feels/
- Portada: Concepto de estudio del amor, Formula of Love (no portada verificada). https://www.elle.com/culture/music/a38209395/twice-formula-of-love-album-interview/

### s27 · Anhelo — Adolescent's Orquesta
- Voz: Adolescent’s Orquesta, voz salsera.
- Contexto: Nostalgia salsera y deseo de encuentro.
- Objetos y composición: Salón con escenario, trompeta sobre atril, rosas en maceta.
- Clímax: Focos del escenario se abren y el latón se ilumina.
- Evitar: Trompeta flotando o rosas sin soporte.
- Fuente anterior: https://www.cifraclub.com/los-adolecentes/585563/letra/
- Portada: Portada no verificada. 

### s28 · 光るなら — Goose house
- Voz: Goose house, voces colectivas.
- Contexto: Música y esperanza tras la lluvia, Your Lie in April.
- Objetos y composición: Piano en pradera, flores y arco iris detrás.
- Clímax: La lluvia cesa, arco iris se completa y teclas se iluminan.
- Evitar: Libro suspendido encima de teclas.
- Fuente anterior: https://en.wikipedia.org/wiki/Hikaru_Nara_(Goose_House_song)
- Portada: Portada no verificada. 

### s29 · Need to Know — Doja Cat
- Voz: Doja Cat, rap y canto.
- Contexto: Curiosidad y atracción en Planet Her.
- Objetos y composición: Club futurista con ventanal a la ciudad alienígena y cabina de DJ.
- Clímax: Se ilumina la pista y una nave pasa por el ventanal.
- Evitar: Nave proyectando rayos sobre mobiliario sin motivo.
- Fuente anterior: https://www.postmagazine.com/press-center/studios/2021/music-video-doja-cat-need-to-know/
- Referencia adicional: https://www.unrealengine.com/spotlights/creating-planet-her-how-doja-cat-brought-an-alien-world-to-life-with-real-time-cg
- Portada: Portada no verificada. 

### s30 · Sweet Boi — Chevy
- Voz: Chevy, voz suave indie.
- Contexto: Afecto tierno, indie.
- Objetos y composición: Escritorio pastel, carta, taza y flores.
- Clímax: La carta adquiere luz y la flor se abre visualmente.
- Evitar: Cartas o corazones suspendidos.
- Fuente anterior: https://chevy.bandcamp.com/track/sweet-boi
- Portada: Portada no verificada. 

### s31 · Amor Completo — Mon Laferte
- Voz: Mon Laferte, voz expresiva.
- Contexto: Entrega y voz intensa de Mon Laferte.
- Objetos y composición: Teatro íntimo, ramo en florero sobre pedestal central.
- Clímax: Telón se abre, luz se amplía y aparecen flores adicionales en el ramo.
- Evitar: Rosas flotando por todo el escenario.
- Fuente anterior: https://www.musica.com/mon-laferte/amor-completo/analisis-cancion
- Portada: Portada no verificada. 

### s32 · Cooler Than Me — Ethan Fields
- Voz: Ethan Fields, versión de Cooler Than Me.
- Contexto: Pose de superioridad y distancia social.
- Objetos y composición: Escaparate frío, gafas en expositor y cristales reflectantes.
- Clímax: Reflejos recorren únicamente las lentes.
- Evitar: Rayos que salen de las gafas.
- Fuente anterior: https://musicbrainz.org/release/caaa61be-d6f6-4892-987d-b7554bc35108
- Portada: Portada no verificada. 

### s33 · Fanática Sensual — Plan B
- Voz: Chencho y Maldy, dúo de reguetón.
- Contexto: Fascinación por imagen, voz y deseo.
- Objetos y composición: Tocador de club, cámara sobre mesa, espejo iluminado y perfume.
- Clímax: Luces del espejo crecen y el piloto de cámara se activa.
- Evitar: Fotografías de personas o flashes fuera del objetivo.
- Fuente anterior: https://www.elespectador.com/el-magazin-cultural/resena-de-fanatica-sensual-article-867393/
- Portada: Portada no verificada. 

### s34 · Criminal — NATTI NATASHA, Ozuna
- Voz: Natti Natasha y Ozuna, dúo.
- Contexto: Atracción prohibida, videoclip de prisión.
- Objetos y composición: Pasillo con puertas enrejadas y dos luces de aviso.
- Clímax: Las luces alternan suavemente y la puerta del fondo se entreabre.
- Evitar: Coche policial o elementos de escenario sin relación.
- Fuente anterior: https://www.musica.com/ozuna/criminal-ft-natti-natasha/analisis-cancion
- Referencia adicional: https://es.wikipedia.org/wiki/Criminal_(canci%C3%B3n_de_Natti_Natasha_y_Ozuna)
- Portada: Portada no verificada. 

### s35 · Mi Bello Angel — Natanael Cano
- Voz: Natanael Cano, corrido tumbado.
- Contexto: Figura que ilumina el rumbo, corrido.
- Objetos y composición: Paisaje de amanecer, camino y arco de nubes aladas.
- Clímax: El horizonte se ilumina y las alas del emblema se expanden.
- Evitar: Guitarra en carretera y alas sin soporte conceptual.
- Fuente anterior: https://www.puroraza.com/song/mi-bello-angel
- Portada: Portada no verificada. 

### s36 · Yellow — Coldplay
- Voz: Chris Martin, voz melódica.
- Contexto: Devoción bajo estrellas, Parachutes.
- Objetos y composición: Globo dorado con soporte sobre mesa, cielo al fondo.
- Clímax: El globo gana resplandor y se encienden estrellas alrededor sin líneas radiales.
- Evitar: Globo sin pie o rayos que atraviesan continentes.
- Fuente anterior: https://usstore.coldplay.com/products/parachutes-cd
- Portada: Globo amarillo iluminado, Parachutes. https://usstore.coldplay.com/products/parachutes-cd

### s37 · Tus Vueltas — Milo j
- Voz: Milo j, voz urbana íntima.
- Contexto: Baile sobre cemento, recuerdo de barrio.
- Objetos y composición: Plaza con banco, árboles y losas, equipo musical portátil en banco.
- Clímax: Los focos del parque se encienden y el equipo marca el ritmo.
- Evitar: Vinilo gigante flotando en plaza.
- Fuente anterior: https://www.cifraclub.com/milo-j/tus-vueltas/letra/
- Portada: Portada no verificada. 

### s38 · You Rock My World — Michael Jackson
- Voz: Michael Jackson, voz rítmica y ad-libs.
- Contexto: Groove nocturno y cortometraje de Invincible.
- Objetos y composición: Escenario de club con sombrero sobre atril y equipo de sonido.
- Clímax: Focos se abren desde techo y pilotos de altavoces se iluminan.
- Evitar: Disco enorme flotando delante de todo.
- Fuente anterior: https://www.youtube.com/watch?v=1-7ABIM2qjU
- Portada: Portada no verificada. 

### s39 · Billie Bossa Nova — Billie Eilish
- Voz: Billie Eilish, interpretación susurrada.
- Contexto: Romance discreto y bossa nova.
- Objetos y composición: Salón íntimo de madera con tocadiscos, dos tazas y cortina.
- Clímax: Lámpara cálida y reflejo de vinilo, ambiente más recogido.
- Evitar: Disco suspendido o luces de club agresivas.
- Fuente anterior: https://pitchfork.com/reviews/albums/billie-eilish-happier-than-ever/
- Portada: Retrato íntimo con lágrimas, Happier Than Ever. https://pitchfork.com/reviews/albums/billie-eilish-happier-than-ever/

### s40 · Stranger — Doja Cat
- Voz: Doja Cat, power ballad.
- Contexto: Conexión entre personas distintas, era Vie.
- Objetos y composición: Dos equipos de comunicación sobre un mismo escritorio.
- Clímax: Ambas pantallas sincronizan su señal y el indicador central se ilumina.
- Evitar: Cables que atraviesan pantallas o espacio sin conectar nada.
- Fuente anterior: https://music.apple.com/us/album/jealous-type/1834042903
- Portada: Portada no verificada. 

### s41 · Freak — Doja Cat
- Voz: Doja Cat, rap y canto.
- Contexto: Deseo y humor, contraste con doo-wop de 1959.
- Objetos y composición: Tocador retro, vinilo apoyado en equipo, perfume y espejo con luces rosadas.
- Clímax: Las luces del tocador pasan de rosa suave a carmín y el disco refleja la iluminación.
- Evitar: Personas, imágenes explícitas o máscaras que no aportan al tema.
- Fuente anterior: https://ratedrnb.com/2020/08/doja-cat-releases-new-single-freak/
- Referencia adicional: https://www.nme.com/news/music/listen-to-doja-cat-sample-paul-anka-on-doo-wop-inspired-freak-2723933
- Portada: Portada no verificada. 

### s42 · Fly Me To The Moon - 2008 Remastered — Frank Sinatra, Count Basie
- Voz: Frank Sinatra, crooner; orquesta Count Basie.
- Contexto: Viaje astral de swing, Sinatra y Count Basie.
- Objetos y composición: Ventana de club con luna y trompeta sobre escenario.
- Clímax: Luz de luna y focos dorados del salón se intensifican.
- Evitar: Trompeta o pista suspendidas en el espacio.
- Fuente anterior: https://www.allmusic.com/song/fly-me-to-the-moon-mt0008651961
- Portada: Portada no verificada. 

### s43 · Deeper Conversation — Yuna
- Voz: Yuna, voz acústica íntima.
- Contexto: Curiosidad por el interior de la otra persona.
- Objetos y composición: Dos tazas en mesa, libro abierto y dos sillas.
- Clímax: Vapor alternado y lámpara se ilumina; el libro sigue legible.
- Evitar: Burbujas de texto en el aire sin emisor.
- Fuente anterior: https://lyricsweb.com/song/yuna/yuna-deeper-conversation
- Portada: Portada no verificada. 

### s44 · ALO (feat. Tutu) — Blessd, Juhn, Fronti, TURY, Tutu
- Voz: Blessd, Juhn, Tutu y colaboradores acreditados.
- Contexto: Llamada y añoranza urbana.
- Objetos y composición: Cabina telefónica junto a banco en la calle.
- Clímax: El teléfono se enciende y el indicador de llamada se ilumina.
- Evitar: Anillos de señal sobre edificios.
- Fuente anterior: https://music.amazon.com/tracks/B0H5YVKLWZ
- Portada: Portada no verificada. 

### s45 · Disfruto — Carla Morrison
- Voz: Carla Morrison, voz íntima.
- Contexto: Disfrutar de la cercanía cotidiana.
- Objetos y composición: Sala tranquila, cama o sofá con almohadas y mesa lateral.
- Clímax: Luz de ventana se vuelve cálida y la lámpara ilumina la mesa.
- Evitar: Ventanas duplicadas y haces opacos encima de cama.
- Fuente anterior: https://carlamorrisonf.substack.com/p/los-frutos-de-disfruto
- Portada: Portada no verificada. 

### s46 · I Don't Want to Miss a Thing - From "Armageddon" Soundtrack — Aerosmith
- Voz: Steven Tyler, voz áspera de balada rock.
- Contexto: No perder un instante, Armageddon.
- Objetos y composición: Observatorio bajo cielo nocturno, telescopio en suelo y cometa.
- Clímax: Cometa gana cola y horizonte se ilumina.
- Evitar: Cometa atravesando telescopio.
- Fuente anterior: https://www.shortlist.com/news/diane-warren-how-i-wrote-i-dont-want-to-miss-a-thing-if-i-could-turn-back-time-and-nothings-gonna-stop-us-now
- Portada: Portada no verificada. 

### s47 · P.Y.T. (Pretty Young Thing) — Michael Jackson
- Voz: Michael Jackson y coros, funk disco.
- Contexto: Funk y baile, Thriller.
- Objetos y composición: Bola disco suspendida del techo, equipo en plataforma.
- Clímax: Bola ilumina baldosas y pilotos de sonido.
- Evitar: Vinilo suspendido sin tocadiscos.
- Fuente anterior: https://musicbrainz.org/release/b8f457c0-a943-4225-878f-65d2301bd111
- Portada: Traje blanco sobre fondo oscuro, Thriller. https://www.mjworld.net/news/2011/03/10/michael-and-zimmerman/

### s48 · Dopamina — Sergi
- Voz: Sergi, identidad vocal no confirmada.
- Contexto: Metáfora provisional de dopamina.
- Objetos y composición: Monitor científico con red de nodos claramente conectados.
- Clímax: Impulsos viajan por conexiones y el núcleo se ilumina.
- Evitar: Presentarlo como interpretación confirmada o red neuronal real.
- Fuente anterior: https://www.youtube.com/watch?v=m6yZJCis4F8
- Portada: Portada no verificada. 

### s49 · CARENCIAS DE CORDURA — Milo j, Yami Safdie
- Voz: Milo j y Yami Safdie, dúo.
- Contexto: Fragilidad y diálogo, dos voces.
- Objetos y composición: Dos espejos sobre pared, uno fracturado, reflejan cielo nocturno.
- Clímax: Los reflejos se aproximan en color y se ilumina la fractura.
- Evitar: Fragmentos flotando y rayos sobre toda la escena.
- Fuente anterior: https://www.musica.com/letras.asp?letra=2603012
- Portada: Portada no verificada. 

### s50 · Química Mayor — Mon Laferte
- Voz: Mon Laferte, voz expresiva.
- Contexto: Química como metáfora de atracción.
- Objetos y composición: Dos matraces apoyados en mesa de laboratorio, conexiones discretas.
- Clímax: El nivel luminoso de líquido sube y burbujea dentro de los matraces.
- Evitar: Tubos desconectados y burbujas fuera de recipientes.
- Fuente anterior: https://www.cifraclub.com/mon-laferte/quimica-mayor/letra/
- Portada: Portada no verificada. 

### s51 · Lo Que Siento — Cuco
- Voz: Cuco, voz melódica bilingüe.
- Contexto: Confesión y ensoñación lo-fi.
- Objetos y composición: Ventana al atardecer, guitarra apoyada junto al tocadiscos.
- Clímax: El atardecer se vuelve rosa y el equipo resplandece suavemente.
- Evitar: Astros superpuestos sobre vidrio o instrumentos flotando.
- Fuente anterior: https://songsense.io/es/cuco/lo-que-siento
- Portada: Portada no verificada. 

### s52 · He's My Man — Luvcat
- Voz: Luvcat, voz teatral de cabaret.
- Contexto: Obsesión doméstica inquietante, balada de asesinato ficticia.
- Objetos y composición: Salón de campo oscuro con dos tazas, reloj y rosa en florero.
- Clímax: La luz baja y el reloj destaca; contraste entre casa acogedora e inquietud.
- Evitar: Romantizar la violencia o representar métodos de daño.
- Fuente anterior: https://www.nme.com/features/music-interviews/luvcat-interview-radar-breakout-dinner-at-brasserie-zedel-3809564
- Referencia adicional: https://www.promonews.tv/videos/2024/12/19/luvcat-hes-my-man-ollie-bradley-baker-luvcat/89535
- Portada: Portada no verificada. 

### s53 · El Mapa De Mi Interior - Remastered 2025 — EME-15
- Voz: EME-15, voces pop grupales.
- Contexto: Cartografía interior, orientación y escucha.
- Objetos y composición: Faro sobre acantilado y barco navegando por agua libre.
- Clímax: El haz gira únicamente por el cielo y el faro se enciende.
- Evitar: Mapa gigante flotando sobre mar o haz delante del faro.
- Fuente anterior: https://www.musica.com/letras.asp?letra=2069392
- Portada: Portada no verificada. 

### s54 · Tú y Yo — Valeria Jasso
- Voz: Valeria Jasso, voz íntima y acústica.
- Contexto: Sueños compartidos y vuelo sobre el mar.
- Objetos y composición: Dos aves, velero y cielo pastel.
- Clímax: Sol y reflejo se vuelven más luminosos; aves mantienen su trayectoria.
- Evitar: Lunas duplicadas y barcos flotando fuera del agua.
- Fuente anterior: https://hgmedia.com.mx/valeria-jasso-convierte-los-suenos-en-refugio-con-tu-y-yo/
- Portada: Portada no verificada. 

### s55 · Machine Love — Jamie Paige
- Voz: Kasane Teto SV; Jamie Paige, autor y productor.
- Contexto: Máquina que busca ser real, homenaje a Song of the Eared Robot.
- Objetos y composición: Terminales conectados a una consola CRT con corazón digital. Teto externa estática.
- Clímax: El corazón se completa y las señales recorren cables hasta sus terminales.
- Evitar: Cables que atraviesan pantallas, Teto animada o duplicada.
- Fuente anterior: https://jamiepaige.bandcamp.com/track/machine-love-3
- Referencia adicional: https://jamiepaige.bandcamp.com/album/machine-love
- Portada: Portada no verificada. 

## Validación
42/42 pruebas Node. Chromium aislado: 55 escenas distintas, cambio entre fotogramas de verso y clímax, sin errores JS. Prueba de integración de etapa con reloj de audio simulado: acentos de clímax, efectos desactivables, pantalla bloqueada y Teto inmóvil. No se compiló el APK ni se validaron rendimiento y apariencia de toda la aplicación en Android. La verificación visual no prueba ausencia universal de solapamientos. Sin modificaciones de audio, Firebase ni dependencias.
