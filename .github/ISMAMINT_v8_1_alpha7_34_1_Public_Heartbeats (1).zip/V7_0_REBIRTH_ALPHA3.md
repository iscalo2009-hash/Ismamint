# Rebirth Alpha 3 — Interacción sensorial

- Conserva la Alpha 2: desgloses visibles, patrones de latido, ajustes de vibración, 55 canciones y efectos originales.
- Transiciones breves sensibles al pulso musical reciente, sin retrasar la navegación.
- Estelas pixel art en acciones seleccionadas; máximo 48 partículas simultáneas y retirada automática.
- Corazón interactivo: toque simple o doble, animaciones y sonidos originales, manteniendo el patrón táctil de latido.
- Celebraciones diferenciadas por categoría; secretos, hitos especiales y aniversarios anuales tienen una variante más intensa. No cambia las condiciones, textos ni fechas de logros.
- Sonidos sintetizados contextuales reutilizando el bus de efectos y su volumen. Desactivar esta opción conserva la respuesta sonora anterior.
- Luz ambiental reactiva al mapa rítmico en Inicio y reproductor, sin desplazar textos ni controles.
- Microanimaciones de iconos, selección y pulsación.
- Modo ambiental ampliado: oculta cabecera, navegación y reproductor compacto. Salida mediante botón visible o Atrás. No modifica las barras de sistema de Android.
- Siete preferencias nuevas, compatibles con las seis anteriores, en Ajustes > Sonido y tacto. Se respeta el interruptor general de vibración y el movimiento reducido. Sin nuevo bucle de renderizado permanente.

Pruebas: Chromium con recursos JS/CSS integrados, almacenamiento y puente Android simulados: desglose, latidos, ajustes, pulso musical simulado, corazón simple/doble, partículas, modo inmersivo y Atrás, transición de navegación, selección de celebración y movimiento reducido. Sintaxis JS y pruebas del Core. Compilación Android, sonido y vibración físicos pendientes. No se añaden mensajes románticos, diagnóstico ni sistemas de respaldo.
