# Alpha 7.26 — Karaoke híbrido

Se han cotejado los 47 LRC aportados con las letras locales de Alpha 7.25. Las 2.862 frases originales y sus marcas iniciales se conservan. 1.701 frases contienen marcas importadas y reancladas; 11.937 segmentos de palabra aprovechan estas marcas, incluidos los subdivididos de 50 frases japonesas. 1.161 frases conservan la estimación anterior.

Método: normalización de texto para comparación (sin modificar texto visible), alineamiento monotónico de secuencias, comprobación de coincidencia contigua por frase, estimación robusta de escala temporal mediante anclas cercanas, rechazo de tiempos duplicados o incompatibles y ajuste dentro del intervalo original. No se usan directamente los tiempos absolutos de los archivos externos. El final de la última palabra se estima a partir de la siguiente marca, con límites; no es un final vocal medido. Las marcas de referencia no se verificaron contra voz separada.

SOLO POR VOS contiene una escala temporal muy diferente (estimación local global de 3,03); Algo Más contiene desplazamientos grandes y discontinuidades; You Rock My World tiene coincidencia textual baja (18%), por lo que conserva mayormente estimaciones. En Hikarunara las marcas son por grupos de texto: se subdividen según la segmentación japonesa del motor. Los ajustes de offset y escala del usuario permanecen intactos.

| Pista | Coincidencia de palabras | Líneas con referencia | Líneas estimadas | Segmentos con referencia |
|---|---:|---:|---:|---:|
| s01 Esclava - Remix | Sin archivo | 0 | 93 | 0 |
| s02 Feel It (From “Invincible”) | 91.9% | 30 | 12 | 259 |
| s03 SOLO POR VOS | 99.4% | 47 | 5 | 467 |
| s04 Hace Mucho Tiempo | 90.8% | 35 | 16 | 253 |
| s05 OJALA | Sin archivo | 0 | 64 | 0 |
| s06 Can't Wait | 89.2% | 34 | 23 | 258 |
| s07 Agora Hills | 90.1% | 47 | 33 | 432 |
| s08 Mountains | 94.5% | 38 | 8 | 151 |
| s09 hostage | 100.0% | 30 | 0 | 189 |
| s10 MIU MIU (feat. GeezyDee, CARABIN3) | 100.0% | 119 | 0 | 959 |
| s11 Calling (Spider-Man: Across the Spider-Verse) | 75.4% | 16 | 49 | 125 |
| s12 Cyber Sex | 88.1% | 24 | 34 | 160 |
| s13 BLANQUITA | 100.0% | 40 | 0 | 319 |
| s14 POLOS OPUESTOS REMIX - BLESSD VERSION | 100.0% | 79 | 1 | 650 |
| s15 Si Me Sobrara el Tiempo | 90.6% | 22 | 26 | 157 |
| s16 Una | 100.0% | 55 | 1 | 409 |
| s17 Halley's Comet | 92.6% | 15 | 7 | 103 |
| s18 Comatose | 83.1% | 40 | 15 | 247 |
| s19 A Tu Merced | 97.6% | 52 | 8 | 375 |
| s20 Apapáchame | Sin archivo | 0 | 17 | 0 |
| s21 MIL D AURA | Sin archivo | 0 | 59 | 0 |
| s22 Algo Más | 96.0% | 47 | 4 | 306 |
| s23 Se Me Antoja | Sin archivo | 0 | 49 | 0 |
| s24 Wonderwall - Remastered | 94.0% | 23 | 8 | 202 |
| s25 Born To Be My Baby | 97.0% | 44 | 10 | 320 |
| s26 The Feels | 47.4% | 19 | 56 | 130 |
| s27 Anhelo | 75.0% | 27 | 20 | 189 |
| s28 光るなら | 100.0% | 50 | 2 | 270 |
| s29 Need to Know | 88.3% | 42 | 36 | 288 |
| s30 Sweet Boi | 89.2% | 25 | 7 | 96 |
| s31 Amor Completo | 80.6% | 17 | 18 | 65 |
| s32 Cooler Than Me | 95.6% | 29 | 10 | 250 |
| s33 Fanática Sensual | 86.1% | 34 | 37 | 206 |
| s34 Criminal | 73.8% | 38 | 44 | 243 |
| s35 Mi Bello Angel | 100.0% | 34 | 0 | 252 |
| s36 Yellow | 98.0% | 32 | 5 | 166 |
| s37 Tus Vueltas | 58.4% | 2 | 29 | 6 |
| s38 You Rock My World | 18.3% | 18 | 91 | 87 |
| s39 Billie Bossa Nova | 96.5% | 30 | 9 | 223 |
| s40 Stranger | 99.4% | 45 | 3 | 321 |
| s41 Freak | 84.0% | 30 | 30 | 254 |
| s42 Fly Me To The Moon - 2008 Remastered | 87.2% | 11 | 8 | 58 |
| s43 Deeper Conversation | 93.9% | 31 | 9 | 178 |
| s44 ALO (feat. Tutu) | 100.0% | 103 | 0 | 908 |
| s45 Disfruto | 85.1% | 36 | 18 | 109 |
| s46 I Don't Want to Miss a Thing - From "Armageddon" Soundtrack | 82.2% | 21 | 37 | 138 |
| s47 P.Y.T. (Pretty Young Thing) | 56.3% | 16 | 59 | 100 |
| s48 Dopamina | Sin archivo | 0 | 0 | 0 |
| s49 CARENCIAS DE CORDURA | Sin archivo | 0 | 29 | 0 |
| s50 Química Mayor | 100.0% | 31 | 0 | 126 |
| s51 Lo Que Siento | 87.6% | 12 | 40 | 113 |
| s52 He's My Man | 96.0% | 33 | 10 | 174 |
| s53 El Mapa De Mi Interior - Remastered 2025 | 98.8% | 40 | 3 | 237 |
| s54 Tú y Yo | Sin archivo | 0 | 0 | 0 |
| s55 Machine Love | 95.6% | 58 | 9 | 409 |

Pruebas: 42/42 Node; Chromium: 47 pistas con referencia, 1.701 líneas, 11.937 segmentos aceptados, 0 inválidos, avance y retroceso comprobados; integración de fondo y karaoke en pantalla principal con reproducción simulada. No se ha comprobado la sincronización vocal escuchando todas las canciones, ni Android físico. No se modifica audio, fondos, efectos ni Firebase.