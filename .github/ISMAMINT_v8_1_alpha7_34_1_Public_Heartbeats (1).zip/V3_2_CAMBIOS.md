# Ismamint 3.1 — navegación y avisos del chat

- Menú principal: Inicio, Juegos, Más, Chat.
- Canal Android separado de los avisos románticos, con sonido y vibración configurables desde Android.
- En Chat > menú > Notificaciones: activar/desactivar, vista previa privada, silencio de 1 hora, 8 horas o indefinido, permiso y configuración del canal.
- Con la app abierta, escucha Firestore y avisa cuando llega un mensaje de la otra persona fuera del chat. Al entrar en el chat se retira el aviso.
- Con la app en segundo plano, JobScheduler consulta Firestore con la sesión existente aproximadamente cada 15 minutos como mínimo; Android puede diferir el trabajo por Doze, ahorro de batería, falta de red, restricciones del fabricante o cierre forzado. No es FCM push en tiempo real. La tarea persistente se programa al iniciar sesión y al volver a la app; no necesita servicio permanente ni alarma exacta.
- Deduplicación por cursor persistente por cuenta (timestamp de servidor + ID). Los mensajes propios, eliminados, cambios y reacciones no generan avisos nuevos. La primera sincronización establece el punto inicial sin avisar por el historial previo. El cursor se conserva al reiniciar. Si llegan varios mensajes juntos, se agrupan en un único aviso. Se usa un aviso de conversación que se reemplaza al llegar otro lote.
- Vista previa de mensajes de texto y etiquetas para adjuntos; contenido privado en la pantalla bloqueada según configuración de Android.
- Al tocar el aviso, abre la sección Chat mediante la navegación existente. No se alteran los avisos del contador o logros.
- Sin dependencia nueva ni cambios de reglas Firestore respecto a V3.0 Beta. No se introduce ninguna credencial de servidor. Firebase Spark sigue siendo suficiente, dentro de sus cuotas.

## Prueba recomendada
1. Instalar la versión en ambos teléfonos y abrir Chat con sesión y conexión. Esperar a que se sincronice el historial inicial. Conceder permiso de notificaciones.
2. En uno, salir a Inicio sin cerrar la app; enviar desde el otro. Debe llegar un aviso. Pulsar y comprobar que abre Chat. Reaccionar o editar y comprobar que no genera otro aviso. Enviar mientras el destinatario está dentro del chat: no debe aparecer aviso del sistema.
3. Probar silencio y vista previa desde el menú Chat. Comprobar que los avisos románticos conservan su configuración.
4. Mandar mensajes con el destinatario en segundo plano, con red y sin cierre forzado. La comprobación es periódica, no inmediata; Android puede retrasarla más de 15 minutos.

## Verificación
Sintaxis JavaScript y XML verificadas; compilación Java/Android y prueba entre dispositivos pendientes. No se ha implementado push automático FCM: requiere un emisor confiable fuera de la APK (backend). No incluir claves privadas en la aplicación.
