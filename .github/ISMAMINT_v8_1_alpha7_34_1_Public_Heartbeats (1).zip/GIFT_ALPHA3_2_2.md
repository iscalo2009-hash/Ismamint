# Alpha 3.2.2 — Advanced Design

- 15 tipos de objetos (7 previos y 8 nuevos). Konva local ya incorporado en 3.2 Preview.
- Relleno sólido, degradado lineal/radial, dos colores, ángulo; contorno, sombra, transparencia, esquinas, fuentes, negrita y cursiva; escalas independientes.
- Fondo sólido o degradado, cuadrícula opcional de 16 unidades y ajuste durante arrastre, centrado, posición numérica.
- Tiradores de transformación, rotación, inspector contextual, selección por capas, nombre, visibilidad, bloqueo, orden, duplicación, copia de apariencia.
- Historial de sesión de 60 cambios, vista previa PNG generada por el mismo motor; las guías no aparecen en el regalo. El lienzo se adapta al ancho disponible.
- Conserva formato de almacenamiento previo; normaliza campos nuevos con valores por defecto. Se admiten regalos visuales con título y objeto visible sin mensaje escrito.
- Limpieza del escenario al cerrar o retirar el editor; las dependencias existentes no se cargan todas al iniciar.
- Límites provisionales: 80 objetos, lienzo lógico de 320 x 320, historial solo en sesión. No se incluye aún agrupación, máscaras, fotos, materiales complejos, escenas múltiples ni IndexedDB. Sin Firebase nuevo ni cambios al audio.
- Pruebas: 28 suites JS, gift-browser, gift-advanced-browser, gift-canvas-browser. Pendiente Android físico, compilación y pruebas de rendimiento extremo.
