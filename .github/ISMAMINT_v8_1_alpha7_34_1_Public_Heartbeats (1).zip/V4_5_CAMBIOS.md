# ISMAMINT V4.5 — Soundtrack Remake

Base: V4.4 Fluid. Se sustituye el SVG ambiental con partículas compartidas por un director procedural de escenas, con dos planos Canvas 2D, sin cambiar el motor de música ni las funciones de chat.

- 55 direcciones individuales, 55 combinaciones distintas de escena de verso, coro y gesto, 42 familias de composición. Cada perfil incorpora paleta, motivo, álbum (si existe en los metadatos), referencias y activadores temáticos individuales.
- El escenario cambia mediante fundido entre composiciones de verso y coro/clímax; ajusta intensidad en introducción, cierre, secciones tranquilas y pasajes instrumentales. Usa energía, rejilla de BPM y ataques precalculados de los MP3 chiptune. Los coros siguen siendo estimaciones.
- Los gestos del primer plano nacen de las letras locales y de golpes fuertes; tienen duración, escala, posición y entrada/salida propias. La capa protege controles, letras y cifras. El fondo es procedural, no una animación de una portada.
- Las letras mantienen la animación de V4.4 y la posición semialeatoria estable. Se conserva el cameo de Teto, las 55 canciones, las 53 letras, los logros, los avisos, las preferencias y el chat. No requiere cambios de Firebase.
- `requestAnimationFrame` sin límite artificial. Resolución interna adaptativa ante caídas sostenidas; dos lienzos con máximo inicial de 1.25x DPR. Animaciones pausadas en segundo plano, chat, juegos y modales; respeto a movimiento reducido y a intensidad seleccionada. No se garantiza una frecuencia determinada en Android.
- No hay portadas incrustadas en los MP3. Las referencias verificadas se distinguen de las interpretaciones de diseño en V4_5_ESCENAS.md. No se descargan, copian ni muestran portadas originales. No se añade ninguna dependencia externa ni suscripción.

## Referencias de dirección artística
- Parachutes: https://eustore.coldplay.com/collections/cd
- Scarlet (portada final): https://pitchfork.com/news/doja-cat-replaces-new-album-cover-that-was-near-replica-of-german-metal-bands/
- Happier Than Ever: https://www.wmagazine.com/culture/billie-eilish-happier-than-ever-aesthetics
- Planet Her: https://www.davidlachapelle.com/post/new-album-artwork-doja-cat-planet-her
- Formula of Love: https://www.elle.com/culture/music/a38209395/twice-formula-of-love-album-interview/
- Thriller: https://www.behindthecovers.com/covers/thriller
- Constant Companions: https://jamiepaige.bandcamp.com/album/constant-companions-deluxe-edition

## Validaciones
- Sintaxis JS de scripts externos modificados y de cinco bloques inline.
- 385 llamadas de render sobre un contexto Canvas simulado, con detección de coordenadas no finitas y operaciones no admitidas; no equivale a una prueba visual.
- 55 perfiles, 42 familias y 55 combinaciones distintas; integridad ZIP. Chromium local no completó la prueba. No se compiló APK ni se midieron FPS en Android.
