# Heartmint 2.0 — Heartbound / Foundation

Primera versión del remake, sobre ISMAMINT Alpha 20. El juego principal utiliza ahora `heartbound-core.js` (simulación), `heartbound-app.js` (adaptador WebView), `heartbound-ui.js` y `heartbound.css`. Los módulos y datos antiguos de viaje, perfiles de boss y música siguen en el proyecto. El antiguo `heartmint.js` ya no se carga.

## Juego
- Corazón con movimiento en dos dimensiones: joystick o arrastre relativo. Teclado WASD/flechas, Z/espacio acción, X defensa, P pausa. Dos botones táctiles contextuales.
- Cuatro estados: libertad, protección direccional y parry, gravedad con salto/caída, vínculo con dos corazones espejados.
- Recogida, cacería y evasión; desafíos específicos de cada estado. Los objetivos hacen avanzar los niveles, no un contador de tiempo global. Los primeros diez mundos mantienen sus encuentros especiales; algunos mundos posteriores terminan en desafíos sin boss. Cada mundo sigue agrupando cinco niveles para conservar los checkpoints.
- Doce patrones de proyectiles, ocho tipos básicos de enemigos con diferentes comportamientos. Los enemigos y las fases de boss utilizan el motor nuevo. El daño de boss se representa por resolución mediante secuencias de ataque y contraataque, no vida bloqueada. La trilogía de los exes conserva los sprites y perfiles musicales; en el encuentro conjunto se eliminan por turnos, aún no combaten de forma independiente en paralelo.
- Primeros tres bosses con secuencias propias. Otros siete conservan identidades y secuencias iniciales, aún no se consideran sus remakes definitivos. Jefes posteriores usan perfiles procedurales y combinaciones compatibles de patrones.
- El motor musical anterior se reutiliza; Feid usa intervalos derivados de su tempo. No hay sincronización exacta con el reloj de audio todavía.
- Los antiguos consumibles, armas y mejoras de estadísticas ya no aparecen como arsenal activo. Sus datos se conservan en el guardado anterior. Se sustituyen inicialmente por energía, corazones, ataque y acciones de estado; la progresión de habilidades permanentes está pendiente.

## Persistencia y límites
`heartbound_progress_v1` conserva el nivel máximo anterior, checkpoint y semilla, usando el guardado Alpha 20 como base si no existe. No escribe sobre el guardado de viaje anterior. Conserva récord y estadísticas de Ismamint, skins y desbloqueos de logros. Nuevas partidas parten con salud y energía base; no trasladan estadísticas de armas antiguas. El mapa pagina ocho mundos y permite saltar por número. El nivel es un entero seguro JS, sin final de diseño.

## Validación
- `node tests/heartbound-core.test.js`: físicas, colisión, protección, vínculo, 10.000 niveles, compatibilidad de patrones y simulaciones con invulnerabilidad de 12 encuentros de boss (incluidos los diez iniciales).
- `node tests/heartbound-integration.test.js`: adaptador con entorno simulado, migración, pausa/cuenta atrás, navegación y checkpoint.
- `node tests/rebirth-core.test.js`, `node tests/heartmint-bosses.test.js`, `node tests/heartmint-audio.test.js`: regresión de módulos reutilizados. Las pruebas antiguas de juego/arsenal/curva no constituyen pruebas del nuevo motor.
- Sintaxis de los scripts nuevos e inline comprobada. Chromium bloqueó la navegación por política del entorno (`ERR_BLOCKED_BY_ADMINISTRATOR`). No hay comprobación visual, compilación Android ni prueba física en esta entrega.

## Pendiente
Prueba táctil y balance humano; validador espacio-temporal de rutas seguras (actualmente se usan patrones compatibles y límites conservadores, sin garantía formal); cuatro estados adicionales; director de intensidad avanzado y progresión horizontal; remakes individuales de los bosses restantes; sincronización musical exacta; optimización y efectos detallados tras validar el núcleo. Esta entrega es una primera alpha de Heartbound, no el plan completo.
