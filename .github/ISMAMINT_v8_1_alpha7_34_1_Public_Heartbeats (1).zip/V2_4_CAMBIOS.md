# Chat V2.4 - Final UX Update
- Contador de mensajes nuevos en el botón de bajar (historial cargado).
- Carga automática al subir, conserva el botón manual.
- Posición local de lectura por cuenta y restauración por ID de mensaje.
- Agrupación visual de mensajes consecutivos.
- Borrador independiente al editar mensajes.
- Reintento individual de envíos rechazados por Firestore, con ID estable y lista local de recuperación.
- Atrás de Android cierra diálogo, pantalla de ajustes, acciones, selección, búsqueda o contexto antes de abandonar el chat.
- Varios mensajes fijados locales, migración del fijado anterior y navegación por lista.
- Copia de historial cargado y selección de fragmentos mediante diálogo de texto.
- Densidad de conversación y alto contraste.
- Reglas de Firestore idénticas a V2.3.2.

Limitaciones: exportación solo de mensajes cargados; silenciar temporalmente se reserva para notificaciones push; no se implementa multimedia. Los mensajes pendientes sin conexión se gestionan mediante la cola de Firestore; la lista de recuperación corresponde a errores de escritura definitivos recibidos por la aplicación. No se ha compilado ni probado en Android en este entorno. Sintaxis JS y ZIP comprobadas.
