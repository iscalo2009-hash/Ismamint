# ISMAMINT Alpha 7.14 · Soundtrack Atelier
55 escenas originales; dirección individual basada en los metadatos, letras locales de 53 pistas y fuentes previas de Alpha 7.12, con comprobaciones externas adicionales en las pistas indicadas. Los créditos vocales describen las grabaciones de referencia, no la voz del MP3 chiptune. El arte es una interpretación, no una reproducción de portadas. Las pistas s48 y s54 no tienen LRC local.

## s01 · Esclava - Remix — Bryant Myers, Anuel AA, Anonimus, Almighty
- Voz: Voces masculinas alternadas, trap grave
- Contexto: Encuentro secreto, tensión y deseo
- Arte: Persianas, fachada de motel, callejón y coche; dos siluetas se encuentran a escondidas.
- Movimiento: Luces del coche, persianas y farola; la escena se cierra en el clímax.
- Referencia anterior: https://www.musica.com/anuel/esclava-remix-ft-bryant-myers-anonimus-almighty/analisis-cancion
- Portada: Portada no verificada

## s02 · Feel It (From “Invincible”) — d4vd
- Voz: d4vd, voz melódica y funk
- Contexto: Euforia del enamoramiento; banda sonora Invincible
- Arte: Ciudad de superhéroes, paneles diagonales de cómic y figuras en movimiento; amarillo y rojo de acción.
- Movimiento: Líneas cinéticas y explosiones de pequeñas estrellas; sin representar al héroe oficial.
- Referencia anterior: https://www.universalmusic.ca/2024/03/27/d4vd-debuts-new-song-feel-it-from-the-original-series-invincible/
- Portada: Portada no verificada

## s03 · SOLO POR VOS — Trueno
- Voz: Trueno, rap melódico
- Contexto: Elegir a alguien frente a la soledad
- Arte: Paisaje entre el sol que cae y la luna; camino de noche y dos siluetas en el horizonte.
- Movimiento: Trayecto iluminado, encuentro y reflejos de atardecer.
- Referencia anterior: https://www.cifraclub.com/trueno/solo-por-vos/letra/
- Portada: Portada no verificada

## s04 · Hace Mucho Tiempo — Arcángel
- Voz: Arcángel, voz nasal melódica
- Contexto: Persona soñada durante mucho tiempo
- Arte: Habitación sepia, reloj y fotografías de un encuentro que se ha imaginado mucho tiempo.
- Movimiento: Fotogramas que se revelan y proyector cálido.
- Referencia anterior: https://www.musica.com/arcangel/hace-mucho-tiempo/analisis-cancion
- Portada: Portada no verificada

## s05 · OJALA — Milo j, Bhavi
- Voz: Milo j y Bhavi, dos voces urbanas
- Contexto: Compañía ante heridas y vulnerabilidad
- Arte: Dos personas bajo lluvia frente a una casa cálida, como refugio ante el peso emocional.
- Movimiento: Gotas y luz doméstica; el interior brilla en los estribillos.
- Referencia anterior: https://www.musica.com/milo-j/ojala-ft-bhavi/analisis-cancion
- Portada: Portada no verificada

## s06 · Can't Wait — Doja Cat
- Voz: Doja Cat, rap y canto
- Contexto: Compromiso a largo plazo y fantasía de vida rural compartida
- Arte: Campo, surcos de cultivo, casa y dos figuras; compromiso doméstico y guiño a las arañas de Scarlet.
- Movimiento: Hilos nacarados y arañas pequeñas; luz de la casa.
- Referencia anterior: https://music.apple.com/us/song/1707932018
- Portada: Dos arañas nacaradas, Scarlet (https://pitchfork.com/reviews/albums/doja-cat-scarlet/)
- Verificación adicional: https://www.thefader.com/2023/09/22/doja-cat-scarlet-samples

## s07 · Agora Hills — Doja Cat
- Voz: Doja Cat, rap susurrado y canto
- Contexto: Mostrar públicamente el vínculo; sueño adolescente
- Arte: Barrio rosa liminal, fotografías que exhiben el vínculo y un fondo onírico; era Scarlet.
- Movimiento: Fotos, corazones y telaraña discreta, acentuados al coro.
- Referencia anterior: https://readdork.com/track/doja-cat-agora-hills-2024
- Portada: Dos arañas nacaradas, Scarlet (https://pitchfork.com/reviews/albums/doja-cat-scarlet/)
- Verificación adicional: https://readdork.com/music-videos/doja-cat-agora-hills

## s08 · Mountains — Sia, Diplo, Labrinth, LSD
- Voz: Sia y Labrinth; producción LSD
- Contexto: Devoción capaz de mover montañas
- Arte: Cordillera fantástica multicolor, sol y arco iris; psicodelia LSD.
- Movimiento: Picos que cambian altura; vibración cromática de cumbres.
- Referencia anterior: https://www.musica.com/lsd/mountains/analisis-cancion
- Portada: Portada no verificada

## s09 · hostage — Billie Eilish
- Voz: Billie Eilish, voz íntima
- Contexto: Apego posesivo y vulnerabilidad; metáfora inquietante
- Arte: Espacio casi vacío y pálido con dos figuras y paredes que parecen cerrar el espacio; referencia al videoclip.
- Movimiento: Sombras y líneas de presión, no un romance idealizado.
- Referencia anterior: https://www.musica.com/billie-eilish/hostage-en-espanol/analisis-cancion
- Portada: Portada no verificada
- Verificación adicional: https://en.wikipedia.org/wiki/Hostage_(Billie_Eilish_song)

## s10 · MIU MIU (feat. GeezyDee, CARABIN3) — Blessd, Kris R., Young Fatty, TURY, CARABIN3
- Voz: Voces alternadas de trap; productores según créditos
- Contexto: Lujo, estilo y exceso
- Arte: Coche de lujo, joyas en escaparates y calle de noche, en clave trap.
- Movimiento: Reflejos cromados en vitrinas y chispas en las joyas.
- Referencia anterior: https://www.musica.com/letras.asp?letra=2633300
- Portada: Portada no verificada

## s11 · Calling (Spider-Man: Across the Spider-Verse) — Metro Boomin, Swae Lee, NAV, A Boogie Wit da Hoodie
- Voz: Swae Lee, NAV y A Boogie; Metro Boomin productor
- Contexto: Rescate y entrega en Spider-Verse
- Arte: Ciudad multiversal, portales, redes y silueta suspendida que tiende una conexión.
- Movimiento: Portal expandido y trazos de red; color de cómic de Spider-Verse.
- Referencia anterior: https://www.pluggedin.com/track-reviews/metro-boomin-calling/
- Portada: Portada no verificada

## s12 · Cyber Sex — Doja Cat
- Voz: Doja Cat, rap y melodía
- Contexto: Conexión digital y estética futurista
- Arte: Dormitorio digital Hot Pink con ordenadores y teléfono, conexión a distancia no explícita.
- Movimiento: Indicadores y ventanas que pulsan; corazones digitales discretos.
- Referencia anterior: https://hypebeast.com/2019/11/doja-cat-cyber-sex-music-video
- Portada: Portada no verificada

## s13 · BLANQUITA — Kris R., Prodmonja
- Voz: Kris R., voz de trap melódico; Prodmonja producción
- Contexto: Admiración y homenaje a un gran amor
- Arte: Nubes claras y alas que enmarcan una silueta; admiración y sensación de volar.
- Movimiento: Nubes desplazándose y plumas de luz.
- Referencia anterior: https://www.musica.com/kris-r/blanquita/analisis-cancion
- Portada: Portada no verificada

## s14 · POLOS OPUESTOS REMIX - BLESSD VERSION — Blessd, Kris R.
- Voz: Blessd y Kris R., alternancia urbana
- Contexto: Atracción entre opuestos
- Arte: Dos barrios enfrentados azul y coral; las figuras convergen, no son solo imanes flotantes.
- Movimiento: Encuentro de campos y acercamiento de las siluetas.
- Referencia anterior: https://www.qobuz.com/ar-es/album/polos-opuestos-remix-blessd-kris-r/h0hnj1huhxjmb
- Portada: Portada no verificada

## s15 · Si Me Sobrara el Tiempo — Duki
- Voz: Duki, cambios de flow
- Contexto: Paso del tiempo, deseo de dedicarlo a alguien
- Arte: Reloj grande, reloj de arena y figuras separadas, el tiempo limitado como protagonista.
- Movimiento: Arena que cae y manecillas aceleradas.
- Referencia anterior: https://los40.com/2024/06/08/asi-es-la-letra-y-el-significado-de-la-cancion-si-me-sobrara-el-tiempo-de-duki/
- Portada: Portada no verificada

## s16 · Una — Blessd
- Voz: Blessd, melodía urbana
- Contexto: Elegir a una persona y compartir una caminata sin lujo
- Arte: Calle de barrio a la luz de la luna, dos figuras tomadas de la mano; se evita representar un coche.
- Movimiento: Farolas cálidas, pasos y puntos de luz.
- Referencia anterior: https://www.cifraclub.com/blessd/una/letra/
- Portada: Portada no verificada

## s17 · Halley's Comet — Billie Eilish
- Voz: Billie Eilish, voz contenida
- Contexto: Enamorarse pese a la resistencia, sueño e intimidad
- Arte: Dormitorio nocturno de tonos apagados y ventana abierta al cielo; enamoramiento que interrumpe el sueño.
- Movimiento: Cometa lento y destello breve en ventana.
- Referencia anterior: https://pitchfork.com/reviews/albums/billie-eilish-happier-than-ever/
- Portada: Retrato íntimo con lágrimas, Happier Than Ever (https://pitchfork.com/reviews/albums/billie-eilish-happier-than-ever/)

## s18 · Comatose — Skillet
- Voz: John Cooper, rock de voz áspera
- Contexto: Romper la apatía; despertar y búsqueda de redención
- Arte: Figura ante una puerta luminosa y un espacio fracturado, metáfora de salir de la apatía.
- Movimiento: Grietas que dejan pasar luz al clímax.
- Referencia anterior: https://lyricsweb.com/song/skillet/skillet-comatose
- Portada: Portada no verificada

## s19 · A Tu Merced — Bad Bunny
- Voz: Bad Bunny, voz grave y cadencia reguetón
- Contexto: Atracción y deseo nocturno
- Arte: Costanera, teléfono y coche bajo una luna tropical; deseo y llamadas.
- Movimiento: Reflejos del mar y señal telefónica.
- Referencia anterior: https://www.cifraclub.com/bad-bunny/a-tu-merced/letra/
- Portada: Portada no verificada

## s20 · Apapáchame — Arroba Nat
- Voz: Arroba Nat, interpretación íntima
- Contexto: Buscar consuelo y un abrazo
- Arte: Habitación cálida, taza, cama y abrazo entre siluetas, desde la vulnerabilidad al consuelo.
- Movimiento: Vapor, luz rosa y pequeños puntos que se reúnen.
- Referencia anterior: https://www.cifraclub.com/arroba-nat/apapachame/letra/
- Portada: Portada no verificada

## s21 · MIL D AURA — Kris R., Prodmonja, Los Money Makers
- Voz: Kris R., trap; Prodmonja y Los Money Makers producción
- Contexto: Deseo de visitar a la persona amada pese a barreras familiares
- Arte: Calle nocturna con una casa, reja, teléfono y dos figuras a distinta altura; padres y deseo de buscarla.
- Movimiento: Farola y ventana que se iluminan, puerta que se abre visualmente.
- Referencia anterior: https://www.musica.com/kris-r/mil-d-aura/analisis-cancion
- Portada: Portada no verificada

## s22 · Algo Más — La Quinta Estacion
- Voz: Natalia Jiménez, voz de balada intensa
- Contexto: Amor que trasciende distancia y tiempo
- Arte: Dos orillas, puente y dos figuras; balada de amor que supera distancia y tiempo.
- Movimiento: Encuentro en el centro y luz del horizonte.
- Referencia anterior: https://www.musica.com/la-quinta-estacion/algo-mas/analisis-cancion
- Portada: Portada no verificada

## s23 · Se Me Antoja — Kodigo 36
- Voz: Kodigo 36, rap
- Contexto: Flechazo y fascinación al mirar
- Arte: Plaza de barrio, figura vista al caminar y disco; fascinación del narrador.
- Movimiento: Estrellas breves alrededor de la silueta y disco giratorio.
- Referencia anterior: https://www.cifraclub.com/kodigo-36/se-me-antoja/letra/
- Portada: Portada no verificada

## s24 · Wonderwall - Remastered — Oasis
- Voz: Liam Gallagher, voz britpop
- Contexto: Esperanza de encontrar a alguien que rescate; interpretación abierta
- Arte: Calle gris britpop, guitarra acústica y ventana iluminada como refugio; interpretación abierta.
- Movimiento: Lluvia y resplandor de la ventana.
- Referencia anterior: https://www.radiox.co.uk/artists/oasis/who-was-wonderwall-written-about/
- Portada: Portada no verificada

## s25 · Born To Be My Baby — Bon Jovi
- Voz: Jon Bon Jovi, rock de estadio
- Contexto: Pareja trabajadora que encuentra apoyo mutuo
- Arte: Barrio bajo lluvia, casa iluminada, guitarra y pareja; apoyo mutuo ante dificultades económicas.
- Movimiento: Luz de hogar y resplandor de escenario.
- Referencia anterior: https://twostorytown.com/born-to-be-my-baby
- Portada: Portada no verificada

## s26 · The Feels — TWICE
- Voz: TWICE, voces de grupo pop
- Contexto: Flechazo, reciprocidad y baile retro
- Arte: Pista pop de fiesta escolar, sobre de invitación y grupo de figuras; estética de The Feels.
- Movimiento: Focos, pequeños destellos y suelo de baile.
- Referencia anterior: https://rollingstoneindia.com/watch-twice-shimmer-under-the-stars-in-the-feels/
- Portada: Concepto de estudio del amor, Formula of Love (no portada verificada) (https://www.elle.com/culture/music/a38209395/twice-formula-of-love-album-interview/)

## s27 · Anhelo — Adolescent's Orquesta
- Voz: Adolescent’s Orquesta, voz salsera
- Contexto: Nostalgia y deseo de estar con la persona amada
- Arte: Salón de salsa cálido, pareja en baile, rosas y luces de latón.
- Movimiento: Pasos de baile y movimiento de pétalos.
- Referencia anterior: https://www.cifraclub.com/los-adolecentes/585563/letra/
- Portada: Portada no verificada

## s28 · 光るなら — Goose house
- Voz: Goose house, voces colectivas
- Contexto: Esperanza, música y luz; Your Lie in April
- Arte: Piano, flores, colinas y arco iris; referencia al anime Your Lie in April.
- Movimiento: Lluvia que desaparece y teclado iluminado.
- Referencia anterior: https://en.wikipedia.org/wiki/Hikaru_Nara_(Goose_House_song)
- Portada: Portada no verificada

## s29 · Need to Know — Doja Cat
- Voz: Doja Cat, rap y canto
- Contexto: Curiosidad y estética extraterrestre del video
- Arte: Ciudad alienígena, naves y planeta con anillo; guiño al vídeo futurista de Need to Know.
- Movimiento: Portal, pequeñas naves y neón, sin contenido explícito.
- Referencia anterior: https://www.postmagazine.com/press-center/studios/2021/music-video-doja-cat-need-to-know/
- Portada: Portada no verificada

## s30 · Sweet Boi — Chevy
- Voz: Chevy, voz suave indie
- Contexto: Afecto tierno y admiración
- Arte: Habitación pastel, carta, taza y una silueta amable; afecto sencillo.
- Movimiento: Corazones pequeños y vapor de la taza.
- Referencia anterior: https://chevy.bandcamp.com/track/sweet-boi
- Portada: Portada no verificada

## s31 · Amor Completo — Mon Laferte
- Voz: Mon Laferte, voz expresiva
- Contexto: Entrega y conexión intensa
- Arte: Teatro íntimo, pareja, flores y luz cálida; expresión intensa de la voz de Mon Laferte.
- Movimiento: Pétalos y focos que se abren.
- Referencia anterior: https://www.musica.com/mon-laferte/amor-completo/analisis-cancion
- Portada: Portada no verificada

## s32 · Cooler Than Me — Ethan Fields
- Voz: Ethan Fields, versión de Cooler Than Me
- Contexto: Distancia social y pose de superioridad
- Arte: Ciudad fría, gafas enormes y silueta apartada; superioridad y distancia social.
- Movimiento: Reflejos y pequeños fragmentos en las lentes.
- Referencia anterior: https://musicbrainz.org/release/caaa61be-d6f6-4892-987d-b7554bc35108
- Portada: Portada no verificada

## s33 · Fanática Sensual — Plan B
- Voz: Chencho y Maldy, dúo de reguetón
- Contexto: Fascinación por imagen y voz; escena de club abstracta
- Arte: Fotografía, pantalla de teléfono y pista de club; fascinación por una imagen.
- Movimiento: Destellos de cámara y foco rítmico.
- Referencia anterior: https://www.elespectador.com/el-magazin-cultural/resena-de-fanatica-sensual-article-867393/
- Portada: Portada no verificada

## s34 · Criminal — NATTI NATASHA, Ozuna
- Voz: Natti Natasha y Ozuna, dúo
- Contexto: Atracción irresistible en diálogo musical
- Arte: Dos figuras bajo luces de alerta urbanas; diálogo musical y atracción.
- Movimiento: Luces alternadas y acercamiento de figuras.
- Referencia anterior: https://www.musica.com/ozuna/criminal-ft-natti-natasha/analisis-cancion
- Portada: Portada no verificada

## s35 · Mi Bello Angel — Natanael Cano
- Voz: Natanael Cano, corrido tumbado
- Contexto: Admiración de una figura que ilumina su rumbo
- Arte: Camino entre colinas, figura alada y guitarra del universo regional mexicano.
- Movimiento: Plumas, halo cálido y camino iluminado.
- Referencia anterior: https://www.puroraza.com/song/mi-bello-angel
- Portada: Portada no verificada

## s36 · Yellow — Coldplay
- Voz: Chris Martin, voz melódica
- Contexto: Devoción; globo dorado de Parachutes
- Arte: Globo dorado con base y estrellas; guiño a la portada de Parachutes, no copia literal.
- Movimiento: Estrellas que se encienden de forma suave.
- Referencia anterior: https://usstore.coldplay.com/products/parachutes-cd
- Portada: Globo amarillo iluminado, Parachutes (https://usstore.coldplay.com/products/parachutes-cd)

## s37 · Tus Vueltas — Milo j
- Voz: Milo j, voz urbana íntima
- Contexto: Fascinación y recuerdo de una persona que baila
- Arte: Plaza de barrio con losas, árboles y dos figuras; referencia explícita a bailar sobre cemento.
- Movimiento: Giro de la figura y huellas rítmicas.
- Referencia anterior: https://www.cifraclub.com/milo-j/tus-vueltas/letra/
- Portada: Portada no verificada

## s38 · You Rock My World — Michael Jackson
- Voz: Michael Jackson, voz rítmica y ad-libs
- Contexto: Atracción que transforma su mundo; corto cinematográfico
- Arte: Escenario nocturno, figuras, sombrero y focos cruzados; referencia al cortometraje de Invincible.
- Movimiento: Focos y pasos al groove.
- Referencia anterior: https://www.youtube.com/watch?v=1-7ABIM2qjU
- Portada: Portada no verificada
- Verificación adicional: https://www.youtube.com/watch?v=1-7ABIM2qjU

## s39 · Billie Bossa Nova — Billie Eilish
- Voz: Billie Eilish, interpretación susurrada
- Contexto: Romance discreto, bossa nova
- Arte: Salón íntimo, cortina, vinilo, taza y dos figuras; discreción y estética cálida de Happier Than Ever.
- Movimiento: Vinilo giratorio y cortinas en semioscuridad.
- Referencia anterior: https://pitchfork.com/reviews/albums/billie-eilish-happier-than-ever/
- Portada: Retrato íntimo con lágrimas, Happier Than Ever (https://pitchfork.com/reviews/albums/billie-eilish-happier-than-ever/)

## s40 · Stranger — Doja Cat
- Voz: Doja Cat, power ballad
- Contexto: Dos personas fuera de lo convencional que conectan; era Vie
- Arte: Dos marcos separados y perspectiva retro; dos personas distintas que encuentran un punto común.
- Movimiento: Señales sincronizadas y acercamiento; sin atribuir al vídeo una escena no verificada.
- Referencia anterior: https://music.apple.com/us/album/jealous-type/1834042903
- Portada: Portada no verificada

## s41 · Freak — Doja Cat
- Voz: Doja Cat, rap y canto
- Contexto: Juego de personalidad y estética retro excéntrica
- Arte: Máscaras, vinilo, cortina rosa y silueta de escena; retro pop y personalidad dual.
- Movimiento: Cambio de luz entre máscaras y ritmo de escenario.
- Referencia anterior: https://ratedrnb.com/2020/08/doja-cat-releases-new-single-freak/
- Portada: Portada no verificada

## s42 · Fly Me To The Moon - 2008 Remastered — Frank Sinatra, Count Basie
- Voz: Frank Sinatra, crooner; orquesta Count Basie
- Contexto: Amor expresado como viaje astral; swing 1964
- Arte: Luna grande, avión de papel y cielo de estrellas con pista de baile; metáfora astral de crooner.
- Movimiento: Órbita lenta y luz de big band.
- Referencia anterior: https://www.allmusic.com/song/fly-me-to-the-moon-mt0008651961
- Portada: Portada no verificada

## s43 · Deeper Conversation — Yuna
- Voz: Yuna, voz acústica íntima
- Contexto: Conocer el interior de la otra persona
- Arte: Dos tazas, un libro y ventanas de conversación; curiosidad por la persona real.
- Movimiento: Vapor alternado y pulsos de diálogo.
- Referencia anterior: https://lyricsweb.com/song/yuna/yuna-deeper-conversation
- Portada: Portada no verificada

## s44 · ALO (feat. Tutu) — Blessd, Juhn, Fronti, TURY, Tutu
- Voz: Blessd, Juhn, Tutu y colaboradores acreditados
- Contexto: Llamada y añoranza después del encuentro
- Arte: Teléfono en primer plano y dos figuras en una calle de noche; añoranza y llamadas.
- Movimiento: Ondas de llamada con luces de barrio.
- Referencia anterior: https://music.amazon.com/tracks/B0H5YVKLWZ
- Portada: Portada no verificada

## s45 · Disfruto — Carla Morrison
- Voz: Carla Morrison, voz íntima
- Contexto: Disfrutar de la presencia y los gestos cotidianos
- Arte: Habitación de tonos cálidos, una persona descansando, fotografía y taza; presencia cotidiana.
- Movimiento: Respiración visual muy suave y luz de ventana.
- Referencia anterior: https://carlamorrisonf.substack.com/p/los-frutos-de-disfruto
- Portada: Portada no verificada

## s46 · I Don't Want to Miss a Thing - From "Armageddon" Soundtrack — Aerosmith
- Voz: Steven Tyler, voz áspera de balada rock
- Contexto: No perder ni un instante junto a alguien; Armageddon
- Arte: Horizonte, planeta, cometa y dos siluetas juntas; referencia al filme Armageddon y deseo de permanecer despierto.
- Movimiento: Cometa que atraviesa el cielo y luz de horizonte.
- Referencia anterior: https://www.shortlist.com/news/diane-warren-how-i-wrote-i-dont-want-to-miss-a-thing-if-i-could-turn-back-time-and-nothings-gonna-stop-us-now
- Portada: Portada no verificada

## s47 · P.Y.T. (Pretty Young Thing) — Michael Jackson
- Voz: Michael Jackson y coros, funk disco
- Contexto: Flechazo y energía de baile; contraste blanco y negro de Thriller
- Arte: Bola de espejos, escenario disco, traje blanco estilizado y coro; contraste de la era Thriller.
- Movimiento: Cuadrículas y destellos de disco sin flash agresivo.
- Referencia anterior: https://musicbrainz.org/release/b8f457c0-a943-4225-878f-65d2301bd111
- Portada: Traje blanco sobre fondo oscuro, Thriller (https://www.mjworld.net/news/2011/03/10/michael-and-zimmerman/)

## s48 · Dopamina — Sergi
- Voz: Sergi, identidad vocal no confirmada
- Contexto: Metáfora artística del título; letra local ausente
- Arte: Red neural con señales que viajan y corazón central; metáfora provisional del título, no letra confirmada.
- Movimiento: Pulsos de nodo a nodo, dependientes de energía.
- Referencia anterior: https://www.youtube.com/watch?v=m6yZJCis4F8
- Portada: Portada no verificada

## s49 · CARENCIAS DE CORDURA — Milo j, Yami Safdie
- Voz: Milo j y Yami Safdie, dúo
- Contexto: Fragilidad, distancia emocional y búsqueda de comprensión
- Arte: Dos lunas, reflejos fracturados y figuras que se acercan; dúo de Milo y Yami.
- Movimiento: Fragmentos y encuentro en el horizonte.
- Referencia anterior: https://www.musica.com/letras.asp?letra=2603012
- Portada: Portada no verificada

## s50 · Química Mayor — Mon Laferte
- Voz: Mon Laferte, voz expresiva
- Contexto: Atracción y química íntima
- Arte: Mesa de laboratorio figurativa con tres recipientes y dos personas; química como metáfora del amor.
- Movimiento: Burbujas y enlaces, no simulación científica.
- Referencia anterior: https://www.cifraclub.com/mon-laferte/quimica-mayor/letra/
- Portada: Portada no verificada

## s51 · Lo Que Siento — Cuco
- Voz: Cuco, voz melódica bilingüe
- Contexto: Confesión amorosa y sueño despierto
- Arte: Ventana de atardecer, disco y guitarra; sueño despierto y regreso a casa.
- Movimiento: Giro lento del disco y nubes de atardecer.
- Referencia anterior: https://songsense.io/es/cuco/lo-que-siento
- Portada: Portada no verificada

## s52 · He's My Man — Luvcat
- Voz: Luvcat, voz teatral de cabaret
- Contexto: Balada de asesinato ficticia: posesión inquietante, contraste con romance
- Arte: Salón gótico con taza, rosa, siluetas y ventana; ficción inquietante con contraste doméstico.
- Movimiento: Sombras, pétalos y luz de teatro, sin romantizar la violencia.
- Referencia anterior: https://www.nme.com/features/music-interviews/luvcat-interview-radar-breakout-dinner-at-brasserie-zedel-3809564
- Portada: Portada no verificada
- Verificación adicional: https://www.nme.com/news/music/luvcat-releases-music-video-for-sinister-new-single-hes-my-man-3798329

## s53 · El Mapa De Mi Interior - Remastered 2025 — EME-15
- Voz: EME-15, voces pop grupales
- Contexto: Ser comprendido en la propia complejidad
- Arte: Costa nocturna, mapa, faro y barco; el ruido interior encuentra orientación y escucha.
- Movimiento: Haz del faro y ondas del mar.
- Referencia anterior: https://www.musica.com/letras.asp?letra=2069392
- Portada: Portada no verificada

## s54 · Tú y Yo — Valeria Jasso
- Voz: Valeria Jasso, voz íntima y acústica
- Contexto: Sueños compartidos, calma y vuelo sobre el mar; sin LRC local
- Arte: Costa rosa, dos aves y barca, guiño a la imagen de vuelo compartido descrita por Valeria Jasso.
- Movimiento: Aves lentas, nubes y reflejos del mar; sin LRC local.
- Referencia anterior: https://hgmedia.com.mx/valeria-jasso-convierte-los-suenos-en-refugio-con-tu-y-yo/
- Portada: Portada no verificada
- Verificación adicional: https://meowmag.mx/un-himno-a-la-ternura-tu-y-yo-de-valeria-jasso/?id=35

## s55 · Machine Love — Jamie Paige
- Voz: Kasane Teto SV; Jamie Paige, autor y productor
- Contexto: Máquina que busca sentir y ser real; identidad de voz sintética
- Arte: Terminales CRT, cables y corazón de píxeles que se completa; Kasane Teto como voz sintética. El sprite original queda quieto.
- Movimiento: Pulsos de datos y ensamblaje de corazón; Teto inmóvil.
- Referencia anterior: https://jamiepaige.bandcamp.com/track/machine-love-3
- Portada: Portada no verificada
- Verificación adicional: https://jamiepaige.bandcamp.com/track/machine-love-3

## Implementación y verificación
- Motor nuevo: `soundtrack-atelier.js`, 55 composiciones figurativas escritas individualmente, resolución interna 180×320 y fotogramas cacheados a 15 Hz por pista/fase. La etapa existente mezcla verso y clímax, mantiene el reloj del audio y los ajustes de intensidad, y protege los controles de efectos en primer plano. Las escenas pueden compartir primitivas de dibujo (casas, siluetas, etc.).
- Teto conserva el sprite original y no se anima; los efectos del entorno sí. No se añaden dependencias ni cambios a Firebase, música, regalos o minijuego.
- 42/42 pruebas Node; Chromium real aislado: 55/55 escenas distintas, movimiento entre dos instantes, cambios de clímax, sin errores JavaScript. Las galerías son capturas del motor real sin la interfaz superpuesta. No se ha compilado el APK, validado la integración completa del reproductor ni medido el rendimiento físico en Android.
- El contexto de las 55 pistas procede de la documentación anterior y las letras disponibles; las comprobaciones externas adicionales se identifican en cada entrada. No se verificaron todas las portadas, y Dopamina sigue siendo provisional.
