# ISMAMINT Alpha 7.23: Audio Choreography

## Arquitectura
- Espectro de los MP3 locales a 20 Hz: graves 35–220 Hz, medios 220–2100 Hz, agudos 2100–5900 Hz, energía y flujo espectral (ataques). Normalización por percentil 95 en cada pista.
- Motor determinista con marcas de beat, ataques, secciones estimadas y coincidencias de palabras clave. La corrección de sincronización de letras de la app se conserva.
- 55 perfiles explícitos con zona, efecto, banda principal y límites de cámara. Las máscaras rectangulares limitan los efectos a zonas de la composición; no constituyen una segmentación semántica exacta de objetos.
- La cámara se ancla al centro del lienzo; la interfaz y Teto quedan fuera de su transformación. No hay destellos de pantalla completa. Los efectos se desactivan con el ajuste de beat.
- El visor usa el mismo motor y admite un MP3 local opcional. No incluye el audio en el HTML.
- Referencias reutilizadas de la investigación existente, no verificadas de nuevo en esta pasada. Las secciones y BPM siguen siendo aproximados; no hay separación vocal.

## Perfiles por pista

| Pista | BPM estimado | Contexto | Efecto y banda | Palabras clave detectadas (líneas) |
|---|---:|---|---|---:|
| Esclava - Remix | 81.1 | Encuentro clandestino, trap nocturno | Luz entre persianas y reflejos metálicos · bass | 14 |
| Feel It (From “Invincible”) | 120.0 | Flechazo en lenguaje de cómic de Invincible | Impactos de viñeta y destellos · attack | 7 |
| SOLO POR VOS | 88.2 | Elegir a alguien, sol y luna | Gradiente cálido del horizonte · mid | 18 |
| Hace Mucho Tiempo | 120.0 | Espera y encuentro largamente imaginado | Barrido de película · treble | 12 |
| OJALA | 83.3 | Acompañar a alguien vulnerable | Gotas iluminadas en el cielo · treble | 6 |
| Can't Wait | 81.1 | Compromiso, hogar rural y vida compartida | Pétalos del campo y luz de tarde · mid | 18 |
| Agora Hills | 125.0 | Mostrar el vínculo, estética rosa liminal | Guirnalda de luz rosa · mid | 21 |
| Mountains | 85.7 | Devoción que mueve montañas, LSD psicodélico | Resplandor cromático sobre la cordillera · bass | 20 |
| hostage | 65.2 | Apego inquietante y encierro (videoclip blanco) | Sombras contenidas en la pared · mid | 7 |
| MIU MIU (feat. GeezyDee, CARABIN3) | 90.9 | Lujo, estilo y trap | Reflejos de joyería · treble | 14 |
| Calling (Spider-Man: Across the Spider-Verse) | 69.8 | Rescate y conexión multiversal | Reverberación en los bordes del portal · attack | 22 |
| Cyber Sex | 65.2 | Conexión digital, deseo a distancia, Hot Pink | Señales dentro del monitor · mid | 12 |
| BLANQUITA | 85.7 | Admiración, elevación y luz | Destellos suaves en nubes · treble | 3 |
| POLOS OPUESTOS REMIX - BLESSD VERSION | 90.9 | Atracción entre opuestos | Pulsos entre polos · bass | 5 |
| Si Me Sobrara el Tiempo | 83.3 | Tiempo limitado y prioridades | Arena iluminada en el cuello del reloj · treble | 6 |
| Una | 120.0 | Elegir una persona, caminar por el barrio | Luces del paseo · mid | 13 |
| Halley's Comet | 71.4 | Insomnio y enamoramiento improbable | Destellos dentro de la ventana · treble | 2 |
| Comatose | 85.7 | Despertar de la apatía | Luz que emerge por el paso rocoso · bass | 25 |
| A Tu Merced | 90.9 | Deseo nocturno y llamadas, YHLQMDLG | Reflejos sobre el mar · bass | 12 |
| Apapáchame | 176.5 | Consuelo y abrazo emocional | Luz suave sobre el tejido · mid | 7 |
| MIL D AURA | 96.8 | Visita nocturna, obstáculos familiares | Luz de la ventana a distancia · attack | 9 |
| Algo Más | 75.0 | Amor que supera distancia y tiempo | Reflejo cálido del puente · mid | 11 |
| Se Me Antoja | 90.9 | Flechazo y rap de barrio | Brillo del surco giratorio · bass | 6 |
| Wonderwall - Remastered | 115.4 | Esperanza y refugio, britpop | Lluvia sobre el entorno urbano · treble | 9 |
| Born To Be My Baby | 130.4 | Pareja trabajadora y apoyo mutuo | Focos de escenario rock · attack | 16 |
| The Feels | 120.0 | Invitación al baile y pop retro | Confeti de fiesta y luces pop · treble | 24 |
| Anhelo | 90.9 | Nostalgia salsera y deseo de encuentro | Luces de terraza y salsa · mid | 5 |
| 光るなら | 157.9 | Música y esperanza tras la lluvia, Your Lie in April | Arco cromático de la canción · mid | 7 |
| Need to Know | 130.4 | Curiosidad y atracción en Planet Her | Órbita y luces de club espacial · bass | 14 |
| Sweet Boi | 111.1 | Afecto tierno, indie | Brillos pastel en papel · treble | 4 |
| Amor Completo | 88.2 | Entrega y voz intensa de Mon Laferte | Floración y pétalos en el jardín · mid | 7 |
| Cooler Than Me | 136.4 | Pose de superioridad y distancia social | Reflejos de las lentes · treble | 8 |
| Fanática Sensual | 81.1 | Fascinación por imagen, voz y deseo | Reflejo óptico en la cámara · mid | 10 |
| Criminal | 157.9 | Atracción prohibida, videoclip de prisión | Luz de las torres · attack | 48 |
| Mi Bello Angel | 130.4 | Figura que ilumina el rumbo, corrido | Halo de luz en el cielo · mid | 5 |
| Yellow | 85.7 | Devoción bajo estrellas, Parachutes | Constelaciones doradas · treble | 15 |
| Tus Vueltas | 107.1 | Baile sobre cemento, recuerdo de barrio | Luces de la plaza · mid | 4 |
| You Rock My World | 93.8 | Groove nocturno y cortometraje de Invincible | Marquesina y focos de jazz · attack | 19 |
| Billie Bossa Nova | 73.2 | Romance discreto y bossa nova | Brillo de vinilo al swing · mid | 2 |
| Stranger | 115.4 | Conexión entre personas distintas, era Vie | Dos señales en la pantalla · mid | 6 |
| Freak | 78.9 | Deseo y humor, contraste con doo-wop de 1959 | Bombillas de tocador y luz retro · treble | 19 |
| Fly Me To The Moon - 2008 Remastered | 120.0 | Viaje astral de swing, Sinatra y Count Basie | Puntos de luz al swing · treble | 2 |
| Deeper Conversation | 85.7 | Curiosidad por el interior de la otra persona | Reflejos sobre las páginas · mid | 11 |
| ALO (feat. Tutu) | 93.8 | Llamada y añoranza urbana | Señal de la cabina telefónica · attack | 4 |
| Disfruto | 90.9 | Disfrutar de la cercanía cotidiana | Reflejo del amanecer sobre el agua · mid | 6 |
| I Don't Want to Miss a Thing - From "Armageddon" Soundtrack | 120.0 | No perder un instante, Armageddon | Estrellas y cometa cinematográfico · mid | 29 |
| P.Y.T. (Pretty Young Thing) | 125.0 | Funk y baile, Thriller | Canales de la consola funk · bass | 30 |
| Dopamina | 157.9 | Metáfora provisional de dopamina | Pulsos de red (interpretación provisional) · attack | 0 |
| CARENCIAS DE CORDURA | 93.8 | Fragilidad y diálogo, dos voces | Reflejos del dúo en el lago · mid | 2 |
| Química Mayor | 81.1 | Química como metáfora de atracción | Flujo dentro del tubo · mid | 6 |
| Lo Que Siento | 65.2 | Confesión y ensoñación lo-fi | Brillo sobre los carretes · mid | 9 |
| He's My Man | 96.8 | Obsesión doméstica inquietante, balada de asesinato ficticia | Sombra teatral del salón · mid | 12 |
| El Mapa De Mi Interior - Remastered 2025 | 83.3 | Cartografía interior, orientación y escucha | Luz de la linterna del faro · mid | 4 |
| Tú y Yo | 115.4 | Sueños compartidos y vuelo sobre el mar | Reflejo del mar, sin letra local · mid | 0 |
| Machine Love | 88.2 | Máquina que busca ser real, homenaje a Song of the Eared Robot | Pulsos digitales dentro del CRT · attack | 7 |

## Verificación
- 55 perfiles y espectros; 55 renderizados distintos con efectos activados/desactivados en Chromium, sin errores de página.
- Revisión visual de las dos escenas modificadas.
- 42 pruebas JavaScript existentes.
- No se ha compilado el APK ni verificado el rendimiento en Android.
