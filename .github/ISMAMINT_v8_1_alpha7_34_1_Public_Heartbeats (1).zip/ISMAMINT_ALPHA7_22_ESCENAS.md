# Alpha 7.22 — Esclava y Freak

- Esclava recupera la composición interior con persiana de Alpha 7.20. Aparador con teléfono y accesorio metálico de dos aros; reflejos y lluvia en la ventana.
- Freak conserva el tocador retro, con un conjunto de vestuario colgado en un soporte independiente y accesorios sobre el aparador. Se elimina la superposición de prendas y silla de la revisión anterior.
- Se desbloquea la cola de eventos de primer plano (máximo 3); los eventos se limitan a las zonas laterales. Al desactivar el beat se desactivan también los movimientos de cámara.
- Visor autónomo con accesos directos a Esclava y Freak; simula el tiempo y la cámara, no el audio ni los eventos extra de primer plano.
- 42/42 pruebas JavaScript; ambas escenas comprobadas en Chromium, con cambios de fotograma durante la reproducción y sin excepciones JavaScript. La integración de los eventos de primer plano y Android físico siguen pendientes.
