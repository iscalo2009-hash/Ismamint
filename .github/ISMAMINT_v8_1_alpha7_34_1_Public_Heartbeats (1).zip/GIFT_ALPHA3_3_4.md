# Creative Assets — primera etapa
Se retira el creador de personajes; se conserva el creador de objetos decorativos y los PNG existentes. Biblioteca con búsqueda por nombre/etiquetas, favoritos y edición de metadatos en IndexedDB. No se eliminan recursos ni se altera su contenido. Pendientes: proyectos editables, importación/exportación de biblioteca y pruebas Android.
