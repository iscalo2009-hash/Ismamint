# Heartbound Alpha 4 — Tactics
Base: Heartbound Alpha 3 Director.
- Optional boss wave objectives from level 10: seals (action near golden seal), grazes, blocks, high ground, rhythm accents, linked anchors and distortion shifts. Completing one awards energy and a Focus charge, capped at two. Focus is run-local and spent on the next applicable defense (free/linked/resonance/distortion: longer invulnerability without energy cost; guard: longer parry without energy cost; gravity: brief protection on drop). No extra buttons or menus.
- A missed counter opening remains open, with one energy/quality penalty, no passive energy farming and no repeat of the completed wave.
- Enemy aim is locked during the last 0.45 seconds; hit a telegraph from level 7 to interrupt, stagger and reclaim energy. Movement direction biases target selection, while protectors still redirect nearby shots.
- The trio interleaves two rounds per ex, separate resolve bars and active attacker/music profile. One attacker at a time, not simultaneous volleys.
- Fixed mirrored heart beam damage. Existing save format, cosmetics and other app modules retained.
- Validation: 15 Node suites, isolated Chromium smoke test (navigation, skin gallery, pause), ZIP CRC. Not a device build or playtest. Existing route validator remains approximate, gravity/guard-specific route search and exact musical synchronization remain incomplete.
