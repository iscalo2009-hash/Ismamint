# Alpha 18 — Encounter Flow
- Four individual encounters still lead to each boss, preserving all level numbers, map nodes, checkpoint format and special boss identities.
- Authored routes for worlds 1–10; six encounter types and seeded route structures thereafter. Compact and extended routes differ in encounter objectives, enemy/event frequency and ordinary obstacle pressure.
- Actual hearts collected, enemies defeated, completed arena/wall attacks, mixed progress or active survival time drive advancement. Each encounter has a minimum active duration and a bounded survival fallback; ongoing attacks may delay transition until clear. No new mandatory menus.
- The HUD displays the current encounter objective in the existing reward line when no reward is showing. Existing tutorials, equipment and automatic rewards remain intact.
- Boss health and early vulnerability windows adjusted. No forced invulnerability timer. Existing combat safety limits retained.
- Browser simulation with automatic targeting and artificially extended player invulnerability reached level 51 in 894 simulated seconds (rounded encounter times vary); no Android or human balance test. Eight Node suites verified. No Firebase changes.
