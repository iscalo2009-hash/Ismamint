# ISMAMINT v8.0 Alpha 7.4 — Visual Engine

Base: Alpha 7.3 Direct Gifts. No cambios en Android nativo, Firestore, Heartmint, Heartbound, soundtrack ni textos personales.

## Editor
- Los regalos visuales utilizan `visualEditor` (Konva). Se mantiene el editor anterior para documentos de formato antiguo.
- Selección y zoom operan sobre nodos existentes; se reconstruye la composición al confirmar un cambio, no al seleccionar. Capas de controles separadas de la composición; guías de centrado y ajuste a cuadrícula; arrastre, escala y giro.
- Zoom 100–500%, movimiento de vista, rueda y lógica de gesto de dos dedos. Barra de herramientas permanente; bandejas contextuales de elementos, capas, fondo, estilo y biblioteca.
- Texto con entrada inmediata, tipografías, colores, tamaño y estilo, vista previa y cancelación sin cambios. Los nuevos textos no contienen dedicatorias automáticas.
- Edición de imágenes: giro, espejo, recorte por bordes, brillo, contraste y saturación. Genera copia PNG en la biblioteca, conserva el original. No se agrega un campo nuevo al formato remoto.
- Capas: visibilidad, bloqueo, selección, orden por flechas y arrastre HTML en entornos compatibles. Corrección del relleno de imágenes transparentes y espera explícita de recursos al renderizar la vista del receptor.

## Pixel Studio
- Diálogo de pantalla completa, lienzo de 8 a 512 px, zoom 50–1200%, vista panorámica, cuadrícula adaptativa y miniatura.
- Pincel, goma, cuentagotas, relleno, línea, rectángulo, elipse, simetría, paleta rápida y selector de color. Hasta ocho capas, duplicación, visibilidad y orden; deshacer/rehacer de pinceladas y operaciones. Resolución modificable sin empezar de cero.
- PNG transparente con ampliación nearest-neighbor, reinserción de sprite como copia. Detección de escala de sprites cuadrados 256px generados por versiones anteriores.
- Los proyectos de capas se mantienen durante la sesión de dibujo; al insertar se aplanan a PNG. No hay guardado de proyectos de dibujo por capas ni animación de sprites. El lienzo del regalo sigue cuadrado.

## Verificación
- `node --test tests/*.test.js`: 39/39 aprobadas, desde raíz de proyecto.
- `python tests/gift-pro-browser.py`: creación, edición/cancelación de texto, arrastre, capas, fondo, dibujo, historial de dibujo, línea, PNG, giro de imagen, zoom por botones, preview y entrega local aprobados en Chromium con dimensiones móviles y medios/almacenamiento simulados. Los anteriores tests de navegador de interfaz pueden referirse a botones del editor anterior; la prueba nueva cubre el flujo visual.
- La inspección de capturas corrigió dimensiones del lienzo y transparencia. No se ha medido rendimiento en hardware real, ni verificado gestos multitáctiles, arrastre de capas táctil, teclado Android, IndexedDB real, Firebase remoto o compilación APK.
- Reglas Firestore, código de sincronización y esquema de objetos conservados. No se necesita volver a publicar las reglas si ya están publicadas las de Alpha 7.3; se recomienda actualizar los dos dispositivos.
