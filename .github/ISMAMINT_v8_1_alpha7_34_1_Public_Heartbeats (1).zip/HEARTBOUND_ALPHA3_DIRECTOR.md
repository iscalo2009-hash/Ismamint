# Heartbound Alpha 3 — Encounter Director

Based on Heartbound Alpha 2. Changes limited to the Heartbound core, adapter, HUD and tests.

- Director: health and recent hits influence wave warnings, enemy firing intervals and rest between waves. Stage-entry enemy and projectile budgets are bounded; seeded patrol/escort/ambush/swarm profiles influence group composition. Advanced hunts may include an elite with extra health and drops; advanced collection stages may become recovery encounters.
- Wave generation: avoids the last two patterns when alternatives exist. A time-expanded cardinal-movement grid samples 18 steps of 0.12 s, checking existing and proposed projectiles and announced beams, including mirrored positions in Link. Unsafe proposals are removed. This is a conservative approximation, not a proof of complete solvability: homing trajectories are approximated, between-sample collisions and future volleys are not exhaustively searched; Gravity and Guard still require specialized validation.
- Attacks: two new families, delayed reflections using the actual recent player trajectory, and alternating horizontal/vertical announced beams. Wave tails allow remaining projectiles time to travel (bounded by four seconds). Expired projectiles cannot deal damage.
- Bosses: thematic mode selection for generated bosses; Celos uses delayed reflections; Link has optional paired stabilization anchors, and clean waves, blocks, accents, grazes and anchors improve counter rewards. Counter opportunities remain explicit and have longer windows. Evil Exes remain sequential in Alpha 3.
- Tutorials: new encounter and pattern instructions on first use, no forced menus. Fixed unrelated rewards counting as perfect waves for cosmetic unlocks.
- Existing checkpoints, cosmetics and Firebase unchanged. No new audio files.

Validation: 14 Node suites, including 10,000 director configurations and 13 automated boss encounters (invulnerable bot); isolated Chromium smoke test. Android build and physical touchscreen/playtesting not performed. The director is an incremental implementation; the full encounter grammar and validator from the roadmap remain unfinished.
