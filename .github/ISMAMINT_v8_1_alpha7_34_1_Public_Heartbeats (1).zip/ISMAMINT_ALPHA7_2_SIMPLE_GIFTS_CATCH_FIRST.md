# ISMAMINT 8.0 Alpha 7.2 — Simple Gifts / Catch First

## Gift Studio
- Los regalos nuevos se crean como un lienzo libre, sin plantillas, carta obligatoria, firma automática ni compositor musical. El nombre de inventario no se dibuja en el regalo.
- El lienzo usa el editor Konva existente: texto, imágenes, formas, sprites, capas, transformación, fondo, deshacer y rehacer. Se añadieron las fuentes locales de la aplicación al selector; VT323 es la predeterminada en nuevos elementos de texto.
- Probar muestra el mismo lienzo final sin los controles del editor ni texto romántico generado. Finalizar abre entrega con nombre interno, fecha opcional y sonido chiptune existente. El envío prepara automáticamente el regalo tras la validación; los regalos sin contenido visible se rechazan.
- Las plantillas guardadas antiguas no se eliminan del almacenamiento, pero ya no aparecen en el menú. Se elimina la creación de nuevas plantillas y el acceso al compositor. Regalos y composiciones anteriores siguen siendo legibles; los borradores anteriores conservan su editor compatible. No hay migración destructiva.
- Campo interno `visualOnly` en el JSON del regalo, conservado por normalización, inventario y respaldo. No se modifican reglas Firestore ni puente nativo, que transmiten el JSON sin exigir ese campo. Ambos dispositivos deberían actualizar para renderizar la nueva presentación. La nube no fue verificada.

## Heartmint
- Cada mundo contiene cuatro niveles de recogida horizontal y un jefe (5, 10, 15...). Los antiguos niveles de combate normal y modos especiales se convierten en recogida. Los modos especiales, ataques manuales y defensas permanecen en los jefes.
- En niveles de recogida con enemigos (tercer tramo desde el nivel 3; cuarto tramo adicional desde nivel 11), cada dos corazones normales o uno dorado generan un disparo automático hacia un enemigo. El objetivo sigue siendo recoger corazones, no eliminar enemigos. Los proyectiles enemigos y obstáculos se esquivan horizontalmente; el escudo también absorbe un proyectil.
- El movimiento horizontal y el destino táctil se conservan entre tramos consecutivos; al llegar a un jefe se cambia el control. Se mantienen perfiles de jefes, sprites, canciones, métricas y datos guardados. Las duraciones reales dependen de la habilidad y de la batalla; cuatro de cinco niveles son de recogida, no una promesa de porcentaje temporal medido.

## Verificación
- 39 suites JavaScript activas superadas, incluidas dos nuevas. Ocho suites antiguas adaptadas a la nueva ruta; originales archivados en `tests/legacy-alpha71` (no son pruebas del comportamiento vigente). Se mantienen pruebas de jefes, perfiles, rutas, almacenamiento y legado que siguen aplicando.
- Prueba de Chromium `tests/gift-simple-browser.py` superada con almacenamiento simulado: creación, texto, fuente, capas, fondo, vista final y entrega local.
- Sin compilación APK ni prueba en Android/Firebase reales. Sin medición de FPS o balance de duración real. El lienzo sigue siendo cuadrado; no se añadieron nuevas dependencias.
