# ISMAMINT V6.0 · Chiptune Renaissance — Alpha 1

Base: V5.0.1. Primera fase del remake, no versión estable.

## Implementado en código
- Sistema visual retro de componentes cuadrados, bordes de píxel, jerarquía tipográfica, colores del tema existente y controles táctiles más amplios. Se mantiene VT323 y Press Start 2P.
- Navegación Inicio, Música, Chat, Juegos, Más. Datos y Logros conservan sus pestañas de Inicio.
- Inicio modular con contador, saludo original, próximo logro, ambas fechas y accesos rápidos. Reordenación, visibilidad y restauración de la configuración; contador no ocultable. Desglose completo por defecto, opción de resumen expandible.
- Biblioteca musical independiente, filtros por autor/tipo/favoritos, búsqueda, controles de reproducción, progreso, acceso a dedicatorias y opciones existentes; mini reproductor en pantallas compatibles. Se reutiliza un solo motor de audio.
- Búsqueda global de secciones, herramientas, ajustes, canciones y logros normales/secretos ya desbloqueados. Búsqueda de logros con filtros de estado; la lista semanal masiva sigue en su interfaz original.
- Más agrupado y panel de preferencias de interfaz local. Conservación de búsqueda musical, favoritos y posiciones de desplazamiento; guardado de posición de chat al navegar y al salir cuando corresponde.
- Protección de áreas de letras/efectos contra superposición con el reproductor compacto y nuevos paneles.

## Conservación
No se ha eliminado ningún archivo de V5.0.1. Las claves de datos existentes, fórmulas, textos, logros, temas, MP3, LRC, escenas, Firebase, reglas, paquete, firma y código nativo se conservan. Las preferencias nuevas tienen claves `isma_v6_*`, independientes de las originales. El sistema de respaldo existente queda intacto, no hay uno nuevo. No se añade diagnóstico ni contenido romántico nuevo.

Para instalar como actualización debe mantenerse la firma original y un versionCode compatible. No desinstalar ni borrar los datos de la app para actualizar.

## Validación
Sintaxis de 17 scripts (incluidos los inline), referencias de navegación, IDs duplicados, comparación del inventario y contenido de archivos con V5.0.1, y 55 MP3 presentes. Chromium bloqueó la navegación local (ERR_BLOCKED_BY_ADMINISTRATOR); no se verificó ejecución visual, compilación Android ni actualización real sobre datos instalados.

## Pendiente
Pruebas en Android y corrección de regresiones, remake detallado de chat/juegos/herramientas/widgets, calendario unificado, refinamiento de accesibilidad, pruebas de migración real y usabilidad con Aurora. No se considera implementado ni comprobado todo el plan de V6.0.
