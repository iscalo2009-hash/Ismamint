# Heartmint Momentum
Direct touch speed 760; free movement 158; gravity 145. Adaptive catch cadence and speed, wave/pairs formations from stage 8. Bounded particles and rings, combo indicator, warning countdown, layered pickup/dodge/boss hit audio. Reduced motion remains respected.
