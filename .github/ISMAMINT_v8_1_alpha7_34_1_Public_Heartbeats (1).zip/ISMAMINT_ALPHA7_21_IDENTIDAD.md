# Alpha 7.21 · Identidad visual
28 composiciones rehechas, 14 aprobadas protegidas, 13 conservadas por tener una composición diferenciada. El código de pintura común no se modificó. Los 55 perfiles se listan aquí.
Referencias adicionales: https://backstage.bonjovi.com/exhibits/new-jersey ; https://www.imdb.com/title/tt7039220/ (vídeo de estudio en blanco y negro); https://www.thefader.com/2023/09/22/doja-cat-scarlet-samples (vida rural imaginada en Can’t Wait). El escenario de rock es una interpretación, no una copia del videoclip. Las demás referencias proceden de las versiones previas.

## s01 · Esclava - Remix
Rehecha: Neón clandestino. Callejón mojado, un letrero encendido y un coche estacionado; tensión nocturna sin habitación ni motel.

## s02 · Feel It (From “Invincible”)
Conservada: Flechazo de cómic. Ciudad al amanecer y una viñeta de acción, corazón centrado como remate.

## s03 · SOLO POR VOS
Aprobada, intacta: Horizonte dividido. Retirados; sol, luna, montañas y ruta conservan protagonismo. Sol y brillo de horizonte.

## s04 · Hace Mucho Tiempo
Rehecha: Archivo de instantes. Primer plano de una tira de película sobre una mesa de luz; la espera aparece como recuerdos revelándose, no como una habitación.

## s05 · OJALA
Aprobada, intacta: Refugio bajo la lluvia. Paraguas con mástil, sendero alineado con entrada y charcos en terreno. Ondas de charco y luz de ventana.

## s06 · Can't Wait
Rehecha: Cosecha escarlata. Campo rural abierto, flores escarlata y dos surcos unidos al horizonte; alusión a la vida compartida imaginada en la letra.

## s07 · Agora Hills
Aprobada, intacta: Dormitorio rosa. Base del teléfono sobre la mesa, mensajes y brillo dentro de pantalla. Mensajes y luz en dormitorio.

## s08 · Mountains
Aprobada, intacta: Paisaje psicodélico. Capas de cordillera y nieve ajustadas; río y arco cromático permanecen. Grosor de arco y luz psicodélica.

## s09 · hostage
Aprobada, intacta: Habitación blanca. Sombras antes de sillas; paredes estrechan el ambiente sin duplicar objetos. Tensión lumínica en bordes.

## s10 · MIU MIU (feat. GeezyDee, CARABIN3)
Conservada: Lujo de escaparate. Expositor de joyería de terciopelo y cristal; sin coches o edificios decorativos.

## s11 · Calling (Spider-Man: Across the Spider-Verse)
Conservada: Portal sobre dos ciudades. Un portal suspendido en el cielo, ciudad de origen y destino dentro de la abertura.

## s12 · Cyber Sex
Aprobada, intacta: Terminal Hot Pink. Corazón centrado (62,155) con escala limitada, monitor y webcam. Conexión digital con pulso del corazón.

## s13 · BLANQUITA
Aprobada, intacta: Emblema celeste. Paloma blanca como metáfora de vuelo, cielo claro, colinas y flores. Interpretación artística. Aleteo anclado al cuerpo y desplazamiento suave.

## s14 · POLOS OPUESTOS REMIX - BLESSD VERSION
Aprobada, intacta: Atracción magnética. Imanes apoyados a nivel del tablero; partículas sólo en el espacio entre polos. Pulsos entre polos.

## s15 · Si Me Sobrara el Tiempo
Rehecha: Reloj de arena suspendido. Primer plano de una pieza de latón y vidrio sobre una base única, sin reloj de pared ni muebles repetidos.

## s16 · Una
Conservada: Paseo de barrio. Sendero peatonal tranquilo entre árboles y farolas; no carretera como protagonista.

## s17 · Halley's Comet
Aprobada, intacta: Noche de insomnio. Recorte existente conservado; alféizar reacciona sin cubrir muebles. Luz del alféizar y cometa.

## s18 · Comatose
Rehecha: Despertar en la grieta. Paisaje rocoso en sombra que se abre a un amanecer; la luz atraviesa un paso natural al clímax.

## s19 · A Tu Merced
Aprobada, intacta: Costanera nocturna. Se retira onda; teléfono sobre base y carretera nocturna. Pantalla y luces del vehículo.

## s20 · Apapáchame
Rehecha: Abrazo de lana. Manta tejida en primer plano, textura cálida y pliegues que respiran suavemente. Sin sala de estar.

## s21 · MIL D AURA
Rehecha: Distancia en la reja. Calle empinada y ventana iluminada al fondo; la barrera es primer plano, no una segunda fachada.

## s22 · Algo Más
Aprobada, intacta: Puente de luz. Eliminadas, iluminación en tablero y reflejos en agua. Luces del puente.

## s23 · Se Me Antoja
Rehecha: Surco del flechazo. Macro de un vinilo con una rosa estampada en la etiqueta y brillo rotatorio, inspirado en la cadencia del rap.

## s24 · Wonderwall - Remastered
Rehecha: Britpop bajo el paso elevado. Exterior urbano británico en lluvia fina; guitarra acústica apoyada junto a un arco de ladrillo.

## s25 · Born To Be My Baby
Rehecha: New Jersey: directo de 1988. Escenario rock monocromático inspirado en el videoclip de estudio: batería, amplificadores, guitarra eléctrica y focos cálidos al coro.

## s26 · The Feels
Rehecha: Prom pop: invitación y luces. Gran sobre rosa sobre pista de fiesta escolar, guirnaldas luminosas y bola de espejos, sin habitación.

## s27 · Anhelo
Rehecha: Bolero de salsa en terraza. Terraza de baile tropical con congas en primer plano, luces de guirnalda y horizonte cálido.

## s28 · 光るなら
Conservada: Música después de la lluvia. Piano con tapa y soporte en un prado; lluvia que se retira y arco iris completo.

## s29 · Need to Know
Rehecha: Planet Her: órbita nocturna. Club de ciencia ficción al aire libre bajo un planeta anillado; luces de pista y naves pequeñas, no salón terrestre.

## s30 · Sweet Boi
Rehecha: Postal de azúcar. Carta pastel desplegada sobre papel texturado con flor prensada y sello de corazón; sin escritorio.

## s31 · Amor Completo
Rehecha: Jardín de floración completa. Arco de rosas en jardín oscuro, flores unidas a ramas y apertura gradual al clímax.

## s32 · Cooler Than Me
Rehecha: Distancia en las lentes. Macro de gafas de sol sobre una superficie azul; reflejo de la ciudad dentro de cada lente y nada detrás que compita.

## s33 · Fanática Sensual
Rehecha: Cámara y fascinación. Primer plano de cámara analógica con visor, lente y reflejos ópticos; alusión a la imagen y la voz en el reguetón.

## s34 · Criminal
Rehecha: Prisión: luz de alerta. Patio carcelario inspirado en el videoclip, puerta de malla, torres y focos localizados; distinto al despertar de Comatose.

## s35 · Mi Bello Angel
Conservada: Camino hacia la luz. Camino de montaña y luz en forma de alas, símbolo del rumbo recuperado.

## s36 · Yellow
Conservada: Globo de Parachutes. Un globo dorado en un escritorio, cielo estrellado y luz cálida; base única.

## s37 · Tus Vueltas
Conservada: Plaza de cemento. Plaza de barrio con banco, arbolado y un pequeño equipo de música; giro de su disco.

## s38 · You Rock My World
Rehecha: Invincible: club de los años cuarenta. Marquesina nocturna y piano en escenario de jazz, alusión al corto de You Rock My World sin repetir salas.

## s39 · Billie Bossa Nova
Rehecha: Bossa en penumbra. Tocadiscos de perfil, vinilo giratorio y reflejo de luz ámbar en superficie de madera; discreción sin ventana ni cortinas.

## s40 · Stranger
Rehecha: Dos frecuencias, una señal. Dos ondas de color que se acoplan en una pantalla de osciloscopio retro; metáfora de conexión entre extraños.

## s41 · Freak
Aprobada, intacta: Doo-wop nocturno. Se retiran líneas; tocador, vinilo, perfume y velas conservan atmósfera retro y tema no explícito. Llama y luz local.

## s42 · Fly Me To The Moon - 2008 Remastered
Conservada: Swing lunar. Luna sobre horizonte nocturno, trompeta de latón apoyada bajo la ventana.

## s43 · Deeper Conversation
Rehecha: Conversación en dos páginas. Libro abierto en primer plano, dos trazos de tinta que se encuentran en el pliegue; intimidad acústica sin mesa ni tazas.

## s44 · ALO (feat. Tutu)
Conservada: Aló, cabina en la noche. Cabina telefónica urbana con marquesina, auricular y reflejo de lluvia en acera.

## s45 · Disfruto
Rehecha: Instantes de luz. Dos huellas de luz sobre arena y mar al amanecer; ternura cotidiana reinterpretada como tiempo compartido, sin sofá.

## s46 · I Don't Want to Miss a Thing - From "Armageddon" Soundtrack
Aprobada, intacta: Observatorio nocturno. Recorte reducido y cometa con pulso de tamaño; trípode sobre terreno. Cometa y brillo localizado.

## s47 · P.Y.T. (Pretty Young Thing)
Rehecha: Thriller: estudio funk. Macro de una consola de mezcla retro, canales rítmicos y bobinas, diferenciada del baile escolar.

## s48 · Dopamina
Rehecha: Dopamina: red de impulsos. Red abstracta a pantalla completa, nodos y pulsos viajan entre enlaces. Interpretación provisional del título, sin monitor ni habitación.

## s49 · CARENCIAS DE CORDURA
Rehecha: Dos reflejos quebrados. Lago nocturno con dos lunas reflejadas y hielo fragmentado; fragilidad y contrapunto del dúo, sin marco de ventana.

## s50 · Química Mayor
Rehecha: Química mayor: reacción de color. Dos matraces de gran formato conectados por un tubo con líquido y burbujas; fondo técnico oscuro sin laboratorio de habitación.

## s51 · Lo Que Siento
Rehecha: Ensueño de Cuco. Atardecer psicodélico sobre mar de nubes; casete lo-fi en primer plano con carretes animados.

## s52 · He's My Man
Conservada: La casa de Luvcat. Comedor gótico con reloj, té y ventilador lento; obsesión doméstica sin representar violencia.

## s53 · El Mapa De Mi Interior - Remastered 2025
Conservada: Faro interior. Faro sobre acantilado y barco en mar abierto, haz sale de la linterna y no cruza la torre.

## s54 · Tú y Yo
Conservada: Vuelo sobre el mar. Dos aves al amanecer, reflejo lunar y velero; calma y horizonte compartido.

## s55 · Machine Love
Aprobada, intacta: Corazón sintético. Cuadrícula estable; sólo cambia ocupación y brillo de celdas, terminales recortados. Pulsos digitales en celdas; Teto inmóvil.

## Pruebas
42/42 pruebas Node (antes del último ajuste visual); 168 pares de fotogramas de las aprobadas idénticos; 55/55 movimiento, clímax, mezcla de tema y pulso en Chromium; 440 intervalos de movimiento ambiental a intensidad fija, 12 estados de corazón anclados. No Android físico; BPM y secciones estimados. Dopamina provisional. No nuevas dependencias ni cambios Firebase.