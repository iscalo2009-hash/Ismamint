# Alpha 14 — Heartmint Arsenal
Base: Alpha 13 Resonance.

- 8 consumables, two equip slots, level unlocks 1/6/11/16/21/31/41/51. New attempts restore charges, boss victories and supply pickups replenish limited stock. Second slot can be changed at boss rewards. No purchases or network.
- 4 collectible powers: supply, overdrive, battery, dash reset. 12 new sound recipes.
- 11 upgrade families (6 additional), gated by level, bounded ranks and deterministic reward pools. Checkpoint storage migrates the old format; previous ranks are clamped to new effective caps. At maximum ranks, supply rewards remain available.
- First level target 7 -> 5; spawn interval 22 -> 17 frames; faster falling objects, more gold/power pickups, shorter boss entry/death, more enemy encounters, arena completion gives progress.
- Boss traits derived from main attack (armor, counter, rush, fracture), phase transitions, vulnerability every two waves, bonus for flawless evasion, aim-based targeting of the trio. Existing procedural generation and safe corridors retained; no simultaneous hostile wave generation introduced.
- Verification: all existing Node tests and new equipment tests, Chromium simulated input and all eight item effects, save/equip, pause, armor, weakness, reward. Android compilation/device play and actual pacing of a complete run not tested.
