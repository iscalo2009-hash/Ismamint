# Alpha 7.24 · Final Rhythm & Karaoke

Base: Alpha 7.23 Audio Choreography. Se conservan los 55 escenarios, música, perfiles visuales, letras originales y ajustes existentes. No se añaden dependencias ni se cambia Firebase.

## Intensidad
- Envolvente continua calculada con el espectro medido, promedio móvil local, pulso, ataque, sección, recuperación entre beats y entrada/salida. Fuerza adicional acotada a 0,78; fase gráfica a 0,92. La fase de dibujo ya no es un interruptor binario de coro.
- Cámara centrada, amplitud de movimiento reducida, luz local limitada a 0,20 de opacidad; menor pulso accesorio de la interfaz y retención de clímax de 1,2 s en lugar de 2,6 s. El fondo principal conserva una opacidad base legible independientemente del pulso.
- Las preferencias de intensidad, efectos de canción, movimiento reducido y beat se conservan.

## Karaoke
- soundtrack-karaoke.js: 55 perfiles explícitos (color, amplitud, estilo, duración y resplandor); 53 pistas con letra integrada y 2 sin letra (s48 Dopamina y s54 Tú y Yo).
- Conserva el texto y tiempos de línea de LRC y la colocación original. Segmentación de palabras con espacios y signos preservados; japonés mediante Intl.Segmenter con alternativa por caracteres. Estima límites mediante peso silábico, BPM, duración de línea y ajuste pequeño a ataques del audio. Acepta marcas individuales si existen en row.words; actualmente no se dispone de ellas.
- El reloj de reproducción y los ajustes escala/desfase controlan el resaltado. Al cambiar de palabra, se modifica solo su apariencia, sin modificar la geometría de la línea. Resaltado y escala moderada, con estilos y acentos distintos por pista. Compatibilidad con retroceso, pausa, cambio de pista y movimiento reducido. No se generan ni descargan nuevas letras.
- Los MP3 locales son la referencia de ritmo/espectro; el análisis no identifica fonemas ni separa voces. La sincronización por palabra es una aproximación, no un alineamiento vocal validado.

## Pruebas
- 42/42 pruebas JavaScript anteriores.
- Chromium: 5.500 muestras temporales de efectos, 55 perfiles con variación y valores acotados; máximo observado de fuerza adicional 0,611 en esa muestra.
- 2.862 líneas y 20.315 segmentos léxicos: conservación del texto, límites temporales ordenados, resaltado de una palabra y retroceso en 53 pistas; movimiento reducido.
- 55 fondos activos en el escenario simulado de inicio; Teto sin transformación. Prueba previa de clímax, bloqueo y preferencia ambiente superada.
- HTML completo de la app con audio y almacenamiento simulados: pista s03, reproducción, fondo principal, karaoke y palabra activa comprobados. Visor interactivo: selección, seek, reproducción simulada, karaoke activable y pistas sin letra.
- No se ha compilado APK ni medido rendimiento en Android físico. No se ha escuchado y validado manualmente cada palabra contra una voz original.
