# Alpha 20 — Player First
Base: Alpha 19 Boss Trials. Changes are limited to Heartmint and its regression tests.

## Balance
- Lost hearts now break combos only after a short grace streak; they no longer cost health. Resistance perks extend combo grace. Missing hearts during bosses or active hazards does not interrupt the combo.
- Normal weapons no longer delete boss projectiles or wall obstacles. Pulse and Prism remain emergency counters. Automatic fire checks weapon range and avoids firing into locked boss phases without other targets; it does not vibrate on every shot.
- Converted gold hearts from Pulse or victory are worth 2 points, and do not grant pulse energy, boss damage, or route progression. Ordinary heart charge is slightly reduced; perfect evasions grant charge and 5.5% boss HP damage (subject to existing cap and phase rules). Every resolved boss wave opens a damage window; actual hits and wave cancellation do not qualify as perfect dodges.
- Bounded assistance based on remaining life and recent hits reduces ordinary pressure and lengthens warnings, without skipping boss phases. At 1–2 lives, a periodic recovery heart is offered if none is present. Calm encounters reduce hazards more strongly.
- Existing authored and procedural routes and boss phase gates remain intact. Normal stages award a small extra score and pulse energy if their objective is completed without taking hits. Ordinary hazards are cleared on a normal stage transition.
- Map marks cleared worlds; earlier-world starts reconstruct bounded perks based on the number of earlier bosses, while Continue retains actual checkpoint perks. Save format is unchanged.

## Readability and performance
- Short tutorial cue in the existing status line for 10 seconds, fuller description below controls, then removed; guide remains available. Stable status height, no new overlay. Objective feedback distinguishes target reached from segment completion. Barrier button disabled while shield is active.
- Active boss wave corridor remains subtly visible. Trio positions now update in simulation rather than drawing. Lower flash intensity, reduced-motion support for screen shake and flashes, fewer routine vibrations. Heart statistics and record writes are batched every two simulation seconds and flushed on exit, reset, and death.

## Verification
- All ten Node test suites passed, including new player pressure, replay perks and combo-grace tests, 10,000 level routes, 10,000 boss phase gates, 162,000 original waves, 30,000 arena patterns, audio and progression regressions.
- Chromium: early unlocks, tutorials, nonlethal misses, protected boss projectiles, converted heart charge/damage prevention, low-life recovery. Automated invulnerable run completed all ten initial bosses; approach 67–181 s, combat 32–44 s, ~25 minutes in total. Separate automated controller with normal damage enabled reached level 16 with no retries. These are simulations, not human difficulty or device performance measurements.
- Android compilation, physical testing and human playtesting remain pending.
