# Alpha 13 — Heartmint Resonance

Original, offline Web Audio synthesis. No Undertale samples, melodies, or audio files were used. The design takes inspiration from recurring motifs, contrasting battle sections, retro synthesis and event cues.

- New `heartmint-audio.js`: 109 sound recipes, filtered noise, pitch envelopes, layered tones, stereo position where supported, voice cap (64, music limited to 40), per-event cooldown and temporary music ducking for important attacks.
- Game events have explicit cues for 12 boss attack families, 10 arena patterns (warning and fire), weapons, enemies, destructible obstacles, collectible types, abilities, phase transitions, vulnerability, boss victory, individual trio defeat, pause/countdown, level and world progression, weapon unlocks and map actions.
- Eight-bar musical structure with original leitmotif, variations, contrasting sections, cadences, diatonic chord voicing, bass, melody, counterline, arpeggios and synthesized percussion. Profiles remain specific to each world/boss, with the exes' medley maintained. Tempo and density react to phase, combo, low health, danger and vulnerability.
- Existing app music and FX volume settings apply. Pause/navigation/visibility cut scheduled voices; the main soundtrack remains suppressed during a live or paused game. No new network services.
- Tests: Node generator, journey, arena and audio graph assertions; Chromium live Web Audio scheduling and arena/ability event hooks, pause/resume/map. Not an Android build or physical audio listening test.
