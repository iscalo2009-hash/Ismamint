# Heartbound Alpha 5 — Identity

- Boss resolution challenges: beat, directional echo, ordered seals, reconnection, platform height, decoy, lure, portal and rebound. Procedural bosses derive challenges from their existing thematic pattern. Some precise defenses shorten guard/seal objectives. The original wave structure remains; no mandatory replay on missed counter window.
- Physical side boundaries narrow gradually in selected free-mode boss waves. Moving one-way platforms from level 17 carry grounded players. Jump velocity corrected from 190 to 210 to reach the first platform from the floor.
- Protectors reposition between allies and player; turrets manage distance, thieves keep and return stolen hearts, directors stagger allies' attacks without overriding telegraphs.
- New canvas indicators for targets, direction, portal entrance and exit, beat, decoy, and stolen heart. No additional buttons or persistence format changes.
- Existing 15 Node test suites plus identity suite; scripted progression with invulnerability, isolated Chromium UI smoke test. No Android compilation or physical device testing. Reachability remains approximate, notably moving boundaries and gravity/guard states. Challenges still follow waves; no claim of human-validated balance.
