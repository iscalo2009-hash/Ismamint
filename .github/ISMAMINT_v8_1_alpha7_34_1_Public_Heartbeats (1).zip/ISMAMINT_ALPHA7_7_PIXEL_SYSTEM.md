# ISMAMINT v8.0 — Alpha 7.7

## Pixel Parallax Styles

### Añadido
- Editor de estilo para fondos parallax.
- Ajustes por fondo: tono, saturación, brillo, velocidad, profundidad y overlay.
- Overlays pixel disponibles: limpio, scanlines, estrellas, corazones y grid.
- Presets rápidos: Base, Dream, Night, Arcade y Love.
- Los estilos del fondo se guardan dentro del regalo.
- Los previews del lienzo y la visualización del regalo usan el mismo estilo guardado.

### Iconografía pixel
- Sistema nuevo de iconos pixel para el editor principal del regalo.
- Iconos pixel en encabezado, acciones de historial, modos del editor y herramientas principales del lienzo.
- Iconos pixel en zoom y navegación principal del editor visual.

### Limpieza
- Se eliminó la dependencia de símbolos Unicode en los controles principales editados en esta versión.
- El motor del fondo no duplica otro sistema: ahora estiliza sobre el parallax ya existente.

### Archivos tocados
- `app/src/main/assets/gift-parallax.js`
- `app/src/main/assets/gift-canvas.js`
- `app/src/main/assets/gift-studio.js`
- `app/src/main/assets/gift-studio.css`
