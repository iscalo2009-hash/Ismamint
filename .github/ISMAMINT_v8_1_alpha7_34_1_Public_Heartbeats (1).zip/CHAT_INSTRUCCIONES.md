# ISMAMINT Chat V1

Proyecto Android basado en la navegación V1. El archivo app/google-services.json corresponde al proyecto existente.

1. En Firebase Console > Firestore Database > Reglas, reemplazar las reglas iniciales por el contenido de `firestore.rules` y publicar.
2. Compilar el proyecto con el mismo entorno y firma que la APK anterior. Usar un versionCode superior al instalado si el entorno no lo incrementa automáticamente.
3. Instalar en ambos teléfonos y abrir Chat. Cada persona entra con su correo y contraseña ya creados en Authentication.
4. Probar mensajes en ambos sentidos, respuestas, reacciones, edición, borrado, lectura, reconexión y retorno a Inicio. Probar también las funciones anteriores.

El SDK Android usa Auth y Firestore. Los documentos se generan automáticamente. Las reglas restringen las operaciones a las dos cuentas y protegen la autoría. Las confirmaciones son pendiente, enviado al servidor y leído (no hay confirmación de entrega independiente). El estado de actividad es aproximado y se actualiza mientras el chat está abierto. Se consultan los últimos 50 mensajes y pueden ampliarse hasta 1000 por sesión. El SDK proporciona caché y cola de escrituras. El borrado local oculta el mensaje solo en el dispositivo. El historial en la nube no tiene cifrado de extremo a extremo. No incluye notificaciones push, fotos, audios ni indicador global de no leídos. El plan Spark puede detener operaciones si se agotan las cuotas.

Verificación realizada: sintaxis JavaScript y comparación de archivos ZIP. No se pudo compilar Android ni probar con Firebase real en este entorno. Las pruebas en navegador se bloquearon por la política del entorno. No es una APK verificada.
