# Connected Gifts — Alpha 4.0 (integración inicial)
- Reutiliza Firebase Auth nativo del chat; inicia sesión antes de usar Conectados.
- En el taller local, prepara un regalo con el perfil correspondiente a la cuenta, marca preparado y usa Enviar por Internet. Si hay fecha elegida puedes programarlo a las 00:00 de Colombia; de lo contrario envío inmediato.
- Conectados muestra envíos y recepciones, actualización manual, apertura y favoritos. Las operaciones remotas requieren conexión. El servidor debe confirmar el envío. La transacción usa el ID del regalo para evitar duplicados. El receptor no puede modificar el contenido remoto.
- Separa metadatos y documento de contenido. Los metadatos revelan existencia y fecha de la sorpresa; las reglas restringen la lectura del contenido al destinatario hasta la fecha indicada, usando la hora del servidor. El nombre del regalo tampoco se incluye en los metadatos.
- Incluye imágenes referenciadas en el documento JSON, máximo 700000 bytes UTF-8 en total. No se usa Cloud Storage aún. No hay transferencia de audio/video externos. La música sintetizada viaja con el JSON.
- Los regalos locales anteriores, taller y papelera permanecen locales y no se sincronizan ni protegen con Auth. Las imágenes remotas se almacenan localmente para renderizar, excluidas de la biblioteca creativa; no hay cifrado local ni aislamiento frente a acceso al dispositivo. No confundir con privacidad local completa.
- No hay notificación push, sincronización de borradores, cola offline ni actualización automática. El inventario remoto requiere conexión y se consulta aparte del local.

## Activación
1. Haz copia de las reglas actualmente desplegadas en Firebase Console > Firestore Database > Rules.
2. Revisa las diferencias con firestore.rules de este proyecto. El archivo conserva las reglas existentes del chat y añade los paths ismamint_gifts. Si existen otras reglas en producción, fusiónalas antes de publicar.
3. Prueba en Firebase Emulator antes de publicar. No se ha ejecutado el emulador en este entorno.
4. Compila el proyecto Android con Android Studio y la configuración Firebase existente; prueba ambas cuentas autorizadas. Crea un regalo sin imágenes, uno con imagen y uno programado. Comprueba que el contenido no pueda leerse anticipadamente, que el envío repetido no duplique el regalo y que una tercera cuenta no pueda acceder. Verifica que el chat siga funcionando.
5. Publica las reglas solamente después de verificar las pruebas. No se ha modificado Firebase remoto desde aquí.

Pruebas locales: 34 suites existentes y nueva prueba JS de empaquetado y contrato de puente simulado; sintaxis JS. Pendientes compilación Java/Android, emulador de reglas, dos dispositivos reales, privacidad local y notificaciones.
