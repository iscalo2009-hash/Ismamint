# Heartmint 2.0 — Heartbound / Finale

Final refinement of Alpha 5. All other Ismamint features remain unchanged.

- Five contextual techniques earned at levels 6, 11, 16, 21 and 26: reflection, marked-projectile rupture, once-per-defense energy refund, timed extended pulse and directional flanking. They are based on the current stage, so revisiting early stages does not alter their original difficulty. No additional buttons or equipment menus.
- Reflected shots can cancel a hostile projectile. Telegraphs are fixed before firing, with limited movement anticipation from level 16. Interrupted enemies stop moving and shooting. Optional ambushes add normal enemies to certain collection encounters; kills do not count as collected hearts.
- Longer, individually authored routes through the first ten worlds; more varied objective counts in subsequent worlds. No additional boss timer or HP inflation. Six heart states and thirteen skins retained.
- Rhythm cues use the simulation clock. Background score locks its tempo to active rhythm periods; playback phase of the entire soundtrack is not guaranteed to match the simulation. Directional warnings in guard mode, marked gold projectiles, action cooldown indicators, stacked tutorial queue and small-screen layout refinements.
- Checkpoint seed protected against replaying the current maximum stage with another seed. Resonance mastery counts actual accents rather than unrelated charge events. Existing storage keys unchanged.

Verification: 17 Node suites, including 10,000 levels, 12 scripted boss encounters with invulnerability, and new technique, rhythm, collection and checkpoint tests. Isolated Chromium UI smoke test. These are not human playtests or proof of universally escapable attacks. Android build and physical touch testing are not performed here. Gravity/guard reachability and moving boundaries remain incompletely modeled. No APK is included; this is the Android project ZIP.
