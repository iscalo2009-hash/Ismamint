# ISMAMINT v8.0 Alpha 7 — Gift Studio Rework

Base: Alpha 6.1 Personal Texts. Cambios limitados a la interfaz de regalos, lienzo, compositor y arte. No se cambian el corazón original, cumpleaños, música existente, temas generales, widgets, esquema de regalos ni Firestore.

## Uso
- Nuevo regalo / borrador: editor modal a pantalla completa. Carta: toca directamente título, mensaje y firma. El texto provisional de edición no se incluye en la entrega.
- Diseño: tarjetas visuales de paletas existentes y ocho aperturas; personalización avanzada plegable. Envoltorios con sprites pixelados originales del editor, colores del regalo y apertura escalonada.
- Lienzo: lienzo Konva editable visible sobre la bandeja de herramientas desplazable; galería de objetos, arrastrar, escalar, girar, capas, cuadrícula, colores. Selección de imagen → Editar sprite: abre el editor artístico con una copia raster del recurso; al guardar sustituye la referencia de ese objeto, no la imagen original. Para imágenes grandes se usa lienzo libre 512; los sprites 256×256 con bloques uniformes se reconocen y reducen a su cuadrícula. Las capas de dibujo son editables durante la sesión, pero se aplanan al guardar como PNG.
- Escenas: miniaturas, duplicación, orden, transiciones, sonidos e interacciones existentes. Se mantiene el contenido anterior sin migración.
- Música: cuadrícula de ocho alturas y 16 pasos, cuatro canales, cuatro patrones, ajustes plegables, reproducción de patrón o composición. No se cambian el sintetizador ni las canciones de ISMAMINT.
- Probar: vista de receptor sin controles de edición, con apertura y escenas; Finalizar: panel de fecha y entrega existente. Guardado local automático, botón de reintento, historial global de 40 cambios en sesión (texto agrupado por ráfaga); galerías de borradores con miniaturas de texto y colores.

## Firebase
`firestore.rules`, `gift-core.js`, `gift-sync.js` y código Android permanecen byte a byte idénticos a Alpha 6.1. Si las reglas de Alpha 6.1 están publicadas, no se requiere actualización de reglas para Alpha 7. Se conserva el límite de envío y el mismo formato de imágenes y composiciones. No se comprobó el proyecto remoto.

## Verificación y límites
- 37 suites Node existentes superadas.
- Chromium: `gift-rework-browser.py` (texto directo, historial, paleta, apertura, Konva, sprite creado y modificado, escena, secuenciador, vista del receptor y preparación); `gift-final-browser.py`, `gift-music-browser.py`, `gift-scenes-browser.py` superadas.
- La navegación al servidor local fue bloqueada por el entorno; la prueba de integración usa los recursos de la app cargados directamente y almacenamiento simulado, no Firebase ni IndexedDB real. Las pruebas históricas del formulario anterior pueden necesitar actualizar sus selectores de interfaz.
- No se ha compilado el APK ni validado en Android físico. No se implementó edición de sprites animados por fotogramas ni persistencia independiente de capas artísticas; no hay zoom con gesto ni reproducción en bucle nueva en el secuenciador. El lienzo conserva el área cuadrada original y el regalo compuesto sigue usando el mismo renderizador y formato. Las opciones avanzadas conservan sus controles anteriores, ahora separados por herramientas. No se introducen dedicatorias personales nuevas.
