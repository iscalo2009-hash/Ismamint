# V4.5 — Dirección visual por canción

Cada escena tiene composición de verso, composición de coro/clímax, un evento temático y una paleta propia. Los datos de álbum proceden de los MP3; las portadas no están incrustadas. Solo se indican referencias externas verificadas cuando corresponde.

## Esclava - Remix — Bryant Myers, Anuel AA, Anonimus, Almighty
Medianoche clandestina. Encuentro oculto: persianas y callejones; el coro cierra el encuadre como un eclipse.
Álbum: Esclava · Interpretación original a partir de pista, artista, letra y metadatos; portada no verificada.
Escenas: alley → eclipse · gesto: shutter · colores: #a76ac8, #ed6277, #201125

## Feel It (From “Invincible”) — d4vd
Viñetas de adrenalina. Cómic cinético inspirado en Invincible y la energía del enamoramiento.
Álbum: Feel It (From “Invincible”) · Interpretación original a partir de pista, artista, letra y metadatos; portada no verificada.
Escenas: comic → speed · gesto: panel · colores: #f7d34d, #f65d73, #16243b

## SOLO POR VOS — Trueno
La luna por vos. El sol cae, la luna asciende y dos trayectorias se encuentran.
Álbum: SOLO POR VOS · Interpretación original a partir de pista, artista, letra y metadatos; portada no verificada.
Escenas: horizon → orbit · gesto: moon · colores: #e79d66, #f2d5a0, #231628

## Hace Mucho Tiempo — Arcángel
Fotogramas del tiempo. Película analógica y ventanas de recuerdos que se abren con el deseo.
Álbum: Sentimiento, Elegancia y Maldad · Interpretación original a partir de pista, artista, letra y metadatos; portada no verificada.
Escenas: film → window · gesto: frame · colores: #d8b680, #f1dec0, #291f1c

## OJALA — Milo j, Bhavi
Peso y esperanza. Lluvia y papel que se despliega en las repeticiones del deseo.
Álbum: 166 (DELUXE) retirada · Interpretación original a partir de pista, artista, letra y metadatos; portada no verificada.
Escenas: rain → paper · gesto: fold · colores: #8796c9, #d8c5ef, #161c32

## Can't Wait — Doja Cat
Hilos de impaciencia. Hilos tensos que convergen; al estribillo se trenzan, referencia a Scarlet.
Álbum: Scarlet · Scarlet: referencia a las arañas de la portada final (Pitchfork).
Escenas: thread → orbit · gesto: knot · colores: #d95372, #f6d6d8, #300f1e

## Agora Hills — Doja Cat
Amor a la vista. Marcos de fotografía y telarañas de seda: del secreto a mostrar el vínculo, referencia a Scarlet.
Álbum: Scarlet · Scarlet: referencia a las arañas de la portada final (Pitchfork).
Escenas: window → thread · gesto: frame · colores: #f2a7b5, #e75d82, #321823

## Mountains — Sia, Diplo, Labrinth, LSD
Montañas imposibles. Montañas que cambian altura al ritmo y paisaje caleidoscópico en el coro.
Álbum: LABRINTH, SIA & DIPLO PRESENT... LSD · Interpretación original a partir de pista, artista, letra y metadatos; portada no verificada.
Escenas: mountain → kaleido · gesto: peak · colores: #40d7c5, #f7b660, #1c2249

## hostage — Billie Eilish
Habitación de cristal. Jaula abstracta que se contrae, grietas y líneas circulatorias.
Álbum: dont smile at me · Interpretación original a partir de pista, artista, letra y metadatos; portada no verificada.
Escenas: cage → vein · gesto: unlock · colores: #e0b86b, #d75d62, #251b1c

## MIU MIU (feat. GeezyDee, CARABIN3) — Blessd, Kris R., Young Fatty, TURY, CARABIN3
Pasarela de diamantes. Pasarela geométrica y refracción de joyas en las barras fuertes.
Álbum: EXTRADITABLESSD · Interpretación original a partir de pista, artista, letra y metadatos; portada no verificada.
Escenas: runway → prism · gesto: gem · colores: #a7c9e8, #f5f0fa, #151f37

## Calling (Spider-Man: Across the Spider-Verse) — Metro Boomin, Swae Lee, NAV, A Boogie Wit da Hoodie
Señal multiversal. Red de conexiones y portales de rescate, estética de cómic multiversal.
Álbum: METRO BOOMIN PRESENTS SPIDER-MAN: ACROSS THE SPIDER-VERSE · Interpretación original a partir de pista, artista, letra y metadatos; portada no verificada.
Escenas: web → portal · gesto: signal · colores: #55a9ee, #fc547d, #151831

## Cyber Sex — Doja Cat
Terminal rosa. Interfaz digital rosa y mensajes abstractos, sin copiar la portada.
Álbum: Hot Pink · Interpretación original a partir de pista, artista, letra y metadatos; portada no verificada.
Escenas: terminal → pixel · gesto: message · colores: #ff65ad, #a68eff, #301438

## BLANQUITA — Kris R., Prodmonja
Cielo de porcelana. Nubes claras, alas geométricas y luz ascendente.
Álbum: BLANQUITA · Interpretación original a partir de pista, artista, letra y metadatos; portada no verificada.
Escenas: cloud → prism · gesto: wing · colores: #e0e9f6, #a5c9ff, #20314b

## POLOS OPUESTOS REMIX - BLESSD VERSION — Blessd, Kris R.
Dos campos opuestos. Campos contrarios que se atraen y se cruzan en el centro.
Álbum: POLOS OPUESTOS REMIX · Interpretación original a partir de pista, artista, letra y metadatos; portada no verificada.
Escenas: magnet → orbit · gesto: collision · colores: #559dff, #ff7189, #1b2142

## Si Me Sobrara el Tiempo — Duki
Reloj que desaparece. Relojes desarmándose y círculos que se cierran como portales.
Álbum: Si Me Sobrara el Tiempo · Interpretación original a partir de pista, artista, letra y metadatos; portada no verificada.
Escenas: clock → portal · gesto: hourglass · colores: #c6a57a, #e8d7b0, #241e2a

## Una — Blessd
Una entre todas. Espuma ascendente y una luna única que ilumina la escena.
Álbum: Una · Interpretación original a partir de pista, artista, letra y metadatos; portada no verificada.
Escenas: foam → horizon · gesto: moon · colores: #78b7db, #f8c1b7, #172b3f

## Halley's Comet — Billie Eilish
Órbita de Halley. Luz beige y azul nostálgico, cometa con una trayectoria larga en los momentos de confesión.
Álbum: Happier Than Ever · Happier Than Ever: estética de retrato íntimo y lágrimas (W).
Escenas: orbit → comet · gesto: meteor · colores: #c9bca7, #a7c0f0, #262832

## Comatose — Skillet
Despertar eléctrico. Vidrio roto, ondas de choque y apertura de luz al despertar.
Álbum: Comatose · Interpretación original a partir de pista, artista, letra y metadatos; portada no verificada.
Escenas: fracture → shock · gesto: crack · colores: #e44c59, #e7d5c8, #23151c

## A Tu Merced — Bad Bunny
Marea nocturna. Olas que cruzan el horizonte, arena y luz nocturna.
Álbum: YHLQMDLG · Interpretación original a partir de pista, artista, letra y metadatos; portada no verificada.
Escenas: tide → horizon · gesto: wave · colores: #6ec7d3, #f2aa77, #1b3039

## Apapáchame — Arroba Nat
Refugio de papel. Papel rasgado que se recompone y dos formas envolventes.
Álbum: Apapáchame · Interpretación original a partir de pista, artista, letra y metadatos; portada no verificada.
Escenas: paper → embrace · gesto: fold · colores: #efd2a8, #ef9da9, #382a25

## MIL D AURA — Kris R., Prodmonja, Los Money Makers
Aura contra el mundo. Callejón de luz y escudos que se levantan contra las barreras.
Álbum: MIL D AURA · Interpretación original a partir de pista, artista, letra y metadatos; portada no verificada.
Escenas: alley → aura · gesto: shield · colores: #67cbb4, #e4b45d, #132b2a

## Algo Más — La Quinta Estacion
Más allá de la distancia. Dos orillas unidas por un puente de pétalos.
Álbum: Flores De Alquiler · Interpretación original a partir de pista, artista, letra y metadatos; portada no verificada.
Escenas: bridge → bloom · gesto: bridge · colores: #e6a2ae, #f3d3a1, #2e1c30

## Se Me Antoja — Kodigo 36
Hechizo en movimiento. Reflejos oculares abstractos y pequeñas flores de luz.
Álbum: Crónicas de un Demente · Interpretación original a partir de pista, artista, letra y metadatos; portada no verificada.
Escenas: prism → bloom · gesto: spark · colores: #d86b9e, #f2b86b, #321d31

## Wonderwall - Remastered — Oasis
Calle hacia el refugio. Perspectiva urbana y una ventana cálida que se abre.
Álbum: (What's The Story) Morning Glory? (Deluxe Remastered Edition) · Interpretación original a partir de pista, artista, letra y metadatos; portada no verificada.
Escenas: street → window · gesto: door · colores: #a6aebc, #dfcaa9, #22262b

## Born To Be My Baby — Bon Jovi
Himno de escenario. Focos de rock de estadio y haces que se cruzan en el estribillo.
Álbum: New Jersey · Interpretación original a partir de pista, artista, letra y metadatos; portada no verificada.
Escenas: stage → shock · gesto: beam · colores: #e04751, #f4d89f, #281b20

## The Feels — TWICE
Laboratorio de mariposas. Experimento pop inspirado en Formula of Love; reacción de corazones y confeti.
Álbum: Formula of Love: O+T=ᐸ3 · Formula of Love: concepto de científicas y estudio del amor (Elle).
Escenas: lab → confetti · gesto: heart · colores: #f4a0cf, #b3c7ff, #28203c

## Anhelo — Adolescent's Orquesta
Salón de anhelo. Suelo de baile cálido y rosa que se abre al coro.
Álbum: Reclamando Nuestro Espacio · Interpretación original a partir de pista, artista, letra y metadatos; portada no verificada.
Escenas: disco → bloom · gesto: rose · colores: #bf9766, #efad91, #2c211e

## 光るなら — Goose house
El cielo aprende a brillar. Amanecer que transforma oscuridad en color, con arcos cromáticos y luz.
Álbum: Hikarunara · Interpretación original a partir de pista, artista, letra y metadatos; portada no verificada.
Escenas: horizon → kaleido · gesto: rainbow · colores: #f0cc68, #81c9f1, #1c2d47

## Need to Know — Doja Cat
Planeta desconocido. Órbitas alienígenas y portal de curiosidad; referencia al arte extraterrestre de Planet Her.
Álbum: Planet Her (Deluxe) · Planet Her: dirección visual extraterrestre (David LaChapelle/iHeart).
Escenas: orbit → portal · gesto: eclipse · colores: #c08cf6, #f0a5d6, #24153d

## Sweet Boi — Chevy
Dulzura de bolsillo. Pegatinas de papel y estrellitas que rebotan como juguete.
Álbum: Sweet Boi · Interpretación original a partir de pista, artista, letra y metadatos; portada no verificada.
Escenas: paper → confetti · gesto: star · colores: #f4b7bb, #f6d8a0, #372736

## Amor Completo — Mon Laferte
Amor que florece. Dos formas se acomodan una junto a otra; floración plena en el coro.
Álbum: Amor Latino · Interpretación original a partir de pista, artista, letra y metadatos; portada no verificada.
Escenas: embrace → bloom · gesto: rose · colores: #df8799, #f3cb9f, #311c25

## Cooler Than Me — Ethan Fields
Fachada de hielo. Cristal frío que se fractura en los golpes y deja entrar luz.
Álbum: Cooler Than Me · Interpretación original a partir de pista, artista, letra y metadatos; portada no verificada.
Escenas: prism → fracture · gesto: gem · colores: #8fcdf4, #e2ebfb, #182b40

## Fanática Sensual — Plan B
Fotografía nocturna. Encuadres de cámara y luces de pasarela nocturna.
Álbum: Love And Sex · Interpretación original a partir de pista, artista, letra y metadatos; portada no verificada.
Escenas: film → runway · gesto: shutter · colores: #d46b9c, #e6ae91, #301a2b

## Criminal — NATTI NATASHA, Ozuna
Alerta de atracción. Señales de neón y ondas rítmicas de alerta sin flashes.
Álbum: Criminal · Interpretación original a partir de pista, artista, letra y metadatos; portada no verificada.
Escenas: alley → shock · gesto: signal · colores: #f65b60, #f0ab70, #29151d

## Mi Bello Angel — Natanael Cano
Alas que orientan. Alas que se abren y camino luminoso que recupera el rumbo.
Álbum: Nata Montana · Interpretación original a partir de pista, artista, letra y metadatos; portada no verificada.
Escenas: cloud → bridge · gesto: wing · colores: #e3c991, #b6d9f5, #20324a

## Yellow — Coldplay
Globo de luz. Globo cálido inspirado en Parachutes, constelación que se ilumina con la letra.
Álbum: Parachutes · Parachutes: globo amarillo iluminado (tienda oficial Coldplay).
Escenas: globe → orbit · gesto: star · colores: #efc14f, #ffe5a0, #17222e

## Tus Vueltas — Milo j
Giros en la plaza. Plaza en perspectiva, anillos de baile y trayectorias circulares.
Álbum: Tus Vueltas · Interpretación original a partir de pista, artista, letra y metadatos; portada no verificada.
Escenas: street → spiral · gesto: turn · colores: #7eab9c, #e5b984, #202c2f

## You Rock My World — Michael Jackson
Escenario magnético. Focos cruzados y suelo disco al groove.
Álbum: no registrado · Interpretación original a partir de pista, artista, letra y metadatos; portada no verificada.
Escenas: stage → disco · gesto: beam · colores: #b5a4ed, #f2d6ad, #211d36

## Billie Bossa Nova — Billie Eilish
Salón de terciopelo. Cortinas de luz, textura fotográfica cálida de la era Happier Than Ever.
Álbum: Happier Than Ever · Happier Than Ever: retrato íntimo (W).
Escenas: curtain → film · gesto: shutter · colores: #d0b89c, #b69c81, #2c2526

## Stranger — Doja Cat
Todo está conectado. Red de organismos abstractos que se enlaza con cada confesión.
Álbum: no registrado · Interpretación original a partir de pista, artista, letra y metadatos; portada no verificada.
Escenas: vein → web · gesto: knot · colores: #a0b2e2, #d6a8ce, #25233d

## Freak — Doja Cat
Teatro excéntrico. Telón teatral y simetrías que cambian de orientación.
Álbum: Freak · Interpretación original a partir de pista, artista, letra y metadatos; portada no verificada.
Escenas: curtain → kaleido · gesto: panel · colores: #e86b96, #c59cf6, #321a39

## Fly Me To The Moon - 2008 Remastered — Frank Sinatra, Count Basie
Vuelo de salón. Luna creciente y órbita de swing con luces de salón.
Álbum: Nuevo año Chill · Interpretación original a partir de pista, artista, letra y metadatos; portada no verificada.
Escenas: orbit → disco · gesto: moon · colores: #b9d0ed, #e5d4a4, #162637

## Deeper Conversation — Yuna
Conversación profunda. Ventanas enfrentadas, pulsos de diálogo y conexiones delicadas.
Álbum: Decorate · Interpretación original a partir de pista, artista, letra y metadatos; portada no verificada.
Escenas: window → vein · gesto: message · colores: #76bfae, #e4d2a5, #172f32

## ALO (feat. Tutu) — Blessd, Juhn, Fronti, TURY, Tutu
Llamada sin cobertura. Ondas telefónicas abstractas y callejón iluminado con señales.
Álbum: EL PEOR HOMBRE DEL MUNDO · Interpretación original a partir de pista, artista, letra y metadatos; portada no verificada.
Escenas: terminal → alley · gesto: signal · colores: #72c5a1, #f0cf7c, #142a30

## Disfruto — Carla Morrison
Tiempo compartido. Fotogramas cálidos, formas cercanas y encuadres que se ralentizan.
Álbum: Déjenme Llorar · Interpretación original a partir de pista, artista, letra y metadatos; portada no verificada.
Escenas: film → embrace · gesto: frame · colores: #e3a48b, #f4d5b8, #392822

## I Don't Want to Miss a Thing - From "Armageddon" Soundtrack — Aerosmith
No dejar pasar el cielo. Cielo cinematográfico, eclipse abierto y estelas ascendentes.
Álbum: I Don't Want To Miss A Thing EP · Interpretación original a partir de pista, artista, letra y metadatos; portada no verificada.
Escenas: comet → eclipse · gesto: meteor · colores: #a9c2ee, #f5d3aa, #15243b

## P.Y.T. (Pretty Young Thing) — Michael Jackson
Disco de blanco y negro. Contraste blanco-negro de Thriller y pista de baile retro.
Álbum: Thriller · Thriller: contraste traje blanco y fondo oscuro (Behind the Covers).
Escenas: disco → runway · gesto: spark · colores: #eee6dc, #cf9f64, #1e1d29

## Dopamina — Sergi
Circuito de dopamina. Red neuronal rítmica; sin letra local, depende de la energía.
Álbum: Dopamina · Interpretación original a partir de pista, artista, letra y metadatos; portada no verificada.
Escenas: lab → vein · gesto: signal · colores: #f5a65f, #f68aba, #302039

## CARENCIAS DE CORDURA — Milo j, Yami Safdie
Luna fracturada. Fragmentos de espejo lunar que se recomponen en órbitas.
Álbum: 111 · Interpretación original a partir de pista, artista, letra y metadatos; portada no verificada.
Escenas: fracture → orbit · gesto: moon · colores: #9eaecb, #d2b9d8, #242638

## Química Mayor — Mon Laferte
Química en soledad. Moléculas con dos núcleos que forman enlaces y se acercan.
Álbum: 1940 Carmen · Interpretación original a partir de pista, artista, letra y metadatos; portada no verificada.
Escenas: lab → embrace · gesto: knot · colores: #caa0de, #e2aa89, #30223b

## Lo Que Siento — Cuco
Regreso a casa. Atardecer lo-fi que termina en una ventana de hogar.
Álbum: Lo Que Siento · Interpretación original a partir de pista, artista, letra y metadatos; portada no verificada.
Escenas: horizon → window · gesto: door · colores: #83c5bc, #e8b2c7, #25313b

## He's My Man — Luvcat
Declaración de cabaret. Telón de cabaret oscuro y rosas que se abren en afirmaciones.
Álbum: He's My Man · Interpretación original a partir de pista, artista, letra y metadatos; portada no verificada.
Escenas: curtain → bloom · gesto: rose · colores: #d14961, #f0c4b5, #301b24

## El Mapa De Mi Interior - Remastered 2025 — EME-15
Faro interior. Mapa de rutas que conduce hacia un faro entre la niebla.
Álbum: no registrado · Interpretación original a partir de pista, artista, letra y metadatos; portada no verificada.
Escenas: map → bridge · gesto: beam · colores: #b9a4df, #a6d7ee, #242a43

## Tú y Yo — Valeria Jasso
Dos órbitas juntas. Dos rutas que convergen; sin letra local, transición según energía.
Álbum: Tú y Yo · Interpretación original a partir de pista, artista, letra y metadatos; portada no verificada.
Escenas: bridge → embrace · gesto: knot · colores: #efb5ce, #a8d5e9, #2d283b

## Machine Love — Jamie Paige
Máquina que aprende a amar. Sistema de ventanas y circuitos que ensamblan un corazón pixelado; cameo de Teto.
Álbum: Constant Companions (Deluxe Edition) · Constant Companions: voces sintetizadas y Kasane Teto (Bandcamp oficial); no se verificó la imagen de portada.
Escenas: terminal → pixel · gesto: heart · colores: #79e1d0, #ff8eb7, #142c31
