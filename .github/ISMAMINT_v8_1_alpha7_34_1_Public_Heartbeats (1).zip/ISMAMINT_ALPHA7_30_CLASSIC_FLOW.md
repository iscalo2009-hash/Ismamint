# Alpha 7.30 — Classic Flow (primera parte de Experience)
Base: Alpha 7.29. Referencia: ISMAMINT_v4_5_soundtrack_remake(1).zip, app/src/main/assets/index.html, funciones fallV, spIv, spawn, event, wallWarn y levelUp. La versión antigua genera corazones mediante una trayectoria horizontal de pasos acotados, usa curvas exponenciales de velocidad/frecuencia y alterna momentos de lluvia con amenazas señalizadas. No se ha restaurado código ni eliminado los sistemas modernos.

## Calendario
- Se agregan metadatos de importancia y ocasión a las fechas existentes, sin alterar títulos, horas, fuentes ni fechas. Cumpleaños y aniversarios anuales tienen prioridad 3; mesiversarios y otras ocasiones, 2; logros y avisos mantienen prioridad normal.
- Rosa para Aurora y San Valentín, amarillo para Ismael y aniversarios, tema activo para otras ocasiones. Marcas pixeladas, leyenda y distinción de hoy/selección. La prioridad se calcula entre los eventos visibles del filtro; conserva el contador de eventos.

## Heartmint
- Intervalo base de corazones: 0,38 s al comienzo, converge a 0,21 s. Velocidad base: 125 a 204 unidades/s. Ambas curvas conservan el ajuste dinámico por asistencia y suavizado de 2,8 s. No se modifica la física fija de 120 Hz.
- Trayectorias de generación con desplazamiento limitado (24–65 unidades según cadencia) y reflexión en los extremos, evitando acumulaciones por recorte de posición.
- Lluvia dorada periódica: primera oportunidad tras 12–17 s, siguientes tras 15–24 s, duración 3,2–4,7 s. No interrumpe la partida ni elimina obstáculos existentes; suspende nuevas amenazas durante la lluvia.
- Avisos de obstáculos con anticipación de 0,39–0,53 s según presión, manteniendo el validador de ruta y los límites existentes.
- La secuencia pseudoaleatoria y temporizador de eventos continúan entre niveles normales. Jefes, equipo, progresión, logros y estética actual intactos. Se conservan objetivos y reglas modernas (no se restablece el daño por perder corazones de v4.5).

## Validación
46/46 archivos de pruebas Node superados. Chromium: calendario (aniversario, mesiversario, cumpleaños, ocasión, selección y filtro), Heartmint (controles, pausa y navegación). No se ha medido FPS ni compilado APK ni realizado una partida manual larga en Android físico. Esta entrega cubre el calendario y ritmo de Heartmint; el resto de mejoras de Experience (chat y editor/inventario de regalos) no se ha implementado en esta versión.
