# ISMAMINT V4.0 — Our Soundtrack

- 55 MP3 chiptune originales del ZIP suministrado, sin recompresión. Metadatos del README; 49 dedicatorias, 6 incorporaciones a playlist, nota original de Esclava.
- Más > Música: anterior/siguiente, pausa, volumen, orden secuencial por fecha, aleatorio sin repetir durante una vuelta normal, repetir pista, búsqueda y filtro por persona. Guarda posición y configuración localmente.
- Aviso interno con título, artista, autor de dedicatoria, fecha y días transcurridos calculados por día civil de Colombia. Los avisos se posponen en chat, juegos y diálogos. Se pueden desactivar.
- Fondos ambientales ligeros con paleta por canción, sin reemplazar el tema. Letras locales LRC importables por canción desde su ficha (···); ajuste de desfase y escala temporal. No se incluyen letras porque el ZIP original no contiene LRC. No se usa Musixmatch ni otra API.
- Recuerdos editables locales, lista cronológica, estadísticas locales de tiempo audible y canciones completas, nueve logros en categoría Música. Completar una pista requiere reproducir al menos aproximadamente 90% y llegar al final. El progreso se mide por dispositivo.
- Pausa de música al ocultar la app o usar audio/vídeo/grabación del chat. Los efectos del juego permanecen activos mientras se usa la app.
- Sin cambios en Firebase, sin servicios nuevos, sin datos móviles para reproducción musical.

## Validación
Se verificaron las 55 correspondencias, duración de MP3 mediante ffprobe, sintaxis JS de scripts incluidos y externos, e integridad del ZIP. No se ha compilado ni probado en Android. Probar selección aleatoria, restauración, importación LRC, aviso en cambio natural, audio de chat, logros y comportamiento al volver del segundo plano en ambos dispositivos.

## Pendiente
Pruebas de dispositivo, conseguir archivos LRC legítimos de las versiones adecuadas, ajustar tiempos por pista y, si se desea, pulir perfiles visuales individuales. No se ha incorporado importación de nuevas canciones MP3 ni sincronización de estadísticas entre dispositivos.
