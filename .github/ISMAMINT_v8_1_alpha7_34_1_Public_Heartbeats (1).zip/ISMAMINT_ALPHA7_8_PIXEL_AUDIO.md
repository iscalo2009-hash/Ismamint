# Alpha 7.8 — Pixel & Audio
- Regalos dispone de una sección propia p15 y acceso en navegación inferior. El botón Crear regalo abre directamente el editor visual.
- Biblioteca compartida de símbolos pixel de 7 × 7, aplicada a controles principales, símbolos de regalos, chat, música, navegación, iconos contextuales y galerías. No cambia el sprite original ni los emojis escritos por los usuarios. Los iconos nativos de Android y decoraciones legacy no han sido auditados exhaustivamente.
- Sonido contextual sobre IsmaFeel, con debounce de 110 ms, volumen de efectos existente y ajuste independiente Sonidos chiptune contextuales. Se evita tocar al dibujar, desplazar, cambiar sliders, o reproducir multimedia del chat. Confirmación de envíos de chat y regalos al recibir respuesta válida; los juegos conservan sus sonidos originales. Las pruebas no verifican salida física del audio.
- Estilos parallax conservados; velocidad base recuperada para fondos sin personalizar.
- 41 suites JavaScript superadas; prueba integrada Chromium del nuevo acceso a Regalos, creación, fondos, estilo, movimiento, preview y entrega local. Pruebas Android y Firebase real pendientes.
