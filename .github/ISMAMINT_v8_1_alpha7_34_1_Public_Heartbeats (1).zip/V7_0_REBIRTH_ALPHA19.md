# Alpha 19 — Boss Trials

- Mantiene los mundos de cinco niveles, checkpoints, desbloqueos y recompensas automáticas.
- Amplía los cuatro encuentros de cada mundo según su composición, con factores de 1,40 a 1,65 en los primeros diez mundos y variaciones deterministas acotadas a partir del undécimo. Los objetivos y la salida de respaldo por supervivencia se conservan.
- Ajusta la vida de los jefes, limita el daño por impacto, reduce el daño de corazones dorados durante el combate y reduce el daño de armas durante las oleadas activas.
- Cada fase tiene su propio mínimo de tiempo de simulación y de oleadas resueltas. El último tramo de vida de la fase está protegido hasta satisfacer ambos requisitos. Una oleada iniciada en una fase anterior no cuenta como oleada de la siguiente. Los ataques cancelados mediante habilidades siguen siendo válidos como oleadas resueltas.
- La barra de vida marca los umbrales de fase. El indicador RESISTE informa de la protección temporal sin abrir ventanas ni pausar la partida. Los límites de HP y de dificultad permanecen acotados.
- Simulación Chromium con jugador automatizado e invulnerable, semilla 123: recorridos 70, 113, 115, 135, 158, 103, 67, 88, 111, 181 s; combates 32, 34, 36, 36, 37, 36, 37, 36, 37, 44 s. No es una medición de juego humano ni una duración máxima garantizada.
- Sin modificaciones de Firebase, canciones ni formato de guardado. Pendiente prueba física Android y ajuste a jugadores reales.
