# Alpha 7.28 — Recepción de regalos

Base: Alpha 7.27. Sin cambios en los recursos musicales, Heartmint, firma ni reglas Firestore.

- Antes: la consulta de entregas estaba restringida al inventario. Las notificaciones nativas solo observaban mensajes del chat. No había una escena global de recepción.
- Ahora: observador Firestore del buzón entrante mientras la actividad está visible, comprobación de fechas cada 30 segundos, consulta al iniciar/reanudar/cambiar sesión y comprobación JS de respaldo cada 45 segundos. Los documentos programados no se leen hasta la fecha; la regla Firestore existente sigue autorizando el acceso por hora del servidor.
- Canal Android Regalos independiente, notificación privada por entrega, deduplicada por cuenta e ID. JobScheduler persistente de 15 minutos nominales (Android controla los tiempos); se reinstala al arrancar/actualizar. No es FCM: no garantiza aviso instantáneo con la aplicación cerrada o detenida a la fuerza. Requiere permiso de notificaciones y sesión de Firebase.
- Al entrar en Inicio aparece la sorpresa pixel art, remitente, Abrir regalo y Más tarde. En otras pantallas aparece acceso discreto; no interrumpe el editor. Al tocar la notificación se prioriza su regalo. Las entregas múltiples se muestran en cola. El regalo no se descarga hasta abrirlo y se conserva su envoltorio original. Se marca abierto tras revelar el envoltorio y, en regalos visuales, después de generar el lienzo. Puede reabrirse desde el inventario. Si la confirmación falla, se ofrece reintentar.
- El puente Android/WebView ahora transmite el contenido leído en fragmentos de 64.000 caracteres base64 UTF-8, en vez de una sola evaluación JS potencialmente enorme. Se informa del código de error Firestore (sin datos del regalo).

## Verificación
- 44/44 pruebas Node.
- Prueba Chromium de la app completa con NativeGifts simulado: sorpresa, aplazamiento, regreso, lectura fragmentada, envoltorio, confirmación, entrega programada, enlace de notificación simulado y lienzo visual.
- Firestore rules y debug.keystore idénticos a 7.27.
- No se dispone de SDK/Gradle Android ni credenciales de ambas cuentas en este entorno. No se compiló APK ni se probó Firebase remoto, notificación Android, JobScheduler o entrega entre teléfonos físicos. Verificar que las reglas Firestore incluidas estén publicadas en la consola; si no, publicar la versión incluida (no abrir la base a todo el mundo). Actualizar ambos teléfonos y comprobar primero con un regalo pequeño inmediato, después uno con imágenes y otro programado.
