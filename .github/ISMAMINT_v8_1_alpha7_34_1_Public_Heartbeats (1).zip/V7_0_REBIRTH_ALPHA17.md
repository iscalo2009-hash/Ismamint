# Alpha 17 — Continuum

- Cuatro tramos entre jefes: 10–15 s mínimos por tramo, seis segundos adicionales como respaldo por supervivencia si no se alcanza el objetivo de corazones. 42–54 s de recorrido base mínimo por mundo, 66–78 s con el respaldo (los eventos activos/introducciones pueden extenderlo). No se inicia otra oleada mayor al cerrar un tramo. Los jefes conservan su posición y generación.
- Sin selector de recompensas: se eliminó el DOM y la preferencia manual antigua se migra a automático. Recompensas, cargas y guardado sin detener la partida; aviso breve de cuatro segundos.
- Equipamiento automático por nivel: arma más reciente, botiquín y segundo objeto desbloqueado más reciente. Cargas existentes se conservan. Personalización opcional plegada en el mapa; disparo automático por defecto, con preferencia explícita persistente.
- Reintento directo desde el tramo de la derrota; conserva semilla y mejoras del intento. Un replay anterior no sobrescribe el checkpoint más avanzado. El mapa sigue disponible.
- Daño por impacto limitado proporcionalmente a la vida del jefe, recompensa de daño por esquivas perfectas en combates prolongados, más oportunidades de curación a poca vida, y no se castiga perder corazones al esquivar una amenaza cercana. Paso de simulación subdividido para mejorar el ritmo a FPS moderados.
- Tutorial inicial actualizado; se mantienen desbloqueos y ataques de introducción. Sin cambios de Firebase, audio, assets musicales ni reglas.

Pruebas: ocho suites Node, 10.000 curvas de progresión, 162.000 oleadas previas, y Chromium con simulación automatizada de cinco combates consecutivos (jugador de prueba invulnerable, seguimiento de objetos y disparos). Intervalos observados: 42 s de simulación entre jefes, sin pausas. Comprobación del respaldo de supervivencia, migración, equipo automático, reintento y conservación de checkpoint. No se ha compilado Android ni validado el equilibrio con jugadores humanos.
