# V4.9 — Quality of Life

- Eliminado el botón de diagnóstico visual y la publicación de métricas y contadores de errores para esa pantalla. Se mantiene el ajuste gráfico adaptativo.
- Hoja de estilos común para inicio, datos, logros, juegos, herramientas, temas, avisos, widgets, Más y controles del chat. Menos borde y resplandor en cajas, mejores tamaños táctiles, ajuste de textos, pantallas estrechas y foco visible.
- Más y Herramientas con filas orientadas a la lectura, iconos y flechas.
- Transición breve al cambiar de pantalla, respetando movimiento reducido. Inicio y ruleta admiten teclado; el contenido de un nuevo modal comienza arriba.
- Música: búsqueda etiquetada, recuento de resultados, estado vacío, pista seleccionada resaltada, controles con nombres accesibles.
- Chat: etiquetas de búsqueda y acceso, ajuste de encabezado y tamaño de controles. No se altera la sincronización ni el almacenamiento.
- Avisos: botón de prueba con nombre explícito. No se altera el programador ni Firebase.
- Se conservan los 55 efectos, 53 letras, cameo de Teto, logros, temas y datos. Sin cambios en respaldo.
- Validación estática JS y ZIP; compilación y comprobación visual en Android pendientes.
