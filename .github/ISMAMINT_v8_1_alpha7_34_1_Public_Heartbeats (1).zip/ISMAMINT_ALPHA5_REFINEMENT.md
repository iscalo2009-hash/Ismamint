# Alpha 5 — Refinamiento general (primera entrega de dos)

Base: Alpha 4.2.1 Focused Gifts. Se conserva el sprite original del corazón, la fórmula y fechas de origen, los temas normales y especiales, los cinco widgets, los juegos y el catálogo musical. No hay sección Radio nueva ni nuevas dependencias.

## Cambios
- Calendario local: fechas especiales, horas secretas (1:36, 11:11, 4:44, 13:36), saludos y rachas utilizan el reloj del dispositivo. Los aniversarios y contadores derivados del origen conservan Colombia. Los avisos de racha y las fechas mostradas usan hora local; se adapta el widget de racha. Se conserva el historial de logros y se ajusta la fecha de la visita previa en la primera migración si corresponde al día colombiano actual.
- Perfil del chat: carga de fotografía con previsualización, JPEG reducido, manejo de errores de decodificación, protección contra guardado durante procesamiento y confirmación nativa explícita. Si falla Firebase, el editor conserva los cambios y permite reintentar. No cambia las reglas de Firestore. No se conoce aún la causa exacta del fallo de Aurora en su dispositivo.
- Audio: las pistas de fondo se suspenden con juegos, grabación, reproducción multimedia del chat y señales musicales de regalos/cumpleaños; después recuperan el punto correspondiente de la rotación virtual existente. Se mantiene la música chiptune, la selección y la cola previa. No se añade un motor alternativo.
- Función Aurora: reutilización del formateador numérico y actualización de números secundarios solo cuando cambian; no se modifica el sprite, la fórmula ni la frecuencia de cálculo principal.
- Interfaz: estados de foco, respuesta táctil, controles de perfil y contador con números tabulares. Efecto de desbloqueo adicional exclusivamente en los avisos de Heartmint (categoría mj), respetando movimiento reducido.

## Verificación
36 archivos de pruebas JavaScript superados; comprobación sintáctica JS e inline. Chromium: celebraciones/cumpleaños, rotación musical (audio simulado), inventario (Firebase simulado), selección y guardado de perfil con error/reintento/confirmación simulados. Sin compilación nativa, Firebase real ni prueba en los teléfonos.

## Siguiente entrega
Completar mejoras de chat y Gift Studio conectado, persistencia/copia de seguridad y privacidad local, pulido visual más profundo, revisión de rendimiento y controles de juegos, ajustes de widgets y celebraciones, verificación nativa. No se promete una versión estable hasta poder probar Android y Firebase. No se agregan funcionalidades ajenas a la aplicación de pareja.
