# Alpha 7.20 · Preferencias visuales

Se mantienen las 14 escenas aprobadas por el usuario y se modifican las restantes 41. Las composiciones originales se reinterpretan usando la investigación de las versiones anteriores; no se han vuelto a comprobar todos los videoclips.

## Criterios

Una escena coherente, un foco principal, objetos apoyados o suspendidos justificadamente, efectos ambientales y respuesta al pulso estimado. Sin figuras humanas; Teto permanece estática.

## Canciones

### s01 · Esclava - Remix — Bryant Myers, Anuel AA, Anonimus, Almighty

Rehecha: Persiana de madrugada. Interior clandestino con persiana, lluvia exterior y luz carmín, sin motel ni coches.

### s02 · Feel It (From “Invincible”) — d4vd

Rehecha: Flechazo de cómic. Ciudad al amanecer y una viñeta de acción, corazón centrado como remate.

### s03 · SOLO POR VOS — Trueno

Conservada sin cambios visuales.

### s04 · Hace Mucho Tiempo — Arcángel

Rehecha: Sala del recuerdo. Una fotografía sobre repisa, reloj y luz de ventana; menos marcos repetidos.

### s05 · OJALA — Milo j, Bhavi

Conservada sin cambios visuales.

### s06 · Can't Wait — Doja Cat

Rehecha: Porche de un futuro compartido. Un campo al atardecer visto desde un porche, casa lejana y dos tazas; Scarlet solo como detalle de seda.

### s07 · Agora Hills — Doja Cat

Conservada sin cambios visuales.

### s08 · Mountains — Sia, Diplo, Labrinth, LSD

Conservada sin cambios visuales.

### s09 · hostage — Billie Eilish

Conservada sin cambios visuales.

### s10 · MIU MIU (feat. GeezyDee, CARABIN3) — Blessd, Kris R., Young Fatty, TURY, CARABIN3

Rehecha: Lujo de escaparate. Expositor de joyería de terciopelo y cristal; sin coches o edificios decorativos.

### s11 · Calling (Spider-Man: Across the Spider-Verse) — Metro Boomin, Swae Lee, NAV, A Boogie Wit da Hoodie

Rehecha: Portal sobre dos ciudades. Un portal suspendido en el cielo, ciudad de origen y destino dentro de la abertura.

### s12 · Cyber Sex — Doja Cat

Conservada sin cambios visuales.

### s13 · BLANQUITA — Kris R., Prodmonja

Conservada sin cambios visuales.

### s14 · POLOS OPUESTOS REMIX - BLESSD VERSION — Blessd, Kris R.

Conservada sin cambios visuales.

### s15 · Si Me Sobrara el Tiempo — Duki

Rehecha: Tiempo contenido. Reloj de arena con dos cámaras de vidrio, arena decreciente arriba y creciente abajo.

### s16 · Una — Blessd

Rehecha: Paseo de barrio. Sendero peatonal tranquilo entre árboles y farolas; no carretera como protagonista.

### s17 · Halley's Comet — Billie Eilish

Conservada sin cambios visuales.

### s18 · Comatose — Skillet

Rehecha: Despertar tras el cristal. Ventana agrietada que revela el amanecer, luz creciente en el suelo y reflejos contenidos. Se distingue del pasillo de Criminal.

### s19 · A Tu Merced — Bad Bunny

Conservada sin cambios visuales.

### s20 · Apapáchame — Arroba Nat

Rehecha: Manta y refugio. Rincón de sofá, manta, cojín, taza y luz cálida; consuelo en vez de dormitorio repetido.

### s21 · MIL D AURA — Kris R., Prodmonja, Los Money Makers

Rehecha: Desde la calle, una ventana. Una reja en primer plano y una ventana que responde a la llamada, sin reciclar casa y coche.

### s22 · Algo Más — La Quinta Estacion

Conservada sin cambios visuales.

### s23 · Se Me Antoja — Kodigo 36

Rehecha: La mirada en un vinilo. Vinilo protagonista en primer plano, carta apoyada y luz lateral de estudio.

### s24 · Wonderwall - Remastered — Oasis

Rehecha: Refugio britpop. Ventana lluviosa y guitarra acústica grande apoyada al suelo, ambiente de ensayo.

### s25 · Born To Be My Baby — Bon Jovi

Rehecha: La luz que espera en casa. Fachada cálida bajo la lluvia con porche y dos luces; apoyo cotidiano.

### s26 · The Feels — TWICE

Rehecha: Fiesta escolar retro. Bola disco, pista y sobre de invitación sobre atril; iluminación de fiesta, sin equipo flotante.

### s27 · Anhelo — Adolescent's Orquesta

Rehecha: Salón de salsa al anochecer. Ventanal arqueado, trompeta en escenario y luces de latón; nostalgia, no decoración de teatro genérica.

### s28 · 光るなら — Goose house

Rehecha: Música después de la lluvia. Piano con tapa y soporte en un prado; lluvia que se retira y arco iris completo.

### s29 · Need to Know — Doja Cat

Rehecha: Salón de otro planeta. Ventana de nave con planeta anillado; pista de club y sillón bajo luz violeta.

### s30 · Sweet Boi — Chevy

Rehecha: Carta dulce. Carta grande en un escritorio de luz pastel con flores y una taza; composición íntima.

### s31 · Amor Completo — Mon Laferte

Rehecha: Flores de entrega. Ramo de rosas completo sobre mesa bajo una luz cálida; tallos llegan al florero.

### s32 · Cooler Than Me — Ethan Fields

Rehecha: La fachada fría. Gafas oscuras sobre un expositor frente a arquitectura de cristal; reflejos internos.

### s33 · Fanática Sensual — Plan B

Rehecha: Imagen y fascinación. Cámara sobre un tocador iluminado, fotografía sin personas y perfume.

### s34 · Criminal — NATTI NATASHA, Ozuna

Rehecha: Criminal: puerta y rejas. Pasillo de prisión con puerta central y lámparas de emergencia, sin falsa perspectiva.

### s35 · Mi Bello Angel — Natanael Cano

Rehecha: Camino hacia la luz. Camino de montaña y luz en forma de alas, símbolo del rumbo recuperado.

### s36 · Yellow — Coldplay

Rehecha: Globo de Parachutes. Un globo dorado en un escritorio, cielo estrellado y luz cálida; base única.

### s37 · Tus Vueltas — Milo j

Rehecha: Plaza de cemento. Plaza de barrio con banco, arbolado y un pequeño equipo de música; giro de su disco.

### s38 · You Rock My World — Michael Jackson

Rehecha: Club de Invincible. Club nocturno de madera, sombrero sobre piano y luz de escenario, guiño cinematográfico.

### s39 · Billie Bossa Nova — Billie Eilish

Rehecha: Bossa a puerta cerrada. Cortinas y tocadiscos sobre consola de madera, con dos tazas y luz ámbar.

### s40 · Stranger — Doja Cat

Rehecha: Dos frecuencias. Dos lámparas distintas iluminan el mismo espacio; convergencia de luces, no terminales de Machine Love.

### s41 · Freak — Doja Cat

Conservada sin cambios visuales.

### s42 · Fly Me To The Moon - 2008 Remastered — Frank Sinatra, Count Basie

Rehecha: Swing lunar. Luna sobre horizonte nocturno, trompeta de latón apoyada bajo la ventana.

### s43 · Deeper Conversation — Yuna

Rehecha: Conversación profunda. Mesa con dos tazas enfrentadas y libro abierto, ventana al atardecer.

### s44 · ALO (feat. Tutu) — Blessd, Juhn, Fronti, TURY, Tutu

Rehecha: Aló, cabina en la noche. Cabina telefónica urbana con marquesina, auricular y reflejo de lluvia en acera.

### s45 · Disfruto — Carla Morrison

Rehecha: Instantes pequeños. Salón al amanecer, sofá y luz de ventana sobre mesa; contemplación cotidiana.

### s46 · I Don't Want to Miss a Thing - From "Armageddon" Soundtrack — Aerosmith

Conservada sin cambios visuales.

### s47 · P.Y.T. (Pretty Young Thing) — Michael Jackson

Rehecha: Funk de Thriller. Tocadiscos y altavoces en contraste negro, crema y oro; bola de espejos con luz rítmica.

### s48 · Dopamina — Sergi

Rehecha: Dopamina: señal. Monitor de una red neuronal, pulso entre nodos; lectura del título, no letra confirmada.

### s49 · CARENCIAS DE CORDURA — Milo j, Yami Safdie

Rehecha: Dos lunas, un reflejo. Ventana de dos hojas, lunas simbólicas y grieta localizada en una de ellas.

### s50 · Química Mayor — Mon Laferte

Rehecha: Química mayor. Mesa de laboratorio: matraces conectados por su contexto, burbujas contenidas en el vidrio.

### s51 · Lo Que Siento — Cuco

Rehecha: Ensoñación de Cuco. Ventana panorámica de atardecer, guitarra y vinilo como habitación musical lo-fi.

### s52 · He's My Man — Luvcat

Rehecha: La casa de Luvcat. Comedor gótico con reloj, té y ventilador lento; obsesión doméstica sin representar violencia.

### s53 · El Mapa De Mi Interior - Remastered 2025 — EME-15

Rehecha: Faro interior. Faro sobre acantilado y barco en mar abierto, haz sale de la linterna y no cruza la torre.

### s54 · Tú y Yo — Valeria Jasso

Rehecha: Vuelo sobre el mar. Dos aves al amanecer, reflejo lunar y velero; calma y horizonte compartido.

### s55 · Machine Love — Jamie Paige

Conservada sin cambios visuales.

## Pruebas

42 pruebas Node superadas; Chromium: 55 escenas distintas, movimiento ambiental, respuesta al pulso y cambios de clímax; 168 pares de fotogramas idénticos para las 14 aprobadas. No APK ni Android físico. El visor usa reloj simulado y no reproduce audio. Las pruebas no certifican calidad artística.