# Alpha 3.6 — Creative Experiences
- Hotspots rectangulares en coordenadas porcentuales, activables por botón accesible, con posición y tamaño configurables. No se anclan automáticamente a objetos; códigos conservan campo de respuesta.
- Plantillas editables de búsqueda de estrellas, cofre secreto e historia ramificada. Se añaden sin reemplazar escenas existentes, respetando límite de 12 escenas.
- Acciones pueden combinar mensaje, modificación de variable, sonido y (según tipo) navegación. No es un motor arbitrario de cadenas.
- Validación básica de destinos inexistentes y códigos vacíos. No valida alcanzabilidad completa.
- 33 suites JS, pruebas Chromium de experiencia anterior y plantilla de tesoro superadas. Android y Firebase pendientes. No cambios de banda sonora.
