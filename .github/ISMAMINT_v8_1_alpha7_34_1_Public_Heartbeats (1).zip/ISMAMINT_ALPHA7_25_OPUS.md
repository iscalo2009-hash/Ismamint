# ISMAMINT v8.1 · Alpha 7.25 · Opus Audio

- 55 pistas Ogg Opus originales del ZIP comprimido.zip, asociadas por título a los identificadores s01–s55. Sin transcodificación: se verificó igualdad de bytes. Se eliminaron los 55 MP3 anteriores.
- Opus mono, 48 kHz; tasa de bits del contenedor de 21.8 a 37.1 kb/s. El conjunto de audio pasa de 24.4 a 41.3 MB (decimales). No implica por sí solo una medición perceptual de calidad.
- Catálogo y duraciones de radio actualizados; .opus sin compresión adicional en el empaquetado Gradle. El reproductor HTMLAudioElement sigue usando las mismas rutas de assets y controles.
- Análisis del audio a 32 kHz, ventanas de 100 ms y paso de 50 ms; graves 35–220 Hz, medios 220–2100 Hz, agudos 2100–15000 Hz, energía total y flujo espectral. Normalización percentil 97 por banda y pista.
- Ataques recalculados; estimación de BPM por periodicidad de ataques y graves cerca del tempo previo, conservando el previo cuando la evidencia es débil. Rejilla temporal estimada; etiquetas de secciones anteriores conservadas donde el alineamiento es consistente, salvo silencios detectados.
- Comparación de cromas de todas las pistas: desplazamiento estimado 0 s con resolución de 100 ms; diferencias de duración del contenedor entre -117 y -81 ms. Letras y ajustes de usuario preservados. No es alineamiento vocal exacto.
- 55 fondos y perfiles gráficos, motor karaoke, Teto y demás sistemas sin cambios de código. Los nuevos datos alimentan sus efectos.
- Verificación: 42 pruebas Node, reproducción iniciada para 55 Opus mediante Blob en Chromium, visor y pantalla de inicio (audio simulado), 53 letras / 2862 líneas. El entorno bloqueó el servidor HTTP local; no se comprobó la ruta real file:///android_asset/ en Android ni se compiló un APK.
- OPUS_AUDIO_AUDIT.json incluye nombres originales, duraciones, tasas, tempo y métricas de alineación.
