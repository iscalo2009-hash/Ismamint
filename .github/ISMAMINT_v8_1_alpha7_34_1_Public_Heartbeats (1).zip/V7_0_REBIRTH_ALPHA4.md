# Rebirth Alpha 4

- Envío de latidos mediante el canal privado autenticado existente. La notificación nativa usa un canal separado con doble pulso. No exige reglas nuevas para los latidos. Mantiene permisos y silencio de chat/Android. La recepción en segundo plano depende del JobScheduler periódico (15 min nominales, no inmediato ni garantizado tras forzar cierre). El latido se conserva como mensaje `♥ Latido`.
- Ambiente por hora local y referencias visuales a fechas especiales, gestos, reposo temporal con temporizador musical y desplazamiento leve del contenido, secretos sin interruptores nuevos. Se oculta la opción que revelaba el cameo de Teto. Se mantienen ajustes generales de accesibilidad, audio y vibración.
- Nuevo widget de acceso a Inicio para enviar latidos, no envío directo desde el launcher. Se conservan cuatro widgets existentes.
- Búsqueda con algunos sinónimos; reparación de índice de notificación agrupada al acumular mensajes.
- Pruebas: node --check para scripts, pruebas del Core, XML parseado, prueba de interfaz Chromium con puente no nativo  (prueba histórica de Alpha 4), comparación de archivos y MP3. No se ha compilado APK ni probado Firebase real ni vibraciones físicas. Actualizar con misma firma y paquete, sin borrar datos; incrementar versionCode.
- Pendientes: push inmediato con servidor confiable, rediseño general de widgets, parallax por sensores, administración de prioridades de audio más amplia y pruebas reales de recepción.

Alpha 4.1 retira la reproducción compartida, su puente y sus reglas; conserva los latidos y el reproductor local.
