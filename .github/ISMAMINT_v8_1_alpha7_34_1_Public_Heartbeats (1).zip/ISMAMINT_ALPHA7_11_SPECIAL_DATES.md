# ISMAMINT v8.0 Alpha 7.11

- Entrega inmediata (release=0, sin alterar reglas) o programada, selector interno con calendario visible solo al programar.
- Fechas especiales del proveedor de calendario existente; selección directa, indicación pixel, acceso a próxima fecha, sugerencia horaria de acontecimientos históricos en hora local.
- Etiquetas dinámicas de meses/años desde las fechas de origen y edades de cumpleaños. Calendario, celebración, próximo evento, avisos pertinentes, snapshot de widgets y fallback nativo. Logros y fechas históricas no modificados.
- Pruebas: 41 archivos de pruebas Node correctos; Chromium en viewport móvil con zona America/Mexico_City: calendario, cantidades, selección 00:36 local para 01:36 Colombia, entrega inmediata (valor de retorno), cancelación. No se ha construido APK ni verificado Firebase real.
