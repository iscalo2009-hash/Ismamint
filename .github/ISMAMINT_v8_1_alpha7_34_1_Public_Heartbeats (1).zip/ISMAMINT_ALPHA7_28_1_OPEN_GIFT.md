# Alpha 7.28.1 — Apertura obligatoria

Base Alpha 7.28. Se elimina «Más tarde» y el estado de aplazamiento de la escena de recepción. Antes de confirmar la apertura, Escape y el botón Atrás de Android (a través de __goBack) se consumen sin cerrar la escena. El botón Abrir regalo conserva el envoltorio elegido por el remitente. Cerrar e Inventario se habilitan solo tras confirmar la apertura; si la lectura o confirmación falla, se permite reintentar. El sistema operativo sigue permitiendo salir de la aplicación; el regalo pendiente se vuelve a detectar al regresar. Se conserva el acceso discreto durante otras actividades.

Verificación: 44 pruebas Node y prueba Chromium con Firebase simulado, incluida la imposibilidad de aplazar o cerrar por Escape/Atrás antes de abrir, apertura del envoltorio, confirmación y entrega programada. No se compiló APK ni se probó Android físico o Firebase remoto. No se modificaron las reglas, firma ni configuración de build.
