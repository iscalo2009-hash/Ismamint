# Chat 2.3.2
- Reacciones externas a la burbuja, detalle por persona y eliminación de reacción propia.
- Emoji personalizado mediante el teclado instalado; no hay panel de emojis propio. Recientes y reacción rápida configurable.
- Búsqueda contextual con texto visible, coincidencias resaltadas, flechas, fecha y carga paginada del historial mientras se busca. Sin conexión puede ser parcial. El coste de lectura depende de la cantidad de historial descargado.
- Saltos a citas antiguas cargan páginas automáticamente. Mensajes largos plegables y controles accesibles.
- Actualizar firestore.rules antes de instalar para permitir reacciones Unicode personalizadas. No borrar datos. La regla limita la longitud y solo permite modificar la reacción propia; la validación de un emoji se hace en la interfaz.
- Verificación: node --check y ZIP. Compilación y pruebas en Android pendientes. Las reacciones de mensajes antiguos fuera de la suscripción de tiempo real se actualizan localmente al reaccionar y al recargar su página; no se garantiza actualización remota inmediata en esos mensajes.
