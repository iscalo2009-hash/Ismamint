# ISMAMINT v8.0 Alpha 7.5 — Creative Refinement

Base: Alpha 7.4 Visual Engine. Cambios limitados al editor de regalos, Pixel Studio, biblioteca de medios y pruebas. No cambia Firestore, sincronización, código Android ni Heartmint.

- Lienzo a pantalla completa con tamaño estable: el panel contextual no reduce la superficie de edición. Barra de añadir siempre visible, controles táctiles más grandes, navegación Editar/Entrega duplicada eliminada y menos controles redundantes en la entrega. No se construyen los campos antiguos de carta para un regalo visual nuevo.
- Capas: panel actualizado después de eliminar/reordenar, selección sincronizada, arrastre táctil desde el asa y flechas como alternativa. Contexto cambia según el objeto; opciones Retocar, Editar sprite/Pixelar, Estilo, Duplicar, Eliminar. Centrar/encajar en apariencia; texto con contraste inicial según fondo y ajuste al lienzo a petición.
- Recorte visual de fotografías con cuatro asas, desplazamiento del área, proporciones iniciales 1:1, 4:5, 16:9 o completa; cancelar recorte, confirmar, restablecer los ajustes de la sesión, rotación, espejo y ajustes de imagen. La edición produce una copia, no reemplaza la imagen original en la biblioteca.
- Pixel Studio: corrección de encaje de resoluciones grandes, no recalcula geometría en cada trazo, historial acotado por memoria (16 MiB aproximados para deshacer), nombre y opacidad por capa, duplicación de propiedades, confirmación de limpieza. Las capas se guardan como proyecto local adjunto al recurso en IndexedDB; pueden reabrirse si el original local permanece. El destinatario recibe el PNG compuesto; el respaldo/exportación y sincronización actuales no transportan capas editables. La imagen se sigue exportando con escala nearest-neighbor.
- Mejora de la respuesta a gestos y zoom anclado a dedos; cancelaciones y liberación de punteros. Falta validar multitáctil y arrastre táctil en teléfonos reales.
- Las imágenes que faltan se señalan en lugar de desaparecer silenciosamente. Se elimina el historial duplicado interno y se conservan los renderizadores antiguos para no romper regalos ya existentes. No se recuperan las capas de sprites aplanados por versiones previas. No se restauran plantillas ni compositor para regalos nuevos.

## Pruebas
- `node --test tests/*.test.js`: 39/39 tests.
- `python tests/gift-pro-browser.py`: Chromium, tamaño móvil, recursos y localStorage simulados. Prueba de texto, edición/cancelación, lienzo estable al abrir capas, resolución 512 encajada, dibujo, deshacer/rehacer, dos capas, reapertura por capas, recorte 4:5, rotación, zoom, vista del receptor y entrega local.
- `python tests/gift-project-browser.py`: prueba de IndexedDB real incluida; navegación bloqueada por política del entorno (`ERR_BLOCKED_BY_ADMINISTRATOR`). No ejecutada hasta completar el almacenamiento real. No se ha compilado APK ni probado en teléfonos reales o Firebase remoto.
- La estructura del regalo transmitido no cambia. No hay que publicar reglas si ya se publicaron las vigentes en 7.4. Se recomienda actualizar ambos teléfonos. El proyecto editable de sprite sólo existe en el almacenamiento local de quien crea el recurso.
