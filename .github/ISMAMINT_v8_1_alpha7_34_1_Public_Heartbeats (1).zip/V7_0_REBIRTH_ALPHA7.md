# Rebirth Alpha 7 — Heartmint Arcade
- Remake del minijuego manteniendo `best`, `aurora_skin`, `aurora_stats_v1`, IDs de logros, recompensas anteriores, nueve skins y los seis potenciadores originales.
- Cuatro ambientes por bloques de niveles; desplazamiento continuo hacia el dedo, teclado, impulso protector con recarga y pulso cargable recogiendo corazones.
- Feid, Justin Bieber y La Distancia conservan sus nombres y sprites, con tres familias de ataques anunciados, fases y ventanas de daño doble. Los siguientes jefes conservan generación de nombres y reutilizan estas familias con dificultad progresiva.
- Mejoras por partida tras cada jefe: amplitud, energía o protección. Eventos de constelación, lluvia dorada y recuperación. Resumen de precisión y estadísticas al perder.
- Banda sonora procedural local por pulsos y frases, variaciones de melodía, tempo, armonía, percusión e intensidad según estado. Usa volumen general y estado de música, interrumpe temporalmente la banda sonora normal durante el juego, y se suspende en pausa, excepto selección de recompensa (música de victoria).
- Avisos de logros se difieren durante la partida; no se eliminan sus datos.
- Sin cambios en Firebase ni Android nativo. Validación: Chromium con estado de combate preparado, prueba de generación de osciladores, sintaxis JS, Core, ZIP. No prueba de equilibrio prolongado ni compilación Android.
