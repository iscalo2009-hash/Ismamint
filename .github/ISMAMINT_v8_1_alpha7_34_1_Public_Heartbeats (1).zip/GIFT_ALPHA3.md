# ISMAMINT V8.0 Alpha 3 — Gift Studio
Base: V8.0 Alpha 2 Birthday Editions.

- Acceso en Nosotros → Gift Studio; enlace desde celebraciones importantes reales y anticipaciones de cumpleaños. Las vistas previas de celebración no crean regalos.
- Taller local con colecciones por autor (Ismael/Aurora), filtros de borradores y preparados, edición, eliminación confirmada y guardado al escribir. Hasta 80 regalos locales; título 100, mensaje 8000, firma 80 caracteres.
- Tres formatos: carta, tarjeta pixel y recuerdo escrito. Cuatro paletas: menta y rosa, Yellow ZK, noche estrellada y carta clásica. Símbolos, firma, vista previa y fecha civil prevista, manual o sugerida por celebración. La fecha no es una programación de entrega. Editar un regalo preparado lo devuelve a borrador.
- Motivo original chiptune de pulso cuadrado y bajo triangular, opcional, por paleta, con volumen de efectos y el mismo canal de atenuación de radio de cumpleaños. El reproductor de pistas y Heartmint permanecen intactos.
- Modelo separado `ismamint_gifts_v1`, versión de esquema 1. Sin cambios de reglas Firebase, permisos, chat, notificaciones, relojes, widgets ni progreso. Los filtros por autor NO son autenticación ni cifrado; los datos residen en localStorage y no deben considerarse privados frente a quien acceda al dispositivo. No hay entrega, sincronización ni desbloqueo automático. No cápsula del tiempo.
- La próxima fase, Gift Sync, deberá establecer identidad autenticada, permisos de lectura/escritura, publicación y entrega, sin sincronizar inadvertidamente los borradores.

Validación: 27 suites JS y pruebas Chromium `celebration-browser.py` y `gift-browser.py`, con red bloqueada y almacenamiento simulado. Se comprueba edición, persistencia simulada, filtrado por autor, eliminación, fecha, vista previa segura y regresión de cumpleaños. Compilación Android, pruebas físicas y escucha real pendientes. No se incluye APK.
