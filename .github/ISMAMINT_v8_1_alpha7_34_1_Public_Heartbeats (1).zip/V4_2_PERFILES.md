# ISMAMINT V4.2 — Perfiles ambientales

55 presets locales. Cada uno contiene dos colores, una textura vectorial propia, un movimiento lento y un disparador temático de letra. Las dos pistas sin LRC usan únicamente el ambiente base. No se realiza análisis de ritmo ni de audio en tiempo real.

| Canción | Preset | Colores HEX | Movimiento (ciclo) | Tema reactivo |
|---|---|---|---|---|
| Esclava - Remix | Neón nocturno | #B65CBB / #D94B69 | Deriva · 20 s | deseo |
| Feel It (From “Invincible”) | Cómic eléctrico | #54A8F4 / #EE77B2 | Desplazamiento · 15 s | luz |
| SOLO POR VOS | Ondas de entrega | #B94773 / #F0AC80 | Respiración · 21 s | amor |
| Hace Mucho Tiempo | Polvo de recuerdos | #D5AF74 / #A77454 | Ascenso · 28 s | tiempo |
| OJALA | Lluvia de deseos | #829FC8 / #AB8ED2 | Descenso · 20 s | sueño |
| Can't Wait | Corazones impacientes | #E775AF / #B999E9 | Ascenso · 17 s | amor |
| Agora Hills | Nubes de algodón | #F2A9CE / #F4DBC5 | Desplazamiento · 30 s | amor |
| Mountains | Horizonte montañoso | #619AD2 / #7ED5DB | Deriva · 32 s | luz |
| hostage | Halos cerrados | #A4A4BD / #B85C75 | Respiración · 24 s | amor |
| MIU MIU (feat. GeezyDee, CARABIN3) | Diamantes de neón | #CFD6EA / #F387CF | Ascenso · 18 s | luz |
| Calling (Spider-Man: Across the Spider-Verse) | Señal entre mundos | #557FD9 / #E76774 | Respiración · 22 s | conexión |
| Cyber Sex | Terminal rosa | #DA68C8 / #67B3F2 | Desplazamiento · 16 s | conexión |
| BLANQUITA | Nieve plateada | #E2E5F4 / #9AABC6 | Descenso · 25 s | luz |
| POLOS OPUESTOS REMIX - BLESSD VERSION | Dos polos | #699AE9 / #E96A85 | Desplazamiento · 24 s | conexión |
| Si Me Sobrara el Tiempo | Tiempo suspendido | #CBB07A / #9C9CBA | Giro suave · 38 s | tiempo |
| Una | Una estrella de San Valentín | #EA799A / #F2CE80 | Respiración · 22 s | amor |
| Halley's Comet | Órbita de Halley | #8DA4EA / #B8E2F5 | Desplazamiento · 28 s | estrellas |
| Comatose | Latido en la oscuridad | #CA6071 / #C2C7DA | Respiración · 15 s | conexión |
| A Tu Merced | Marea cálida | #E3AB83 / #DE7D9E | Desplazamiento · 26 s | amor |
| Apapáchame | Abrazo de algodón | #E5BCB1 / #F6DCC3 | Respiración · 30 s | amor |
| MIL D AURA | Aura esmeralda | #60CDA7 / #D7BC68 | Respiración · 21 s | luz |
| Algo Más | Pétalos de esperanza | #DB9BAA / #D4BA7C | Descenso · 29 s | amor |
| Se Me Antoja | Brasas de deseo | #D85C77 / #E5A46A | Ascenso · 20 s | deseo |
| Wonderwall - Remastered | Ventana nostálgica | #8EAAC6 / #BBC8D7 | Deriva · 32 s | sueño |
| Born To Be My Baby | Escenario dorado | #D96575 / #E4BB69 | Respiración · 20 s | amor |
| The Feels | Confeti enamorado | #F18BD2 / #ADA3F0 | Descenso · 17 s | amor |
| Anhelo | Bruma de anhelo | #7799D0 / #D7BD7A | Desplazamiento · 31 s | deseo |
| 光るなら | Amanecer multicolor | #F2D378 / #82C6EB | Ascenso · 26 s | luz |
| Need to Know | Órbitas violetas | #AF7BE7 / #F17CC5 | Giro suave · 25 s | deseo |
| Sweet Boi | Estrellas de azúcar | #F0A9C8 / #F4D0A2 | Ascenso · 24 s | amor |
| Amor Completo | Rosa de amor completo | #C76D96 / #E5B575 | Respiración · 28 s | amor |
| Cooler Than Me | Cristal de hielo | #86C7E5 / #D0E0F0 | Deriva · 25 s | luz |
| Fanática Sensual | Luces de medianoche | #C95C91 / #9B72C7 | Desplazamiento · 21 s | deseo |
| Criminal | Pulso carmesí | #D65F72 / #F0A0A6 | Desplazamiento · 16 s | amor |
| Mi Bello Angel | Alas celestes | #E9D0A1 / #9DCAED | Ascenso · 30 s | luz |
| Yellow | Cielo Yellow | #EBC755 / #798DCA | Deriva · 30 s | estrellas |
| Tus Vueltas | Vueltas infinitas | #82A9BC / #83C4A9 | Giro suave · 36 s | tiempo |
| You Rock My World | Órbita de groove | #A18CD9 / #C7CDE6 | Desplazamiento · 18 s | amor |
| Billie Bossa Nova | Reflejos de lounge | #75B5A5 / #DABF91 | Desplazamiento · 29 s | amor |
| Stranger | Siluetas de niebla | #9898BA / #708BBE | Deriva · 32 s | sueño |
| Freak | Cortinas de teatro | #D16AA9 / #A277C6 | Respiración · 23 s | deseo |
| Fly Me To The Moon - 2008 Remastered | Luna de plata | #AFC8EE / #DDE5F4 | Deriva · 35 s | estrellas |
| Deeper Conversation | Ondas de conversación | #68B5BD / #8BCFC0 | Respiración · 29 s | conexión |
| ALO (feat. Tutu) | Señal ALO | #A5D96D / #E6D982 | Ascenso · 17 s | conexión |
| Disfruto | Atardecer de Disfruto | #EA9B8E / #E9BB78 | Deriva · 34 s | amor |
| I Don't Want to Miss a Thing - From "Armageddon" Soundtrack | Horizonte de Armageddon | #91B0DC / #D5DEF3 | Respiración · 33 s | estrellas |
| P.Y.T. (Pretty Young Thing) | Disco de píxeles | #D779D9 / #7A9DE8 | Desplazamiento · 18 s | amor |
| Dopamina | Sinapsis de dopamina | #F0A369 / #DC79C5 | Respiración · 19 s | Sin LRC |
| CARENCIAS DE CORDURA | Fragmentos de cordura | #9BABC0 / #C77B8B | Deriva · 27 s | sueño |
| Química Mayor | Enlace molecular | #BB87D9 / #EAC18B | Giro suave · 34 s | conexión |
| Lo Que Siento | Nubes de confesión | #8BC9C7 / #E7A6C4 | Desplazamiento · 33 s | amor |
| He's My Man | Corazones de cereza | #D96185 / #E5A3B5 | Respiración · 22 s | amor |
| El Mapa De Mi Interior - Remastered 2025 | Constelación interior | #B2A0E7 / #91C6D9 | Deriva · 34 s | conexión |
| Tú y Yo | Dos órbitas juntas | #ECA9C9 / #9EC8ED | Giro suave · 33 s | Sin LRC |
| Machine Love | Circuito de corazón | #6DD6CF / #E28DDC | Desplazamiento · 20 s | conexión |

Intensidad: suave 9 %, normal 17 %, intensa 25 %. En paneles secundarios, 55 % de la intensidad seleccionada. Se oculta en contextos bloqueados y con la música pausada. Movimiento reducido: sin animación. Reacciones suaves, sin flashes.
