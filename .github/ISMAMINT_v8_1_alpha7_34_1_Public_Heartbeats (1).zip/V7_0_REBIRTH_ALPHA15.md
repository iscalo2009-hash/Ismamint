# Alpha 15 · Motion

Actualización de la interfaz general sobre Alpha 14. Se sustituye el controlador de animaciones de Alpha 10, manteniendo los motores de fondo, audio, letras, iluminación y hápticos previos. No se cambia Heartmint ni Firebase.

- Indicador animado de navegación con color por sección; entradas escalonadas y direccionales de elementos visibles.
- Ondas y partículas pixel art en acciones y tarjetas; estados táctiles, selección y destellos.
- Inicio: onda y partículas al cambio de minuto, únicamente cuando el corazón está visible y no compite con la música/escena inmersiva. El cálculo del contador es intacto.
- Logros: entrada de tarjetas, barras de progreso y partículas en la pestaña al desbloquear un logro real (no al cargar el historial). No revela logros ocultos.
- Nosotros: entradas de la cronología al filtrar; calendario: transiciones al cambiar mes o fecha, realce de selección.
- Música: entradas de vistas, título al cambiar de canción, realce de la pista seleccionada. No cambia la sincronización ni los archivos de audio.
- Chat: entrada breve del último mensaje nuevo visible después de hidratar el historial; se respeta la preferencia propia de animaciones del chat. No altera el envío, la lectura o el almacenamiento.
- Ventanas: entrada breve en overlays existentes sin cambiar su navegación ni sus controles.
- Web Animations API con degradación sin efectos cuando no está disponible. Máximo 24 animaciones administradas y 26 elementos de partículas; se limpian al terminar, cambiar de sección, ocultar la app o activar movimiento reducido. Sin nuevo bucle permanente de renderizado.

Pruebas: seis suites Node originales; Chromium (navegación, limpieza, partículas, calendario, cambio de minuto simulado, movimiento reducido, chat simulado, logros, música, entrada al mapa Heartmint) sin excepciones JS. No se ha compilado ni probado físicamente en Android. El chat real y la fluidez en hardware requieren comprobación.
