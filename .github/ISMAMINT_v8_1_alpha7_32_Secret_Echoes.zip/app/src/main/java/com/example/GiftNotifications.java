package com.example;

import android.Manifest;
import android.app.*;
import android.app.job.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.*;
import android.webkit.WebView;
import com.google.firebase.Timestamp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.*;
import java.util.*;

/** Independent gift inbox. Only metadata is observed; sealed payloads are never downloaded here. */
public final class GiftNotifications {
    private static final String CHANNEL="ismamint_gifts_v1";
    private static final int JOB=38451;
    private final Activity activity;
    private final WebView web;
    private final Handler main=new Handler(Looper.getMainLooper());
    private final FirebaseAuth auth=FirebaseAuth.getInstance();
    private final FirebaseAuth.AuthStateListener authListener=a->attach();
    private ListenerRegistration listener;
    private List<DocumentSnapshot> inbox=Collections.emptyList();
    private String account;
    private boolean active, loaded;
    private int generation;
    private static volatile boolean foreground;
    private final Runnable tick=new Runnable(){public void run(){if(!active)return;update();main.postDelayed(this,30000);}};
    GiftNotifications(Activity activity,WebView web){this.activity=activity;this.web=web;channel(activity);}
    static String uid(){return ChatNotifications.uid();}
    static Query query(String uid){String peer=ChatNotifications.A.equals(uid)?ChatNotifications.I:ChatNotifications.A;return FirebaseFirestore.getInstance().collection("ismamint_gifts").document(peer).collection("deliveries").whereEqualTo("opened",false);}
    static boolean isForeground(){return foreground;}
    static void channel(Context c){NotificationManager n=c.getSystemService(NotificationManager.class);if(n!=null)n.createNotificationChannel(new NotificationChannel(CHANNEL,"Regalos",NotificationManager.IMPORTANCE_HIGH));}
    static void schedule(Context c){try{JobScheduler j=c.getSystemService(JobScheduler.class);if(j!=null&&j.getPendingJob(JOB)==null)j.schedule(new JobInfo.Builder(JOB,new ComponentName(c,GiftNotificationJob.class)).setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY).setPeriodic(15*60*1000L).setPersisted(true).build());}catch(RuntimeException e){android.util.Log.w("Ismamint","Gift schedule",e);}}
    void resume(){if(active)return;active=true;foreground=true;schedule(activity);auth.addAuthStateListener(authListener);main.post(tick);}
    void permissionChanged(){update();}
    void pause(){if(!active)return;active=false;foreground=false;auth.removeAuthStateListener(authListener);detach();main.removeCallbacks(tick);schedule(activity);}
    private void detach(){generation++;if(listener!=null){listener.remove();listener=null;}inbox=Collections.emptyList();account=null;loaded=false;}
    private void attach(){detach();if(!active)return;String u=uid();signal();if(u==null)return;account=u;int g=generation;listener=query(u).addSnapshotListener(MetadataChanges.INCLUDE,(s,e)->{if(!active||g!=generation||!u.equals(uid()))return;if(e!=null){android.util.Log.w("Ismamint","Gift inbox listener",e);signal();return;}if(s==null||s.getMetadata().isFromCache()||s.getMetadata().hasPendingWrites())return;inbox=s.getDocuments();loaded=true;update();});}
    private void signal(){if(active)web.evaluateJavascript("window.IsmaGiftArrival?.refresh()",null);}
    private void update(){if(!active||!loaded||account==null||!account.equals(uid()))return;consume(activity,account,inbox);askPermission();signal();}
    private void askPermission(){if(Build.VERSION.SDK_INT<33||activity.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)==PackageManager.PERMISSION_GRANTED)return;SharedPreferences p=activity.getSharedPreferences("isma_gift_alerts",Context.MODE_PRIVATE);if(p.getBoolean("permissionAsked",false)||ChatNotifications.prefs(activity).getBoolean("asked",false))return;long now=System.currentTimeMillis();for(DocumentSnapshot d:inbox){Timestamp r=d.getTimestamp("release");if(r!=null&&r.toDate().getTime()<=now&&account.equals(d.getString("recipient"))){p.edit().putBoolean("permissionAsked",true).apply();ChatNotifications.prefs(activity).edit().putBoolean("asked",true).apply();activity.requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},WebAppInterface.REQ_POST_NOTIFICATIONS);break;}}}
    static synchronized void consume(Context c,String u,List<DocumentSnapshot> docs){
        if(!u.equals(uid()))return;
        NotificationManager nm=c.getSystemService(NotificationManager.class);if(nm==null)return;channel(c);
        SharedPreferences p=c.getSharedPreferences("isma_gift_alerts",Context.MODE_PRIVATE);
        Set<String> seen=new HashSet<>(p.getStringSet(u,Collections.emptySet()));
        Set<String> remaining=new HashSet<>();List<DocumentSnapshot> fresh=new ArrayList<>();long now=System.currentTimeMillis();
        for(DocumentSnapshot d:docs){if(d.getMetadata().hasPendingWrites()||!u.equals(d.getString("recipient"))||Boolean.TRUE.equals(d.getBoolean("opened")))continue;remaining.add(d.getId());Timestamp r=d.getTimestamp("release");if(r!=null&&r.toDate().getTime()<=now&&!seen.contains(d.getId()))fresh.add(d);}
        // No pruning on partial/error results; only authoritative snapshots reach here.
        for(String id:new HashSet<>(seen))if(!remaining.contains(id)){nm.cancel("gift:"+u+":"+id,JOB);seen.remove(id);}
        if(!nm.areNotificationsEnabled()||(Build.VERSION.SDK_INT>=33&&c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)){p.edit().putStringSet(u,seen).apply();return;}
        NotificationChannel ch=nm.getNotificationChannel(CHANNEL);if(ch==null||ch.getImportance()==NotificationManager.IMPORTANCE_NONE)return;
        for(DocumentSnapshot d:fresh){String id=d.getId();String sender=ChatNotifications.A.equals(u)?"Ismael":"Aurora";Intent i=new Intent(c,MainActivity.class).putExtra("isma_open_gift",id).setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP).setData(android.net.Uri.parse("ismamint://gift/"+id));PendingIntent tap=PendingIntent.getActivity(c,JOB,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            Notification n=new Notification.Builder(c,CHANNEL).setSmallIcon(R.drawable.ic_notification).setContentTitle("Regalo de "+sender).setContentText("Tienes un regalo sin abrir").setContentIntent(tap).setAutoCancel(true).setVisibility(Notification.VISIBILITY_PRIVATE).setCategory(Notification.CATEGORY_MESSAGE).setColor(0xffee90b9).setPublicVersion(new Notification.Builder(c,CHANNEL).setSmallIcon(R.drawable.ic_notification).setContentTitle("ISMAMINT").setContentText("Regalo recibido").build()).build();
            try{nm.notify("gift:"+u+":"+id,JOB,n);seen.add(id);}catch(SecurityException ignored){}
        }
        p.edit().putStringSet(u,seen).commit();
    }
}
