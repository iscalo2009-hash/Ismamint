from pathlib import Path
from playwright.sync_api import sync_playwright
import re,json
root=Path(__file__).resolve().parents[1]/'app/src/main/assets'; h=(root/'index.html').read_text();child=(root/'heartmint-v2/index.html').read_text();child=child.replace('<script src="../heartmint-v2-achievements.js"></script>','<script>'+(root/'heartmint-v2-achievements.js').read_text()+'</script>');
def scripts(m):
 f=root/m.group(1)
 if not f.is_file(): return ''
 t=f.read_text()
 if f.name=='heartmint-v2-host.js':t=t.replace("frame.src='heartmint-v2/index.html';",'frame.srcdoc='+json.dumps(child).replace('</script','<\\/script')+';')
 return '<script>\n'+t.replace('</script','<\\/script')+'\n</script>'
h=re.sub(r'<script\s+src="([^"]+)"\s*>\s*</script>',scripts,h)
h=re.sub(r'<link\s+rel="stylesheet"\s+href="([^"]+)"\s*/?>',lambda m:'<style>'+ (root/m.group(1)).read_text()+'</style>' if (root/m.group(1)).is_file() else '',h)
pre='''<script>for(const name of ['localStorage','sessionStorage']){const m=new Map();Object.defineProperty(window,name,{value:{getItem:k=>m.has(k)?m.get(k):null,setItem:(k,v)=>m.set(k,String(v)),removeItem:k=>m.delete(k),clear:()=>m.clear(),key:i=>[...m.keys()][i],get length(){return m.size}}});}localStorage.setItem('heartmint_release_v1',JSON.stringify({max:90,metrics:{hearts:5000,best:12345}}));localStorage.setItem('hm_classic_preview_v5',JSON.stringify({max:777,checkpoint:700,profileStats:{bestScore:999999}}));localStorage.setItem('aurora_logros_v1',JSON.stringify({hmr_boss_1:123456}));</script>'''
h=re.sub(r'<head[^>]*>',lambda m:m.group(0)+pre,h,count=1,flags=re.I)
with sync_playwright() as pw:
 b=pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage']);p=b.new_page(viewport={'width':420,'height':850},is_mobile=True,has_touch=True); errs=[];logs=[];p.on('pageerror',lambda e:errs.append(str(e)));p.on('console',lambda e:logs.append(e.text) if e.type=='error' else None);p.route('**/*',lambda r:r.abort());p.set_content(h,wait_until='domcontentloaded',timeout=15000);p.wait_for_timeout(300)
 print('init errors',errs[:10],flush=True)
 print('parent globals',p.evaluate('''()=>({game:typeof GAME,catalog:HeartmintV2.achievements.length,oldAward:U.hmr_boss_1,oldCard:ACH.some(a=>a.id==='hmr_boss_1'),new:ACH.filter(a=>a.id.startsWith('hm2_')).length,spoilers:ACH.filter(a=>a.id.startsWith('hm2_victory_')&&!a.secret).length})'''),flush=True)
 p.evaluate("document.querySelector('main').style.setProperty('display','block','important');document.querySelector('#start').style.display='none';document.querySelector('.tabs button[data-p=p4]').click()")
 p.wait_for_timeout(800);fr=p.frame(url='about:srcdoc');assert fr,[f.url for f in p.frames]
 print('child init',fr.evaluate('''()=>({debug:!!document.querySelector('#hmDebug'),reduced:!!document.querySelector('#reduced'),countdown:!!document.querySelector('#countdown'),guide:!!document.querySelector('#instruction'),home:document.querySelector('#hmHomeStats').textContent,preview:typeof HeartmintPreview})'''),flush=True)
 print('host initial',p.evaluate('GAME.progress()'),flush=True)
 fr.locator('#hmPlay').click(force=True);fr.locator('#continue').click(force=True);p.wait_for_timeout(1000)
 print('running',p.evaluate('GAME.info()'),fr.locator('#stageLabel').inner_text(),flush=True)
 p.evaluate("document.querySelector('#hm2Fullscreen').click()");p.wait_for_timeout(150)
 print('portrait geometry',fr.locator('#gc').evaluate('e=>{const r=e.getBoundingClientRect();return {w:r.width,h:r.height,ratio:r.width/r.height,viewport:[innerWidth,innerHeight]}}'),flush=True)
 p.set_viewport_size({'width':850,'height':420});p.wait_for_timeout(150)
 print('landscape geometry',fr.locator('#gc').evaluate('e=>{const r=e.getBoundingClientRect();return {w:r.width,h:r.height,ratio:r.width/r.height,viewport:[innerWidth,innerHeight]}}'),flush=True)
 p.evaluate('window.__heartmintNativePause()');p.wait_for_timeout(200);print('paused',p.evaluate('GAME.info()'),fr.locator('#overlayTitle').inner_text(),flush=True)
 p.evaluate('window.__heartmintNativeResume()');p.wait_for_timeout(200);fr.evaluate("document.querySelector('#resume').click()");p.wait_for_timeout(200);print('resumed',p.evaluate('GAME.info()'),flush=True)
 print('errors',errs[:30], 'logs',logs[:10],flush=True);b.close();assert not errs and not logs,(errs,logs)
