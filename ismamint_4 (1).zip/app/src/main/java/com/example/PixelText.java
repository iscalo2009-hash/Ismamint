package com.example;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.util.LruCache;
import android.util.TypedValue;
import android.widget.RemoteViews;

/**
 * Dibuja texto con las fuentes de la app (Press Start 2P y VT323) y lo entrega como bitmap.
 *
 * Los widgets y las notificaciones se dibujan en otro proceso (launcher / SystemUI), que ignora
 * android:fontFamily="@font/..." de los RemoteViews y usa la fuente del sistema. Un bitmap sí
 * viaja intacto, así que el texto se ve igual que dentro de la app.
 *
 * Los bitmaps son ALPHA_8 (máscara de 1 byte por pixel) y el color se aplica con setColorFilter,
 * por eso ocupan 4 veces menos que un ARGB y caben holgados en el límite de Binder.
 */
public final class PixelText {

    /** Press Start 2P: títulos, etiquetas y badges. */
    public static final int TITLE = 0;
    /** VT323: números, fechas y texto corrido. */
    public static final int BODY = 1;

    private static Typeface sTitle;
    private static Typeface sBody;

    private static final LruCache<String, Bitmap> CACHE = new LruCache<String, Bitmap>(2 * 1024 * 1024) {
        @Override
        protected int sizeOf(String key, Bitmap value) {
            return value.getByteCount();
        }
    };

    private PixelText() {}

    // ---------------------------------------------------------------- API para RemoteViews

    /** Una línea de texto (con puntos suspensivos si pasa de maxWidthPx) dentro de un ImageView. */
    public static void set(RemoteViews views, int viewId, Context context, CharSequence text,
                           int font, float sizeSp, int color, int maxWidthPx) {
        String safe = text == null ? "" : text.toString();
        views.setImageViewBitmap(viewId, line(context, safe, font, sizeSp, maxWidthPx));
        views.setInt(viewId, "setColorFilter", color);
        views.setContentDescription(viewId, safe);
    }

    /** Como set(), pero baja el tamaño (de 2 en 2 sp) hasta que el texto quepa sin cortarse. */
    public static void fit(RemoteViews views, int viewId, Context context, CharSequence text,
                           int font, float maxSp, float minSp, int color, int maxWidthPx) {
        String safe = text == null ? "" : text.toString();
        float sp = maxSp;
        while (sp > minSp && measure(context, safe, font, sp) > maxWidthPx) {
            sp -= 2f;
        }
        set(views, viewId, context, safe, font, Math.max(sp, minSp), color, maxWidthPx);
    }

    /** Ancho en px que ocupa el texto en una línea. */
    public static float measure(Context context, String text, int font, float sizeSp) {
        TextPaint paint = newPaint(context, font, sizeSp);
        return paint.measureText(text, 0, text.length());
    }

    // ---------------------------------------------------------------- Render

    public static Bitmap line(Context context, String text, int font, float sizeSp, int maxWidthPx) {
        DisplayMetrics dm = context.getResources().getDisplayMetrics();
        String key = "L|" + font + "|" + sizeSp + "|" + maxWidthPx + "|" + dm.densityDpi + "|" + text;
        Bitmap hit = CACHE.get(key);
        if (hit != null) return hit;

        TextPaint paint = newPaint(context, font, sizeSp);
        CharSequence shown = text;
        if (maxWidthPx > 0 && paint.measureText(shown, 0, shown.length()) > maxWidthPx) {
            shown = TextUtils.ellipsize(shown, paint, maxWidthPx, TextUtils.TruncateAt.END);
        }

        Paint.FontMetrics fm = paint.getFontMetrics();
        int pad = 1;
        int w = Math.max(2, (int) Math.ceil(paint.measureText(shown, 0, shown.length())) + pad * 2);
        int h = Math.max(2, (int) Math.ceil(fm.descent - fm.ascent) + pad * 2);

        Bitmap argb = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(argb);
        canvas.drawText(shown, 0, shown.length(), pad, pad - fm.ascent, paint);

        Bitmap out = toMask(dm, argb);
        CACHE.put(key, out);
        return out;
    }

    /** Párrafo de varias líneas (para el cuerpo de una notificación). */
    public static Bitmap block(Context context, String text, int font, float sizeSp,
                               int widthPx, int maxLines, float lineSpacing) {
        DisplayMetrics dm = context.getResources().getDisplayMetrics();
        String key = "B|" + font + "|" + sizeSp + "|" + widthPx + "|" + maxLines + "|" + lineSpacing
                + "|" + dm.densityDpi + "|" + text;
        Bitmap hit = CACHE.get(key);
        if (hit != null) return hit;

        TextPaint paint = newPaint(context, font, sizeSp);
        CharSequence src = (text == null || text.isEmpty()) ? " " : text;
        StaticLayout layout = StaticLayout.Builder
                .obtain(src, 0, src.length(), paint, Math.max(8, widthPx))
                .setMaxLines(Math.max(1, maxLines))
                .setEllipsize(TextUtils.TruncateAt.END)
                .setLineSpacing(0f, lineSpacing)
                .setIncludePad(false)
                .build();

        int pad = 1;
        float widest = 1f;
        for (int i = 0; i < layout.getLineCount(); i++) {
            widest = Math.max(widest, layout.getLineWidth(i));
        }
        int w = Math.max(2, (int) Math.ceil(widest) + pad * 2);
        int h = Math.max(2, layout.getHeight() + pad * 2);

        Bitmap argb = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(argb);
        canvas.translate(pad, pad);
        layout.draw(canvas);

        Bitmap out = toMask(dm, argb);
        CACHE.put(key, out);
        return out;
    }

    // ---------------------------------------------------------------- Utilidades

    private static Bitmap toMask(DisplayMetrics dm, Bitmap argb) {
        Bitmap mask = argb.extractAlpha();
        argb.recycle();
        // Misma densidad que la pantalla: el ImageView lo mide en dp reales, sin escalarlo.
        mask.setDensity(dm.densityDpi);
        return mask;
    }

    private static TextPaint newPaint(Context context, int font, float sizeSp) {
        TextPaint paint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
        paint.setColor(Color.WHITE);
        paint.setTypeface(face(context, font));
        paint.setTextSize(sizePx(context, font, sizeSp));
        paint.setSubpixelText(false);
        return paint;
    }

    /** Press Start 2P está dibujada en una cuadrícula de 8 px: ajustarla evita bordes borrosos. */
    private static float sizePx(Context context, int font, float sizeSp) {
        DisplayMetrics dm = context.getResources().getDisplayMetrics();
        float px = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, sizeSp, dm);
        if (font == TITLE) {
            float snapped = Math.max(8f, Math.round(px / 8f) * 8f);
            if (Math.abs(snapped - px) / px <= 0.15f) {
                return snapped;
            }
        }
        return px;
    }

    private static synchronized Typeface face(Context context, int font) {
        Context app = context.getApplicationContext() != null ? context.getApplicationContext() : context;
        try {
            if (font == TITLE) {
                if (sTitle == null) sTitle = app.getResources().getFont(R.font.press_start_2p);
                return sTitle;
            }
            if (sBody == null) sBody = app.getResources().getFont(R.font.vt323);
            return sBody;
        } catch (RuntimeException e) {
            return Typeface.MONOSPACE;
        }
    }

    public static int dp(Context context, float dp) {
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp,
                context.getResources().getDisplayMetrics()));
    }
}
