package com.example;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.atomic.AtomicBoolean;

/** Busca nuevas versiones en GitHub Releases, las descarga y abre el instalador. */
public final class UpdateHelper {

    public static final String APK_NAME = "ismamint.apk";
    private static final AtomicBoolean BUSY = new AtomicBoolean(false);
    private static volatile boolean pendingInstallPermission = false;

    private UpdateHelper() {}

    public static boolean consumePendingInstallPermission() {
        boolean v = pendingInstallPermission;
        pendingInstallPermission = false;
        return v;
    }

    private static void toast(Activity a, String msg) {
        a.runOnUiThread(() -> Toast.makeText(a, msg, Toast.LENGTH_LONG).show());
    }

    /** "usuario/repositorio", escrito por la compilación de GitHub en assets/update_repo.txt. */
    private static String repoSlug(Context c) {
        try (InputStream in = c.getAssets().open("update_repo.txt")) {
            byte[] buf = new byte[256];
            int n = in.read(buf);
            if (n <= 0) return null;
            String s = new String(buf, 0, n, "UTF-8").trim();
            return s.matches("[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+") ? s : null;
        } catch (Exception e) {
            return null;
        }
    }

    public static long currentVersion(Context c) {
        try {
            PackageInfo pi = c.getPackageManager().getPackageInfo(c.getPackageName(), 0);
            return Build.VERSION.SDK_INT >= Build.VERSION_CODES.P ? pi.getLongVersionCode() : pi.versionCode;
        } catch (Exception e) {
            return 0;
        }
    }

    public static String versionName(Context c) {
        try {
            return c.getPackageManager().getPackageInfo(c.getPackageName(), 0).versionName;
        } catch (Exception e) {
            return "?";
        }
    }

    /** Borra el APK ya instalado para no ocupar espacio. */
    public static void cleanup(Context c) {
        try {
            File f = ApkProvider.apkFile(c);
            if (f.exists()) //noinspection ResultOfMethodCallIgnored
                f.delete();
        } catch (Exception ignored) {
        }
    }

    public static void check(Activity activity, boolean manual) {
        if (!BUSY.compareAndSet(false, true)) return;
        new Thread(() -> {
            try {
                String slug = repoSlug(activity);
                if (slug == null) {
                    if (manual) toast(activity, "Esta versión no tiene actualizaciones automáticas configuradas");
                    return;
                }
                HttpURLConnection conn = (HttpURLConnection) new URL(
                        "https://api.github.com/repos/" + slug + "/releases/latest").openConnection();
                conn.setConnectTimeout(10000);
                conn.setReadTimeout(10000);
                conn.setRequestProperty("Accept", "application/vnd.github+json");
                conn.setRequestProperty("User-Agent", "ISMAMINT-app");
                int code = conn.getResponseCode();
                if (code == 404) {
                    if (manual) toast(activity, "Aún no hay versiones publicadas");
                    return;
                }
                if (code != 200) {
                    if (manual) toast(activity, "No se pudo buscar actualizaciones (código " + code + ")");
                    return;
                }
                StringBuilder sb = new StringBuilder();
                try (InputStream in = conn.getInputStream()) {
                    byte[] buf = new byte[8192];
                    int n;
                    while ((n = in.read(buf)) > 0) sb.append(new String(buf, 0, n, "UTF-8"));
                }
                JSONObject json = new JSONObject(sb.toString());
                String tag = json.optString("tag_name", "").replaceAll("[^0-9]", "");
                long remote = tag.isEmpty() ? 0 : Long.parseLong(tag);
                String url = null;
                JSONArray assets = json.optJSONArray("assets");
                if (assets != null) {
                    for (int i = 0; i < assets.length(); i++) {
                        JSONObject as = assets.getJSONObject(i);
                        if (APK_NAME.equals(as.optString("name"))) {
                            url = as.optString("browser_download_url", null);
                            break;
                        }
                    }
                }
                long current = currentVersion(activity);
                if (remote > current && url != null) {
                    final String downloadUrl = url;
                    final long remoteV = remote;
                    activity.runOnUiThread(() -> new AlertDialog.Builder(activity)
                            .setTitle("Actualización disponible")
                            .setMessage("Hay una versión nueva (v" + remoteV + "). Tu versión es v" + current
                                    + ".\n\n¿Descargar e instalar ahora?")
                            .setPositiveButton("ACTUALIZAR", (d, w) -> download(activity, downloadUrl))
                            .setNegativeButton("Después", null)
                            .show());
                } else if (manual) {
                    toast(activity, "Ya tienes la última versión (v" + current + ")");
                }
            } catch (Exception e) {
                if (manual) toast(activity, "No se pudo buscar actualizaciones. Revisa tu conexión.");
            } finally {
                BUSY.set(false);
            }
        }).start();
    }

    private static void download(Activity activity, String url) {
        final AtomicBoolean cancelled = new AtomicBoolean(false);
        LinearLayout box = new LinearLayout(activity);
        box.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (20 * activity.getResources().getDisplayMetrics().density);
        box.setPadding(pad, pad, pad, pad / 2);
        TextView label = new TextView(activity);
        label.setText("Descargando...");
        label.setGravity(Gravity.CENTER_HORIZONTAL);
        ProgressBar bar = new ProgressBar(activity, null, android.R.attr.progressBarStyleHorizontal);
        bar.setMax(100);
        box.addView(label);
        box.addView(bar);
        AlertDialog dialog = new AlertDialog.Builder(activity)
                .setTitle("Actualizando")
                .setView(box)
                .setCancelable(false)
                .setNegativeButton(android.R.string.cancel, (d, w) -> cancelled.set(true))
                .show();

        new Thread(() -> {
            File out = ApkProvider.apkFile(activity);
            boolean ok = false;
            try {
                //noinspection ResultOfMethodCallIgnored
                out.getParentFile().mkdirs();
                HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
                conn.setConnectTimeout(15000);
                conn.setReadTimeout(30000);
                conn.setRequestProperty("User-Agent", "ISMAMINT-app");
                conn.setInstanceFollowRedirects(true);
                long total = conn.getContentLengthLong();
                long done = 0;
                int lastPct = -1;
                try (InputStream in = conn.getInputStream(); FileOutputStream fos = new FileOutputStream(out)) {
                    byte[] buf = new byte[16384];
                    int n;
                    while ((n = in.read(buf)) > 0) {
                        if (cancelled.get()) throw new Exception("cancel");
                        fos.write(buf, 0, n);
                        done += n;
                        if (total > 0) {
                            int pct = (int) (done * 100 / total);
                            if (pct != lastPct) {
                                lastPct = pct;
                                final int p = pct;
                                activity.runOnUiThread(() -> {
                                    bar.setProgress(p);
                                    label.setText("Descargando... " + p + "%");
                                });
                            }
                        }
                    }
                }
                ok = out.length() > 100_000;
            } catch (Exception e) {
                ok = false;
            }
            final boolean success = ok;
            activity.runOnUiThread(() -> {
                try {
                    dialog.dismiss();
                } catch (Exception ignored) {
                }
                if (cancelled.get()) {
                    cleanup(activity);
                    return;
                }
                if (success) {
                    install(activity);
                } else {
                    cleanup(activity);
                    Toast.makeText(activity, "No se pudo descargar la actualización", Toast.LENGTH_LONG).show();
                }
            });
        }).start();
    }

    private static void install(Activity activity) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                && !activity.getPackageManager().canRequestPackageInstalls()) {
            pendingInstallPermission = true;
            Toast.makeText(activity,
                    "Activa «Permitir desde esta fuente» para ISMAMINT y vuelve a la app",
                    Toast.LENGTH_LONG).show();
            try {
                activity.startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                        Uri.parse("package:" + activity.getPackageName())));
            } catch (Exception ignored) {
            }
            return;
        }
        try {
            Uri uri = Uri.parse("content://" + activity.getPackageName() + ".apkprovider/" + APK_NAME);
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setDataAndType(uri, "application/vnd.android.package-archive");
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            activity.startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(activity, "No se pudo abrir el instalador", Toast.LENGTH_LONG).show();
        }
    }
}
