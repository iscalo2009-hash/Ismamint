package com.example;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.os.Bundle;
import android.widget.RemoteViews;

import org.json.JSONObject;

public class StatsStreakWidgetProvider extends AppWidgetProvider {

    private static final int PINK = 0xFFFF9999;
    private static final int RED = 0xFFFF4D4D;
    private static final int GOLD = 0xFFFFD24D;
    private static final int DIM = 0xFFE07070;

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        updateWidgets(context, appWidgetManager, appWidgetIds);
    }

    @Override
    public void onAppWidgetOptionsChanged(Context context, AppWidgetManager appWidgetManager,
                                          int appWidgetId, Bundle newOptions) {
        updateWidgets(context, appWidgetManager, new int[]{appWidgetId});
    }

    public static void updateWidgets(Context context, AppWidgetManager manager, int[] ids) {
        long now = System.currentTimeMillis();
        long conoceMs = Math.max(0L, now - WidgetDataHelper.CONOCE_MS);
        long juntosMs = Math.max(0L, now - WidgetDataHelper.JUNTOS_MS);
        double latidos = conoceMs * (100000.0 / 86400000.0);
        long horasJuntos = juntosMs / 3600000L;

        JSONObject snap = WidgetDataHelper.loadSnapshot(context);
        int streakCur = snap.optInt("streakCur", 0);
        int streakBest = snap.optInt("streakBest", 0);
        String visitDate = snap.optString("visitDate", "");
        String todayKey = WidgetDataHelper.todayCotKey(now);
        boolean visitedToday = todayKey.equals(visitDate);

        String streakStr = streakCur + (streakCur == 1 ? " día" : " días");
        String bestStr = "Récord: " + streakBest + " d";
        String statusStr = visitedToday ? "HOY OK" : "ENTRA HOY";
        String beatsStr = WidgetDataHelper.formatShortBig(latidos);
        String hoursStr = WidgetDataHelper.formatNumber(horasJuntos) + " h";

        for (int appWidgetId : ids) {
            int w = WidgetDataHelper.innerWidthPx(context, manager, appWidgetId);
            int cell = (w - PixelText.dp(context, 6)) / 2 - PixelText.dp(context, 8);

            RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_stats_streak);

            PixelText.set(views, R.id.widget_stats_title, context, "RACHA Y DATOS", PixelText.TITLE, 8, PINK, w);

            int badgeText = (int) PixelText.measure(context, statusStr, PixelText.TITLE, 7);
            int left = Math.max(PixelText.dp(context, 50),
                    w - PixelText.dp(context, 12) - badgeText - PixelText.dp(context, 12) - PixelText.dp(context, 6));
            PixelText.fit(views, R.id.widget_streak_cur, context, streakStr, PixelText.BODY, 24, 16, GOLD, left);
            PixelText.set(views, R.id.widget_streak_best, context, bestStr, PixelText.BODY, 15, DIM, left);
            PixelText.set(views, R.id.widget_streak_status, context, statusStr, PixelText.TITLE, 7,
                    visitedToday ? GOLD : RED, w / 2);
            views.setInt(R.id.widget_streak_status, "setBackgroundResource",
                    visitedToday ? R.drawable.widget_bg_gold_badge : R.drawable.widget_bg_red_badge);

            PixelText.fit(views, R.id.widget_stats_beats, context, beatsStr, PixelText.BODY, 21, 14, RED, cell);
            PixelText.set(views, R.id.widget_stats_beats_label, context, "latidos", PixelText.BODY, 15, PINK, cell);
            PixelText.fit(views, R.id.widget_stats_hours, context, hoursStr, PixelText.BODY, 21, 14, RED, cell);
            PixelText.set(views, R.id.widget_stats_hours_label, context, "juntos", PixelText.BODY, 15, PINK, cell);

            views.setOnClickPendingIntent(R.id.widget_stats_root,
                    WidgetDataHelper.createOpenTabPendingIntent(context, "p5", 6004));

            manager.updateAppWidget(appWidgetId, views);
        }
    }
}
