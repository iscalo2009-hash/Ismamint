package com.example;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.os.Bundle;
import android.widget.RemoteViews;

import org.json.JSONObject;

public class AchievementsWidgetProvider extends AppWidgetProvider {

    private static final int PINK = 0xFFFF9999;
    private static final int RED = 0xFFFF4D4D;
    private static final int GOLD = 0xFFFFD24D;
    private static final int TEXT = 0xFFFFD6D6;

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        updateWidgets(context, appWidgetManager, appWidgetIds);
    }

    @Override
    public void onAppWidgetOptionsChanged(Context context, AppWidgetManager appWidgetManager,
                                          int appWidgetId, Bundle newOptions) {
        updateWidgets(context, appWidgetManager, new int[]{appWidgetId});
    }

    public static void updateWidgets(Context context, AppWidgetManager manager, int[] ids) {
        JSONObject snap = WidgetDataHelper.loadSnapshot(context);
        int got = snap.optInt("achGot", -1);
        int total = snap.optInt("achTotal", -1);
        int pct = snap.optInt("achPct", 0);
        String lastTitle = snap.optString("lastAchName", "");
        String nextTitle = snap.optString("nextAchName", "");
        int nextPct = snap.optInt("nextAchPct", -1);
        String nextEta = snap.optString("nextAchEta", "");

        String countText = (got >= 0 && total > 0)
                ? WidgetDataHelper.formatNumber(got) + " / " + WidgetDataHelper.formatNumber(total)
                : "-- / --";
        String pctText = (got >= 0 && total > 0) ? pct + "%" : "--";
        int progressVal = (got >= 0 && total > 0) ? Math.max(0, Math.min(100, pct)) : 0;

        if (lastTitle.isEmpty()) {
            lastTitle = "Toca para abrir tus logros";
        }
        if (nextTitle.isEmpty()) {
            nextTitle = "Abre la app para sincronizar";
        }
        String nextMeta = "";
        if (nextPct >= 0) {
            nextMeta = nextPct + "%";
            if (!nextEta.isEmpty()) {
                nextMeta += " · " + nextEta;
            }
        } else if (!nextEta.isEmpty()) {
            nextMeta = nextEta;
        }

        for (int appWidgetId : ids) {
            int w = WidgetDataHelper.innerWidthPx(context, manager, appWidgetId);
            int cell = w - PixelText.dp(context, 16);

            RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_achievements);

            PixelText.set(views, R.id.widget_ach_title, context, "LOGROS", PixelText.TITLE, 8, PINK, w / 3);
            PixelText.set(views, R.id.widget_ach_count, context, countText, PixelText.BODY, 16, TEXT, w / 3);
            PixelText.set(views, R.id.widget_ach_pct, context, pctText, PixelText.TITLE, 8, GOLD, w / 4);
            views.setProgressBar(R.id.widget_ach_progress, 100, progressVal, false);

            PixelText.set(views, R.id.widget_ach_last_label, context, "ULTIMO DESBLOQUEADO", PixelText.TITLE, 7, GOLD, cell);
            PixelText.set(views, R.id.widget_ach_last_title, context, lastTitle, PixelText.BODY, 17, TEXT, cell);

            int metaW = nextMeta.isEmpty() ? 0 : (int) PixelText.measure(context, nextMeta, PixelText.TITLE, 7) + PixelText.dp(context, 4);
            PixelText.set(views, R.id.widget_ach_next_label, context, "PROXIMO CERCANO", PixelText.TITLE, 7, PINK,
                    Math.max(PixelText.dp(context, 60), cell - metaW - PixelText.dp(context, 6)));
            PixelText.set(views, R.id.widget_ach_next_meta, context, nextMeta, PixelText.TITLE, 7, RED, cell / 2);
            PixelText.set(views, R.id.widget_ach_next_title, context, nextTitle, PixelText.BODY, 17, TEXT, cell);

            views.setOnClickPendingIntent(R.id.widget_ach_root,
                    WidgetDataHelper.createOpenTabPendingIntent(context, "p3", 6002));

            manager.updateAppWidget(appWidgetId, views);
        }
    }
}
