# ISMAMINT — compatibilidad Redmi / MIUI

Esta versión parte del proyecto ISMAMINT con las correcciones anteriores de planificación de notificaciones y añade ajustes para launchers MIUI/Redmi.

## Cambios incluidos

- Los cuatro widgets renderizan sus textos en bitmaps `ARGB_8888` ya coloreados. Así no dependen de que el launcher aplique correctamente un `ColorFilter` a una máscara `ALPHA_8` recibida por `RemoteViews`.
- Se añade una prueba para comprobar el formato del bitmap del texto de widget.
- El canal de notificaciones cambia a `ismamint_push_v3`; se retiran los canales anteriores de la app para no reutilizar una configuración previa bloqueada.
- La comprobación de notificaciones revisa el permiso Android 13+, el bloqueo general de la app y el estado del canal.
- Los ajustes de permisos tienen rutas alternativas: Alarmas y recordatorios, notificaciones de la app y ficha general de ISMAMINT.
- Al volver de Ajustes, Android vuelve a consultar permisos y las alarmas futuras se programan otra vez.
- La pantalla de avisos incluye controles para Redmi/MIUI: acceso directo al gestor de Inicio automático (intent de MIUI, con fallback a la ficha de la app), acceso a la ficha de ISMAMINT y guía para habilitar Notificaciones y Ahorro de batería sin restricciones.

## Ajustes recomendados en Redmi Note 10 / MIUI

1. Dentro de ISMAMINT, abre **Avisos** y pulsa **Activar notificaciones**.
2. Si aparece **Permitir alarmas**, activa **Alarmas y recordatorios** para ISMAMINT.
3. En Ajustes > Aplicaciones > Administrar aplicaciones > ISMAMINT, permite las notificaciones y activa **Inicio automático** si MIUI lo ofrece.
4. En Ahorro de batería de ISMAMINT, selecciona **Sin restricciones**.
5. Pulsa **VER** dentro de ISMAMINT para comprobar que llega una notificación de prueba.
6. Si un widget antiguo aún no muestra la tipografía, actualiza la app y vuelve a añadir ese widget desde el launcher.

Los nombres y la ubicación exacta de estos controles pueden variar según la versión de MIUI/HyperOS. La app no puede cambiar esos permisos por sí sola: el usuario debe concederlos desde Ajustes.

## Validación realizada

- Sintaxis de los cuatro bloques JavaScript del `index.html` comprobada con Node.js.
- Comprobación estática de que los cuatro proveedores de widgets usan el nuevo renderizador.
- Comprobación estática de que los controles de ajustes añadidos existen.

No se pudo compilar ni ejecutar Robolectric en este entorno: el archivo del proyecto no incluye el script `gradlew`, y aquí no hay Gradle ni Android SDK instalados. Tampoco se ha podido probar físicamente en un Redmi Note 10; la verificación final de MIUI debe hacerse en el dispositivo.
