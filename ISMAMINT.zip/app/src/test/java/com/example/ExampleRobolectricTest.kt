package com.example

import android.app.AlarmManager
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun readAppNameFromContext() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("ISMAMINT", appName)
  }

  @Test
  fun notificationChannelHasHighImportanceAndNoSound() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    NotificationHelper.ensureChannel(context)
    val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    val channel = nm.getNotificationChannel(NotificationHelper.CHANNEL_ID)
    assertNotNull(channel)
    assertEquals(NotificationManager.IMPORTANCE_HIGH, channel.importance)
    assertNull(channel.sound)
  }

  @Test
  fun scheduleAndCancelAllManagesAlarmAndBootReschedule() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    val shadowAm = Shadows.shadowOf(am)
    val future = System.currentTimeMillis() + 600_000L

    NotificationHelper.scheduleNotification(context, 42, "ISMAMINT", "Hola", future)
    assertNotNull(shadowAm.nextScheduledAlarm)

    NotificationHelper.cancelAll(context)
    assertEquals(0, shadowAm.scheduledAlarms.size)

    // Re-schedule and test BootReceiver
    NotificationHelper.scheduleNotification(context, 77, "ISMAMINT", "Boot", future)
    val bootReceiver = BootReceiver()
    bootReceiver.onReceive(context, Intent(Intent.ACTION_BOOT_COMPLETED))
    assertNotNull(shadowAm.nextScheduledAlarm)
  }

  @Test
  fun activityLoadsWithoutCrashing() {
    val controller = Robolectric.buildActivity(MainActivity::class.java).setup()
    val activity = controller.get()
    assertNotNull(activity)
  }

  @Test
  fun allFourWidgetsAreDetectedByAppWidgetManagerAndRenderCleanly() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val pm = context.packageManager
    val resolved = pm.queryBroadcastReceivers(
      Intent(android.appwidget.AppWidgetManager.ACTION_APPWIDGET_UPDATE),
      android.content.pm.PackageManager.GET_META_DATA
    ).filter { it.activityInfo.packageName == context.packageName }
    assertEquals(4, resolved.size)
    resolved.forEach { info ->
      assertNotNull(info.activityInfo.metaData?.getInt("android.appwidget.provider"))
    }

    val awm = android.appwidget.AppWidgetManager.getInstance(context)
    val shadowAwm = Shadows.shadowOf(awm)
    val mainId = shadowAwm.createWidget(MainCounterWidgetProvider::class.java, R.layout.widget_main_counter)
    val achId = shadowAwm.createWidget(AchievementsWidgetProvider::class.java, R.layout.widget_achievements)
    val evId = shadowAwm.createWidget(EventsWidgetProvider::class.java, R.layout.widget_events)
    val stId = shadowAwm.createWidget(StatsStreakWidgetProvider::class.java, R.layout.widget_stats_streak)

    val snapshot = """
      {
        "achGot": 150,
        "achTotal": 1850,
        "achPct": 8,
        "lastAchName": "Aniversario 1 · 1 año juntos",
        "nextAchName": "400 días juntos",
        "nextAchPct": 96,
        "nextAchEta": "16d",
        "streakCur": 5,
        "streakBest": 12,
        "visitDate": "${WidgetDataHelper.todayCotKey(System.currentTimeMillis())}",
        "events": [
          {"title": "Cumpleaños de Ismael", "ts": ${System.currentTimeMillis() + 5L * WidgetDataHelper.DAY_MS}, "dateStr": "27/11/2026"}
        ]
      }
    """.trimIndent()
    WidgetDataHelper.saveSnapshot(context, snapshot)

    MainCounterWidgetProvider.updateWidgets(context, awm, intArrayOf(mainId))
    AchievementsWidgetProvider.updateWidgets(context, awm, intArrayOf(achId))
    EventsWidgetProvider.updateWidgets(context, awm, intArrayOf(evId))
    StatsStreakWidgetProvider.updateWidgets(context, awm, intArrayOf(stId))

    assertNotNull(shadowAwm.getViewFor(mainId))
    assertNotNull(shadowAwm.getViewFor(achId))
    assertNotNull(shadowAwm.getViewFor(evId))
    assertNotNull(shadowAwm.getViewFor(stId))

    val conoceAfter10Days = WidgetDataHelper.computeBreakdown(
      WidgetDataHelper.CONOCE_MS,
      WidgetDataHelper.CONOCE_MS + 10L * WidgetDataHelper.DAY_MS
    )
    assertEquals(10L, conoceAfter10Days.totalDays)
    assertEquals(0, conoceAfter10Days.totalMonths)
  }
}
