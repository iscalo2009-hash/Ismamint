package com.example;

import android.Manifest;
import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.widget.RemoteViews;

import org.json.JSONObject;

import java.util.Iterator;

public final class NotificationHelper {

    public static final String CHANNEL_ID = "ismamint_push_v2";
    private static final String LEGACY_CHANNEL_ID = "ismamint_channel";
    public static final String ACTION_ALARM_NOTIFY = "com.example.ACTION_ALARM_NOTIFY";
    public static final String EXTRA_ID = "notif_id";
    public static final String EXTRA_TITLE = "notif_title";
    public static final String EXTRA_TEXT = "notif_text";

    private static final String PREFS_NAME = "ismamint_alarms_prefs";
    private static final String KEY_ALARMS = "scheduled_alarms";

    private static final int ACCENT = 0xFFFF4D4D;
    private static final int PINK = 0xFFFF9999;
    private static final int TEXT = 0xFFFFD6D6;

    private NotificationHelper() {}

    /**
     * Tarjeta ISMAMINT: título en Press Start 2P y cuerpo en VT323, dibujados como bitmap porque
     * SystemUI no carga las fuentes de la app. Los lectores de pantalla leen contentDescription.
     */
    private static RemoteViews buildCard(Context context, String title, String text, int maxLines, boolean large) {
        DisplayMetrics dm = context.getResources().getDisplayMetrics();
        // Ancho útil de la tarjeta: pantalla (máx. 412dp) menos márgenes del sistema y padding propio.
        int screen = Math.min(dm.widthPixels, PixelText.dp(context, 412));
        int inner = Math.max(PixelText.dp(context, 180), screen - PixelText.dp(context, 76));

        RemoteViews card = new RemoteViews(context.getPackageName(),
                large ? R.layout.notification_card_large : R.layout.notification_card);
        float titleSp = large ? 9f : 8f;
        float bodySp = large ? 18f : 16f;
        float lineSpacing = large ? 1f : 0.9f;

        PixelText.set(card, R.id.notif_title, context, title.toUpperCase(java.util.Locale.ROOT),
                PixelText.TITLE, titleSp, PINK, inner - PixelText.dp(context, large ? 28 : 20));

        if (text.isEmpty()) {
            card.setViewVisibility(R.id.notif_body, android.view.View.GONE);
        } else {
            card.setViewVisibility(R.id.notif_body, android.view.View.VISIBLE);
            card.setImageViewBitmap(R.id.notif_body,
                    PixelText.block(context, text, PixelText.BODY, bodySp, inner, maxLines, lineSpacing));
            card.setInt(R.id.notif_body, "setColorFilter", TEXT);
            card.setContentDescription(R.id.notif_body, text);
        }
        return card;
    }

    public static void ensureChannel(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm == null) return;
            NotificationChannel legacy = nm.getNotificationChannel(LEGACY_CHANNEL_ID);
            if (legacy != null) {
                nm.deleteNotificationChannel(LEGACY_CHANNEL_ID);
            }
            NotificationChannel existing = nm.getNotificationChannel(CHANNEL_ID);
            if (existing != null) {
                existing.enableVibration(true);
                existing.setVibrationPattern(new long[]{0L, 60L, 40L, 60L});
                return;
            }

            String name = context.getString(R.string.notification_channel_name);
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    name,
                    NotificationManager.IMPORTANCE_HIGH
            );
            channel.setDescription(context.getString(R.string.notification_channel_desc));
            channel.setSound(null, null);
            channel.enableVibration(true);
            channel.setVibrationPattern(new long[]{0L, 60L, 40L, 60L});
            channel.enableLights(true);
            channel.setLightColor(ACCENT);
            channel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            channel.setShowBadge(true);
            nm.createNotificationChannel(channel);
        }
    }

    public static boolean hasNotificationPermission(Context context) {
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
                return false;
            }
        }
        return nm == null || nm.areNotificationsEnabled();
    }

    public static void showNotification(Context context, int id, String titulo, String texto) {
        if (!hasNotificationPermission(context)) {
            return;
        }
        ensureChannel(context);
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;

        Intent launchIntent = new Intent(context, MainActivity.class);
        launchIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                | Intent.FLAG_ACTIVITY_CLEAR_TOP
                | Intent.FLAG_ACTIVITY_SINGLE_TOP);

        PendingIntent contentIntent = PendingIntent.getActivity(
                context,
                id,
                launchIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        String safeTitle = (titulo == null || titulo.isEmpty())
                ? context.getString(R.string.app_name)
                : titulo;
        String safeText = (texto == null) ? "" : texto;

        Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(context, CHANNEL_ID)
                : new Notification.Builder(context);

        builder.setSmallIcon(R.drawable.ic_notification)
                .setColor(ACCENT)
                .setContentTitle(safeTitle)
                .setContentText(safeText)
                .setCategory(Notification.CATEGORY_REMINDER)
                .setContentIntent(contentIntent)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setOnlyAlertOnce(true)
                .setAutoCancel(true);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            builder.setDefaults(Notification.DEFAULT_VIBRATE | Notification.DEFAULT_LIGHTS);
        }

        // Tarjeta con las fuentes de la app. Si algo falla al dibujarla, queda la notificación normal.
        try {
            RemoteViews collapsed = buildCard(context, safeTitle, safeText, 2, false);
            RemoteViews expanded = buildCard(context, safeTitle, safeText, 6, true);
            RemoteViews headsUp = buildCard(context, safeTitle, safeText, 4, true);
            builder.setStyle(new Notification.DecoratedCustomViewStyle())
                    .setCustomContentView(collapsed)
                    .setCustomBigContentView(expanded)
                    .setCustomHeadsUpContentView(headsUp);
        } catch (RuntimeException e) {
            builder.setStyle(new Notification.BigTextStyle().bigText(safeText));
        }

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            builder.setDefaults(Notification.DEFAULT_VIBRATE | Notification.DEFAULT_LIGHTS);
            builder.setPriority(Notification.PRIORITY_HIGH);
        } else {
            // Canal nuevo con IMPORTANCE_HIGH; la alerta de pantalla también depende de ajustes del usuario.
        }

        try {
            nm.notify(id, builder.build());
        } catch (SecurityException ignored) {
        }
    }

    public static void scheduleNotification(Context context, int id, String titulo, String texto, long timestampMillis) {
        if (timestampMillis <= System.currentTimeMillis()) {
            return;
        }
        ensureChannel(context);
        saveAlarm(context, id, titulo, texto, timestampMillis);
        scheduleAlarmInternal(context, id, titulo, texto, timestampMillis);
    }

    private static void scheduleAlarmInternal(Context context, int id, String titulo, String texto, long timestampMillis) {
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarmManager == null) return;

        PendingIntent pi = buildAlarmPendingIntent(context, id, titulo, texto, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        if (pi == null) return;

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                if (alarmManager.canScheduleExactAlarms()) {
                    alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, timestampMillis, pi);
                } else {
                    alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, timestampMillis, pi);
                }
            } else {
                alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, timestampMillis, pi);
            }
        } catch (SecurityException e) {
            alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, timestampMillis, pi);
        }
    }

    public static void cancelAll(Context context) {
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        JSONObject map = loadAlarmsMap(context);
        Iterator<String> keys = map.keys();
        while (keys.hasNext()) {
            String key = keys.next();
            try {
                int id = Integer.parseInt(key);
                if (alarmManager != null) {
                    PendingIntent pi = buildAlarmPendingIntent(context, id, "", "", PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
                    if (pi != null) {
                        alarmManager.cancel(pi);
                        pi.cancel();
                    }
                }
            } catch (NumberFormatException ignored) {
            }
        }
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .remove(KEY_ALARMS)
                .apply();
    }

    public static void rescheduleAll(Context context) {
        ensureChannel(context);
        long now = System.currentTimeMillis();
        JSONObject map = loadAlarmsMap(context);
        JSONObject updated = new JSONObject();
        Iterator<String> keys = map.keys();
        while (keys.hasNext()) {
            String key = keys.next();
            JSONObject item = map.optJSONObject(key);
            if (item == null) continue;
            int id = item.optInt("id", 0);
            String title = item.optString("title", "");
            String text = item.optString("text", "");
            long ts = item.optLong("ts", 0L);
            if (ts > now) {
                scheduleAlarmInternal(context, id, title, text, ts);
                try {
                    updated.put(key, item);
                } catch (Exception ignored) {
                }
            }
        }
        saveAlarmsMap(context, updated);
    }

    public static void removeSavedAlarm(Context context, int id) {
        JSONObject map = loadAlarmsMap(context);
        map.remove(String.valueOf(id));
        saveAlarmsMap(context, map);
    }

    private static PendingIntent buildAlarmPendingIntent(Context context, int id, String titulo, String texto, int flags) {
        Intent intent = new Intent(context, NotificationReceiver.class);
        intent.setAction(ACTION_ALARM_NOTIFY);
        intent.putExtra(EXTRA_ID, id);
        intent.putExtra(EXTRA_TITLE, titulo != null ? titulo : "");
        intent.putExtra(EXTRA_TEXT, texto != null ? texto : "");
        return PendingIntent.getBroadcast(context, id, intent, flags);
    }

    private static void saveAlarm(Context context, int id, String titulo, String texto, long ts) {
        JSONObject map = loadAlarmsMap(context);
        try {
            JSONObject obj = new JSONObject();
            obj.put("id", id);
            obj.put("title", titulo != null ? titulo : "");
            obj.put("text", texto != null ? texto : "");
            obj.put("ts", ts);
            map.put(String.valueOf(id), obj);
            saveAlarmsMap(context, map);
        } catch (Exception ignored) {
        }
    }

    private static JSONObject loadAlarmsMap(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        String raw = prefs.getString(KEY_ALARMS, null);
        if (raw == null || raw.isEmpty()) {
            return new JSONObject();
        }
        try {
            return new JSONObject(raw);
        } catch (Exception e) {
            return new JSONObject();
        }
    }

    private static void saveAlarmsMap(Context context, JSONObject map) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .putString(KEY_ALARMS, map.toString())
                .apply();
    }
}
