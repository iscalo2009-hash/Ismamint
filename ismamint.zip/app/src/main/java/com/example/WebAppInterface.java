package com.example;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.os.VibratorManager;
import android.webkit.JavascriptInterface;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

public class WebAppInterface {

    public static final int REQ_POST_NOTIFICATIONS = 1001;
    private static final AtomicInteger IMMEDIATE_ID = new AtomicInteger(950000);

    private final Activity activity;
    private final Context appContext;

    public WebAppInterface(Activity activity) {
        this.activity = activity;
        this.appContext = activity.getApplicationContext();
    }

    @JavascriptInterface
    public void vibrate(String patron) {
        if (patron == null || patron.trim().isEmpty()) {
            return;
        }
        String[] parts = patron.split(",");
        List<Long> durations = new ArrayList<>();
        for (String part : parts) {
            String trimmed = part.trim();
            if (trimmed.isEmpty()) continue;
            try {
                long ms = Long.parseLong(trimmed);
                durations.add(Math.max(0L, ms));
            } catch (NumberFormatException ignored) {
            }
        }
        if (durations.isEmpty()) {
            return;
        }

        Vibrator vibrator = getVibrator();
        if (vibrator == null || !vibrator.hasVibrator()) {
            return;
        }

        try {
            if (durations.size() == 1) {
                long ms = durations.get(0);
                if (ms <= 0) return;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE));
                } else {
                    vibrator.vibrate(ms);
                }
            } else {
                // JS pattern alternates [vibrate, pause, vibrate, ...];
                // Android waveform alternates [delay, vibrate, pause, vibrate, ...].
                long[] androidPattern = new long[durations.size() + 1];
                androidPattern[0] = 0L;
                boolean hasPositive = false;
                for (int i = 0; i < durations.size(); i++) {
                    long val = durations.get(i);
                    androidPattern[i + 1] = val;
                    if (val > 0) hasPositive = true;
                }
                if (!hasPositive) return;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator.vibrate(VibrationEffect.createWaveform(androidPattern, -1));
                } else {
                    vibrator.vibrate(androidPattern, -1);
                }
            }
        } catch (SecurityException ignored) {
        }
    }

    @JavascriptInterface
    public void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (activity.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
                activity.runOnUiThread(() -> activity.requestPermissions(
                        new String[]{Manifest.permission.POST_NOTIFICATIONS},
                        REQ_POST_NOTIFICATIONS
                ));
            }
        }
    }

    @JavascriptInterface
    public boolean hasNotificationPermission() {
        return NotificationHelper.hasNotificationPermission(appContext);
    }

    @JavascriptInterface
    public void scheduleNotification(int id, String titulo, String texto, String timestampMillis) {
        scheduleNotificationEx(id, titulo, texto, timestampMillis, false);
    }

    @JavascriptInterface
    public void scheduleNotificationEx(int id, String titulo, String texto, String timestampMillis, boolean mandatory) {
        if (timestampMillis == null || timestampMillis.trim().isEmpty()) {
            return;
        }
        try {
            long ts = Long.parseLong(timestampMillis.trim());
            NotificationHelper.scheduleNotification(appContext, id, titulo, texto, ts, mandatory);
        } catch (NumberFormatException ignored) {
        }
    }

    @JavascriptInterface
    public void scheduleNotificationSmart(int id, String titulo, String texto,
                                          String timestampMillis, String expiresAtMillis) {
        if (timestampMillis == null || expiresAtMillis == null
                || timestampMillis.trim().isEmpty() || expiresAtMillis.trim().isEmpty()) {
            return;
        }
        try {
            long ts = Long.parseLong(timestampMillis.trim());
            long expiresAt = Long.parseLong(expiresAtMillis.trim());
            NotificationHelper.scheduleNotification(appContext, id, titulo, texto, ts, expiresAt);
        } catch (NumberFormatException ignored) {
        }
    }

    @JavascriptInterface
    public void cancelAll() {
        NotificationHelper.cancelAll(appContext);
    }

    @JavascriptInterface
    public void showNotification(String titulo, String texto) {
        int id = IMMEDIATE_ID.getAndIncrement();
        if (id > 999990) {
            IMMEDIATE_ID.set(950000);
        }
        NotificationHelper.showNotification(appContext, id, titulo, texto);
    }

    @JavascriptInterface
    public void saveImage(String dataUrl, String name) {
        new Thread(() -> ImageSaver.saveWithToast(activity, dataUrl, name)).start();
    }

    @JavascriptInterface
    public void shareImage(String dataUrl, String name) {
        new Thread(() -> ImageSaver.share(activity, dataUrl, name)).start();
    }

    @JavascriptInterface
    public void checkUpdate(boolean manual) {
        UpdateHelper.check(activity, manual);
    }

    @JavascriptInterface
    public String appVersion() {
        return UpdateHelper.versionName(appContext) + " (v" + UpdateHelper.currentVersion(appContext) + ")";
    }

    @JavascriptInterface
    public void saveTextFile(String name, String text) {
        new Thread(() -> {
            if (ImageSaver.saveText(activity, name, text)) {
                activity.runOnUiThread(() -> android.widget.Toast.makeText(activity,
                        "Respaldo guardado en Descargas", android.widget.Toast.LENGTH_LONG).show());
            }
        }).start();
    }

    @JavascriptInterface
    public boolean canScheduleExactAlarms() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            android.app.AlarmManager am = (android.app.AlarmManager) appContext.getSystemService(Context.ALARM_SERVICE);
            return am != null && am.canScheduleExactAlarms();
        }
        return true;
    }

    @JavascriptInterface
    public void openExactAlarmSettings() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            activity.runOnUiThread(() -> {
                try {
                    android.content.Intent i = new android.content.Intent(
                            android.provider.Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                            android.net.Uri.parse("package:" + appContext.getPackageName()));
                    activity.startActivity(i);
                } catch (Exception ignored) {
                }
            });
        }
    }

    @JavascriptInterface
    public void syncWidgetData(String json) {
        WidgetDataHelper.saveSnapshot(appContext, json);
        WidgetDataHelper.updateAllWidgets(appContext);
    }

    @JavascriptInterface
    public boolean canPinWidgets() {
        return WidgetDataHelper.canRequestPinWidget(appContext);
    }

    @JavascriptInterface
    public boolean pinWidget(String kind) {
        return WidgetDataHelper.requestPinWidget(appContext, kind);
    }

    private Vibrator getVibrator() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            VibratorManager vm = (VibratorManager) appContext.getSystemService(Context.VIBRATOR_MANAGER_SERVICE);
            return vm != null ? vm.getDefaultVibrator() : null;
        }
        return (Vibrator) appContext.getSystemService(Context.VIBRATOR_SERVICE);
    }
}
