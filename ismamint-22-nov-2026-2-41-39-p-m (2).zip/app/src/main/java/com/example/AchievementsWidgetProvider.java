package com.example;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.widget.RemoteViews;

import org.json.JSONObject;

public class AchievementsWidgetProvider extends AppWidgetProvider {

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        updateWidgets(context, appWidgetManager, appWidgetIds);
    }

    public static void updateWidgets(Context context, AppWidgetManager manager, int[] ids) {
        JSONObject snap = WidgetDataHelper.loadSnapshot(context);
        int got = snap.optInt("achGot", -1);
        int total = snap.optInt("achTotal", -1);
        int pct = snap.optInt("achPct", 0);
        String lastTitle = snap.optString("lastAchName", "");
        String nextTitle = snap.optString("nextAchName", "");
        int nextPct = snap.optInt("nextAchPct", -1);
        String nextEta = snap.optString("nextAchEta", "");

        String countText = (got >= 0 && total > 0)
                ? WidgetDataHelper.formatNumber(got) + " / " + WidgetDataHelper.formatNumber(total)
                : "-- / --";
        String pctText = (got >= 0 && total > 0) ? pct + "%" : "--";
        int progressVal = (got >= 0 && total > 0) ? Math.max(0, Math.min(100, pct)) : 0;

        if (lastTitle.isEmpty()) {
            lastTitle = "Toca para abrir tus logros";
        }
        if (nextTitle.isEmpty()) {
            nextTitle = "Abre la app para sincronizar";
        }
        String nextMeta = "";
        if (nextPct >= 0) {
            nextMeta = nextPct + "%";
            if (!nextEta.isEmpty()) {
                nextMeta += " · " + nextEta;
            }
        } else if (!nextEta.isEmpty()) {
            nextMeta = nextEta;
        }

        for (int appWidgetId : ids) {
            RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_achievements);
            views.setTextViewText(R.id.widget_ach_count, countText);
            views.setTextViewText(R.id.widget_ach_pct, pctText);
            views.setProgressBar(R.id.widget_ach_progress, 100, progressVal, false);
            views.setTextViewText(R.id.widget_ach_last_title, lastTitle);
            views.setTextViewText(R.id.widget_ach_next_title, nextTitle);
            views.setTextViewText(R.id.widget_ach_next_meta, nextMeta);

            views.setOnClickPendingIntent(R.id.widget_ach_root,
                    WidgetDataHelper.createOpenTabPendingIntent(context, "p3", 6002));

            manager.updateAppWidget(appWidgetId, views);
        }
    }
}
