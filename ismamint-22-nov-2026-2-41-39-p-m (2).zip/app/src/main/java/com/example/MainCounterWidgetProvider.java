package com.example;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;

public class MainCounterWidgetProvider extends AppWidgetProvider {

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        updateWidgets(context, appWidgetManager, appWidgetIds);
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        if (intent != null && WidgetDataHelper.ACTION_REFRESH_WIDGETS.equals(intent.getAction())) {
            WidgetDataHelper.updateAllWidgets(context);
        }
    }

    public static void updateWidgets(Context context, AppWidgetManager manager, int[] ids) {
        long now = System.currentTimeMillis();
        WidgetDataHelper.TimeBreakdown conoce = WidgetDataHelper.computeBreakdown(WidgetDataHelper.CONOCE_MS, now);
        WidgetDataHelper.TimeBreakdown juntos = WidgetDataHelper.computeBreakdown(WidgetDataHelper.JUNTOS_MS, now);
        String amoresStr = WidgetDataHelper.formatNumber(conoce.totalMs);
        String clockStr = WidgetDataHelper.formatClockCot(now);

        for (int appWidgetId : ids) {
            RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_main_counter);
            views.setTextViewText(R.id.widget_main_ms, amoresStr);
            views.setTextViewText(R.id.widget_main_updated, clockStr);
            views.setTextViewText(R.id.widget_main_conoce_days,
                    WidgetDataHelper.formatNumber(conoce.totalDays) + (conoce.totalDays == 1 ? " día" : " días"));
            views.setTextViewText(R.id.widget_main_conoce_detail, conoce.formatCompactYmd());
            views.setTextViewText(R.id.widget_main_juntos_days,
                    WidgetDataHelper.formatNumber(juntos.totalDays) + (juntos.totalDays == 1 ? " día" : " días"));
            views.setTextViewText(R.id.widget_main_juntos_detail, juntos.formatCompactYmd());

            views.setOnClickPendingIntent(R.id.widget_main_root,
                    WidgetDataHelper.createOpenTabPendingIntent(context, "p1", 6001));
            views.setOnClickPendingIntent(R.id.widget_main_refresh,
                    WidgetDataHelper.createRefreshPendingIntent(context));

            manager.updateAppWidget(appWidgetId, views);
        }
    }
}
