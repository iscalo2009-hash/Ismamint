package com.example;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.view.View;
import android.widget.RemoteViews;

import java.util.List;

public class EventsWidgetProvider extends AppWidgetProvider {

    private static final int[] ROW_IDS = {
            R.id.widget_events_row1,
            R.id.widget_events_row2,
            R.id.widget_events_row3
    };
    private static final int[] TITLE_IDS = {
            R.id.widget_ev1_title,
            R.id.widget_ev2_title,
            R.id.widget_ev3_title
    };
    private static final int[] DATE_IDS = {
            R.id.widget_ev1_date,
            R.id.widget_ev2_date,
            R.id.widget_ev3_date
    };
    private static final int[] ETA_IDS = {
            R.id.widget_ev1_eta,
            R.id.widget_ev2_eta,
            R.id.widget_ev3_eta
    };

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        updateWidgets(context, appWidgetManager, appWidgetIds);
    }

    public static void updateWidgets(Context context, AppWidgetManager manager, int[] ids) {
        long now = System.currentTimeMillis();
        List<WidgetDataHelper.EventItem> events = WidgetDataHelper.getUpcomingEvents(context, now);

        for (int appWidgetId : ids) {
            RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_events);
            for (int i = 0; i < 3; i++) {
                if (i < events.size()) {
                    WidgetDataHelper.EventItem item = events.get(i);
                    boolean urgent = WidgetDataHelper.isUrgentEvent(item.ts, now);
                    views.setViewVisibility(ROW_IDS[i], View.VISIBLE);
                    views.setTextViewText(TITLE_IDS[i], item.title);
                    views.setTextViewText(DATE_IDS[i], item.dateStr);
                    views.setTextViewText(ETA_IDS[i], WidgetDataHelper.formatCountdownLabel(item.ts, now));
                    views.setInt(ETA_IDS[i], "setBackgroundResource",
                            urgent ? R.drawable.widget_bg_gold_badge : R.drawable.widget_bg_red_badge);
                    views.setTextColor(ETA_IDS[i], urgent ? 0xFFFFD24D : 0xFFFF9999);
                } else {
                    views.setViewVisibility(ROW_IDS[i], View.GONE);
                }
            }

            views.setOnClickPendingIntent(R.id.widget_events_root,
                    WidgetDataHelper.createOpenTabPendingIntent(context, "p8", 6003));

            manager.updateAppWidget(appWidgetId, views);
        }
    }
}
