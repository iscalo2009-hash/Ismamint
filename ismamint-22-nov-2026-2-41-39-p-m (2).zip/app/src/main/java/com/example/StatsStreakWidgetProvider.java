package com.example;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.widget.RemoteViews;

import org.json.JSONObject;

public class StatsStreakWidgetProvider extends AppWidgetProvider {

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        updateWidgets(context, appWidgetManager, appWidgetIds);
    }

    public static void updateWidgets(Context context, AppWidgetManager manager, int[] ids) {
        long now = System.currentTimeMillis();
        long conoceMs = Math.max(0L, now - WidgetDataHelper.CONOCE_MS);
        long juntosMs = Math.max(0L, now - WidgetDataHelper.JUNTOS_MS);
        double latidos = conoceMs * (100000.0 / 86400000.0);
        long horasJuntos = juntosMs / 3600000L;

        JSONObject snap = WidgetDataHelper.loadSnapshot(context);
        int streakCur = snap.optInt("streakCur", 0);
        int streakBest = snap.optInt("streakBest", 0);
        String visitDate = snap.optString("visitDate", "");
        String todayKey = WidgetDataHelper.todayCotKey(now);
        boolean visitedToday = todayKey.equals(visitDate);

        String streakStr = streakCur + (streakCur == 1 ? " día" : " días");
        String bestStr = "Récord: " + streakBest + " d";
        String statusStr = visitedToday ? "HOY OK" : "ENTRA HOY";

        for (int appWidgetId : ids) {
            RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_stats_streak);
            views.setTextViewText(R.id.widget_streak_cur, streakStr);
            views.setTextViewText(R.id.widget_streak_best, bestStr);
            views.setTextViewText(R.id.widget_streak_status, statusStr);
            views.setInt(R.id.widget_streak_status, "setBackgroundResource",
                    visitedToday ? R.drawable.widget_bg_gold_badge : R.drawable.widget_bg_red_badge);
            views.setTextColor(R.id.widget_streak_status, visitedToday ? 0xFFFFD24D : 0xFFFF4D4D);

            views.setTextViewText(R.id.widget_stats_beats, WidgetDataHelper.formatShortBig(latidos));
            views.setTextViewText(R.id.widget_stats_hours, WidgetDataHelper.formatNumber(horasJuntos) + " h");

            views.setOnClickPendingIntent(R.id.widget_stats_root,
                    WidgetDataHelper.createOpenTabPendingIntent(context, "p5", 6004));

            manager.updateAppWidget(appWidgetId, views);
        }
    }
}
