const assert=require('node:assert/strict'),C=require('../app/src/main/assets/heartbound-core'),B=require('../app/src/main/assets/heartmint-bosses');
const make=(stage,emit)=>C.create({stage,seed:123,profile:n=>B.profile(n,123),emit});const tick=(g,n)=>{for(let i=0;i<n;i++)g.update(1/120);};
let g=make(10);tick(g,240);let s=g.state,w=s.wave;assert.equal(w.task.kind,'seal');w.age=w.warn+.1;s.player.x=w.task.x;s.player.y=w.task.y;s.player.cd=0;assert(g.action());assert.equal(s.focus,1);assert(w.task.claimed);s.player.cd=0;assert(!g.action());assert.equal(s.focus,1);s.energy=0;s.player.defCd=0;assert(g.defense());assert.equal(s.focus,0);assert.equal(s.energy,0);assert(s.player.inv>=.68);
// Expired counter costs energy and a life, then moves on without replaying the wave.
g=make(5);s=g.state;s.boss.state='open';s.boss.timer=.001;s.energy=30;s.player.inv=0;tick(g,1);assert.equal(s.boss.state,'rest');assert.equal(s.health,4);assert.equal(s.boss.missed,1);assert.equal(s.boss.round,1);
// Enemies may be interrupted only during a telegraph, with no repeated reward while staggered.
g=make(7);s=g.state;s.spawn=100;s.player.x=120;s.player.y=220;s.enemies.push({type:C.enemyTypes[2],hp:3,x:120,y:150,t:0,fire:.3});s.shots.push({x:120,y:150,vx:0,vy:0,t:1,r:3});tick(g,1);let enemy=s.enemies[0];assert(enemy.stagger>.8);assert.equal(enemy.hp,2);assert(enemy.fire>1);assert(s.notice.includes('INTERRUMPIDO'));const points=s.score;s.shots.push({x:enemy.x,y:enemy.y,vx:0,vy:0,t:1,r:3});tick(g,1);assert.equal(s.score,points);
// The two linked hearts share damage, including the mirrored half of a vertical beam.
g=make(13);s=g.state;s.player.x=65;s.player.y=230;s.player.inv=0;s.lasers.push({axis:'x',x:175,width:16,age:1,warn:.5,active:1});tick(g,1);assert.equal(s.health,4);
// All three exes stay active through the first three counters, then each loses its last seal.
g=make(50);s=g.state;for(let i=0;i<6;i++){s.boss.owner=i%3;s.boss.state='open';s.boss.ready=false;s.mode='free';s.player.x=120;s.player.y=140;s.player.cd=0;assert(g.action());if(i<5){assert.deepEqual(s.boss.members,Array.from({length:3},(_,k)=>2-Math.floor((i+3-k)/3)));}}assert.equal(g.state.stage,51);
console.log('Tactics: optional seals, focus consumption, no replay, interrupts, mirrored damage and interleaved trio passed.');
