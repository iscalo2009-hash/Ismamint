const assert=require('node:assert/strict'),C=require('../app/src/main/assets/heartbound-core'),B=require('../app/src/main/assets/heartmint-bosses');
const make=n=>C.create({stage:n,seed:123,profile:i=>B.profile(i,123)}),tick=(g,n)=>{for(let i=0;i<n;i++)g.update(1/120);};
function challenge(g,mode='free',round=0){const s=g.state,b=s.boss;s.mode=mode;b.round=round;b.state='open';b.timer=100;b.challenge=C.bossChallenge(C.world(s.stage),round,mode,0,b.owner);b.challenge.step=0;b.challenge.time=0;return b.challenge;}
let g=make(5),c=challenge(g),s=g.state;s.player.x=120;s.player.y=140;c.time=.4;assert(!g.action());c.time=0;assert(g.action());assert.equal(s.boss.round,1);
g=make(10);c=challenge(g);s=g.state;s.player.x=c.points[0].x;s.player.y=c.points[0].y;assert(g.action());assert.equal(s.boss.round,0);s.player.cd=0;assert(!g.action());s.player.x=c.points[1].x;s.player.y=c.points[1].y;assert(g.action());assert.equal(s.boss.round,1);
g=make(15);c=challenge(g,'link');s=g.state;s.player.x=c.points[0].x;s.player.y=c.points[0].y;assert(g.action());s.player.cd=0;s.player.x=100;s.player.y=c.points[1].y;assert(!g.action());s.player.x=114;assert(g.action());assert.equal(s.boss.round,1);
g=make(25);c=challenge(g);s=g.state;Object.assign(s.player,c.decoy);assert(!g.action());Object.assign(s.player,c.points[0]);assert(g.action());
g=make(35);c=challenge(g);s=g.state;Object.assign(s.player,c.points[0]);assert(!g.action());tick(g,300);assert.equal(s.boss.round,1);
g=make(40);c=challenge(g,'distortion');s=g.state;s.player.x=c.points[0].x;s.player.y=c.points[0].y;assert(!g.action());s.player.x=240-c.points[0].x;assert(g.action());assert(c.shifted);assert.equal(s.boss.round,0);s.player.cd=0;assert(g.action());assert.equal(s.boss.round,1);
// Jump from floor to the first platform without modifying velocity or enabling invulnerability.
g=make(8);s=g.state;s.player.x=50;assert(g.action());tick(g,140);assert.equal(s.player.y,248);assert(s.player.grounded);
g=make(17);s=g.state;s.player.x=50;s.player.y=248;s.player.grounded=true;let px=s.player.x,ax=s.platforms[0].x;tick(g,40);assert(Math.abs(s.platforms[0].x-ax)>2);assert(Math.abs(s.player.x-px)>2);
// Constricting arena changes real movement bounds, not just a rendered overlay.
g=make(25);s=g.state;s.boss.round=3;s.boss.timer=0;tick(g,1);assert.equal(s.mode,'free');s.boss.round=4;s.wave.age=s.wave.warn+.1;s.player.x=20;g.input.x=-1;tick(g,120);assert(s.arena.l>27);assert(s.player.x>=s.arena.l+C.R-.001);
// Protector moves between ally and player. Thief's stolen resource persists until defeated.
g=make(12);s=g.state;s.spawn=100;s.player.x=120;s.player.y=250;s.enemies.push({type:C.enemyTypes[3],hp:3,x:50,y:100,t:0,fire:3},{type:C.enemyTypes[2],hp:3,x:120,y:110,t:0,fire:3});tick(g,80);assert(s.enemies[0].x>60);assert(s.enemies[0].y>100);
g=make(16);s=g.state;s.spawn=100;s.enemies.push({type:C.enemyTypes[4],hp:1,x:90,y:100,t:0,fire:3});s.hearts.push({kind:'green',x:90,y:100,vy:0,t:10});tick(g,1);assert.equal(s.enemies[0].loot,'green');s.shots.push({x:s.enemies[0].x,y:s.enemies[0].y,vx:0,vy:0,t:1});tick(g,1);assert(s.hearts.some(h=>h.kind==='green'&&h.t>0));
console.log('Identity: unique resolution challenges, actual jump, moving platforms, arena limits, protector positioning and stolen hearts verified.');
