const assert=require('node:assert/strict'),C=require('../app/src/main/assets/heartbound-core'),B=require('../app/src/main/assets/heartmint-bosses');
const make=(stage,emit)=>C.create({stage,seed:123,profile:n=>B.profile(n,123),emit});const tick=(g,n)=>{for(let i=0;i<n;i++)g.update(1/120)};
for(const t of C.techniques){assert(!C.has(t.stage-1,t.id));assert(C.has(t.stage,t.id));}
// Rupture only targets marked nearby bullets; consumes energy and has a cooldown.
let g=make(14),s=g.state;tick(g,1);s.wave.age=s.wave.warn+.1;s.wave.next=999;s.player.inv=0;s.energy=30;s.bullets.push({x:150,y:252,t:4,r:3,vx:0,vy:0,age:0,breakable:true},{x:160,y:252,t:4,r:3,vx:0,vy:0,age:0});assert(g.action());assert.equal(s.bullets[0].t,0);assert.equal(s.bullets[1].t,4);assert.equal(s.energy,22);assert(!g.action());
// Parries launch reflected projectiles and can remove another projectile.
g=make(6);s=g.state;s.player.inv=0;g.input.x=1;tick(g,1);assert(g.action());s.bullets.push({x:135,y:230,t:1,r:3,vx:-30,vy:0,age:0,block:true});tick(g,1);assert.equal(s.parries,1);assert(s.shots.some(q=>q.reflected));s.bullets.push({x:145,y:230,t:1,r:3,vx:0,vy:0,age:0});tick(g,5);assert(!s.bullets.some(q=>q.x===145));
// Rescue pays once per defense, not repeatedly during invulnerability.
g=make(19);s=g.state;s.player.inv=0;s.energy=50;s.player.dir=0;assert(g.defense());const p=s.player;s.bullets.push(...[0,1].map(()=>({x:p.x,y:p.y,t:2,r:3,vx:0,vy:0,age:0})));tick(g,1);assert.equal(s.health,5);assert(s.energy>43&&s.energy<44);assert.equal(p.rescue,0);
// Cadence increases pulse range only on beat.
g=make(23);s=g.state;s.mode='resonance';tick(g,1);s.wave.age=s.wave.warn+s.wave.beat;s.wave.next=999;s.bullets.push({x:s.player.x+45,y:s.player.y,t:3,r:3,vx:0,vy:0,age:0});assert(g.defense());assert.equal(s.bullets[0].t,0);
// Flanking permits shots through the unprotected side, not through the shield.
function flank(x){const g=make(27),s=g.state;s.spawn=100;s.mode='free';s.enemies=[{type:C.enemyTypes[2],hp:3,x:120,y:150,t:0,fire:4},{type:C.enemyTypes[3],hp:3,x:90,y:150,t:0,fire:4}];s.shots.push({x,y:150,vx:x>120?-260:260,vy:0,t:1});tick(g,2);return s.enemies[0].hp;}
assert.equal(flank(130),2);assert.equal(flank(110),3);
// Rhythm cue shares simulation clock, no duplicate beat events within a beat.
let beats=[];g=make(18,(id,d)=>{if(id==='rhythm:beat')beats.push(d.beat)});tick(g,120*4);assert(beats.length>=4);assert.equal(new Set(beats).size,beats.length);
console.log('Finale: five progression techniques, real reflection, once-per-defense rescue, directional shield, rhythmic events verified.');
assert.equal(C.route(1,123).goal,7);assert.equal(C.route(4,123).goal,4);assert.equal(C.route(3,123).goal,6);assert.equal(C.route(50,123).type,'boss');
// A kill during collection does not advance the heart counter.
g=make(11);s=g.state;s.spawn=100;s.enemies.push({type:C.enemyTypes[0],hp:1,x:120,y:150,t:0,fire:3});s.shots.push({x:120,y:150,vx:0,vy:0,t:1,r:3});tick(g,1);assert.equal(s.kills,1);assert.equal(s.done,0);
