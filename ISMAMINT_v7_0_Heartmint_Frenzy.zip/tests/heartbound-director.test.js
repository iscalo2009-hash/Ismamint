const assert=require('node:assert/strict'),C=require('../app/src/main/assets/heartbound-core'),B=require('../app/src/main/assets/heartmint-bosses');
const at={x:120,y:230};assert(C.reachable(at,[]));
// A solid beam covering the whole horizontal arena must be rejected, not treated as a safe column.
assert(!C.reachable(at,[],[{axis:'y',y:185,width:300,age:0,warn:.12,active:1.4}]));
assert(C.reachable(at,[],[{axis:'x',x:120,width:18,age:0,warn:1.2,active:.4}]));
for(let n=1;n<=10000;n++){let a=C.director(n,123,{health:5}),b=C.director(n,123,{health:1,stress:1});assert(a.cap<=4&&b.cap<=a.cap);assert(b.budget<a.budget);assert(b.gap>a.gap);assert.equal(a.style,C.director(n,123,{health:5}).style);}
const make=(stage,emit)=>C.create({stage,seed:123,profile:n=>B.profile(n,123),emit});
const tick=(g,n)=>{for(let i=0;i<n;i++)g.update(1/120);};
let g=make(25);tick(g,120*4);assert.equal(g.state.wave.pattern,'reflection');assert(g.state.wave.marks.length>0||g.state.wave.validated>0);assert(g.state.trail.length<=20);
g=make(13);tick(g,2);let a=g.state.wave.anchor;assert(a&&!a.claimed);g.state.player.x=a.x;g.state.player.y=a.y;tick(g,1);assert(a.claimed);
g=make(24);g.state.player.inv=0;g.state.lasers.push({axis:'y',y:g.state.player.y,width:18,age:0,warn:.2,active:.4});tick(g,30);assert.equal(g.state.health,4);
g=make(2);g.state.player.inv=0;g.state.bullets.push({x:120,y:252,vx:0,vy:0,r:3,t:0,age:0});tick(g,1);assert.equal(g.state.health,5);
console.log('Director: 10,000 difficulty profiles, bounded reachability, reflected marks, link anchor, horizontal beams and expired hazards verified.');
