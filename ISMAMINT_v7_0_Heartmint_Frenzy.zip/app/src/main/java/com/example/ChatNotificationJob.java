package com.example;

import android.app.job.JobParameters;
import android.app.job.JobService;
import android.os.Handler;
import android.os.Looper;
import com.google.firebase.firestore.Source;

/** Android decides when to execute; never wakes the phone with exact alarms. */
public final class ChatNotificationJob extends JobService {
    private final Handler main=new Handler(Looper.getMainLooper());
    private JobParameters running;
    private final Runnable timeout=()->finish(true);
    @Override public boolean onStartJob(JobParameters p){
        if(running!=null)return false;
        String u;try{u=ChatNotifications.uid();}catch(RuntimeException e){return false;}
        if(u==null||ChatNotifications.isForeground()||!ChatNotifications.enabled(this))return false;
        running=p;main.postDelayed(timeout,20000);
        try{fetch(p,u,0);return true;}catch(RuntimeException e){running=null;main.removeCallbacks(timeout);return false;}
    }
    private void fetch(JobParameters p,String u,int pages){
        ChatNotifications.query(this,u).get(Source.SERVER).addOnCompleteListener(t->{
            if(running!=p)return;
            if(ChatNotifications.isForeground()||!u.equals(ChatNotifications.uid())){finish(false);return;}
            if(!t.isSuccessful()||t.getResult()==null){finish(true);return;}
            ChatNotifications.consume(this,u,t.getResult().getDocuments(),false);
            // Catch up in bounded pages; a larger backlog continues at the next job.
            if(t.getResult().size()>=100&&pages<2)fetch(p,u,pages+1);else finish(false);
        });
    }
    private void finish(boolean retry){JobParameters p=running;running=null;main.removeCallbacks(timeout);if(p!=null)jobFinished(p,retry);}
    @Override public boolean onStopJob(JobParameters p){if(running==p){running=null;main.removeCallbacks(timeout);}return !ChatNotifications.isForeground();}
}
