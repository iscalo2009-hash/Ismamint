package com.example;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.webkit.JsResult;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {

    private WebView webView;
    private ChatManager chatManager;
    private String pendingOpenTab;
    private boolean pageReady;
    private ValueCallback<Uri[]> fileCallback;
    private static final int REQ_FILE_CHOOSER = 2001;

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            getWindow().setAttributes(lp);
        }

        NotificationHelper.ensureChannel(this);

        // Request the highest refresh rate at the current display resolution; OS may override.
        android.view.Display display = getWindowManager().getDefaultDisplay();
        android.view.Display.Mode currentMode = display.getMode(), bestMode = currentMode;
        for (android.view.Display.Mode mode : display.getSupportedModes()) {
            if (mode.getPhysicalWidth() == currentMode.getPhysicalWidth() && mode.getPhysicalHeight() == currentMode.getPhysicalHeight() && mode.getRefreshRate() > bestMode.getRefreshRate()) bestMode = mode;
        }
        WindowManager.LayoutParams refreshParams = getWindow().getAttributes();
        refreshParams.preferredDisplayModeId = bestMode.getModeId();
        getWindow().setAttributes(refreshParams);
        webView = new WebView(this);
        webView.setBackgroundColor(Color.BLACK);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);

        webView.addJavascriptInterface(new WebAppInterface(this), "Android");
        try {
            chatManager = new ChatManager(webView);
            webView.addJavascriptInterface(chatManager, "NativeChat");
        } catch (RuntimeException e) {
            android.util.Log.e("Ismamint", "Firebase chat unavailable", e);
        }

        // Mantener pulsada una imagen -> ofrecer guardarla en la galería.
        webView.setOnLongClickListener(v -> {
            WebView.HitTestResult result = webView.getHitTestResult();
            int type = result.getType();
            if (type == WebView.HitTestResult.IMAGE_TYPE
                    || type == WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE) {
                final String url = result.getExtra();
                if (url != null && url.startsWith("data:image")) {
                    new AlertDialog.Builder(MainActivity.this)
                            .setMessage("¿Guardar imagen en la galería?")
                            .setPositiveButton("Guardar", (d, w) ->
                                    new Thread(() -> ImageSaver.saveWithToast(MainActivity.this, url, "ismamint")).start())
                            .setNegativeButton(android.R.string.cancel, null)
                            .show();
                    return true;
                }
            }
            return false;
        });

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request != null ? request.getUrl() : null;
                if (uri == null) return false;
                String scheme = uri.getScheme();
                if ("file".equals(scheme) || "about".equals(scheme) || "data".equals(scheme) || "blob".equals(scheme)) {
                    return false;
                }
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, uri));
                } catch (Exception ignored) {
                }
                return true;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                pageReady = true;
                dispatchPendingTab();
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (fileCallback != null) {
                    fileCallback.onReceiveValue(null);
                }
                fileCallback = callback;
                try {
                    Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    String[] types = params.getAcceptTypes();
                    intent.setType(types != null && types.length == 1 && !types[0].isEmpty() ? types[0] : "*/*");
                    intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, params.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE);
                    startActivityForResult(Intent.createChooser(intent, "Elegir archivo"), REQ_FILE_CHOOSER);
                } catch (Exception e) {
                    fileCallback = null;
                    callback.onReceiveValue(null);
                }
                return true;
            }

            @Override
            public boolean onJsAlert(WebView view, String url, String message, JsResult result) {
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage(message)
                        .setPositiveButton(android.R.string.ok, (d, w) -> result.confirm())
                        .setOnCancelListener(d -> result.cancel())
                        .show();
                return true;
            }

            @Override
            public boolean onJsConfirm(WebView view, String url, String message, JsResult result) {
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage(message)
                        .setPositiveButton(android.R.string.ok, (d, w) -> result.confirm())
                        .setNegativeButton(android.R.string.cancel, (d, w) -> result.cancel())
                        .setOnCancelListener(d -> result.cancel())
                        .show();
                return true;
            }
        });

        // Android 13+ (y obligatorio en Android 16): el botón atrás se registra así.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            getOnBackInvokedDispatcher().registerOnBackInvokedCallback(
                    android.window.OnBackInvokedDispatcher.PRIORITY_DEFAULT,
                    this::handleBack);
        }

        setContentView(webView);
        applyFullscreen();

        extractTabIntent(getIntent());
        if (savedInstanceState != null) {
            webView.restoreState(savedInstanceState);
        } else {
            webView.loadUrl("file:///android_asset/index.html");
            UpdateHelper.cleanup(this);
            webView.postDelayed(() -> UpdateHelper.check(MainActivity.this, false), 4000);
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        extractTabIntent(intent);
        dispatchPendingTab();
    }

    private void extractTabIntent(Intent intent) {
        if (intent == null) return;
        String tab = intent.getStringExtra(WidgetDataHelper.EXTRA_OPEN_TAB);
        if (tab != null && !tab.trim().isEmpty()) {
            pendingOpenTab = tab.trim();
        }
    }

    private void dispatchPendingTab() {
        if (pendingOpenTab == null || webView == null || !pageReady) return;
        String safeTab = pendingOpenTab.replaceAll("[^a-zA-Z0-9_]", "");
        if (safeTab.isEmpty()) {
            pendingOpenTab = null;
            return;
        }
        String tabToOpen = safeTab;
        pendingOpenTab = null;
        webView.post(() -> webView.evaluateJavascript(
                "if(window.__openTab)window.__openTab('" + tabToOpen + "');", null));
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (webView != null) {
            webView.saveState(outState);
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            applyFullscreen();
        }
    }

    private void applyFullscreen() {
        Window window = getWindow();
        if (window == null) return;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.setDecorFitsSystemWindows(false);
            WindowInsetsController controller = window.getInsetsController();
            if (controller != null) {
                controller.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                controller.setSystemBarsBehavior(
                        WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                );
            }
        } else {
            View decorView = window.getDecorView();
            decorView.setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_FULLSCREEN
            );
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 2012 && resultCode == RESULT_OK && chatManager != null) chatManager.cameraResult(data);
        if (requestCode == REQ_FILE_CHOOSER && fileCallback != null) {
            Uri[] result = null;
            if (resultCode == RESULT_OK && data != null) {
                if (data.getClipData() != null) { int n = Math.min(5,data.getClipData().getItemCount()); result = new Uri[n]; for(int i=0;i<n;i++) result[i]=data.getClipData().getItemAt(i).getUri(); }
                else if(data.getData()!=null) result = new Uri[]{data.getData()};
            }
            fileCallback.onReceiveValue(result);
            fileCallback = null;
        }
    }

    @Override
    public void onBackPressed() {
        handleBack();
    }

    private void handleBack() {
        if (webView == null) {
            finish();
            return;
        }
        // La página decide: cierra ventanas/paneles primero; si no hay nada, se sale.
        webView.evaluateJavascript(
                "(function(){try{return window.__goBack?window.__goBack():false;}catch(e){return false;}})()",
                value -> {
                    if ("true".equals(value)) return;
                    if (webView != null && webView.canGoBack()) {
                        webView.goBack();
                    } else {
                        finish();
                    }
                });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == WebAppInterface.REQ_POST_NOTIFICATIONS
                && grantResults.length > 0
                && grantResults[0] == PackageManager.PERMISSION_GRANTED
                && webView != null) {
            webView.post(() -> webView.evaluateJavascript(
                    "document.dispatchEvent(new Event('visibilitychange'));", null));
        }
    }

    private android.hardware.SensorManager depthSensors;
    private long depthLast;
    private boolean depthWanted,depthResumed;
    void depthActive(boolean wanted){runOnUiThread(()->{if(depthWanted==wanted)return;depthWanted=wanted;if(depthResumed&&wanted)startDepth();else if(depthSensors!=null)depthSensors.unregisterListener(depthListener);});}
    private final android.hardware.SensorEventListener depthListener=new android.hardware.SensorEventListener(){
        public void onAccuracyChanged(android.hardware.Sensor sensor,int accuracy){}
        public void onSensorChanged(android.hardware.SensorEvent e){
            long now=android.os.SystemClock.elapsedRealtime();if(webView==null||now-depthLast<50)return;depthLast=now;
            float[] matrix=new float[9],angles=new float[3];android.hardware.SensorManager.getRotationMatrixFromVector(matrix,e.values);android.hardware.SensorManager.getOrientation(matrix,angles);
            float x=(float)Math.toDegrees(angles[2]),y=(float)Math.toDegrees(angles[1]);if(Float.isFinite(x)&&Float.isFinite(y))webView.evaluateJavascript("window.IsmaUniverse&&IsmaUniverse.tilt("+x+","+y+")",null);
        }
    };
    private void startDepth(){depthSensors=(android.hardware.SensorManager)getSystemService(SENSOR_SERVICE);if(depthSensors==null)return;android.hardware.Sensor sensor=depthSensors.getDefaultSensor(android.hardware.Sensor.TYPE_GAME_ROTATION_VECTOR);if(sensor==null)sensor=depthSensors.getDefaultSensor(android.hardware.Sensor.TYPE_ROTATION_VECTOR);if(sensor!=null)depthSensors.registerListener(depthListener,sensor,50000);}
    private boolean heartmintWasPaused = false;

    @Override
    protected void onResume() {
        super.onResume();
        depthResumed=true;if(depthWanted)startDepth();
        if (chatManager != null) chatManager.resume();
        if (webView != null) {
            webView.onResume();
            webView.resumeTimers();
            if (heartmintWasPaused) webView.evaluateJavascript("if(window.__heartmintNativeResume)window.__heartmintNativeResume();", null);
            heartmintWasPaused = false;
        }
        applyFullscreen();
        WidgetDataHelper.updateAllWidgets(this);
        // Volver de Ajustes puede conceder Alarmas y recordatorios sin relanzar la app.
        // Reinstala las alarmas persistidas y refresca el estado visible en la WebView.
        NotificationHelper.rescheduleAll(this);
        if (webView != null) {
            webView.post(() -> webView.evaluateJavascript(
                    "if(window.__refreshNotificationUi)window.__refreshNotificationUi();", null));
        }
        if (UpdateHelper.consumePendingInstallPermission()) {
            UpdateHelper.check(this, true);
        }
    }

    @Override
    protected void onPause() {
        heartmintWasPaused = true;
        depthResumed=false;
        if(depthSensors!=null)depthSensors.unregisterListener(depthListener);
        if (chatManager != null) chatManager.pause();
        WidgetDataHelper.updateAllWidgets(this);
        if (webView != null) {
            webView.evaluateJavascript("if(window.__heartmintNativePause)window.__heartmintNativePause();", null);
            webView.onPause();
            // Detiene JS/timers/animaciones en segundo plano: las alarmas nativas siguen avisando.
            webView.pauseTimers();
        }
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        if (chatManager != null) chatManager.destroy();
        if (webView != null) {
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
