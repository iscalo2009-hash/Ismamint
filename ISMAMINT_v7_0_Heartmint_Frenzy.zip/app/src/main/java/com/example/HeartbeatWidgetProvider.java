package com.example;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.widget.RemoteViews;
public final class HeartbeatWidgetProvider extends AppWidgetProvider {
    static void refresh(Context c){AppWidgetManager m=AppWidgetManager.getInstance(c);if(m!=null)new HeartbeatWidgetProvider().onUpdate(c,m,m.getAppWidgetIds(new android.content.ComponentName(c,HeartbeatWidgetProvider.class)));}
    @Override public void onUpdate(Context c,AppWidgetManager m,int[] ids){for(int id:ids){RemoteViews v=new RemoteViews(c.getPackageName(),R.layout.widget_heartbeat);String u=ChatNotifications.uid();v.setTextViewText(R.id.widget_heartbeat_label,u==null?"Abrir Ismamint":"Enviar latido");v.setOnClickPendingIntent(R.id.widget_heartbeat_root,u==null?WidgetDataHelper.createOpenTabPendingIntent(c,"p10",6005):HeartbeatActions.intent(c,u,"widget"+id,false,true));m.updateAppWidget(id,v);}}
}
