package com.example;

import android.Manifest;
import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.widget.RemoteViews;

import org.json.JSONObject;
import org.json.JSONArray;

import java.util.Iterator;

public final class NotificationHelper {

    public static final String CHANNEL_ID = "ismamint_push_v3";
    private static final String PREVIOUS_CHANNEL_ID = "ismamint_push_v2";
    private static final String LEGACY_CHANNEL_ID = "ismamint_channel";
    public static final String ACTION_ALARM_NOTIFY = "com.example.ACTION_ALARM_NOTIFY";
    public static final String EXTRA_ID = "notif_id";
    public static final String EXTRA_TITLE = "notif_title";
    public static final String EXTRA_TEXT = "notif_text";
    public static final String EXTRA_TRIGGER_AT = "notif_trigger_at";
    public static final String EXTRA_EXPIRES_AT = "notif_expires_at";

    private static final int SCHEDULE_VERSION = 2;
    private static final long DEFAULT_VALIDITY_MS = 2L * 60L * 60L * 1000L;
    private static final String PREFS_NAME = "ismamint_alarms_prefs";
    private static final String KEY_ALARMS = "scheduled_alarms";
    private static final String KEY_DELIVERED = "delivered_notification_ids";
    private static final int MAX_DELIVERED_IDS = 1200;
    private static final String KEY_CUSTOM_CARDS = "custom_cards";

    private static final int ACCENT = 0xFFFF4D4D;
    private static final int PINK = 0xFFFF9999;
    private static final int TEXT = 0xFFFFD6D6;

    private NotificationHelper() {}

    /**
     * Tarjeta ISMAMINT: título en Press Start 2P y cuerpo en VT323, dibujados como bitmap porque
     * SystemUI no carga las fuentes de la app. Los lectores de pantalla leen contentDescription.
     */
    private static RemoteViews buildCard(Context context, String title, String text, int maxLines, boolean large) {
        DisplayMetrics dm = context.getResources().getDisplayMetrics();
        // Ancho útil de la tarjeta: pantalla (máx. 412dp) menos márgenes del sistema y padding propio.
        int screen = Math.min(dm.widthPixels, PixelText.dp(context, 412));
        int inner = Math.max(PixelText.dp(context, 180), screen - PixelText.dp(context, 76));

        RemoteViews card = new RemoteViews(context.getPackageName(),
                large ? R.layout.notification_card_large : R.layout.notification_card);
        float titleSp = large ? 9f : 8f;
        float bodySp = large ? 18f : 16f;
        float lineSpacing = large ? 1f : 0.9f;

        PixelText.set(card, R.id.notif_title, context, title.toUpperCase(java.util.Locale.ROOT),
                PixelText.TITLE, titleSp, PINK, inner - PixelText.dp(context, large ? 28 : 20));

        if (text.isEmpty()) {
            card.setViewVisibility(R.id.notif_body, android.view.View.GONE);
        } else {
            card.setViewVisibility(R.id.notif_body, android.view.View.VISIBLE);
            card.setImageViewBitmap(R.id.notif_body,
                    PixelText.block(context, text, PixelText.BODY, bodySp, inner, maxLines, lineSpacing));
            card.setInt(R.id.notif_body, "setColorFilter", TEXT);
            card.setContentDescription(R.id.notif_body, text);
        }
        return card;
    }

    public static void ensureChannel(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm == null) return;
            // Migración de canales anteriores: un canal que el usuario o MIUI dejó bloqueado
            // conserva ese estado para siempre; el canal nuevo permite recuperar avisos habilitados.
            NotificationChannel legacy = nm.getNotificationChannel(LEGACY_CHANNEL_ID);
            if (legacy != null) nm.deleteNotificationChannel(LEGACY_CHANNEL_ID);
            NotificationChannel previous = nm.getNotificationChannel(PREVIOUS_CHANNEL_ID);
            if (previous != null) nm.deleteNotificationChannel(PREVIOUS_CHANNEL_ID);
            NotificationChannel existing = nm.getNotificationChannel(CHANNEL_ID);
            if (existing != null) {
                existing.enableVibration(true);
                existing.setVibrationPattern(new long[]{0L, 60L, 40L, 60L});
                return;
            }

            String name = context.getString(R.string.notification_channel_name);
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    name,
                    NotificationManager.IMPORTANCE_HIGH
            );
            channel.setDescription(context.getString(R.string.notification_channel_desc));
            channel.setSound(null, null);
            channel.enableVibration(true);
            channel.setVibrationPattern(new long[]{0L, 60L, 40L, 60L});
            channel.enableLights(true);
            channel.setLightColor(ACCENT);
            channel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            channel.setShowBadge(true);
            nm.createNotificationChannel(channel);
        }
    }

    /** Activa o desactiva la tarjeta personalizada (fuentes pixel). Apagada por defecto. */
    public static void setCustomCards(Context context, boolean enabled) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit().putBoolean(KEY_CUSTOM_CARDS, enabled).apply();
    }

    public static boolean isCustomCards(Context context) {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .getBoolean(KEY_CUSTOM_CARDS, false);
    }

    public static boolean hasNotificationPermission(Context context) {
        ensureChannel(context);
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
                return false;
            }
        }
        if (nm == null || !nm.areNotificationsEnabled()) return false;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = nm.getNotificationChannel(CHANNEL_ID);
            return channel != null && channel.getImportance() != NotificationManager.IMPORTANCE_NONE;
        }
        return true;
    }

    /** True if the system allows precise alarms on this Android version/device. */
    public static boolean canScheduleExactAlarms(Context context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return true;
        AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        try {
            return manager != null && manager.canScheduleExactAlarms();
        } catch (RuntimeException ignored) {
            return false;
        }
    }

    /**
     * Entrega un aviso programado como máximo una vez, incluso si Android/MIUI
     * dispara dos veces el mismo PendingIntent tras restaurar o reprogramar alarmas.
     */
    public static synchronized void showNotificationOnce(Context context, int id, String titulo, String texto) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        String raw = prefs.getString(KEY_DELIVERED, "[]");
        org.json.JSONArray delivered;
        try {
            delivered = new org.json.JSONArray(raw);
        } catch (Exception ignored) {
            delivered = new org.json.JSONArray();
        }
        String key = String.valueOf(id);
        for (int i = 0; i < delivered.length(); i++) {
            if (key.equals(delivered.optString(i))) return;
        }
        delivered.put(key);
        while (delivered.length() > MAX_DELIVERED_IDS) delivered.remove(0);
        // commit antes de notificar: prioriza no duplicar frente a repetir tras un cierre abrupto.
        if (!prefs.edit().putString(KEY_DELIVERED, delivered.toString()).commit()) return;
        showNotification(context, id, titulo, texto);
    }

    public static void showNotification(Context context, int id, String titulo, String texto) {
        if (!hasNotificationPermission(context)) {
            return;
        }
        ensureChannel(context);
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;

        Intent launchIntent = new Intent(context, MainActivity.class);
        launchIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                | Intent.FLAG_ACTIVITY_CLEAR_TOP
                | Intent.FLAG_ACTIVITY_SINGLE_TOP);

        PendingIntent contentIntent = PendingIntent.getActivity(
                context,
                id,
                launchIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        String safeTitle = (titulo == null || titulo.isEmpty())
                ? context.getString(R.string.app_name)
                : titulo;
        String safeText = (texto == null) ? "" : texto;

        Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(context, CHANNEL_ID)
                : new Notification.Builder(context);

        builder.setSmallIcon(R.drawable.ic_notification)
                .setColor(ACCENT)
                .setContentTitle(safeTitle)
                .setContentText(safeText)
                .setCategory(Notification.CATEGORY_REMINDER)
                .setContentIntent(contentIntent)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setOnlyAlertOnce(true)
                .setAutoCancel(true);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            builder.setDefaults(Notification.DEFAULT_VIBRATE | Notification.DEFAULT_LIGHTS);
        }

        // Tarjeta con las fuentes de la app. Si algo falla al dibujarla, queda la notificación normal.
        if (!isCustomCards(context)) {
            builder.setStyle(new Notification.BigTextStyle().bigText(safeText));
        } else try {
            RemoteViews collapsed = buildCard(context, safeTitle, safeText, 2, false);
            RemoteViews expanded = buildCard(context, safeTitle, safeText, 6, true);
            RemoteViews headsUp = buildCard(context, safeTitle, safeText, 4, true);
            builder.setStyle(new Notification.DecoratedCustomViewStyle())
                    .setCustomContentView(collapsed)
                    .setCustomBigContentView(expanded)
                    .setCustomHeadsUpContentView(headsUp);
        } catch (RuntimeException e) {
            builder.setStyle(new Notification.BigTextStyle().bigText(safeText));
        }

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            builder.setDefaults(Notification.DEFAULT_VIBRATE | Notification.DEFAULT_LIGHTS);
            builder.setPriority(Notification.PRIORITY_HIGH);
        } else {
            // Canal nuevo con IMPORTANCE_HIGH; la alerta de pantalla también depende de ajustes del usuario.
        }

        try {
            nm.notify(id, builder.build());
        } catch (SecurityException ignored) {
        }
    }

    public static void scheduleNotification(Context context, int id, String titulo, String texto, long timestampMillis) {
        scheduleNotification(context, id, titulo, texto, timestampMillis, timestampMillis + DEFAULT_VALIDITY_MS);
    }

    /**
     * Compatibilidad con la interfaz anterior. Los avisos vencidos nunca se recuperan:
     * mostrar una predicción tarde podría afirmar algo que ya no es cierto.
     */
    public static void scheduleNotification(Context context, int id, String titulo, String texto,
                                            long timestampMillis, boolean ignoredMandatory) {
        scheduleNotification(context, id, titulo, texto, timestampMillis,
                timestampMillis + DEFAULT_VALIDITY_MS);
    }

    /** Programa un aviso con una fecha límite de validez explícita. */
    public static void scheduleNotification(Context context, int id, String titulo, String texto,
                                            long timestampMillis, long expiresAtMillis) {
        long now = System.currentTimeMillis();
        if (timestampMillis <= now || expiresAtMillis <= now || expiresAtMillis < timestampMillis) {
            return;
        }
        ensureChannel(context);
        saveAlarm(context, id, titulo, texto, timestampMillis, expiresAtMillis);
        scheduleAlarmInternal(context, id, titulo, texto, timestampMillis, expiresAtMillis);
    }

    private static void scheduleAlarmInternal(Context context, int id, String titulo, String texto,
                                              long timestampMillis, long expiresAtMillis) {
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarmManager == null) return;

        PendingIntent pi = buildAlarmPendingIntent(context, id, titulo, texto, timestampMillis,
                expiresAtMillis, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        if (pi == null) return;

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                if (canScheduleExactAlarms(context)) {
                    alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, timestampMillis, pi);
                } else {
                    // El recordatorio no se pierde por completo si el acceso especial está denegado;
                    // la interfaz informa que MIUI/Android puede entregarlo con retraso.
                    alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, timestampMillis, pi);
                }
            } else {
                alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, timestampMillis, pi);
            }
        } catch (SecurityException e) {
            alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, timestampMillis, pi);
        }
    }

    private static void cancelAlarm(Context context, int id) {
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarmManager == null) return;
        PendingIntent pi = buildAlarmPendingIntent(context, id, "", "", 0L, 0L,
                PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
        if (pi != null) {
            alarmManager.cancel(pi);
            pi.cancel();
        }
    }

    /** Evita avisos atrasados cuando Android despierta tarde o el teléfono estuvo apagado. */
    public static boolean isAlarmFresh(Intent intent) {
        if (intent == null) return false;
        long triggerAt = intent.getLongExtra(EXTRA_TRIGGER_AT, 0L);
        long expiresAt = intent.getLongExtra(EXTRA_EXPIRES_AT, 0L);
        long now = System.currentTimeMillis();
        return triggerAt > 0L && expiresAt >= triggerAt && now >= triggerAt - 60_000L && now <= expiresAt;
    }

    private static Boolean lastExactMode = null;

    /** Reconciles the complete desired plan in one bridge call and one preference write. */
    public static synchronized boolean reconcileNotifications(Context context, String json) {
        try {
            JSONArray plan = new JSONArray(json);
            if (plan.length() > 400) return false;
            JSONObject desired = new JSONObject();
            long now = System.currentTimeMillis();
            for (int i=0; i<plan.length(); i++) {
                JSONObject n=plan.getJSONObject(i);
                int id=n.getInt("id"); long ts=n.getLong("ts"), expires=n.getLong("expiresAt");
                if (ts<=now || expires<ts) continue;
                JSONObject row=new JSONObject();
                row.put("id",id); row.put("title",n.getString("title")); row.put("text",n.getString("text"));
                row.put("ts",ts); row.put("expiresAt",expires); row.put("version",SCHEDULE_VERSION);
                desired.put(String.valueOf(id),row);
            }
            ensureChannel(context);
            JSONObject old=loadAlarmsMap(context);
            boolean exact=canScheduleExactAlarms(context);
            boolean modeChanged=lastExactMode==null || lastExactMode.booleanValue()!=exact;
            Iterator<String> keys=desired.keys();
            while(keys.hasNext()) {
                String key=keys.next(); int id=Integer.parseInt(key);
                JSONObject n=desired.getJSONObject(key), prev=old.optJSONObject(key);
                long ts=n.getLong("ts"), exp=n.getLong("expiresAt");
                boolean same=prev!=null && prev.optLong("ts")==ts && prev.optLong("expiresAt")==exp
                    && prev.optInt("version")==SCHEDULE_VERSION && n.getString("title").equals(prev.optString("title"))
                    && n.getString("text").equals(prev.optString("text"));
                PendingIntent existing=buildAlarmPendingIntent(context,id,"","",0L,0L,PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
                if(!same || modeChanged || existing==null) scheduleAlarmInternal(context,id,n.getString("title"),n.getString("text"),ts,exp);
            }
            keys=old.keys();
            while(keys.hasNext()) {String key=keys.next(); if(!desired.has(key)) try {cancelAlarm(context,Integer.parseInt(key));}catch(NumberFormatException ignored){} }
            saveAlarmsMap(context,desired); lastExactMode=exact;
            return true;
        } catch(Exception e) { return false; }
    }

    public static synchronized void cancelAll(Context context) {
        JSONObject map = loadAlarmsMap(context);
        Iterator<String> keys = map.keys();
        while (keys.hasNext()) {
            String key = keys.next();
            try {
                cancelAlarm(context, Integer.parseInt(key));
            } catch (NumberFormatException ignored) {
            }
        }
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .remove(KEY_ALARMS)
                .apply();
    }

    public static synchronized void rescheduleAll(Context context) {
        ensureChannel(context);
        long now = System.currentTimeMillis();
        JSONObject map = loadAlarmsMap(context);
        JSONObject updated = new JSONObject();
        // Avisos que debieron sonar mientras el teléfono estaba apagado/reiniciando pero siguen
        // dentro de su ventana de validez: se entregan al volver (máx. 3, los más recientes).
        java.util.List<JSONObject> missed = new java.util.ArrayList<>();
        Iterator<String> keys = map.keys();
        while (keys.hasNext()) {
            String key = keys.next();
            JSONObject item = map.optJSONObject(key);
            if (item == null) continue;
            if (item.optInt("version", 0) == SCHEDULE_VERSION) {
                long mts = item.optLong("ts", 0L);
                long mexp = item.optLong("expiresAt", 0L);
                if (mts > 0L && mts <= now && mexp >= mts && now <= mexp) missed.add(item);
            }
            int id = item.optInt("id", 0);
            String title = item.optString("title", "");
            String text = item.optString("text", "");
            long ts = item.optLong("ts", 0L);
            long expiresAt = item.optLong("expiresAt", 0L);
            int version = item.optInt("version", 0);

            // Descarta alarmas de versiones anteriores, vencidas o mal formadas.
            // Es importante no reactivar predicciones antiguas con textos engañosos.
            if (version == SCHEDULE_VERSION && ts > now && expiresAt >= ts && expiresAt > now) {
                scheduleAlarmInternal(context, id, title, text, ts, expiresAt);
                try {
                    updated.put(key, item);
                } catch (Exception ignored) {
                }
            } else {
                cancelAlarm(context, id);
            }
        }
        saveAlarmsMap(context, updated);

        java.util.Collections.sort(missed, (x, y) -> Long.compare(y.optLong("ts", 0L), x.optLong("ts", 0L)));
        for (int i = 0; i < missed.size() && i < 3; i++) {
            JSONObject m = missed.get(i);
            showNotificationOnce(context, m.optInt("id", 0), m.optString("title", ""), m.optString("text", ""));
        }
    }

    public static void removeSavedAlarm(Context context, int id) {
        JSONObject map = loadAlarmsMap(context);
        map.remove(String.valueOf(id));
        saveAlarmsMap(context, map);
    }

    private static PendingIntent buildAlarmPendingIntent(Context context, int id, String titulo, String texto,
                                                         long timestampMillis, long expiresAtMillis, int flags) {
        Intent intent = new Intent(context, NotificationReceiver.class);
        intent.setAction(ACTION_ALARM_NOTIFY);
        intent.putExtra(EXTRA_ID, id);
        intent.putExtra(EXTRA_TITLE, titulo != null ? titulo : "");
        intent.putExtra(EXTRA_TEXT, texto != null ? texto : "");
        intent.putExtra(EXTRA_TRIGGER_AT, timestampMillis);
        intent.putExtra(EXTRA_EXPIRES_AT, expiresAtMillis);
        return PendingIntent.getBroadcast(context, id, intent, flags);
    }

    private static void saveAlarm(Context context, int id, String titulo, String texto,
                                  long ts, long expiresAtMillis) {
        JSONObject map = loadAlarmsMap(context);
        try {
            JSONObject obj = new JSONObject();
            obj.put("id", id);
            obj.put("title", titulo != null ? titulo : "");
            obj.put("text", texto != null ? texto : "");
            obj.put("ts", ts);
            obj.put("expiresAt", expiresAtMillis);
            obj.put("version", SCHEDULE_VERSION);
            map.put(String.valueOf(id), obj);
            saveAlarmsMap(context, map);
        } catch (Exception ignored) {
        }
    }

    private static JSONObject loadAlarmsMap(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        String raw = prefs.getString(KEY_ALARMS, null);
        if (raw == null || raw.isEmpty()) {
            return new JSONObject();
        }
        try {
            return new JSONObject(raw);
        } catch (Exception e) {
            return new JSONObject();
        }
    }

    private static void saveAlarmsMap(Context context, JSONObject map) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .putString(KEY_ALARMS, map.toString())
                .apply();
    }
}
