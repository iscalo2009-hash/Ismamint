/* Rebirth core: deterministic time, event subscriptions, navigation and lifecycle.
   Existing keys and original domain engines remain authoritative. */
(function(root){'use strict';
const DAY=86400000, listeners=new Map();
const emit=(type,payload)=>{for(const fn of [...(listeners.get(type)||[])]){try{fn(payload)}catch(e){console.error('IsmaCore subscriber',type,e)}}};
const on=(type,fn)=>{if(!listeners.has(type))listeners.set(type,new Set());listeners.get(type).add(fn);return()=>listeners.get(type)?.delete(fn)};
let known=0,together=0,offset=18000000,lastNow=null,lastSnapshot;
const elapsed=(start,now=Date.now())=>Math.max(0,now-start),days=(start,now)=>Math.floor(elapsed(start,now)/DAY);
function breakdown(start,now=Date.now()){
 if(now<start)return [0,0,0,0,0];
 const S=new Date(start-offset),N=now-offset,n=new Date(N),y=S.getUTCFullYear(),mo=S.getUTCMonth(),d=S.getUTCDate(),h=S.getUTCHours(),mi=S.getUTCMinutes();
 let m=(n.getUTCFullYear()-y)*12+n.getUTCMonth()-mo;
 if(Date.UTC(y,mo+m,d,h,mi)>N)m--;
 const r=N-Date.UTC(y,mo+m,d,h,mi);
 return [m,Math.floor(r/DAY),Math.floor(r%DAY/3600000),Math.floor(r%3600000/60000),Math.floor(r%60000/1000)];
}
function snapshot(now=Date.now()){
 if(now===lastNow)return lastSnapshot;
 const part=start=>Object.freeze({ms:elapsed(start,now),days:days(start,now),parts:Object.freeze(breakdown(start,now))});
 lastNow=now;return lastSnapshot=Object.freeze({now,known:part(known),together:part(together)});
}
const time={configure(a,b,z){known=a;together=b;offset=z;lastNow=null},elapsed,days,breakdown,snapshot,colombiaDate:ts=>new Date(ts-offset).toISOString().slice(0,10)};
let provider=null,revision=0,calendarCache=new Map();
function invalidate(){revision++;calendarCache.clear()}
const events={on,emit,setCalendarProvider(fn){provider=fn;invalidate()},calendar(year,month){if(!provider)return [];const key=`${year}:${month}:${revision}:${new Date().getTimezoneOffset()}:${new Date().toDateString()}`;if(!calendarCache.has(key)){if(calendarCache.size>=6)calendarCache.delete(calendarCache.keys().next().value);calendarCache.set(key,provider(year,month));}return calendarCache.get(key).slice()},invalidate};
on('achievements:changed',invalidate);
let current='p1', history=[],replaying=false;
const groups={p1:'home',p5:'us',p3:'us',p13:'us',p4:'explore',p6:'explore',p14:'explore',p10:'chat',p12:'music',p7:'profile',p8:'profile',p9:'profile',p11:'profile'};
const navigation={group:id=>groups[id]||'profile',current:()=>current,quiet:()=>!['p1','p12'].includes(current),changed(id){if(id===current)return;const prev=current;if(!replaying){history.push(prev);if(history.length>50)history.shift()}replaying=false;current=id;emit('navigation:changed',{from:prev,to:id,group:groups[id]})},back(){while(history.length){let target=history.pop();if(['p7','p8','p9'].includes(target))target='p11';if(target!==current){replaying=true;return target}}replaying=false;return null},clear(){history=[];replaying=false}};
const tasks=new Map();
function schedule(key){const t=tasks.get(key);if(!t||t.id||root.document?.hidden)return;t.id=root.requestAnimationFrame(ts=>{t.id=0;t.fn(ts)})}
const lifecycle={frame(key,fn){let t=tasks.get(key);if(!t){t={id:0,fn};tasks.set(key,t)}else t.fn=fn;schedule(key)},stop(key){const t=tasks.get(key);if(t?.id)root.cancelAnimationFrame(t.id);tasks.delete(key)}};
root.document?.addEventListener('visibilitychange',()=>{if(root.document.hidden){for(const t of tasks.values()){if(t.id)root.cancelAnimationFrame(t.id);t.id=0}}else for(const key of tasks.keys())schedule(key);emit('lifecycle:visibility',{visible:!root.document.hidden})});
root.IsmaCore=Object.freeze({time,events,navigation,lifecycle});
})(typeof window==='undefined'?globalThis:window);
