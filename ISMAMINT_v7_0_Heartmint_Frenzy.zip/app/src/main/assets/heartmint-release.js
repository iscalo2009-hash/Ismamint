(function(root){'use strict';
const KEY='heartmint_release_v1',defaults={movement:'both',sensitivity:1,countdown:3,music:true,vibration:true,reduced:false};
const fields=['hearts','gold','kills','clean','parries','resonances','interrupts','ruptures','grazes','tactics','anchors','reflections','bosses','perfectBosses','completed','perfectStages','runs','maxCombo','best','max','cleanStreak'];
const num=v=>Number.isFinite(Number(v))?Math.max(0,Math.min(Number.MAX_SAFE_INTEGER,Math.floor(Number(v)))):0;
function read(storage){let q={};try{q=JSON.parse(storage.getItem(KEY)||'{}')||{}}catch{}const max=Math.max(1,num(q.max));const metrics=Object.fromEntries(fields.map(k=>[k,num(q.metrics?.[k])]));metrics.max=max;const prefs={...defaults,...q.prefs};delete prefs.hand;prefs.movement=['both','stick','drag'].includes(prefs.movement)?prefs.movement:'both';prefs.sensitivity=[.75,1,1.25,1.5].includes(Number(prefs.sensitivity))?Number(prefs.sensitivity):1;prefs.countdown=[1,3,5].includes(Number(prefs.countdown))?Number(prefs.countdown):3;for(const k of ['music','vibration','reduced'])prefs[k]=typeof prefs[k]==='boolean'?prefs[k]:defaults[k];return {max,checkpoint:{stage:Math.min(max,Math.max(1,num(q.checkpoint?.stage))),seed:Number.isFinite(q.checkpoint?.seed)?q.checkpoint.seed>>>0:null},completed:Math.min(max,num(q.completed)),seen:q.seen&&typeof q.seen==='object'?q.seen:{},cosmetics:q.cosmetics||{},mastery:{clean:metrics.clean,parries:metrics.parries,resonances:metrics.resonances},metrics,prefs,bossWins:q.bossWins||{},perfectWins:q.perfectWins||{},records:q.records&&typeof q.records==='object'?q.records:{},last:q.last||null};}
const a=[];const add=(id,group,name,field,target,desc,unit='veces')=>a.push({id:'hmr_'+id,group,name,field,target,desc,unit});
for(const [i,n] of [[1,'Primer latido'],[5,'Más allá de Órbita'],[15,'Constelación naciente'],[25,'Horizonte abierto'],[50,'El largo viaje'],[100,'Sin fronteras'],[250,'Cartógrafo del infinito'],[1000,'Más allá de todo']])add('stage_'+i,'Viaje',n,'completed',i,'Completa hasta el nivel '+i,'niveles');
for(const [i,n] of ['Feid','Justin Bieber','La distancia','Seven','Celos','El sexto guardián','Ex malvado 1','Ex malvado 2','Ex malvado 3','Exes malvados'].entries()){add('boss_'+(i+1),'Jefes',i===9?'Los tres a la vez':'Victoria: '+n,'boss:'+ (i+1),1,'Derrota a '+n);add('flawless_'+(i+1),'Maestría','Intocable: '+n,'perfect:'+ (i+1),1,'Derrota a '+n+' sin recibir daño');}
for(const [key,g,unit,desc,steps] of [
 ['best','Expedición','puntos','Consigue en una expedición desde nivel 1',[[1000,'Chispa'],[5000,'Estela'],[15000,'Supernova'],[50000,'Horizonte dorado'],[150000,'Órbita eterna']]],
 ['hearts','Recursos','corazones','Recoge corazones',[[50,'Recolector'],[250,'Jardín de latidos'],[1000,'Constelación rosa']]],
 ['gold','Recursos','dorados','Recoge corazones dorados',[[25,'Destello dorado'],[100,'Alquimia']]],
 ['kills','Combate','enemigos','Derrota enemigos',[[10,'Primera línea'],[100,'Cazador'],[500,'Guardián del viaje']]],
 ['clean','Maestría','oleadas','Supera oleadas sin daño',[[5,'Paso ligero'],[25,'Danza de proyectiles'],[100,'Silencio entre balas']]],
 ['perfectStages','Maestría','tramos','Completa tramos sin daño',[[5,'Trayectoria limpia'],[25,'Precisión constante'],[100,'Sin cicatrices']]],
 ['cleanStreak','Maestría','tramos','Encadena tramos perfectos en una partida',[[3,'Fluidez'],[8,'Imperturbable']]],
 ['parries','Técnicas','parries','Realiza parries reales',[[10,'Espejo'],[50,'Respuesta perfecta'],[150,'Maestro del reflejo']]],
 ['resonances','Técnicas','acentos','Ejecuta acentos rítmicos precisos',[[10,'En sintonía'],[50,'Metrónomo'],[150,'Sinfonía']]],
 ['interrupts','Técnicas','interrupciones','Interrumpe ataques enemigos',[[5,'Cortocircuito'],[30,'Sin previo aviso']]],
 ['ruptures','Técnicas','rupturas','Rompe proyectiles dorados',[[10,'Rompeolas'],[50,'Fragmentos de luz']]],
 ['grazes','Maestría','roces','Roza proyectiles sin recibir daño',[[25,'Por un píxel'],[150,'Equilibrista'],[500,'Borde imposible']]],
 ['tactics','Técnicas','objetivos','Completa objetivos tácticos',[[5,'Estratega'],[25,'Dos pasos por delante'],[100,'Dominio táctico']]],
 ['anchors','Técnicas','vínculos','Estabiliza ambos corazones',[[5,'Dos latidos'],[25,'Inseparables']]],
 ['reflections','Técnicas','proyectiles','Destruye amenazas con proyectiles devueltos',[[5,'De vuelta'],[30,'Reacción en cadena']]],
 ['bosses','Jefes','jefes','Derrota jefes, incluidas revanchas',[[15,'Rompefronteras'],[50,'Leyenda de Heartmint'],[150,'Eternidad']]],
 ['perfectBosses','Maestría','jefes','Vence jefes sin daño',[[3,'Pulso de acero'],[10,'Sin titubeos'],[25,'Maestría absoluta']]],
 ['maxCombo','Maestría','acciones','Alcanza un combo de acciones puntuables sin daño',[[20,'Flujo'],[50,'Cadena de luz'],[100,'Continuum']]]])for(const [t,n] of steps)add(key+'_'+t,g,n,key,t,desc+' · '+t,unit);
function value(p,f){if(f.startsWith('boss:'))return Number(!!p.bossWins[f.slice(5)]);if(f.startsWith('perfect:'))return Number(!!p.perfectWins[f.slice(8)]);return p.metrics[f]||0;}
const api={KEY,defaults,read,achievements:a,value,num};if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.HeartmintRelease=api;
})(typeof window!=='undefined'?window:globalThis);