package com.example;

import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.os.Handler;
import android.os.Looper;
import com.google.firebase.Timestamp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.*;
import org.json.*;
import java.util.*;

/** Native, foreground-only chat bridge. No credentials or chat data in localStorage. */
public final class ChatManager {
    private static final String A="MCbwjlCpBnhTHxfQTuvcOVWLN3w2", I="MIPr6C3HW5QPp9GXd5ZjlHCmFQJ3";
    private final WebView web;
    private final Handler main=new Handler(Looper.getMainLooper());
    private final FirebaseAuth auth;
    private final CollectionReference messages, states;
    private ListenerRegistration msgListener, stateListener;
    private boolean active, foreground, destroyed, typing;
    private int limit=50;
    private long lastTyping=0;
    private String latestIncoming="";
    private final Runnable heartbeat=new Runnable(){public void run(){if(active&&foreground&&uid()!=null){presence(typing);main.postDelayed(this,25000);}}};
    public ChatManager(WebView web){this.web=web;auth=FirebaseAuth.getInstance();DocumentReference room=FirebaseFirestore.getInstance().collection("ismamint_chat").document("private");messages=room.collection("messages");states=room.collection("states");}
    private String uid(){FirebaseUser u=auth.getCurrentUser();return u!=null&&(A.equals(u.getUid())||I.equals(u.getUid()))?u.getUid():null;}
    private String peer(){return A.equals(uid())?I:A;}
    private void emit(String type,Object value){if(destroyed)return;try{JSONObject o=new JSONObject();o.put("type",type);o.put("value",value==null?JSONObject.NULL:value);web.evaluateJavascript("window.IsmaChat&&window.IsmaChat.receive("+JSONObject.quote(o.toString())+")",null);}catch(JSONException ignored){}}
    private void error(Exception e){emit("error", e instanceof FirebaseFirestoreException&&((FirebaseFirestoreException)e).getCode()==FirebaseFirestoreException.Code.PERMISSION_DENIED?"Acceso denegado. Comprueba las reglas de Firestore.":"No se pudo completar la operación. Comprueba tu conexión o tus datos.");}
    private void session(){String u=uid();emit("session",u);}
    @JavascriptInterface public void open(boolean value){main.post(()->{active=value;if(value){session();start();}else stop();});}
    @JavascriptInterface public void login(String email,String password){main.post(()->{auth.signInWithEmailAndPassword(email.trim(),password).addOnCompleteListener(t->{if(destroyed)return;if(!t.isSuccessful()){error(t.getException());return;}if(uid()==null){auth.signOut();emit("error","Cuenta no autorizada.");return;}session();start();});});}
    @JavascriptInterface public void logout(){main.post(()->{stop();auth.signOut();limit=50;latestIncoming="";session();});}
    public void resume(){foreground=true;if(active){session();start();}}
    public void pause(){foreground=false;stop();}
    public void destroy(){pause();destroyed=true;}
    private void start(){if(!active||!foreground||uid()==null||msgListener!=null)return;subscribe();stateListener=states.document(peer()).addSnapshotListener((s,e)->{if(!active||!foreground)return;if(e!=null){error(e);return;}try{JSONObject o=new JSONObject();if(s!=null&&s.exists()){o.put("seen",ms(s.getTimestamp("seen")));o.put("typing",Boolean.TRUE.equals(s.getBoolean("typing")));o.put("read",ms(s.getTimestamp("read")));}emit("peer",o);}catch(JSONException ignored){}});presence(false);main.removeCallbacks(heartbeat);main.postDelayed(heartbeat,25000);}
    private void stop(){main.removeCallbacks(heartbeat);if(msgListener!=null){msgListener.remove();msgListener=null;}if(stateListener!=null){stateListener.remove();stateListener=null;}if(uid()!=null&&(typing||lastTyping!=0)){Map<String,Object> m=new HashMap<>();m.put("typing",false);m.put("seen",FieldValue.serverTimestamp());states.document(uid()).set(m,SetOptions.merge());}typing=false;lastTyping=0;}
    private long ms(Timestamp t){return t==null?0:t.toDate().getTime();}
    private void subscribe(){if(msgListener!=null)msgListener.remove();msgListener=messages.orderBy("created",Query.Direction.DESCENDING).limit(limit).addSnapshotListener(MetadataChanges.INCLUDE,(s,e)->{if(!active||!foreground||uid()==null)return;if(e!=null){error(e);return;}if(s==null)return;try{JSONArray arr=new JSONArray();List<DocumentSnapshot> docs=s.getDocuments();for(int n=docs.size()-1;n>=0;n--){DocumentSnapshot d=docs.get(n);JSONObject o=new JSONObject();o.put("id",d.getId());o.put("sender",d.getString("sender"));o.put("text",d.getString("text"));o.put("reply",d.getString("reply"));o.put("created",ms(d.getTimestamp("created",DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)));o.put("edited",Boolean.TRUE.equals(d.getBoolean("edited")));o.put("deleted",Boolean.TRUE.equals(d.getBoolean("deleted")));o.put("pending",d.getMetadata().hasPendingWrites());Object r=d.get("reactions");o.put("reactions",r instanceof Map?new JSONObject((Map)r):new JSONObject());arr.put(o);}
        JSONObject out=new JSONObject();out.put("items",arr);out.put("more",docs.size()==limit);out.put("cache",s.getMetadata().isFromCache());emit("messages",out);
    }catch(JSONException ignored){}});}
    @JavascriptInterface public void older(){main.post(()->{if(active&&foreground&&uid()!=null&&limit<1000){limit+=50;subscribe();}});}
    @JavascriptInterface public void send(String text,String reply){main.post(()->{String u=uid();if(!active||u==null||text.trim().isEmpty()||text.length()>4000||reply.length()>150)return;Map<String,Object> m=new HashMap<>();m.put("sender",u);m.put("text",text.trim());m.put("created",FieldValue.serverTimestamp());m.put("reply",reply);m.put("edited",false);m.put("deleted",false);m.put("reactions",new HashMap<String,String>());messages.document().set(m).addOnFailureListener(this::error);setTyping(false);});}
    @JavascriptInterface public void edit(String id,String text){main.post(()->{if(valid(id)&&!text.trim().isEmpty()&&text.length()<=4000)messages.document(id).update("text",text.trim(),"edited",true).addOnFailureListener(this::error);});}
    @JavascriptInterface public void remove(String id){main.post(()->{if(valid(id))messages.document(id).update("text","","deleted",true).addOnFailureListener(this::error);});}
    @JavascriptInterface public void react(String id,String emoji){main.post(()->{if(valid(id)&&emoji.length()<=16)messages.document(id).update("reactions."+uid(),emoji.isEmpty()?FieldValue.delete():emoji).addOnFailureListener(this::error);});}
    private boolean valid(String id){return active&&uid()!=null&&id.matches("[A-Za-z0-9]{20}");}
    @JavascriptInterface public void writing(boolean value){main.post(()->setTyping(value));}
    private void setTyping(boolean value){if(!active||!foreground||uid()==null)return;long now=System.currentTimeMillis();if(value==typing&&now-lastTyping<4000)return;presence(value);}
    private void presence(boolean value){String u=uid();if(u==null)return;typing=value;lastTyping=System.currentTimeMillis();Map<String,Object> m=new HashMap<>();m.put("typing",value);m.put("seen",FieldValue.serverTimestamp());states.document(u).set(m,SetOptions.merge()).addOnFailureListener(this::error);}
    @JavascriptInterface public void read(String id){main.post(()->{if(!foreground||!valid(id)||id.equals(latestIncoming))return;String u=uid();messages.document(id).get(Source.SERVER).addOnSuccessListener(d->{if(!foreground||!active||!u.equals(uid())||!d.exists()||u.equals(d.getString("sender")))return;Timestamp t=d.getTimestamp("created");if(t==null)return;latestIncoming=id;Map<String,Object> m=new HashMap<>();m.put("read",t);states.document(u).set(m,SetOptions.merge()).addOnFailureListener(e->{latestIncoming="";error(e);});});});}
}
