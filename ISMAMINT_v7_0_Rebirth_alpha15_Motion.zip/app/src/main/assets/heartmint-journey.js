/* Heartmint Journey: local, constant-size checkpoint and deterministic encounter plans. */
(function(root){'use strict';
const KEY='heartmint_journey_v1', zones=[['ÓRBITA','#15112d','#a691ff'],['NEBULOSA','#30112e','#ee90b9'],['AURORA','#102b32','#72e4d5'],['ECLIPSE','#30201a','#ebc65c'],['CRISTAL','#132537','#7ce5ff'],['ABISMO','#19142d','#b18afa'],['COMETA','#34221c','#ffc080'],['CONSTELACIÓN','#182b27','#8ce4aa']];
const prefixes=['','Órbita','Nebulosa','Aurora','Eclipse','Cristal','Abismo','Cometa','Constelación'];
const weapons=[{id:'bolt',name:'Chispa',level:1,cd:40,damage:2,color:'#ffd34d',desc:'Disparo preciso y rápido'},{id:'fan',name:'Tridente',level:6,cd:65,damage:3,color:'#72e4d5',desc:'Tres rayos, amplio alcance'},{id:'beam',name:'Rayo',level:11,cd:85,damage:5,color:'#a691ff',desc:'Haz concentrado, daño alto'},{id:'nova',name:'Nova',level:21,cd:115,damage:5,color:'#ff83be',desc:'Explosión que limpia peligros'},{id:'echo',name:'Eco',level:51,cd:68,damage:4,color:'#82cfff',desc:'Doble disparo amplio'}];
const items=[
 {id:'heal',name:'Botiquín',level:1,max:2,color:'#7af3a3',desc:'Recupera 2 vidas'},
 {id:'barrier',name:'Barrera',level:6,max:2,color:'#7dffe8',desc:'Escudo y 1 segundo de invulnerabilidad'},
 {id:'freeze',name:'Crono',level:11,max:2,color:'#b388ff',desc:'Ralentiza el combate durante 5 s'},
 {id:'bomb',name:'Estallido',level:16,max:1,color:'#ffad69',desc:'Limpia peligros y daña al jefe'},
 {id:'battery',name:'Batería',level:21,max:2,color:'#ffe16b',desc:'Carga el pulso al 100%'},
 {id:'overdrive',name:'Sobrecarga',level:31,max:1,color:'#ff6f9d',desc:'Disparos más rápidos y fuertes durante 6 s'},
 {id:'magnet',name:'Atracción',level:41,max:2,color:'#69c8ff',desc:'Imán y plataforma ancha durante 6 s'},
 {id:'prism',name:'Prisma',level:51,max:1,color:'#d9a5ff',desc:'Cancela amenazas y daña al jefe un 9% (máx. 24)'}];
const perks=[
 {id:'wide',name:'Amplitud',level:1,desc:'Mayor alcance de recogida',cap:3}, {id:'charge',name:'Energía',level:1,desc:'Carga más rápida del pulso',cap:12}, {id:'guard',name:'Protección',level:1,desc:'Escudo, vida e invulnerabilidad',cap:12}, {id:'rapid',name:'Cadencia',level:6,desc:'Reduce recarga del arma',cap:12}, {id:'magnet',name:'Atracción',level:6,desc:'Imán pasivo de corazones',cap:12},
 {id:'power',name:'Potencia',level:11,desc:'Daño adicional del arma',cap:8}, {id:'agility',name:'Agilidad',level:16,desc:'Impulso se recarga antes',cap:8}, {id:'fortune',name:'Fortuna',level:21,desc:'Más corazones dorados',cap:8}, {id:'supply',name:'Reserva',level:31,desc:'Recarga objetos al derrotar jefes',cap:2}, {id:'focus',name:'Concentración',level:41,desc:'Mayor ventana de daño doble',cap:8}, {id:'recovery',name:'Resistencia',level:51,desc:'Más fallos tolerados antes de perder vida',cap:3}];
function cleanPerks(p={}){return Object.fromEntries(perks.map(k=>[k.id,Math.max(0,Math.min(k.cap,Math.floor(Number(p?.[k.id])||0)))]));}
function loadout(ids,max){const a=Array.isArray(ids)?ids:[],valid=id=>items.some(x=>x.id===id&&x.level<=max);const first=valid(a[0])?a[0]:'heal';return [first,valid(a[1])&&a[1]!==first?a[1]:null];}
function rewards(n,seed,p){const pool=perks.filter(k=>k.level<=n&&(p[k.id]||0)<k.cap);const sorted=pool.sort((a,b)=>hash(seed^hash(n)^hash(perks.indexOf(a)+71))-hash(seed^hash(n)^hash(perks.indexOf(b)+71)));const out=sorted.slice(0,3).map(k=>k.id);if(out.length<3)out.push('restock');return out;}
const enemies={drifter:{name:'Errante',color:'#ff85bd',hp:1,sprite:['0011100','0111110','1121211','1111111','0101010']},hunter:{name:'Acechador',color:'#ff985a',hp:2,sprite:['1000001','0111110','1121211','0111110','0010100']},turret:{name:'Centinela',color:'#b9a1ff',hp:2,sprite:['0011100','0112110','1111111','0011100','0011100']},splitter:{name:'Fragmento',color:'#70d9ff',hp:2,sprite:['0010100','0110110','1210121','0110110','0010100']},mine:{name:'Mina',color:'#f5a75c',hp:1,sprite:['0010100','0111110','1121211','0111110','0010100']}};
function hash(n){n>>>=0;n=Math.imul(n^(n>>>16),0x21f0aaad);n=Math.imul(n^(n>>>15),0x735a2d97);return (n^(n>>>15))>>>0;}
const stage=n=>Math.max(1,Math.min(Number.MAX_SAFE_INTEGER-10,Math.floor(Number(n)||1))),world=n=>Math.floor((stage(n)-1)/5)+1,entry=w=>stage((stage(w)-1)*5+1);
const worldNames=['VÉRTICE','PRISMA','PULSAR','UMBRAL','MAREA','ESPEJO','VÓRTICE','ESTELA','ALBOR','HORIZONTE','SANTUARIO','TRÁNSITO','NEXO','ECO','ÓRBITA','NEBULOSA'];
const worldTones=['CARMESÍ','LUNAR','DORADO','SILENTE','IRIDISCENTE','GLACIAL','ELÉCTRICO','VIOLETA','NOCTURNO','CELESTE','ESMERALDA','AMBARINO'];
function zone(n){const w=world(n),z=zones[(w-1)%zones.length],h=hash(hash(w)^hash(Math.floor(w/4294967296))^311),hue=h%360;return {n:w<=8?z[0]:worldNames[h%worldNames.length]+' '+worldTones[(h>>>8)%worldTones.length]+' · '+w,c:w<=8?z[1]:`hsl(${hue},32%,13%)`,a:w<=8?z[2]:`hsl(${hue},78%,72%)`,world:w,style:w<=8?(w-1)%5:(h>>>16)%8,seed:h};}
function target(n){return 5+Math.min(4,Math.floor(Math.log2(stage(n))/2))+(stage(n)%5===4?1:0);}
function interval(n){return Math.max(10,17-1.5*Math.log2(stage(n)));}
function plan(n,seed,i){const h=hash(hash(seed)^hash(n)^hash(i+101)),r=(h>>>0)/4294967296,keys=Object.keys(enemies),pool=keys.slice(0,Math.min(5,1+Math.floor((n+1)/2))),kind=pool[h%pool.length];return {kind,lane:1+(h>>>8)%8,style:(h>>>16)%5,pattern:['formation','gate','cross','rain','duel'][(h>>>20)%5],roll:r};}
function read(storage,legacy=1){let s={};try{s=JSON.parse(storage.getItem(KEY)||'{}')||{};}catch{}const max=Math.max(stage(legacy),stage(s.max));const cp=s.checkpoint&&typeof s.checkpoint==='object'?s.checkpoint:{};const at=Math.min(max,stage(cp.stage||entry(world(max))));return {max,checkpoint:{stage:at,seed:Number.isFinite(cp.seed)?cp.seed>>>0:hash(at+91),perks:cleanPerks(cp.perks)},items:loadout(s.items,max),auto:!!s.auto,weapon:weapons.some(w=>w.id===s.weapon&&w.level<=max)?s.weapon:'bolt'};}
function save(storage,p){try{storage.setItem(KEY,JSON.stringify(p));return true;}catch{return false;}}
function checkpoint(p,n,seed,perks){n=stage(n);if(n<p.max)return false;p.max=n;p.checkpoint={stage:n,seed:seed>>>0,perks:cleanPerks(perks)};return true;}
const api={KEY,zones,weapons,items,perks,cleanPerks,loadout,rewards,enemies,world,entry,zone,target,interval,plan,read,save,checkpoint};if(typeof module!=='undefined'&&module.exports)module.exports=api;else root.HeartmintJourney=api;
})(typeof window!=='undefined'?window:globalThis);
