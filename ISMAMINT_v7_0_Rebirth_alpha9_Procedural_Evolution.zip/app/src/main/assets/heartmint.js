(()=>{'use strict';
// Beat-level score: all notes generated locally. A dedicated bus is disconnected on pause/exit.
const active=()=>!document.hidden&&document.getElementById('p4').classList.contains('on')&&GAME.info().st==='play';
let bus=null,clock=0,beat=0,seed=1,energy=0,tempo=120,lastMode='',lastScore=null,phrase=[],running=false;
const motifs=[[0,2,4,7,4,2,5,3],[0,4,2,5,7,5,2,1],[0,1,4,3,6,4,1,2],[0,3,5,2,4,6,5,2]];
const scales=[[0,2,3,5,7,8,10],[0,2,4,5,7,9,11],[0,1,3,5,7,8,10],[0,2,3,5,7,9,10]];
const roots=[45,48,43,50];
function random(){seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;}
function reset(){seed=(Date.now()^Math.floor(Math.random()*0xffffffff))>>>0;beat=0;phrase=[];lastMode='';lastScore=null;energy=0;tempo=120;clock=0;}
function create(){if(bus)return;bus=ctx.createGain();bus.gain.value=.8;bus.connect(master);}
function stop(){if(bus){try{bus.disconnect()}catch{}bus=null;}running=false;clock=0;}
function tone(m,t,len,vol,type='square'){
 const o=ctx.createOscillator(),q=ctx.createGain();o.type=type;o.frequency.value=440*Math.pow(2,(m-69)/12);q.gain.setValueAtTime(.0001,t);q.gain.linearRampToValueAtTime(vol,t+.006);q.gain.exponentialRampToValueAtTime(.0001,t+Math.max(.025,len));o.connect(q);q.connect(bus);o.start(t);o.stop(t+Math.max(.025,len)+.01);o.onended=()=>{o.disconnect();q.disconnect()};
}
function drum(t,strong){const o=ctx.createOscillator(),q=ctx.createGain();o.type='triangle';o.frequency.setValueAtTime(strong?145:280,t);o.frequency.exponentialRampToValueAtTime(strong?43:90,t+.075);q.gain.setValueAtTime(strong?.11:.045,t);q.gain.exponentialRampToValueAtTime(.0001,t+.09);o.connect(q);q.connect(bus);o.start(t);o.stop(t+.10);o.onended=()=>{o.disconnect();q.disconnect()};}
function describe(i){if(i.upgrade)return 'VICTORIA';if(i.boss&&i.intro>0)return 'JEFE · ENTRADA';if(i.boss&&i.weak>0)return 'JEFE · VULNERABLE';if(i.boss)return 'JEFE · FASE '+i.phase;if(i.lv<=1)return 'ÚLTIMA VIDA';if(i.danger)return 'PELIGRO';if(i.rain)return 'LLUVIA DORADA';if(i.cb>=16)return 'COMBO';return 'EXPLORACIÓN';}
function mode(i){return i.upgrade?'win':i.boss?(i.intro>0?'intro':i.weak>0?'weak':'boss'+i.bossNumber+'-'+i.phase):i.lv<=1?'low':i.danger?'danger':i.rain?'rain':i.cb>=16?'combo':'normal';}
function schedule(t,i){
 const m=mode(i),boss=i.boss,bp=boss?i.bossScore:null,z=Math.floor((i.stg-1)/5)%4;
 if((bp?.key??null)!==lastScore){lastScore=bp?.key??null;beat=0;phrase=[];lastMode='';if(bp)seed=bp.key||1;}
 const target=m==='win'?100:bp?bp.tempo+(i.phase-1)*8+(i.danger?4:0)-(i.weak>0?10:0)-(i.lv<=1?5:0):m==='low'?108:116+Math.min(30,i.stg*2)+Math.min(12,i.cb/3);
 tempo+=(Math.min(178,target)-tempo)*.28;energy+=(Math.min(1,(i.cb/25)+(boss?.5:0)+(i.danger?.2:0))-energy)*.3;
 const d=60/tempo, pos=beat%4, bar=Math.floor(beat/4), sc=bp?bp.scale:scales[z], progression=bp?bp.chords:[0,5,3,7],root=(bp?bp.root:roots[z])+progression[Math.floor(bar/2)%progression.length];
 const note=(degree,oct=0)=>root+sc[((degree%7)+7)%7]+12*(Math.floor(degree/7)+oct);
 if(pos===0||phrase.length===0){const motif=bp?.medley?bp.medley[Math.floor(bar/2)%bp.medley.length].motif:bp?bp.motif:motifs[z];phrase=Array.from({length:16},(_,k)=>motif[(k+bar)%motif.length]+(random()<.12+(i.phase||0)*.035?(random()<.5?2:-2):0));}
 if(m!==lastMode){if(m==='intro'||m.startsWith('boss')){tone(root+12,t,.13,.07,'sawtooth');tone(root+19,t+.14,.16,.06,'square');}else if(m==='weak'||m==='win'){tone(root+24,t,.12,.07,'triangle');tone(root+31,t+.12,.17,.06,'square');}lastMode=m;}
 if(m==='win'){tone(note(phrase[pos],2),t,d*.8,.035,'triangle');tone(root-12,t,d*.9,.035,'triangle');}
 else{
  tone(root-12+(pos===3?7:0),t,d*.72,.065,bp?bp.bass:'triangle');
  if(m==='low'){tone(root+12,t,d*.24,.035,'sine');if(pos%2===0)tone(root+12,t+d*.34,d*.18,.025,'sine');}
  else{
   const rhythm=bp?bp.rhythm:[0,.5];for(let k=0;k<rhythm.length;k++){const at=rhythm[k],duration=(rhythm[k+1]??1)-at;tone(note(phrase[pos*4+k],2),t+at*d,d*Math.max(.1,duration*.76),.025+energy*.012,bp?bp.lead:'square');}
   if(energy>.38||m==='rain')for(let k=0;k<4;k++)tone(note([0,2,4,7][(k+pos)%4],1),t+k*d/4,d*.18,.018,'triangle');
  }
  if(bp?([0,2].includes(pos)||(bp.drums===1&&pos===3)||(bp.drums===2&&i.phase===3)||(bp.drums===3&&pos===1)):pos%2===0)drum(t,true);if(pos%2===1||bp?.drums===3)drum(t,false);if(energy>.65)drum(t+d*(bp?.drums===2?.75:.5),false);
  if(m==='danger'||m==='intro')tone(root+6,t+d*.5,d*.23,.022,'sawtooth');
  if(m==='weak')tone(root+24,t+d*.5,d*.3,.035,'triangle');
 }
 beat++;return d;
}
function tick(){const i=GAME.info(),can=active()&&(!i.paused||i.upgrade)&&ctx?.state==='running'&&window.IsmaMusic?.state().enabled!==false;if(!can){if(running)stop();return;}create();if(!running){clock=ctx.currentTime+.035;running=true;}if(clock<ctx.currentTime-.1)clock=ctx.currentTime+.025;let n=0;while(clock<ctx.currentTime+.13&&n++<4)clock+=schedule(clock,i);}
setInterval(tick,30);document.addEventListener('visibilitychange',()=>{if(document.hidden)stop()});window.HeartmintAudio={active,reset:()=>{stop();reset()},describe};reset();
const box=document.querySelector('#p4 .box'),canvas=document.getElementById('gc'),pause=document.getElementById('gp'),skin=document.getElementById('gk');
const el=(tag,cls,text)=>{const e=document.createElement(tag);e.className=cls;if(text)e.textContent=text;return e};const button=(label,fn)=>{const b=el('button','btn hm-btn',label);b.type='button';b.onclick=fn;return b};
const stage=el('div','hm-stage');canvas.before(stage);stage.append(canvas);const banner=el('div','hm-status');stage.before(banner);const zone=el('span','hm-zone'),music=el('span','hm-music');banner.append(zone,music);
const controls=el('div','hm-controls'),pulse=button('PULSO',()=>GAME.ability('pulse')),dash=button('IMPULSO',()=>GAME.ability('dash'));const meter=el('span','hm-meter'),fill=el('i','');meter.append(fill);pulse.append(meter);controls.append(pulse,dash);stage.after(controls);const row=el('div','hm-secondary');controls.after(row);row.append(pause,skin);skin.style.marginLeft='0';
const overlay=el('div','hm-upgrade');overlay.hidden=true;overlay.setAttribute('role','group');overlay.setAttribute('aria-label','Elegir recompensa');stage.append(overlay);overlay.append(el('strong','','JEFE DERROTADO'),el('small','','Elige una mejora para esta partida'));for(const [id,name,desc] of [['wide','AMPLITUD','Más alcance de recogida'],['charge','ENERGÍA','Carga el pulso más rápido'],['guard','PROTECCIÓN','Vida, escudo e invulnerabilidad extra']]){const b=button(name,()=>{if(GAME.choose(id))sync()});b.append(el('small','',desc));overlay.append(b)}
let cache='';function sync(){const i=GAME.info(),data=[i.st,i.stg,i.paused,i.charge|0,Math.ceil(i.dashCd/60),i.zone,i.upgrade?.length,describe(i),i.bossAttack,i.bossNumber,i.score].join('|');document.body.classList.toggle('hm-playing',active());if(data===cache)return;cache=data;zone.textContent=i.boss?'JEFE '+i.bossNumber+' · '+i.bossName:'NIVEL '+i.stg+' · '+i.zone;music.textContent='♪ '+(i.st==='play'?describe(i):'HEARTMINT');music.title=i.bossAttack||'';pulse.firstChild.nodeValue='PULSO '+Math.floor(i.charge)+'%';fill.style.width=i.charge+'%';pulse.disabled=i.st!=='play'||i.paused||i.charge<100;dash.textContent=i.dashCd>0?'IMPULSO '+Math.ceil(i.dashCd/60)+'s':'IMPULSO';dash.disabled=i.st!=='play'||i.paused||i.dashCd>0;pause.disabled=i.st!=='play'||!!i.upgrade;overlay.hidden=!i.upgrade;const rec=box.querySelector('.r2-game-record');if(rec)rec.textContent='RÉCORD · '+Number(best).toLocaleString('es-CO');}
window.HeartmintUI={sync};new MutationObserver(sync).observe(document.getElementById('p4'),{attributes:true,attributeFilter:['class']});sync();
})();
